﻿# Cenarios de Teste — Aurora Bank Credit Orchestration

Tres cenarios usando os CPFs fixos dos mocks. Todos podem ser executados no chat do Watson Orchestrate.

---

## Cenario 1 — Correntista com Baixo Comprometimento (APROVADO)

**CPF:** `111.444.777-35`
**Perfil:** Joao Silva — correntista Aurora Bank desde 2018

### Dados do Cenario

| Item | Valor | Fonte |
|------|-------|-------|
| Renda liquida | R$ 5.000,00 | Aurora Bank (comprovada) |
| Score | 810 — BOM | Aurora Bank (interno) |
| Multiplo de risco | 2,0x | Tabela de risco |
| Compromisso BACEN (nao-cons.) | R$ 500,00/mes | Banco XYZ — Emprestimo Pessoal |
| Compromisso BACEN (consig.) | R$ 300,00/mes | Financeira ABC — EXCLUIDO |
| Contrato Aurora pos-BACEN (nao-cons.) | R$ 400,00/mes | CTR-001 — Cartao (contratado 2024-08-10) |
| Contrato Aurora anterior (nao-cons.) | — | CTR-002 — ja no BACEN, nao soma |

### Calculo Esperado

```
total_nao_consignado  = 500 + 400 = R$ 900,00
percentual            = 900 / 5000 = 18,0%
margem_disponivel     = (5000 * 0,40) - 900 = R$ 1.100,00

Limite cartao (fator 15%): 1100 / 0.15 = R$ 7.333,33
Teto risco (BOM, 2.0x):    2.0 * 5000  = R$ 10.000,00
Limite final (floor):       R$ 7.300,00
```

### Resultado Esperado
- **Decisao:** APROVADO
- **Produto:** Cartao de Credito Aurora Visa
- **Limite:** R$ 7.300,00
- **Log gravado:** `audit_YYYYMMDD_11144477735.json`

### Comando para testar no chat
```
Quero analisar credito para o CPF 111.444.777-35
```

---

## Cenario 2 — Correntista com Alto Comprometimento (RECUSADO)

**CPF:** `222.555.888-46`
**Perfil:** Maria Oliveira — correntista Aurora Bank desde 2015

### Dados do Cenario

| Item | Valor | Fonte |
|------|-------|-------|
| Renda liquida | R$ 4.000,00 | Aurora Bank (comprovada) |
| Score | 540 — REGULAR | Aurora Bank (interno) |
| Multiplo de risco | 1,0x | Tabela de risco |
| Compromisso BACEN — Financiamento Imob. | R$ 900,00/mes | Banco Nacional |
| Compromisso BACEN — Cartao | R$ 200,00/mes | Credora Sul |
| Contrato Aurora pos-BACEN | R$ 800,00/mes | CTR-003 — Emprestimo (2024-09-05) |
| Contrato Aurora anterior | R$ 350,00/mes | CTR-004 — ja no BACEN, nao soma |

### Calculo Esperado

```
total_nao_consignado = 900 + 200 + 800 = R$ 1.900,00
percentual           = 1900 / 4000 = 47,5%
margem_disponivel    = (4000 * 0,40) - 1900 = -R$ 300,00 (negativa)
```

### Resultado Esperado
- **Decisao:** RECUSADO
- **Motivo:** Comprometimento de 47,5% supera o limite de 40%
- **Log gravado:** `audit_YYYYMMDD_22255588846.json`
- **Justificativa ao cliente:** deve explicar o percentual, o limite e sugerir proximos passos

### Comando para testar no chat
```
Analise de credito para CPF 222.555.888-46
```

---

## Cenario 3 — Nao-Correntista com Renda Presumida SERASA (APROVADO com ressalva)

**CPF:** `333.666.999-57`
**Perfil:** Carlos Mendes — NAO e cliente Aurora Bank

### Dados do Cenario

| Item | Valor | Fonte |
|------|-------|-------|
| Renda liquida | R$ 3.500,00 | SERASA (presumida — ESTIMATIVA) |
| Score | 720 — BOM | SERASA |
| Multiplo de risco | 2,0x | Tabela de risco |
| Compromisso BACEN (nao-cons.) | R$ 250,00/mes | Fintech Verde — Emprestimo Pessoal |
| Sem contratos Aurora Bank | — | Nao e correntista |

### Fluxo Especial Esperado

1. Agente nao encontra CPF no Aurora Bank
2. Agente solicita nome e renda declarada no chat
3. Agente consulta SERASA e retorna renda presumida + score
4. Agente registra renda em `dados_incertos[]` e exibe aviso ao analista

### Calculo Esperado

```
renda_base (SERASA):     R$ 3.500,00 (estimada — nao comprovada)
total_nao_consig. (BACEN): R$ 250,00
percentual:               250 / 3500 = 7,1%
margem_disponivel:        (3500 * 0,40) - 250 = R$ 1.150,00

Limite cartao (fator 15%): 1150 / 0.15 = R$ 7.666,67
Teto risco (BOM, 2.0x):    2.0 * 3500  = R$ 7.000,00
Limite final (floor):       R$ 7.000,00
```

### Resultado Esperado
- **Decisao:** APROVADO
- **Produto:** Cartao de Credito Aurora Visa
- **Limite:** R$ 7.000,00
- **Ressalva obrigatoria:** agente deve informar que a renda e presumida (SERASA) e constar em `dados_incertos[]`
- **Log gravado:** `audit_YYYYMMDD_33366699957.json`

### Comando para testar no chat
```
Preciso de analise de credito para CPF 333.666.999-57
```
Quando solicitado: nome `Carlos Mendes`, renda `R$ 3.500`

---

## Tabela Resumo dos Cenarios

| Cenario | CPF | Perfil | Comprometimento | Decisao | Limite |
|---------|-----|--------|----------------|---------|--------|
| 1 | 111.444.777-35 | Correntista, BOM | 18% | APROVADO | R$ 7.300 |
| 2 | 222.555.888-46 | Correntista, REGULAR | 47,5% | RECUSADO | — |
| 3 | 333.666.999-57 | Nao-correntista, BOM (SERASA) | 7,1% | APROVADO* | R$ 7.000 |

*com ressalva de renda presumida
