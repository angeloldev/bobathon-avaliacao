﻿# Regras de Negocio — Analise de Credito Aurora Bank

## 1. Regra de Comprometimento de Renda

### Definicao
O comprometimento de renda e o percentual da renda liquida mensal ja comprometido com dividas existentes.

### Limite maximo
```
comprometimento_maximo = 40% da renda liquida mensal
```

### Formula
```
total_nao_consignado = soma de todas as parcelas mensais nao-consignadas
percentual           = total_nao_consignado / renda_liquida
margem_disponivel    = (renda_liquida * 0.40) - total_nao_consignado

APROVADO se: percentual <= 0.40
RECUSADO se: percentual >  0.40
```

### Exemplo numerico
```
Renda liquida:          R$ 5.000,00
Parcela BACEN (nao-cons): R$ 500,00
Parcela Aurora (nao-cons): R$ 400,00
Parcela consignada:    R$ 600,00 (EXCLUIDA)

total_nao_consignado = 500 + 400 = R$ 900,00
percentual = 900 / 5000 = 18,0%
margem = (5000 * 0,40) - 900 = R$ 1.100,00

Resultado: 18% <= 40% -> APROVADO
```

---

## 2. Regra do Consignado

### Definicao
Credito consignado e aquele cujas parcelas sao descontadas diretamente no contracheque antes do recebimento do salario. Por isso, **nao comprometem a margem de renda disponivel do cliente**.

### Regra
```
Se consignado = true -> NAO incluir no calculo de comprometimento
Se consignado = false -> INCLUIR no calculo
```

### Justificativa regulatoria
O consignado e descontado na fonte pelo empregador/INSS antes de o dinheiro chegar ao cliente. Incluir esses valores no calculo de comprometimento resultaria em dupla penalizacao — o cliente ja nao recebe esse dinheiro em sua renda liquida.

> Os valores consignados DEVEM aparecer no log de auditoria para transparencia, mas com flag `incluido_no_calculo: false`.

---

## 3. Regra de Sobreposicao BACEN / Aurora Bank

### Problema
O BACEN/SISBACEN tem atraso de aproximadamente 60 dias. Contratos recentes do Aurora Bank nao aparecem nos dados do BACEN, mas contratos mais antigos aparecem em ambos.

### Regra para evitar dupla contagem
```
data_corte = data_referencia retornada pelo BACEN (tipicamente ~60 dias atras)

Do BACEN:       incluir TODOS os compromissos nao-consignados
Do Aurora Bank: incluir APENAS contratos com data_contratacao > data_corte
```

### Exemplo de timeline
```
Hoje: 2025-07-15
data_referencia_BACEN: 2025-05-15 (60 dias de atraso)

CTR-001 (Aurora, contratado 2024-08-10): ANTERIOR a 2025-05-15
  -> Ja esta nos dados BACEN -> NAO incluir do Aurora Bank

CTR-002 (Aurora, contratado 2025-06-20): POSTERIOR a 2025-05-15
  -> NAO esta nos dados BACEN -> INCLUIR do Aurora Bank
```

---

## 4. Fontes de Renda

| Tipo de cliente | Fonte de renda | Classificacao |
|----------------|----------------|---------------|
| Correntista Aurora Bank | Renda cadastrada no banco | `comprovada_aurora_bank` |
| Nao-correntista com dados SERASA | Estimativa SERASA | `presumida_serasa` |
| Nao-correntista sem SERASA | Declaracao do solicitante | registrar em `dados_incertos[]` |

> Renda presumida SERASA e renda declarada devem sempre ser registradas em `dados_incertos[]` no log de auditoria.

---

## 5. Calculo do Limite de Credito

### Principio
O limite e calculado com base na **margem disponivel** do cliente e no seu **perfil de risco**.

### 5a. Limite pela margem (padroes de mercado brasileiro)

```
Para cartao de credito:
  fator_parcela_minima = 0.15 (15% do limite e a parcela minima mensal)
  limite_pela_margem = margem_disponivel / 0.15

Para credito pessoal:
  fator_parcela_minima = 0.10
  limite_pela_margem = margem_disponivel / 0.10
```

**Por que 15% para cartao?**
O mercado brasileiro (Bradesco, Itau, Santander) exige pagamento minimo de 15% da fatura do cartao. Isso significa que, para cada R$ 100 de limite, o cliente compromete R$ 15/mes no pior caso.

### 5b. Teto por perfil de risco (score)

| Classificacao | Score | Multiplo maximo da renda |
|--------------|-------|--------------------------|
| EXCELENTE | >= 850 | 3,0 x renda liquida |
| BOM | 700 - 849 | 2,0 x renda liquida |
| REGULAR | 500 - 699 | 1,0 x renda liquida |
| RUIM | < 500 | 0,5 x renda liquida |
| Sem score | — | 2,0 x renda liquida |

```
teto_risco = multiplo * renda_base
```

### 5c. Formula completa

```
limite_calculado = min(
  limite_pela_margem,
  teto_risco,
  limite_maximo_absoluto_do_produto
)

limite_final = floor(limite_calculado / 100) * 100  # arredondar para baixo ate centena
```

### 5d. Limite minimo

Se `limite_final < R$ 500`: recusar — abaixo do minimo economicamente viavel.

### Exemplo completo (cartao de credito)

```
Renda:             R$ 5.000
Margem disponivel: R$ 1.100
Score:             810 (BOM, multiplo 2.0x)

Passo 1 — Pelo margem:    1100 / 0.15 = R$ 7.333,33
Passo 2 — Teto risco:     2.0 * 5000  = R$ 10.000,00
Passo 3 — Teto produto:   R$ 50.000,00
Passo 4 — Menor teto:     min(7333, 10000, 50000) = R$ 7.333,33
Passo 5 — Arredondar:     floor(7333.33 / 100) * 100 = R$ 7.300,00

Limite aprovado: R$ 7.300
```

---

## 6. Auditoria Obrigatoria

Toda analise (aprovada OU recusada) deve gerar um log JSON com:
- Todos os compromissos usados e excluidos (com justificativa)
- Formula de calculo passo a passo
- Fonte da renda utilizada
- Dados incertos declarados explicitamente
- Justificativa em linguagem acessivel ao cliente
- Justificativa tecnica para o regulador
