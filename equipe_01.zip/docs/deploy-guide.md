﻿# Guia de Deploy — Aurora Bank Credit Orchestration no Watson Orchestrate

## Pre-requisitos

- Instancia ativa do **IBM Watson Orchestrate**
- Acesso ao IBM Cloud com permissoes de Agent Builder
- Modelo `meta-llama/llama-3-3-70b-instruct` disponivel na instancia
- Repositorio clonado localmente

---

## Passo 1 — Importar as Tools (OpenAPI)

As tools devem ser importadas ANTES de criar os agentes.

1. No Watson Orchestrate, acesse **Tools** no menu lateral
2. Clique em **Add tool** > **From OpenAPI file**
3. Importe cada arquivo na ordem abaixo:

| Ordem | Arquivo | Tool criada |
|-------|---------|-------------|
| 1 | `src/tools/aurora-bank-lookup.yaml` | `aurora-bank-lookup` |
| 2 | `src/tools/bacen-sisbacen-lookup.yaml` | `bacen-sisbacen-lookup` |
| 3 | `src/tools/serasa-renda-lookup.yaml` | `serasa-renda-lookup` |
| 4 | `src/tools/aurora-bank-products.yaml` | `aurora-bank-products` |
| 5 | `src/tools/audit-log-writer.yaml` | `audit-log-writer` |

> Capturar print da tela de listagem das 5 tools criadas → salvar em `evidencias/01-tools-listagem.png`

---

## Passo 2 — Criar os Agentes Sub (em ordem)

Os tres agentes sub devem ser criados ANTES do orquestrador.

### 2a. Agente Cliente

1. Acesse **Agents** > **Create agent**
2. Preencha:
   - **Name**: `client-agent`
   - **Display name**: `Agente Cliente — Aurora Bank`
   - **Model**: `meta-llama/llama-3-3-70b-instruct`
   - **Instructions**: cole o conteudo de `src/prompts/client-agent.md`
3. Em **Tools**, adicione:
   - `aurora-bank-lookup`
   - `bacen-sisbacen-lookup`
   - `serasa-renda-lookup`
4. Clique em **Save**

### 2b. Agente Carteira

1. Crie novo agente:
   - **Name**: `wallet-agent`
   - **Display name**: `Agente Carteira — Aurora Bank`
   - **Model**: `meta-llama/llama-3-3-70b-instruct`
   - **Instructions**: cole o conteudo de `src/prompts/wallet-agent.md`
2. Em **Tools**, adicione:
   - `aurora-bank-products`
3. Salve

### 2c. Agente Decisao

1. Crie novo agente:
   - **Name**: `decision-agent`
   - **Display name**: `Agente Decisao — Aurora Bank`
   - **Model**: `meta-llama/llama-3-3-70b-instruct`
   - **Instructions**: cole o conteudo de `src/prompts/decision-agent.md`
2. Em **Tools**, adicione:
   - `audit-log-writer`
3. Salve

> Capturar print da tela com os 3 agentes criados → `evidencias/02-agentes-sub.png`

---

## Passo 3 — Criar o Agente Orquestrador

1. Crie novo agente:
   - **Name**: `orchestrator-agent`
   - **Display name**: `Analista de Credito Virtual — Aurora Bank`
   - **Model**: `meta-llama/llama-3-3-70b-instruct`
   - **Instructions**: cole o conteudo de `src/prompts/orchestrator-agent.md`
2. Em **Collaborators**, adicione os 3 agentes:
   - `client-agent`
   - `wallet-agent`
   - `decision-agent`
3. Salve

> Capturar print mostrando os 3 colaboradores configurados → `evidencias/03-orchestrator-colaboradores.png`

---

## Passo 4 — Testar no Chat do Orchestrate

### Cenario 1 — Cliente correntista aprovado

1. Abra o chat do `orchestrator-agent`
2. Digite: `Quero analisar credito para o CPF 111.444.777-35`
3. Aguarde a analise completa
4. Verifique: decisao APROVADO, limite calculado, justificativa, confirmacao do log

> Capturar print do chat completo → `evidencias/04-chat-cenario1-aprovado.png`

### Cenario 2 — Cliente correntista recusado

1. Digite: `Analise de credito CPF 222.555.888-46`
2. Verifique: decisao RECUSADO, motivo claro, confirmacao do log

> Capturar print → `evidencias/05-chat-cenario2-recusado.png`

### Cenario 3 — Novo cliente (nao-correntista)

1. Digite: `Preciso de analise para CPF 333.666.999-57`
2. O agente deve pedir nome e renda declarada
3. Fornecer: nome `Carlos Mendes`, renda `R$ 3.500`
4. Verificar: aviso de renda presumida SERASA, decisao com ressalva

> Capturar print → `evidencias/06-chat-cenario3-novo-cliente.png`

---

## Passo 5 — Verificar Log de Auditoria

Apos cada analise, verificar o arquivo gerado em `src/audit-logs/`:
- Confirmar presenca dos campos: `dados_incertos[]`, `justificativa_cliente`, `justificativa_tecnica`, `calculo_limite`
- Para cenario aprovado: verificar detalhamento do calculo de limite

> Capturar print ou colar conteudo do JSON → `evidencias/07-audit-log-exemplo.png`

---

## Troubleshooting

| Problema | Solucao |
|----------|---------|
| Tool nao aparece no agente | Verificar se o YAML foi importado sem erros de sintaxe |
| Agente nao chama colaborador | Confirmar que o colaborador foi adicionado no orchestrator-agent |
| Limite calculado errado | Verificar se o score esta sendo passado do client-agent para o wallet-agent |
| Log nao e gravado | Verificar se o decision-agent tem a tool `audit-log-writer` configurada |
