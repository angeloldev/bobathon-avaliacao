﻿# Diagrama de Fluxo — Analise de Credito Aurora Bank

## Fluxo Principal

```
Analista digita CPF no chat do Watson Orchestrate
        |
        v
[orchestrator-agent] Valida formato do CPF (11 digitos)
        |
        v
[client-agent] aurora-bank-lookup(cpf)
        |
        +--[encontrado=true]-----> usa renda_liquida + score_interno do banco
        |                                     |
        +--[encontrado=false]---> pede nome e renda ao analista no chat
                                              |
                                    [client-agent] serasa-renda-lookup(cpf)
                                              |
                                    usa renda_presumida + score SERASA
                                    registra em dados_incertos[]
        |
        v
[client-agent] bacen-sisbacen-lookup(cpf)
        |
        v
[client-agent] CALCULA COMPROMETIMENTO
  - soma parcelas BACEN nao-consignadas
  - soma parcelas Aurora pos-referencia nao-consignadas (sem sobreposicao)
  - total_nao_consignado / renda_base = percentual
  - margem = (renda * 0.40) - total_nao_consignado
        |
        v
[wallet-agent] aurora-bank-products()
        |
        v
[wallet-agent] CALCULA LIMITE POR PRODUTO
  Para cada produto:
    1. limite_pela_margem = margem / fator_parcela_minima
       - cartao: fator = 0.15 (parcela minima = 15% do limite)
       - pessoal: fator = 0.10
    2. teto_risco = multiplo_risco * renda_base
       - EXCELENTE (>=850): 3.0x | BOM (700-849): 2.0x
       - REGULAR (500-699): 1.0x | RUIM (<500): 0.5x
    3. limite_final = min(pela_margem, teto_risco, teto_produto)
    4. arredonda para baixo ate centena (floor)
    5. se < R$ 500: produto nao elegivel
        |
        v
[decision-agent] APLICA REGRA 40%
        |
        +--[percentual <= 40%]---> APROVADO
        |   e produtos_elegiveis > 0
        |                    |
        |            seleciona produto de maior limite
        |            grava calculo completo
        |
        +--[percentual > 40%]----> RECUSADO
        |   ou margem <= 0         grava motivo_recusa
        |   ou sem produtos
        |
        v
[decision-agent] audit-log-writer(payload_completo)
  - Grava: audit_{YYYYMMDD}_{cpf}.json
  - Campos obrigatorios: dados_incertos[], justificativa_cliente, justificativa_tecnica
  - Executado em TODA analise (aprovada E recusada)
        |
        v
[orchestrator-agent] Exibe resultado formatado no chat:
  - Decisao (APROVADO / RECUSADO)
  - Se aprovado: produto, limite, como foi calculado passo a passo
  - Se recusado: motivo claro em linguagem acessivel
  - Confirmacao do arquivo de auditoria gravado
        |
        v
Analista recebe resposta no chat
```

## Regra de Sobreposicao BACEN / Aurora Bank

```
Linha do tempo:
<--- BACEN cobre ate aqui ---> | <--- Aurora Bank (pos-referencia) --->
                          data_referencia
                          (aprox. 60 dias atras)

Compromissos Aurora Bank contratados ANTES de data_referencia:
  -> Ja estao incluidos nos dados BACEN -> NAO somar novamente

Compromissos Aurora Bank contratados APOS data_referencia:
  -> NAO estao no BACEN -> Somar no calculo de comprometimento
```

## Regra do Consignado

```
Parcela consignada (consignado=true):
  -> Descontada diretamente no contracheque
  -> NAO compromete a margem disponivel do cliente
  -> Aparece no log de auditoria para transparencia
  -> NUNCA incluir no calculo de comprometimento

Parcela nao-consignada (consignado=false):
  -> Compromete a renda disponivel do cliente
  -> SEMPRE incluir no calculo (respeitando regra de sobreposicao)
```

## Formula Completa de Calculo do Limite (Cartao de Credito)

```
Entrada:
  renda_base          = R$ 5.000
  total_nao_consig.   = R$ 900
  score               = 810 (BOM, multiplo 2.0x)

Passo 1 — Margem disponivel:
  margem = (5000 * 0.40) - 900 = 2000 - 900 = R$ 1.100

Passo 2 — Limite pela margem:
  limite_pela_margem = 1100 / 0.15 = R$ 7.333,33

Passo 3 — Teto por perfil de risco:
  teto_risco = 2.0 * 5000 = R$ 10.000

Passo 4 — Aplicar menor teto:
  limite = min(7333, 10000, 50000) = R$ 7.333,33

Passo 5 — Arredondar para baixo ate centena:
  limite_final = floor(7333.33 / 100) * 100 = R$ 7.300

Resultado: Limite aprovado = R$ 7.300
```
