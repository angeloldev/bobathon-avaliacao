# Aurora Bank — Orquestrador de Análise de Crédito

> Sistema multi-agente rodando no **Watson Orchestrate** que decide crédito com explicação clara, justificativa auditável e rastreabilidade regulatória.

---

## O Problema

O sistema legado do Aurora Bank tem 22 anos e toma 4 milhões de decisões de crédito por mês sem explicar o motivo. Clientes são recusados sem saber por quê. A carta de decisão diz literalmente: _"não pode ser explicada nem contestada"_. O regulador não recebe justificativas.

## A Solução

Um orquestrador de agentes de IA no Watson Orchestrate que:

1. Recebe o CPF do solicitante no **chat do Orchestrate**
2. Identifica se é cliente Aurora Bank ou novo cliente
3. Coleta dados internos (Aurora Bank) e externos (BACEN/SISBACEN + SERASA)
4. Calcula o comprometimento de renda com as regras do banco
5. Decide: **APROVADO** ou **RECUSADO** — com limite sugerido
6. Gera justificativa em linguagem que o cliente entende
7. Grava log de auditoria estruturado a cada análise realizada

---

## Arquitetura

```
Analista (chat Watson Orchestrate)
        │  "Análise de crédito CPF 111.222.333-44"
        ▼
┌──────────────────────────────────────┐
│        Agente Orquestrador           │
│   Conduz conversa e consolida        │
│   resultado final no chat            │
└────┬─────────────┬────────────┬──────┘
     │             │            │
     ▼             ▼            ▼
┌──────────┐ ┌──────────┐ ┌────────────┐
│  Agente  │ │  Agente  │ │   Agente   │
│  Cliente │ │ Carteira │ │  Decisão   │
└──┬───────┘ └────┬─────┘ └─────┬──────┘
   │              │              │
   ├─ aurora-bank-lookup         │
   ├─ bacen-sisbacen-lookup      │
   └─ serasa-renda-lookup        │
                  │              │
             aurora-bank-products
                                 │
                            audit-log-writer
                            (JSON dinâmico)
```

### Regras de Negócio

| Regra | Detalhe |
|-------|---------|
| Comprometimento máximo | **40% da renda líquida** |
| Consignado | **Excluído** do cálculo (já descontado em contracheque) |
| Sobreposição BACEN/Aurora | Contratos Aurora Bank com `data_contratacao > data_referencia_BACEN` (atraso ~60 dias) |
| Renda correntista | `renda_comprovada` cadastrada no Aurora Bank |
| Renda não-correntista | `renda_presumida` consultada no SERASA |

---

## Estrutura do Repositório

```
aurora-bank-credit/
├── README.md                        ← este arquivo
├── AGENTS.md                        ← contexto do projeto para o Bob
├── .gitignore
├── src/
│   ├── agents/                      ← definições YAML dos agentes (importar no Orchestrate)
│   ├── tools/                       ← schemas OpenAPI 3.0 das tools
│   ├── prompts/                     ← system prompts em pt-BR
│   ├── mocks/                       ← dados JSON simulados (Aurora Bank, BACEN, SERASA)
│   ├── flows/                       ← fluxo de orquestração YAML
│   └── audit-logs/                  ← logs de auditoria dinâmicos + exemplos
├── evidencias/                      ← prints e exports do Watson Orchestrate (prova do evento)
└── docs/
    ├── deploy-guide.md              ← passo a passo de deploy no Orchestrate
    ├── regras-de-negocio.md         ← regras de crédito documentadas formalmente
    ├── cenarios-de-teste.md         ← 3 cenários com CPFs e resultado esperado
    └── flow-diagram.md              ← diagrama do fluxo de orquestração
```

---

## Como Usar (Watson Orchestrate)

### Pré-requisitos

- Instância ativa do **IBM Watson Orchestrate**
- Acesso ao **IBM Cloud** com credenciais válidas
- Modelo `meta-llama/llama-3-3-70b-instruct` disponível na instância

### Deploy em 4 passos

1. **Importe as Tools** — carregue cada arquivo de `src/tools/*.yaml` no Orchestrate como tool via OpenAPI
2. **Crie os Agentes** — use os YAMLs de `src/agents/` para criar cada agente no Orchestrate Agent Builder
3. **Configure os Colaboradores** — no `orchestrator-agent`, adicione `client-agent`, `wallet-agent` e `decision-agent` como colaboradores
4. **Teste no Chat** — abra o chat do Orchestrate e diga: _"Quero analisar crédito para o CPF 111.444.777-35"_

> Consulte [`docs/deploy-guide.md`](docs/deploy-guide.md) para o passo a passo detalhado com screenshots instruídos.

### Exemplo de Interação no Chat

```
Analista:     "Análise de crédito para CPF 111.444.777-35"

Orquestrador: "Identificando cliente... ✓ João Silva — cliente Aurora Bank.
               Consultando BACEN... ✓ Compromissos externos: R$ 800/mês
               Consultando contratos internos pós-BACEN... ✓ R$ 400/mês
               Consultando produtos disponíveis... ✓

               ✅ CRÉDITO APROVADO
               Produto: Crédito Pessoal | Limite sugerido: R$ 15.000

               Justificativa: Sua renda líquida é de R$ 5.000. Seus compromissos
               financeiros atuais (excluindo consignado) somam R$ 1.200, o que
               representa 24% da sua renda — abaixo do limite de 40%.
               Você tem margem de R$ 800/mês disponível para novas parcelas.

               📋 Auditoria gravada: audit_20250715_111444777-35.json"
```

---

## Cenários de Teste (Mocks)

| CPF | Perfil | Resultado Esperado |
|-----|--------|--------------------|
| `111.444.777-35` | Correntista, baixo comprometimento (24%) | ✅ APROVADO |
| `222.555.888-46` | Correntista, alto comprometimento (52%) | ❌ RECUSADO |
| `333.666.999-57` | Não-correntista, renda presumida SERASA | ✅ APROVADO (com ressalva) |

> Consulte [`docs/cenarios-de-teste.md`](docs/cenarios-de-teste.md) para os detalhes completos de cada cenário.

---

## Como o Bob Foi Usado Neste Projeto

Este repositório foi inteiramente planejado e construído com o **IBM Bob** no modo Agent:

- **Plan mode:** levantamento de requisitos, definição da arquitetura, criação do plano em [`aurora-credit-orchestration-plan.md`](../aurora-credit-orchestration-plan.md)
- **Agent mode:** geração de todos os artefatos — prompts, schemas OpenAPI, YAMLs dos agentes, mocks, documentação
- **Skills:** o Bob usou a skill de documentação IBM para embasar as decisões de arquitetura do Watson Orchestrate

---

## Equipe

> ⚠️ Preencha esta seção com o nome da sua equipe e integrantes antes de submeter.

| Nome | Papel |
|------|-------|
| — | — |
| — | — |

---

## Evidências

As evidências de funcionamento no Watson Orchestrate (prints do chat, exports dos agentes) estão na pasta [`evidencias/`](evidencias/).
Consulte [`evidencias/README.md`](evidencias/README.md) para o checklist completo do que deve ser capturado.
