# AGENTS.md — Aurora Bank Credit Orchestration

## Visão Geral do Projeto

Sistema multi-agente no Watson Orchestrate para análise de crédito com decisão explicável e auditável. Resolve o problema de um sistema legado de 22 anos que decide crédito sem justificativa.

**Interface de uso:** Chat do Watson Orchestrate (conversacional, sem frontend adicional).

## Estrutura de Pastas

```
aurora-bank-credit/
├── src/
│   ├── agents/       ← YAMLs dos agentes para importar no Watson Orchestrate
│   ├── tools/        ← Schemas OpenAPI 3.0 das tools (importar antes dos agentes)
│   ├── prompts/      ← System prompts em pt-BR (referenciados pelos agentes)
│   ├── mocks/        ← Dados JSON simulados das 3 fontes de dados
│   ├── flows/        ← Fluxo de orquestração declarativo
│   └── audit-logs/   ← Logs gerados dinamicamente + exemplos (exemplo-*.json)
├── evidencias/       ← Prints/exports do Orchestrate para o evento
└── docs/             ← Documentação operacional
```

## Agentes e Responsabilidades

| Agente | Arquivo | Responsabilidade |
|--------|---------|-----------------|
| `orchestrator-agent` | `src/agents/orchestrator-agent.yaml` | Conduz a conversa no chat, delega aos sub-agentes, consolida a resposta final |
| `client-agent` | `src/agents/client-agent.yaml` | Identifica o cliente (CPF), coleta dados Aurora Bank + BACEN + SERASA, calcula comprometimento |
| `wallet-agent` | `src/agents/wallet-agent.yaml` | Consulta produtos disponíveis e filtra os elegíveis para o perfil do cliente |
| `decision-agent` | `src/agents/decision-agent.yaml` | Aplica a regra dos 40%, produz decisão com justificativa, grava log de auditoria |

## Tools e Fontes de Dados

| Tool | Arquivo | Fonte | Tipo |
|------|---------|-------|------|
| `aurora-bank-lookup` | `src/tools/aurora-bank-lookup.yaml` | DB Aurora Bank | Mock JSON |
| `bacen-sisbacen-lookup` | `src/tools/bacen-sisbacen-lookup.yaml` | BACEN/SISBACEN | Mock JSON |
| `serasa-renda-lookup` | `src/tools/serasa-renda-lookup.yaml` | SERASA | Mock JSON |
| `aurora-bank-products` | `src/tools/aurora-bank-products.yaml` | Catálogo interno | Mock JSON |
| `audit-log-writer` | `src/tools/audit-log-writer.yaml` | — | Escreve arquivo JSON |

## Regras de Negócio Críticas

1. **Comprometimento máximo:** 40% da renda líquida
2. **Consignado excluído:** parcelas consignadas (`consignado: true`) nunca entram no cálculo
3. **Sobreposição BACEN/Aurora:** usar do Aurora Bank apenas contratos com `data_contratacao > data_referencia_BACEN` (BACEN tem atraso de ~60 dias)
4. **Fonte de renda:** `renda_comprovada` para correntistas; `renda_presumida` do SERASA para não-correntistas
5. **Fórmula:** `percentual = total_parcelas_nao_consignadas / renda_liquida` — aprovado se `<= 0.40`

## Princípio Anti-Alucinação (Critério do Evento)

- Agentes **nunca inventam** dados de renda, CPF ou comprometimento
- Se um dado não for encontrado, o agente **declara explicitamente** e pergunta ao usuário
- Todo log de auditoria contém o campo `dados_incertos[]` — presente mesmo se vazio
- O campo `encontrado: bool` na resposta do `aurora-bank-lookup` é a âncora para esse comportamento

## CPFs de Teste (Mocks)

| CPF | Perfil | Resultado |
|-----|--------|-----------|
| `11144477735` | Correntista Aurora Bank, 24% comprometimento | APROVADO |
| `22255588846` | Correntista Aurora Bank, 52% comprometimento | RECUSADO |
| `33366699957` | Não-correntista, renda presumida SERASA | APROVADO (com ressalva) |

## Convenções de Nomenclatura

- Arquivos de agente: `{nome-do-agente}.yaml` em `src/agents/`
- Arquivos de tool: `{nome-da-tool}.yaml` em `src/tools/`
- Prompts: mesmo nome do agente, extensão `.md` em `src/prompts/`
- Logs de auditoria dinâmicos: `audit_{YYYYMMDD}_{cpf_sem_pontos}.json`
- Exemplos de log: prefixo `exemplo-` (mantidos no git)

## Ordem de Importação no Watson Orchestrate

1. Tools (OpenAPI) → 2. Agentes sub (client, wallet, decision) → 3. Agente orquestrador

## Modelo LLM

`meta-llama/llama-3-3-70b-instruct` — todos os agentes
