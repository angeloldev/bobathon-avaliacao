# Evidências — Watson Orchestrate

Esta pasta deve conter os prints e exports que comprovam o funcionamento do sistema no Watson Orchestrate.

## Checklist de Evidências Obrigatórias para o Evento

### 1. Tools Importadas
- [ ] Print da tela de listagem de tools no Orchestrate mostrando as 5 tools criadas:
  - `aurora-bank-lookup`
  - `bacen-sisbacen-lookup`
  - `serasa-renda-lookup`
  - `aurora-bank-products`
  - `audit-log-writer`

### 2. Agentes Criados
- [ ] Print da tela de listagem de agentes mostrando os 4 agentes:
  - `orchestrator-agent`
  - `client-agent`
  - `wallet-agent`
  - `decision-agent`
- [ ] Print da configuração do `orchestrator-agent` mostrando os 3 colaboradores configurados

### 3. Fluxo em Funcionamento (Chat)
- [ ] Print do chat mostrando o **Cenário 1** completo: CPF `111.444.777-35` → APROVADO
  - Deve mostrar a resposta com justificativa e confirmação do log de auditoria
- [ ] Print do chat mostrando o **Cenário 2** completo: CPF `222.555.888-46` → RECUSADO
  - Deve mostrar a resposta com motivo da recusa
- [ ] Print do chat mostrando o **Cenário 3**: CPF `333.666.999-57` → novo cliente, renda SERASA

### 4. Log de Auditoria
- [ ] Print ou cópia do arquivo `audit_*.json` gerado dinamicamente após uma análise
  - O arquivo deve mostrar os campos: `dados_incertos[]`, `justificativa_cliente`, `justificativa_tecnica`

### 5. Export dos Agentes (opcional mas recomendado)
- [ ] Export JSON/YAML de cada agente pelo painel do Orchestrate

## Nomenclatura dos Arquivos

Salve os prints com nomes descritivos, por exemplo:
- `01-tools-listagem.png`
- `02-agentes-listagem.png`
- `03-orchestrator-colaboradores.png`
- `04-chat-cenario1-aprovado.png`
- `05-chat-cenario2-recusado.png`
- `06-chat-cenario3-novo-cliente.png`
- `07-audit-log-exemplo.png`
