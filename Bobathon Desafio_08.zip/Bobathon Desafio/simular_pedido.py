"""
simular_pedido.py
=================
Simulador local de pedido de crédito — Aurora Bank.

O cliente informa apenas:
  1. CPF
  2. Valor desejado (R$)

Todos os demais dados (renda, score, investimentos, portabilidade,
data de nascimento, nome) são consultados internamente na base de clientes
— exatamente como aconteceria em um banco real.

Uso interativo:
    python simular_pedido.py

Uso com argumentos:
    python simular_pedido.py --cpf "116.155.940-00" --valor 20000

A saída é salva em evidencias/decisao_<cpf>_<timestamp>.json
e também exibida no terminal.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from consultar_cliente import consultar_por_cpf
from decisao_credito import analisar_pedido

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EVIDENCIAS_DIR = os.path.join(_BASE_DIR, "evidencias")
os.makedirs(EVIDENCIAS_DIR, exist_ok=True)


def salvar_resultado(saida: dict, cpf: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    cpf_limpo = cpf.replace(".", "").replace("-", "")
    nome_arquivo = f"decisao_{cpf_limpo}_{ts}.json"
    caminho = os.path.join(EVIDENCIAS_DIR, nome_arquivo)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)
    return caminho


def exibir_resultado(resultado, caminho: str) -> None:
    print()
    print("=" * 60)
    status = "APROVADO" if resultado.aprovado else "NEGADO"
    print(f"  DECISAO: {status}")
    if resultado.aprovado:
        print(f"  Limite  : R$ {resultado.limite_aprovado:,.2f}")
        print(f"  Produto : {resultado.produto_sugerido}")
    print("=" * 60)
    print()
    print(resultado.justificativa)
    print()
    print("--- Registro auditavel ---")
    print(json.dumps(resultado.registro_auditavel, ensure_ascii=False, indent=2))
    print()
    print(f"Salvo em: {caminho}")


def coletar_interativo() -> tuple[str, float]:
    print()
    print("=" * 60)
    print("  Aurora Bank — Pedido de Credito")
    print("=" * 60)
    print()
    cpf = input("  CPF: ").strip()
    while True:
        try:
            valor = float(input("  Valor desejado (R$): ").strip().replace(",", "."))
            break
        except ValueError:
            print("  [!] Digite um valor numerico. Ex: 10000")
    return cpf, valor


def main():
    parser = argparse.ArgumentParser(description="Simulador Aurora Bank — informe CPF e valor")
    parser.add_argument("--cpf",   help="CPF do cliente (formato 000.000.000-00)")
    parser.add_argument("--valor", type=float, help="Valor de credito desejado em R$")
    args = parser.parse_args()

    # Coleta entrada
    if args.cpf and args.valor:
        cpf, valor = args.cpf, args.valor
    else:
        cpf, valor = coletar_interativo()

    # --- Consulta interna: banco busca os dados pelo CPF ---
    print()
    print("  Consultando cadastro interno...")
    cliente = consultar_por_cpf(cpf)

    if not cliente:
        print()
        print("  [!] CPF nao encontrado na base de clientes do Aurora Bank.")
        print("  Para abrir sua conta, acesse nosso site ou uma agencia.")
        return

    print(f"  Cliente identificado: {cliente.nome}")
    print()

    # Monta pedido completo com dados internos
    pedido = {
        "nome":                  cliente.nome,
        "cpf":                   cliente.cpf,
        "data_nascimento":       cliente.data_nascimento,
        "renda_mensal":          cliente.renda_mensal,
        "score_serasa":          cliente.score_serasa,
        "recursos_investidos":   cliente.recursos_investidos,
        "portabilidade_salario": cliente.portabilidade_salario,
        "valor_solicitado":      valor,
    }

    # Executa análise
    resultado = analisar_pedido(pedido)

    # Monta saída completa
    saida = {
        "aprovado":           resultado.aprovado,
        "limite_aprovado":    resultado.limite_aprovado,
        "produto_sugerido":   resultado.produto_sugerido,
        "justificativa":      resultado.justificativa,
        "motivos_aprovacao":  resultado.motivos_aprovacao,
        "motivos_negacao":    resultado.motivos_negacao,
        "alertas":            resultado.alertas,
        "registro_auditavel": resultado.registro_auditavel,
    }

    caminho = salvar_resultado(saida, cliente.cpf)
    exibir_resultado(resultado, caminho)


if __name__ == "__main__":
    main()
