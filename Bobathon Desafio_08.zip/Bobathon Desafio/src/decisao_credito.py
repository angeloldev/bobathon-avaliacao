"""
decisao_credito.py
==================
Lógica de decisão de crédito do Aurora Bank.

Etapas implementadas (conforme arquitetura do desafio):
  1. Pedido chega        — recebe dados do cliente
  2. Agente Carteira     — consulta produtos e limites disponíveis do banco
  3. Agente Cliente      — avalia perfil, score, renda e comportamento
  4. Decisão             — aprova ou nega + limite sugerido
  5. Justificativa       — motivo em linguagem clara (sem jargão técnico)
  6. Registro auditável  — dicionário com todo o raciocínio da decisão

Uso:
    from decisao_credito import analisar_pedido
    resultado = analisar_pedido(dados_cliente)
    print(resultado["justificativa"])
    print(resultado["registro_auditavel"])
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from datetime import date, datetime

# Garante que src/ está no path ao rodar diretamente
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from produtos_banco import selecionar_produto as _catalogo_selecionar, produtos_elegiveis


# ---------------------------------------------------------------------------
# 2. ESTRUTURA DE DADOS DO PEDIDO
# ---------------------------------------------------------------------------

@dataclass
class DadosCliente:
    """Representa os dados de entrada de um pedido de crédito."""
    nome: str
    cpf: str
    data_nascimento: str          # formato DD/MM/AAAA
    renda_mensal: float           # valor em R$
    score_serasa: int             # 0 a 1000
    recursos_investidos: float    # total investido no banco, em R$
    portabilidade_salario: str    # "Sim" ou "Não"
    valor_solicitado: float       # quanto o cliente quer tomar

    def idade(self) -> int:
        """Calcula a idade atual a partir da data de nascimento."""
        nascimento = datetime.strptime(self.data_nascimento, "%d/%m/%Y").date()
        hoje = date.today()
        return (hoje - nascimento).days // 365


@dataclass
class ResultadoDecisao:
    """Resultado completo da análise de crédito."""
    aprovado: bool
    limite_aprovado: float                   # 0 se negado
    produto_sugerido: str                    # nome do produto ou "N/A"
    motivos_aprovacao: list[str] = field(default_factory=list)
    motivos_negacao: list[str] = field(default_factory=list)
    alertas: list[str] = field(default_factory=list)   # pontos de atenção não bloqueantes
    justificativa: str = ""                  # texto para o cliente
    registro_auditavel: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# 3. REGRAS DE NEGÓCIO (Agente Cliente)
#    Cada função de regra retorna (passou: bool, mensagem: str)
# ---------------------------------------------------------------------------

def _regra_score_minimo(score: int) -> tuple[bool, str]:
    """Score abaixo de 300 bloqueia qualquer aprovação."""
    if score < 300:
        return False, f"Score Serasa insuficiente ({score}/1000). Mínimo exigido: 300."
    return True, f"Score Serasa dentro do aceitável ({score}/1000)."


def _regra_renda_minima(renda: float) -> tuple[bool, str]:
    """Renda abaixo do salário mínimo bloqueia aprovação."""
    RENDA_MINIMA = 1_320.0
    if renda < RENDA_MINIMA:
        return False, f"Renda mensal (R$ {renda:,.2f}) abaixo do mínimo exigido (R$ {RENDA_MINIMA:,.2f})."
    return True, f"Renda mensal de R$ {renda:,.2f} aprovada."


def _regra_comprometimento(
    valor_solicitado: float, renda: float, comprometimento_max: float
) -> tuple[bool, str]:
    """
    Verifica se a parcela estimada (12x) não compromete mais do que
    comprometimento_max da renda.
    """
    parcela_estimada = valor_solicitado / 12
    comprometimento_real = parcela_estimada / renda
    if comprometimento_real > comprometimento_max:
        return (
            False,
            f"Comprometimento de renda seria {comprometimento_real:.0%} "
            f"(máx. permitido: {comprometimento_max:.0%}). "
            f"Parcela estimada: R$ {parcela_estimada:,.2f}/mês.",
        )
    return (
        True,
        f"Comprometimento de renda de {comprometimento_real:.0%} "
        f"está dentro do limite ({comprometimento_max:.0%}).",
    )


def _regra_idade_maxima(idade: int) -> tuple[bool, str]:
    """Clientes com mais de 80 anos não são elegíveis a crédito."""
    IDADE_MAXIMA = 80
    if idade > IDADE_MAXIMA:
        return False, f"Idade ({idade} anos) acima do limite máximo permitido ({IDADE_MAXIMA} anos)."
    return True, f"Idade ({idade} anos) dentro do limite permitido."


def _regra_valor_maximo(
    valor_solicitado: float, renda: float, recursos: float
) -> tuple[bool, str]:
    """
    Limite máximo concedível: 2,5× a renda mensal.
    Recursos investidos concedem bônus de até 20% sobre esse teto.
    """
    limite_base = renda * 2.5
    bonus_investimentos = min(recursos * 0.10, limite_base * 0.20)
    limite_final = round(limite_base + bonus_investimentos, 2)

    if valor_solicitado > limite_final:
        return (
            False,
            f"Valor solicitado (R$ {valor_solicitado:,.2f}) excede o limite "
            f"máximo concedível (R$ {limite_final:,.2f}) — teto de 2,5× a renda mensal.",
        )
    return True, f"Valor solicitado (R$ {valor_solicitado:,.2f}) dentro do limite máximo (R$ {limite_final:,.2f})."


def _regra_portabilidade(portabilidade: str) -> tuple[bool, str]:
    """
    Portabilidade de salário no banco é fator positivo (não bloqueante).
    Retorna alerta se não tiver portabilidade.
    """
    if portabilidade == "Sim":
        return True, "Cliente com portabilidade de salário no banco — fator positivo."
    return True, "Cliente sem portabilidade de salário — não bloqueia, mas reduz o limite potencial."


def _regra_relacionamento(recursos: float) -> tuple[bool, str]:
    """
    Investimentos no banco indicam relacionamento. Não bloqueia,
    mas é fator de ajuste do limite.
    """
    if recursos >= 50_000:
        return True, f"Bom relacionamento: R$ {recursos:,.2f} investidos no banco."
    if recursos >= 10_000:
        return True, f"Relacionamento moderado: R$ {recursos:,.2f} investidos no banco."
    if recursos == 0:
        return True, "Sem investimentos no banco — fator neutro."
    return True, f"Relacionamento inicial: R$ {recursos:,.2f} investidos no banco."


# ---------------------------------------------------------------------------
# 4. CÁLCULO DO LIMITE APROVADO
#    Combina score, renda, recursos e portabilidade em um limite final.
# ---------------------------------------------------------------------------

def _calcular_limite(
    score: int,
    renda: float,
    recursos: float,
    portabilidade: str,
    valor_solicitado: float,
) -> float:
    """
    Calcula o limite de crédito aprovado com base em múltiplos fatores.

    Fórmula:
      teto    = renda_mensal × 2,5
      teto   += bônus investimentos (até 20% do teto)
      teto   *= 1,10 se portabilidade == "Sim"
      limite  = min(teto, valor_solicitado)
    """
    # Teto fixo: 2,5× a renda mensal
    teto = renda * 2.5

    # Bônus por investimentos no banco (até 20% do teto)
    bonus_inv = min(recursos * 0.08, teto * 0.20)
    teto += bonus_inv

    # Bônus por portabilidade de salário (10% adicional sobre o teto)
    if portabilidade == "Sim":
        teto *= 1.10

    # Limite final: não excede o teto nem o valor solicitado
    limite = min(teto, valor_solicitado)

    return round(limite, 2)


# ---------------------------------------------------------------------------
# 5. SELEÇÃO DE PRODUTO (Agente Carteira)
# ---------------------------------------------------------------------------

def _selecionar_produto(renda: float, score: int, portabilidade: str) -> str:
    """
    Agente Carteira: delega ao catálogo real (produtos_banco.py).
    Retorna o nome do produto mais adequado ou 'N/A'.
    """
    produto = _catalogo_selecionar(renda, score, portabilidade)
    return produto.nome_produto if produto else "N/A"


# ---------------------------------------------------------------------------
# 6. GERAÇÃO DE JUSTIFICATIVA (em linguagem clara para o cliente)
# ---------------------------------------------------------------------------

def _gerar_justificativa(
    cliente: DadosCliente,
    aprovado: bool,
    limite: float,
    produto: str,
    motivos: list[str],
) -> str:
    """
    Gera um texto de justificativa em linguagem simples, sem jargão técnico,
    explicando a decisão ao cliente.
    """
    primeiro_nome = cliente.nome.split()[0]

    if aprovado:
        linhas = [
            f"Olá, {primeiro_nome}! Temos uma boa notícia.",
            "",
            f"Sua solicitação de crédito foi APROVADA no valor de R$ {limite:,.2f}.",
            f"Produto: {produto}.",
            "",
            "Por que aprovamos:",
        ]
        for m in motivos:
            linhas.append(f"  • {m}")
        linhas += [
            "",
            "Para contratar, acesse seu aplicativo ou entre em contato com nossa equipe.",
        ]
    else:
        linhas = [
            f"Olá, {primeiro_nome}. Analisamos com cuidado o seu pedido.",
            "",
            "Infelizmente, não foi possível aprovar sua solicitação neste momento.",
            "",
            "O que impediu a aprovação:",
        ]
        for m in motivos:
            linhas.append(f"  • {m}")
        linhas += [
            "",
            "O que você pode fazer para melhorar:",
            "  • Manter as contas em dia para aumentar seu score de crédito.",
            "  • Considerar um valor de crédito menor.",
            "  • Trazer sua conta-salário para o Aurora Bank.",
            "",
            "Você pode solicitar novamente daqui a 90 dias.",
        ]

    return "\n".join(linhas)


# ---------------------------------------------------------------------------
# 7. FUNÇÃO PRINCIPAL — analisar_pedido
#    Coordena todos os agentes e retorna o resultado completo.
# ---------------------------------------------------------------------------

def analisar_pedido(dados: dict | DadosCliente) -> ResultadoDecisao:
    """
    Ponto de entrada principal. Recebe os dados do cliente (dict ou DadosCliente)
    e retorna um ResultadoDecisao com decisão, limite, justificativa e registro.

    Parâmetros
    ----------
    dados : dict | DadosCliente
        Dados do cliente + campo 'valor_solicitado'.

    Retorna
    -------
    ResultadoDecisao
        Objeto com todos os campos preenchidos, incluindo registro auditável.
    """
    # Normaliza entrada
    if isinstance(dados, dict):
        cliente = DadosCliente(**dados)
    else:
        cliente = dados

    motivos_negacao: list[str] = []
    motivos_aprovacao: list[str] = []
    alertas: list[str] = []
    passou_todas = True

    # --- Etapa 3: Agente Cliente — aplica regras de negócio ---

    regras_bloqueantes = [
        _regra_idade_maxima(cliente.idade()),
        _regra_score_minimo(cliente.score_serasa),
        _regra_renda_minima(cliente.renda_mensal),
        _regra_valor_maximo(
            cliente.valor_solicitado, cliente.renda_mensal, cliente.recursos_investidos
        ),
    ]

    for passou, msg in regras_bloqueantes:
        if passou:
            motivos_aprovacao.append(msg)
        else:
            motivos_negacao.append(msg)
            passou_todas = False

    # Regras de comprometimento (só avalia se ainda pode aprovar)
    if passou_todas:
        # Usa comprometimento do produto mais exigente como referência
        passou_comp, msg_comp = _regra_comprometimento(
            cliente.valor_solicitado, cliente.renda_mensal, comprometimento_max=0.40
        )
        if passou_comp:
            motivos_aprovacao.append(msg_comp)
        else:
            motivos_negacao.append(msg_comp)
            passou_todas = False

    # Regras não-bloqueantes (geram alertas)
    _, msg_port = _regra_portabilidade(cliente.portabilidade_salario)
    alertas.append(msg_port)

    _, msg_rel = _regra_relacionamento(cliente.recursos_investidos)
    alertas.append(msg_rel)

    # --- Etapa 4: Decisão ---
    if passou_todas:
        limite = _calcular_limite(
            score=cliente.score_serasa,
            renda=cliente.renda_mensal,
            recursos=cliente.recursos_investidos,
            portabilidade=cliente.portabilidade_salario,
            valor_solicitado=cliente.valor_solicitado,
        )
        produto_nome = _selecionar_produto(cliente.renda_mensal, cliente.score_serasa, cliente.portabilidade_salario)
        elegiveis = [p.nome_produto for p in produtos_elegiveis(cliente.renda_mensal, cliente.score_serasa)]
        aprovado = limite > 0
    else:
        limite = 0.0
        produto_nome = "N/A"
        elegiveis = []
        aprovado = False

    # --- Etapa 5: Justificativa ---
    justificativa = _gerar_justificativa(
        cliente=cliente,
        aprovado=aprovado,
        limite=limite,
        produto=produto_nome,
        motivos=motivos_aprovacao if aprovado else motivos_negacao,
    )

    # --- Etapa 6: Registro auditável ---
    registro = {
        "timestamp": datetime.now().isoformat(),
        "cliente": {
            "nome": cliente.nome,
            "cpf": cliente.cpf,
            "idade": cliente.idade(),
            "renda_mensal": cliente.renda_mensal,
            "score_serasa": cliente.score_serasa,
            "recursos_investidos": cliente.recursos_investidos,
            "portabilidade_salario": cliente.portabilidade_salario,
        },
        "pedido": {
            "valor_solicitado": cliente.valor_solicitado,
        },
        "agente_cliente": {
            "regras_avaliadas": [
                {"regra": m, "resultado": "aprovado"} for m in motivos_aprovacao
            ] + [
                {"regra": m, "resultado": "negado"} for m in motivos_negacao
            ],
            "alertas": alertas,
        },
        "agente_carteira": {
            "produto_sugerido": produto_nome,
            "produtos_elegiveis": elegiveis if passou_todas else [],
        },
        "decisao": {
            "aprovado": aprovado,
            "limite_aprovado": limite,
        },
    }

    return ResultadoDecisao(
        aprovado=aprovado,
        limite_aprovado=limite,
        produto_sugerido=produto_nome,
        motivos_aprovacao=motivos_aprovacao,
        motivos_negacao=motivos_negacao,
        alertas=alertas,
        justificativa=justificativa,
        registro_auditavel=registro,
    )


# ---------------------------------------------------------------------------
# DEMO — executa exemplos ao rodar o script diretamente
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    casos_teste = [
        # Caso 1 — aprovação normal dentro do teto (2,5× R$4.505 = R$11.262)
        {
            "nome": "Maria Tavares Barbosa",
            "cpf": "332.181.960-00",
            "data_nascimento": "13/05/1949",   # 77 anos — dentro do limite
            "renda_mensal": 4505.01,
            "score_serasa": 375,
            "recursos_investidos": 40101.67,
            "portabilidade_salario": "Sim",
            "valor_solicitado": 8_000.0,        # ≤ 2,5× renda → aprovado
        },
        # Caso 2 — excede teto de 2,5× renda (R$9.803 × 2,5 = R$24.508)
        {
            "nome": "Carlos Duarte Pinto",
            "cpf": "116.155.940-00",
            "data_nascimento": "28/11/1987",
            "renda_mensal": 9803.32,
            "score_serasa": 680,
            "recursos_investidos": 0.0,
            "portabilidade_salario": "Sim",
            "valor_solicitado": 30_000.0,       # > 2,5× renda → negado
        },
        # Caso 3 — score baixo
        {
            "nome": "Cliente Score Baixo",
            "cpf": "000.000.000-00",
            "data_nascimento": "01/01/1990",
            "renda_mensal": 2500.0,
            "score_serasa": 210,
            "recursos_investidos": 0.0,
            "portabilidade_salario": "Não",
            "valor_solicitado": 5_000.0,
        },
        # Caso 4 — idade acima de 80 anos
        {
            "nome": "Jose Idoso Exemplo",
            "cpf": "111.222.333-96",
            "data_nascimento": "01/01/1940",    # 85 anos → bloqueado
            "renda_mensal": 5000.0,
            "score_serasa": 750,
            "recursos_investidos": 100000.0,
            "portabilidade_salario": "Sim",
            "valor_solicitado": 10_000.0,
        },
    ]

    for caso in casos_teste:
        print("\n" + "=" * 70)
        print(f"PEDIDO: {caso['nome']} — R$ {caso['valor_solicitado']:,.2f}")
        print("=" * 70)
        resultado = analisar_pedido(caso)
        print(resultado.justificativa)
        print("\n--- Registro Auditável ---")
        print(json.dumps(resultado.registro_auditavel, ensure_ascii=False, indent=2))
