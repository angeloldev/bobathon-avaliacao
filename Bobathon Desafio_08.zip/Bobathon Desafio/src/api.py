"""
api.py
======
API REST do Aurora Bank — Motor de Decisão de Crédito.
Implementada com a stdlib do Python (http.server + json) — sem dependências externas.

Endpoints:

  GET  /health              — verificação de saúde
  GET  /produtos            — catálogo de produtos do banco (Agente Carteira)
  GET  /clientes            — lista todos os clientes da base (resumo)
  GET  /clientes/<cpf>      — consulta um cliente pelo CPF
  POST /analisar-credito    — recebe CPF + valor, busca base e retorna decisão

Uso:
    python src/api.py
    # Servidor em http://localhost:5000

Teste rápido (PowerShell):
    Invoke-RestMethod -Uri http://localhost:5000/health -Method GET
    Invoke-RestMethod -Uri http://localhost:5000/analisar-credito -Method POST `
      -ContentType 'application/json' `
      -Body '{"nome":"Joao Silva","cpf":"123.456.789-09","data_nascimento":"15/03/1985",
              "renda_mensal":5000,"score_serasa":650,"recursos_investidos":12000,
              "portabilidade_salario":"Sim","valor_solicitado":10000}'
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

# Garante que src/ está no path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

FRONTEND_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend", "index.html")

from consultar_cliente import consultar_por_cpf, carregar_clientes_resumo
from decisao_credito import analisar_pedido
from produtos_banco import catalogo

# ---------------------------------------------------------------------------
# Diretório de evidências — persiste registros auditáveis em disco
# ---------------------------------------------------------------------------
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVIDENCIAS_DIR = os.path.join(_BASE_DIR, "evidencias")
os.makedirs(EVIDENCIAS_DIR, exist_ok=True)

PORT = 5000


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _json_response(handler: BaseHTTPRequestHandler, status: int, data: dict) -> None:
    """Envia uma resposta JSON."""
    body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(body)


def _salvar_registro(registro: dict) -> str:
    """Persiste o registro auditável em evidencias/ e retorna o nome do arquivo."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    cpf_limpo = registro["cliente"]["cpf"].replace(".", "").replace("-", "")
    nome_arquivo = f"decisao_{cpf_limpo}_{ts}.json"
    caminho = os.path.join(EVIDENCIAS_DIR, nome_arquivo)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(registro, f, ensure_ascii=False, indent=2)
    return nome_arquivo


# ---------------------------------------------------------------------------
# Handler HTTP
# ---------------------------------------------------------------------------

class AuroraBankHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        """Formata logs de acesso."""
        print(f"  [{self.log_date_time_string()}] {format % args}")

    def do_OPTIONS(self):
        """Suporte a CORS preflight."""
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path

        if path in ("/", "/index.html"):
            try:
                with open(FRONTEND_PATH, encoding="utf-8") as f:
                    html = f.read().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
            except FileNotFoundError:
                _json_response(self, 404, {"erro": "Frontend nao encontrado."})
            return

        if path == "/health":
            _json_response(self, 200, {
                "status": "ok",
                "servico": "Aurora Bank — Motor de Credito",
            })

        elif path == "/produtos":
            produtos = [
                {
                    "id": p.id_produto,
                    "nome": p.nome_produto,
                    "categoria": p.categoria,
                    "renda_minima": p.renda_minima,
                    "renda_maxima": p.renda_maxima if p.renda_maxima != float("inf") else None,
                    "descricao": p.descricao,
                }
                for p in catalogo()
                if p.ativo
            ]
            _json_response(self, 200, {"produtos": produtos, "total": len(produtos)})

        elif path == "/clientes":
            clientes = carregar_clientes_resumo()
            _json_response(self, 200, {"clientes": clientes, "total": len(clientes)})

        elif path.startswith("/clientes/"):
            cpf_raw = path[len("/clientes/"):]
            cliente = consultar_por_cpf(cpf_raw)
            if cliente:
                _json_response(self, 200, {
                    "nome": cliente.nome,
                    "cpf": cliente.cpf,
                    "data_nascimento": cliente.data_nascimento,
                    "renda_mensal": cliente.renda_mensal,
                    "score_serasa": cliente.score_serasa,
                    "recursos_investidos": cliente.recursos_investidos,
                    "portabilidade_salario": cliente.portabilidade_salario,
                })
            else:
                _json_response(self, 404, {"erro": "Cliente nao encontrado."})

        else:
            _json_response(self, 404, {"erro": f"Rota nao encontrada: {path}"})

    def do_POST(self):
        path = urlparse(self.path).path

        if path != "/analisar-credito":
            _json_response(self, 404, {"erro": f"Rota nao encontrada: {path}"})
            return

        # Lê o corpo
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            _json_response(self, 400, {"erro": "Corpo da requisicao ausente."})
            return

        raw = self.rfile.read(length)
        try:
            dados = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            _json_response(self, 400, {"erro": f"JSON invalido: {exc}"})
            return

        # Campos obrigatórios: só CPF + valor. Resto vem da base.
        for campo in ("cpf", "valor_solicitado"):
            if campo not in dados:
                _json_response(self, 400, {"erro": f"Campo obrigatorio ausente: {campo}"})
                return

        try:
            valor_solicitado = float(dados["valor_solicitado"])
        except (ValueError, TypeError) as exc:
            _json_response(self, 400, {"erro": f"valor_solicitado invalido: {exc}"})
            return

        # Busca dados internos pelo CPF
        cliente = consultar_por_cpf(dados["cpf"])
        if not cliente:
            _json_response(self, 404, {"erro": "CPF nao encontrado na base de clientes."})
            return

        pedido = {
            "nome":                  cliente.nome,
            "cpf":                   cliente.cpf,
            "data_nascimento":       cliente.data_nascimento,
            "renda_mensal":          cliente.renda_mensal,
            "score_serasa":          cliente.score_serasa,
            "recursos_investidos":   cliente.recursos_investidos,
            "portabilidade_salario": cliente.portabilidade_salario,
            "valor_solicitado":      valor_solicitado,
        }

        # Executa análise
        try:
            resultado = analisar_pedido(pedido)
        except Exception as exc:
            _json_response(self, 500, {"erro": f"Erro interno na analise: {exc}"})
            return

        # Persiste registro auditável
        arquivo = _salvar_registro(resultado.registro_auditavel)

        _json_response(self, 200, {
            "aprovado": resultado.aprovado,
            "limite_aprovado": resultado.limite_aprovado,
            "produto_sugerido": resultado.produto_sugerido,
            "justificativa": resultado.justificativa,
            "motivos_aprovacao": resultado.motivos_aprovacao,
            "motivos_negacao": resultado.motivos_negacao,
            "alertas": resultado.alertas,
            "registro_arquivo": arquivo,
            "registro_auditavel": resultado.registro_auditavel,
        })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", PORT), AuroraBankHandler)
    print("=" * 60)
    print("Aurora Bank - Motor de Decisao de Credito")
    print(f"Servidor: http://localhost:{PORT}")
    print("Endpoints:")
    print(f"  GET  http://localhost:{PORT}/health")
    print(f"  GET  http://localhost:{PORT}/produtos")
    print(f"  GET  http://localhost:{PORT}/clientes")
    print(f"  GET  http://localhost:{PORT}/clientes/<cpf>")
    print(f"  POST http://localhost:{PORT}/analisar-credito  {{cpf, valor_solicitado}}")
    print("Pressione Ctrl+C para parar.")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
        server.server_close()
