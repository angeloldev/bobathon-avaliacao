"""
produtos_banco.py
=================
Agente Carteira — catálogo de produtos do Aurora Bank.

Lê os produtos de cartão de crédito do CSV e expõe funções para:
  - listar todos os produtos disponíveis
  - selecionar o melhor produto para um cliente dado sua renda mensal

Fonte de dados: data/produtos_cartao_credito.csv
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Caminho do CSV (relativo à raiz do projeto)
# ---------------------------------------------------------------------------
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRODUTOS_CSV = os.path.join(_BASE_DIR, "data", "produtos_cartao_credito.csv")


# ---------------------------------------------------------------------------
# Estrutura de produto
# ---------------------------------------------------------------------------

@dataclass
class ProdutoBanco:
    id_produto: int
    nome_produto: str
    categoria: str          # Internacional | Gold | Platinum | Black | Diamante
    renda_minima: float     # R$
    renda_maxima: float     # R$ ou float("inf") para "Sem limite"
    moeda: str
    descricao: str
    ativo: bool


# ---------------------------------------------------------------------------
# Mapeamento de categorias → score mínimo exigido
# (complementa a regra de score da decisão de crédito)
# ---------------------------------------------------------------------------

SCORE_MINIMO_POR_CATEGORIA = {
    "Internacional": 300,
    "Gold":          450,
    "Platinum":      600,
    "Black":         750,
    "Diamante":      900,
}

# Comprometimento máximo de renda por categoria (parcela / renda)
COMPROMETIMENTO_POR_CATEGORIA = {
    "Internacional": 0.30,
    "Gold":          0.35,
    "Platinum":      0.35,
    "Black":         0.40,
    "Diamante":      0.40,
}


# ---------------------------------------------------------------------------
# Carregamento do catálogo
# ---------------------------------------------------------------------------

def _parse_renda(valor: str) -> float:
    """Converte string de renda para float. 'Sem limite' → inf."""
    valor = valor.strip()
    if valor.lower() == "sem limite":
        return float("inf")
    # Remove separador de milhar (.) e troca vírgula decimal por ponto
    return float(valor.replace(".", "").replace(",", "."))


def carregar_produtos(csv_path: str = PRODUTOS_CSV) -> list[ProdutoBanco]:
    """Lê o CSV de produtos e retorna lista de ProdutoBanco ativos."""
    produtos: list[ProdutoBanco] = []
    with open(csv_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        for row in reader:
            produtos.append(ProdutoBanco(
                id_produto=int(row["id_produto"]),
                nome_produto=row["nome_produto"].strip(),
                categoria=row["categoria"].strip(),
                renda_minima=_parse_renda(row["renda_minima"]),
                renda_maxima=_parse_renda(row["renda_maxima"]),
                moeda=row["moeda"].strip(),
                descricao=row["descricao"].strip(),
                ativo=row["ativo"].strip().upper() == "S",
            ))
    return produtos


# Cache em memória para não reler o CSV a cada chamada
_CATALOGO: list[ProdutoBanco] | None = None


def catalogo() -> list[ProdutoBanco]:
    """Retorna o catálogo (com cache). Recarrega se ainda não carregado."""
    global _CATALOGO
    if _CATALOGO is None:
        _CATALOGO = carregar_produtos()
    return _CATALOGO


# ---------------------------------------------------------------------------
# Seleção do melhor produto (Agente Carteira)
# ---------------------------------------------------------------------------

def selecionar_produto(
    renda_mensal: float,
    score_serasa: int,
    portabilidade_salario: str = "Não",
) -> ProdutoBanco | None:
    """
    Retorna o produto mais adequado para o cliente.

    Critérios (em ordem de prioridade):
      1. Produto ativo
      2. renda_minima ≤ renda_mensal ≤ renda_maxima
      3. score_serasa ≥ score mínimo da categoria
      4. Entre os elegíveis, retorna o de maior categoria (hierarquia)
         exceto Diamante, que exige análise especial

    Parâmetros
    ----------
    renda_mensal : float
        Renda bruta mensal do cliente em R$.
    score_serasa : int
        Score de crédito do cliente (0–1000).
    portabilidade_salario : str
        "Sim" ou "Não" — portabilidade não é critério de produto aqui,
        mas pode ser usado para desempate futuro.

    Retorna
    -------
    ProdutoBanco | None
        Melhor produto elegível, ou None se não houver nenhum.
    """
    # Hierarquia de categorias (menor → maior)
    hierarquia = ["Internacional", "Gold", "Platinum", "Black", "Diamante"]

    elegiveis = [
        p for p in catalogo()
        if p.ativo
        and p.renda_minima <= renda_mensal
        and (p.renda_maxima == float("inf") or renda_mensal <= p.renda_maxima)
        and score_serasa >= SCORE_MINIMO_POR_CATEGORIA.get(p.categoria, 0)
    ]

    if not elegiveis:
        return None

    # Ordena pela posição na hierarquia (maior categoria primeiro)
    elegiveis.sort(key=lambda p: hierarquia.index(p.categoria), reverse=True)

    # Retorna o primeiro produto da categoria mais alta
    # (dentro da categoria, prefere Visa > Mastercard > Elo por ordem do CSV)
    melhor_categoria = elegiveis[0].categoria
    candidatos_da_melhor = [p for p in elegiveis if p.categoria == melhor_categoria]
    return candidatos_da_melhor[0]


def produtos_elegiveis(
    renda_mensal: float,
    score_serasa: int,
) -> list[ProdutoBanco]:
    """Retorna todos os produtos elegíveis para o cliente, em ordem decrescente de categoria."""
    hierarquia = ["Internacional", "Gold", "Platinum", "Black", "Diamante"]
    resultado = [
        p for p in catalogo()
        if p.ativo
        and p.renda_minima <= renda_mensal
        and (p.renda_maxima == float("inf") or renda_mensal <= p.renda_maxima)
        and score_serasa >= SCORE_MINIMO_POR_CATEGORIA.get(p.categoria, 0)
    ]
    resultado.sort(key=lambda p: hierarquia.index(p.categoria), reverse=True)
    return resultado


# ---------------------------------------------------------------------------
# DEMO
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== Catálogo de Produtos Aurora Bank ===\n")
    for p in catalogo():
        status = "S" if p.ativo else "N"
        limite = f"R$ {p.renda_maxima:,.0f}" if p.renda_maxima != float("inf") else "Sem limite"
        print(f"[{status}] {p.nome_produto:45s} | {p.categoria:12s} | "
              f"Renda: R$ {p.renda_minima:,.0f} – {limite}")

    print("\n=== Seleção por perfil ===\n")
    casos = [
        ("Cliente Básico",   1800.0,  320),
        ("Cliente Gold",     3500.0,  470),
        ("Cliente Platinum", 5000.0,  650),
        ("Cliente Black",    20000.0, 800),
        ("Cliente Diamante", 90000.0, 950),
        ("Cliente Negado",   400.0,   150),
    ]
    for nome, renda, score in casos:
        prod = selecionar_produto(renda, score)
        if prod:
            print(f"{nome:20s} (renda R${renda:,.0f} | score {score}) => {prod.nome_produto}")
        else:
            print(f"{nome:20s} (renda R${renda:,.0f} | score {score}) => Nenhum produto disponivel")
