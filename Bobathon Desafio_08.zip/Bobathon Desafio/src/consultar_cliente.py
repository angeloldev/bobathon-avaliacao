"""
consultar_cliente.py
====================
Módulo de consulta à base de clientes do Aurora Bank.

Simula o que seria uma consulta ao CRM/sistema interno do banco:
dado o CPF, retorna os dados cadastrais e financeiros do cliente
sem que ele precise informar nada além do CPF.

Dados retornados pelo banco (internos — o cliente não informa):
  - nome
  - data_nascimento
  - renda_mensal        ← banco tem na folha de pagamento / declaração
  - score_serasa        ← consultado pelo banco no bureau de crédito
  - recursos_investidos ← saldo na própria instituição
  - portabilidade_salario ← cadastrado na conta

Fonte: data/clientes_banco_digital.csv
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass


_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLIENTES_CSV = os.path.join(_BASE_DIR, "data", "clientes_banco_digital.csv")


@dataclass
class DadosInternosCliente:
    """Dados que o banco possui sobre o cliente — não informados por ele."""
    nome: str
    cpf: str
    data_nascimento: str      # DD/MM/AAAA
    renda_mensal: float
    score_serasa: int
    recursos_investidos: float
    portabilidade_salario: str   # "Sim" ou "Não"


def _normalizar_cpf(cpf: str) -> str:
    """Remove pontos e traço para comparação uniforme."""
    return cpf.replace(".", "").replace("-", "").strip()


def consultar_por_cpf(cpf: str, csv_path: str = CLIENTES_CSV) -> DadosInternosCliente | None:
    """
    Busca o cliente na base pelo CPF.

    Parâmetros
    ----------
    cpf : str
        CPF no formato 000.000.000-00 ou apenas dígitos.

    Retorna
    -------
    DadosInternosCliente | None
        Dados internos do cliente, ou None se não encontrado.
    """
    cpf_normalizado = _normalizar_cpf(cpf)

    with open(csv_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if _normalizar_cpf(row["cpf"]) == cpf_normalizado:
                return DadosInternosCliente(
                    nome=row["nome"].strip(),
                    cpf=row["cpf"].strip(),
                    data_nascimento=row["data_nascimento"].strip(),
                    renda_mensal=float(row["renda_mensal"]),
                    score_serasa=int(row["score_serasa"]),
                    recursos_investidos=float(row["recursos_investidos"]),
                    portabilidade_salario=row["portabilidade_salario"].strip(),
                )
    return None


# ---------------------------------------------------------------------------
# DEMO
# ---------------------------------------------------------------------------

def carregar_clientes_resumo(csv_path: str = CLIENTES_CSV) -> list[dict]:
    """Retorna lista resumida de todos os clientes (sem dados sensíveis de score)."""
    clientes = []
    with open(csv_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            clientes.append({
                "nome":                  row["nome"].strip(),
                "cpf":                   row["cpf"].strip(),
                "data_nascimento":       row["data_nascimento"].strip(),
                "renda_mensal":          float(row["renda_mensal"]),
                "score_serasa":          int(row["score_serasa"]),
                "recursos_investidos":   float(row["recursos_investidos"]),
                "portabilidade_salario": row["portabilidade_salario"].strip(),
            })
    return clientes


if __name__ == "__main__":
    testes = [
        "332.181.960-00",   # Maria Tavares Barbosa — deve encontrar
        "116.155.940-00",   # Carlos Duarte Pinto   — deve encontrar
        "000.000.000-00",   # CPF inexistente        — deve retornar None
    ]
    for cpf in testes:
        cliente = consultar_por_cpf(cpf)
        if cliente:
            print(f"[OK] {cpf} => {cliente.nome} | "
                  f"renda R${cliente.renda_mensal:,.2f} | "
                  f"score {cliente.score_serasa} | "
                  f"investido R${cliente.recursos_investidos:,.2f} | "
                  f"portabilidade {cliente.portabilidade_salario}")
        else:
            print(f"[NAO ENCONTRADO] {cpf}")
