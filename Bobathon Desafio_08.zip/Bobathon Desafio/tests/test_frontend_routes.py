import unittest
from pathlib import Path


class FrontendRouteTests(unittest.TestCase):
    def test_fetches_use_api_base_not_browser_origin(self):
        html = Path("frontend/index.html").read_text(encoding="utf-8")

        self.assertIn("const API =", html)
        self.assertIn("fetch(`${API}/analisar-credito`", html)
        self.assertIn("fetch(`${API}/produtos`", html)
        self.assertIn("fetch(`${API}/clientes`", html)


if __name__ == "__main__":
    unittest.main()
