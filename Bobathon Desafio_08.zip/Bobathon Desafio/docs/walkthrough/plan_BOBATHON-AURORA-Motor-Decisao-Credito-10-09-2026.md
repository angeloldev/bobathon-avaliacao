# Walkthrough — Aurora Bank: Motor de Decisão de Crédito com Agentes de IA

**Sigla do projeto:** `BOBATHON-AURORA`  
**Data e hora:** 2026-09-10  
**Autor:** IBM Bob (Agente de IA) + Equipe BRB  
**Contexto:** Bob-a-thon BRB — Desafio Aurora Bank — IBM watsonx Orchestrate

---

## 1. Objetivo

Substituir um sistema legado de 22 anos de concessão de crédito do Aurora Bank — que decidia sem explicar — por uma solução baseada em agentes de IA que decide com transparência, justificativa auditável e linguagem clara ao cliente.

---

## 2. Arquitetura implementada

```
Pedido chega
    │
    ▼
[Agente Cliente]  ←──────────────────────────────────────────────
    │  Aplica 5 regras de negócio em sequência:                  │
    │  1. Idade ≤ 80 anos                                        │
    │  2. Score Serasa ≥ 300                                     │
    │  3. Renda ≥ R$ 1.320/mês                                   │
    │  4. Valor solicitado ≤ 2,5× renda (+ bônus investimentos)  │
    │  5. Comprometimento de renda ≤ 40%                         │
    │                                                            │
    ▼                                                            │
[Agente Carteira]  ───────────────────────────────────────────────
    │  Consulta catálogo de produtos (produtos_cartao_credito.csv)
    │  Seleciona produto mais adequado (renda + score)
    │
    ▼
[Decisão + Limite]
    │
    ▼
[Justificativa em linguagem clara]
    │
    ▼
[Registro auditável → evidencias/decisao_*.json]
```

---

## 3. Arquivos criados

### Dados
| Arquivo | Descrição |
|---------|-----------|
| `data/clientes_banco_digital.csv` | 200 clientes fictícios brasileiros (seed 42) |
| `data/produtos_cartao_credito.csv` | 15 produtos de cartão (Internacional → Diamante) |

### Código (`src/`)
| Arquivo | Módulo | Responsabilidade |
|---------|--------|-----------------|
| `src/decisao_credito.py` | Agente Cliente | 5 regras bloqueantes + cálculo de limite + justificativa + registro auditável |
| `src/produtos_banco.py` | Agente Carteira | Leitura do CSV de produtos + seleção por renda/score/hierarquia |
| `src/api.py` | Orquestração | API REST com stdlib (`http.server`) — 3 endpoints: `/health`, `/produtos`, `/analisar-credito` |

### Instruções dos agentes (`evidencias/`)
| Arquivo | Para quem |
|---------|-----------|
| `evidencias/agente_carteira_instrucoes.md` | System prompt do Agente Carteira no Orchestrate |
| `evidencias/agente_cliente_instrucoes.md` | System prompt do Agente Cliente no Orchestrate |

### Entrega
| Arquivo | Descrição |
|---------|-----------|
| `README.md` | Documentação oficial da entrega (uso do Bob, Orchestrate, regras, endpoints) |
| `gerar_clientes.py` | Script Python de geração da base fictícia |

---

## 4. Regras de negócio implementadas

### Regras bloqueantes (qualquer falha → negação)

| # | Regra | Valor | Função |
|---|-------|-------|--------|
| 1 | Idade máxima | ≤ 80 anos | `_regra_idade_maxima()` |
| 2 | Score mínimo Serasa | ≥ 300 | `_regra_score_minimo()` |
| 3 | Renda mínima | ≥ R$ 1.320,00 | `_regra_renda_minima()` |
| 4 | Limite máximo | ≤ 2,5× renda + bônus inv. | `_regra_valor_maximo()` |
| 5 | Comprometimento de renda | parcela ≤ 40% da renda | `_regra_comprometimento()` |

### Fatores de ajuste (não bloqueantes)
- **Portabilidade de salário:** +10% no teto do limite
- **Investimentos no banco:** bônus até +20% no teto (recursos × 8%, limitado)

### Seleção de produto (Agente Carteira)
Hierarquia: Internacional → Gold → Platinum → Black → Diamante  
Critérios: renda_mínima ≤ renda ≤ renda_máxima E score ≥ score_mínimo_da_categoria

---

## 5. Casos de teste validados

| Cliente | Situação | Resultado esperado | Resultado obtido |
|---------|----------|--------------------|-----------------|
| Maria Tavares (77 anos, score 375, R$4.505) | Pedido R$8.000 | Aprovado | ✅ Aprovado R$8.000 |
| Carlos Duarte (38 anos, score 680, R$9.803) | Pedido R$30.000 (excede 2,5×) | Negado | ✅ Negado — teto R$24.508 |
| Cliente Score Baixo (score 210) | Pedido R$5.000 | Negado por score | ✅ Negado — score 210 < 300 |
| José Idoso (86 anos, score 750) | Pedido R$10.000 | Negado por idade | ✅ Negado — 86 > 80 anos |

---

## 6. Impedimento técnico registrado

**Orchestrate ADK para tools:** não disponível no ambiente do evento.

**Impacto:** Os agentes no Orchestrate não puderam ser conectados via tool à API REST local. A solução adotada foi gerar instruções em linguagem natural completas (`evidencias/agente_*.md`) que replicam exatamente a lógica do código — incluindo todas as regras, exemplos de cálculo e o formato de resposta esperado.

**Em uma implementação completa:**
- Agente Cliente → tool `POST /analisar-credito`
- Agente Carteira → tool `GET /produtos`
- Registro auditável → gravado automaticamente em `evidencias/` a cada chamada

---

## 7. Decisões técnicas relevantes

| Decisão | Justificativa |
|---------|---------------|
| API com `http.server` (stdlib) | Sem dependências externas — sem Flask, sem FastAPI. Funciona em qualquer Python 3.x sem `pip install`. |
| Teto de 2,5× a renda | Regra definida pelo time durante o evento para garantir concessão responsável. |
| Bônus de portabilidade (+10%) | Incentivo ao produto estratégico do banco. |
| Bônus de investimentos (até +20%) | Reconhece o relacionamento do cliente sem ultrapassar o teto principal. |
| CSV com UTF-8-BOM | Compatibilidade com Excel no Windows — acentos exibidos corretamente. |
| Seed fixo = 42 | Reprodutibilidade da base fictícia — mesma seed sempre gera os mesmos 200 registros. |

---

## 8. Próximos passos (pós-evento)

- [ ] Integrar a API via tool no Orchestrate assim que o ADK estiver disponível
- [ ] Adicionar campo `historico_inadimplencia` à base e à lógica de decisão
- [ ] Implementar endpoint `GET /analisar-lote` para processar múltiplos pedidos de uma vez
- [ ] Adicionar autenticação na API (API key ou OAuth)
- [ ] Criar dashboard simples para visualizar as decisões geradas em `evidencias/`

---

*Gerado com IBM Bob — Bob-a-thon BRB 2026*
