# Plano — BDCHALLENGE: Geração de Base de Dados Fictícia para Banco Digital

> **Data de criação:** 2026  
> **Sigla do projeto:** `BDCHALLENGE`  
> **Autor:** IBM Bob (Agente de IA)  
> **Contexto:** Desafio banco digital — geração de dados fictícios para agentes de IA no IBM Orchestrate

---

## 1. Objetivo

Gerar uma base de dados com **200 clientes fictícios brasileiros** para uso em um projeto de desafio voltado a um banco digital, com o formato de arquivo adequado para consumo por agentes de IA no IBM Orchestrate e plataformas similares.

---

## 2. Recomendação de Formato: CSV (UTF-8-BOM)

### Justificativa

| Critério | Justificativa |
|----------|--------------|
| Leitura por agentes | CSV é consumido nativamente por `pandas.read_csv()` sem dependências extras |
| Compatibilidade | Padrão de importação universal: IBM Orchestrate, n8n, Watson, Excel, Google Sheets |
| Legibilidade humana | Validação imediata no Excel/editor de texto, sem transformação |
| Suporte Python | Bibliotecas `csv` e `pandas` nativas, sem instalação adicional |
| Estrutura dos dados | Dados tabulares planos (sem aninhamento) — CSV é a representação natural |

**UTF-8-BOM** garante que acentos e caracteres especiais brasileiros sejam exibidos corretamente no Excel (Windows).

> Segunda opção: **JSONL** — recomendado se os registros tiverem campos aninhados ou opcionais, ou se o pipeline exigir streaming linha-a-linha.

---

## 3. Estrutura dos Dados

| Campo | Tipo | Restrições |
|-------|------|-----------|
| `nome` | string | Nome completo brasileiro realista (Faker pt_BR) |
| `cpf` | string | Formato `000.000.000-00`, fictício mas estruturalmente plausível |
| `data_nascimento` | string | `DD/MM/AAAA`, idades entre 18 e 80 anos |
| `renda_mensal` | float | R$ 1.320,00 a R$ 45.000,00 |
| `score_serasa` | int | 0 a 1000, distribuição realista (concentração entre 300–850) |
| `recursos_investidos` | float | R$ 0,00 a R$ 500.000,00, inclui zeros |
| `portabilidade_salario` | string | `Sim` ou `Não`, distribuição equilibrada |

---

## 4. Sub-Tarefas

### Sub-Tarefa 1 — Código Python de Geração
- **Intent:** Criar o script `gerar_clientes.py` com todos os requisitos técnicos
- **Expected Outcomes:** Script funcional que gera `clientes_banco_digital.csv` com 200 registros
- **Status:** `[x] done`

**Todo List:**
1. Instalar dependências: `faker`, `pandas`, `numpy`
2. Configurar Faker com locale `pt_BR` e seed para reprodutibilidade
3. Implementar geração de CPF fictício estruturalmente plausível
4. Implementar geração de `data_nascimento` com idades 18–80 anos
5. Implementar `renda_mensal` com distribuição log-normal (realista)
6. Implementar `score_serasa` com distribuição beta concentrada em 300–850
7. Implementar `recursos_investidos` com 15–20% de zeros (clientes sem investimentos)
8. Implementar `portabilidade_salario` com ~50% Sim / ~50% Não
9. Exportar para CSV com `encoding='utf-8-sig'` (UTF-8-BOM)
10. Exibir preview das primeiras 5 linhas

### Sub-Tarefa 2 — Arquivo CSV de Saída
- **Intent:** Gerar e persistir o arquivo `clientes_banco_digital.csv` no repositório
- **Expected Outcomes:** Arquivo CSV com exatamente 200 linhas de dados + 1 linha de cabeçalho
- **Status:** `[x] done` — 201 linhas (1 header + 200 registros), encoding UTF-8-BOM, validações passando

---

## 5. Arquivos a Criar

```
produto-legado-was/docs/walkthrough/
├── plan_BDCHALLENGE-GeracaoDadosFicticios-banco-digital.md  ← este arquivo
└── gerar_clientes.py                                         ← script Python

produto-legado-was/docs/walkthrough/data/
└── clientes_banco_digital.csv                               ← saída gerada
```

---

## 6. Decisões Técnicas

### 6.1 CPF Fictício Estruturalmente Plausível
CPFs serão gerados com 9 dígitos aleatórios + 2 dígitos verificadores calculados pelo algoritmo oficial do CPF. Isso garante que os CPFs **passem em validações de formato** mas sejam claramente fictícios (não pertencentes a pessoas reais cadastradas na Receita Federal).

### 6.2 Distribuição Realista de Score Serasa
Usada distribuição **beta transformada** para concentrar valores no intervalo 300–850, com caudas em 0–299 (inadimplentes) e 851–1000 (excelentes), refletindo a distribuição real do mercado brasileiro.

### 6.3 Distribuição de Renda Mensal
Usada distribuição **log-normal** truncada entre R$ 1.320 e R$ 45.000, que reflete a distribuição real de renda no Brasil (muitos com renda baixa/média, poucos com renda alta).

### 6.4 Recursos Investidos com Zeros
Aproximadamente 20% dos clientes terão `recursos_investidos = 0,00`, simulando clientes que possuem conta mas não investem — padrão realista para um banco digital.

---

## 7. Código Python Completo — `gerar_clientes.py`

```python
"""
gerar_clientes.py
=================
Script de geração de base de dados fictícia com 200 clientes brasileiros
para uso no desafio de banco digital com agentes de IA (IBM Orchestrate).

Formato de saída: CSV (UTF-8-BOM) — recomendado por:
  - Consumo nativo por pandas.read_csv() sem dependências extras
  - Compatibilidade universal com IBM Orchestrate, Excel, Google Sheets
  - Legibilidade humana imediata para validação
  - Estrutura plana (tabular) sem necessidade de JSON hierárquico

Dependências:
    pip install faker pandas numpy

Autor: IBM Bob (Agente de IA)
"""

import random
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd
from faker import Faker

# ---------------------------------------------------------------------------
# 1. Configuração do gerador com locale pt_BR e seed fixo
#    Seed garante reprodutibilidade: mesma seed → mesmos 200 registros
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
fake = Faker("pt_BR")
Faker.seed(SEED)

TOTAL_CLIENTES = 200


# ---------------------------------------------------------------------------
# 2. Funções auxiliares
# ---------------------------------------------------------------------------

def calcular_digitos_verificadores(cpf9: str) -> str:
    """
    Calcula os 2 dígitos verificadores de um CPF com base nos 9 primeiros
    dígitos, usando o algoritmo oficial da Receita Federal.

    Os CPFs gerados são estruturalmente válidos (passam em validações de
    formato), mas são fictícios e não pertencem a pessoas reais.
    """
    # Primeiro dígito verificador
    digitos = [int(d) for d in cpf9]
    soma = sum(d * (10 - i) for i, d in enumerate(digitos))
    resto = soma % 11
    d1 = 0 if resto < 2 else 11 - resto

    # Segundo dígito verificador
    digitos.append(d1)
    soma = sum(d * (11 - i) for i, d in enumerate(digitos))
    resto = soma % 11
    d2 = 0 if resto < 2 else 11 - resto

    return f"{d1}{d2}"


def gerar_cpf() -> str:
    """
    Gera um CPF fictício estruturalmente plausível no formato 000.000.000-00.

    Evita sequências inválidas conhecidas (ex: 000.000.000-00, 111.111.111-11,
    etc.) que são automaticamente rejeitadas por validadores de formato.
    """
    sequencias_invalidas = {str(d) * 9 for d in range(10)}
    while True:
        cpf9 = "".join([str(random.randint(0, 9)) for _ in range(9)])
        if cpf9 not in sequencias_invalidas:
            break
    dvs = calcular_digitos_verificadores(cpf9)
    return f"{cpf9[:3]}.{cpf9[3:6]}.{cpf9[6:9]}-{dvs}"


def gerar_data_nascimento() -> str:
    """
    Gera uma data de nascimento aleatória garantindo que o cliente tenha
    entre 18 e 80 anos na data de hoje.
    Retorna string no formato DD/MM/AAAA.
    """
    hoje = date.today()
    # Limite superior: 80 anos atrás
    data_min = date(hoje.year - 80, hoje.month, hoje.day)
    # Limite inferior: 18 anos atrás
    data_max = date(hoje.year - 18, hoje.month, hoje.day)
    delta = (data_max - data_min).days
    data = data_min + timedelta(days=random.randint(0, delta))
    return data.strftime("%d/%m/%Y")


def gerar_renda_mensal() -> float:
    """
    Gera renda mensal com distribuição log-normal truncada entre
    R$ 1.320,00 (salário mínimo 2026) e R$ 45.000,00.

    Log-normal reflete a distribuição real de renda no Brasil:
    concentração em rendas baixas/médias com cauda longa para altas rendas.
    """
    renda_min = 1320.0
    renda_max = 45000.0
    while True:
        # mu e sigma calibrados para concentrar em R$ 2.500 – R$ 8.000
        valor = np.random.lognormal(mean=8.2, sigma=0.9)
        if renda_min <= valor <= renda_max:
            return round(valor, 2)


def gerar_score_serasa() -> int:
    """
    Gera score de crédito Serasa com distribuição realista.

    Usa distribuição beta transformada para o intervalo [0, 1000]:
    - Concentração entre 300 e 850 (maioria da população)
    - Caudas em 0–299 (inadimplentes) e 851–1000 (excelentes)
    - alpha=4, beta=3 produz assimetria ligeiramente positiva, realista
    """
    # Distribuição beta com alpha=4, beta=3 no intervalo [0, 1000]
    valor = int(np.random.beta(a=4, b=3) * 1000)
    # Garante que está dentro dos limites
    return max(0, min(1000, valor))


def gerar_recursos_investidos() -> float:
    """
    Gera o total investido no banco.

    Aproximadamente 20% dos clientes têm R$ 0,00 (conta sem investimentos).
    Os demais têm valores entre R$ 100,00 e R$ 500.000,00 com distribuição
    log-normal (maioria com valores baixos/médios, poucos com valores altos).
    """
    # 20% de chance de não ter investimentos
    if random.random() < 0.20:
        return 0.0
    # Distribuição log-normal calibrada para concentrar em R$ 5k – R$ 50k
    while True:
        valor = np.random.lognormal(mean=10.0, sigma=1.5)
        if 100.0 <= valor <= 500000.0:
            return round(valor, 2)


def gerar_portabilidade() -> str:
    """
    Gera o campo de portabilidade de salário com ~50% Sim / ~50% Não.
    Usa random.random() para distribuição uniforme.
    """
    return "Sim" if random.random() < 0.50 else "Não"


# ---------------------------------------------------------------------------
# 3. Geração dos 200 registros
# ---------------------------------------------------------------------------

print("=" * 60)
print("Gerando base de dados fictícia — 200 clientes")
print("=" * 60)

registros = []

for i in range(TOTAL_CLIENTES):
    registro = {
        "nome": fake.name(),
        "cpf": gerar_cpf(),
        "data_nascimento": gerar_data_nascimento(),
        "renda_mensal": gerar_renda_mensal(),
        "score_serasa": gerar_score_serasa(),
        "recursos_investidos": gerar_recursos_investidos(),
        "portabilidade_salario": gerar_portabilidade(),
    }
    registros.append(registro)

# ---------------------------------------------------------------------------
# 4. Construção do DataFrame e validações básicas
# ---------------------------------------------------------------------------

df = pd.DataFrame(registros)

# Verificações de integridade
assert len(df) == 200, "Número de registros incorreto"
assert df["cpf"].nunique() == 200, "CPFs duplicados encontrados"
assert df["score_serasa"].between(0, 1000).all(), "Scores fora do intervalo"
assert df["renda_mensal"].between(1320.0, 45000.0).all(), "Rendas fora do intervalo"
assert df["portabilidade_salario"].isin(["Sim", "Não"]).all(), "Valores inválidos em portabilidade"

# ---------------------------------------------------------------------------
# 5. Exportação para CSV (UTF-8-BOM para compatibilidade com Excel no Windows)
# ---------------------------------------------------------------------------

# Cria o diretório de saída se não existir
output_dir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(output_dir, exist_ok=True)

output_path = os.path.join(output_dir, "clientes_banco_digital.csv")

# utf-8-sig = UTF-8 com BOM — garante acentos corretos ao abrir no Excel
df.to_csv(output_path, index=False, encoding="utf-8-sig", sep=",")

print(f"\n✅ Arquivo gerado: {output_path}")
print(f"   Registros: {len(df)}")
print(f"   Colunas: {list(df.columns)}")

# ---------------------------------------------------------------------------
# 6. Estatísticas de distribuição para validação
# ---------------------------------------------------------------------------

print("\n--- Estatísticas de distribuição ---")
print(f"  Renda mensal     — min: R$ {df['renda_mensal'].min():,.2f}  "
      f"| mediana: R$ {df['renda_mensal'].median():,.2f}  "
      f"| max: R$ {df['renda_mensal'].max():,.2f}")

print(f"  Score Serasa     — min: {df['score_serasa'].min()}  "
      f"| mediana: {df['score_serasa'].median()}  "
      f"| max: {df['score_serasa'].max()}")

print(f"  Rec. Investidos  — zeros: {(df['recursos_investidos'] == 0).sum()} clientes  "
      f"| mediana (não-zero): R$ "
      f"{df.loc[df['recursos_investidos'] > 0, 'recursos_investidos'].median():,.2f}")

print(f"  Portabilidade    — Sim: {(df['portabilidade_salario'] == 'Sim').sum()}  "
      f"| Não: {(df['portabilidade_salario'] == 'Não').sum()}")

# ---------------------------------------------------------------------------
# 7. Preview das primeiras 5 linhas
# ---------------------------------------------------------------------------

print("\n--- Preview: primeiras 5 linhas ---")
# Formata valores monetários para exibição no preview
df_preview = df.head(5).copy()
df_preview["renda_mensal"] = df_preview["renda_mensal"].apply(
    lambda x: f"R$ {x:,.2f}"
)
df_preview["recursos_investidos"] = df_preview["recursos_investidos"].apply(
    lambda x: f"R$ {x:,.2f}"
)
print(df_preview.to_string(index=False))
print("\n" + "=" * 60)
print("Geração concluída com sucesso.")
print("=" * 60)
```

---

## 8. Instrução para o Modo Agent

Ao entrar no modo Agent, executar:

1. Criar `produto-legado-was/docs/walkthrough/gerar_clientes.py` com o código da seção 7
2. Criar diretório `produto-legado-was/docs/walkthrough/data/`
3. Executar `python gerar_clientes.py` para gerar `clientes_banco_digital.csv`
4. Exibir o preview das primeiras 5 linhas no chat
5. Atualizar status das Sub-Tarefas 1 e 2 para `[x] done`
