"""
gerar_clientes.py
=================
Script de geração de base de dados fictícia com 200 clientes brasileiros
para uso no desafio de banco digital com agentes de IA (IBM Orchestrate).

Formato de saída: CSV (UTF-8-BOM) — recomendado por:
  - Consumo nativo por pandas.read_csv() sem dependências extras
  - Compatibilidade universal com IBM Orchestrate, Excel, Google Sheets
  - Legibilidade humana imediata para validação
  - Estrutura plana (tabular) sem necessidade de JSON hierárquico

Dependências: apenas bibliotecas padrão Python + pandas
  - random, math, os, csv, datetime: stdlib (sem instalação)
  - pandas: pip install pandas  (geralmente já disponível)

Autor: IBM Bob (Agente de IA)
"""

import random
import math
import os
import csv
from datetime import date, timedelta

import pandas as pd

# ---------------------------------------------------------------------------
# 1. Configuração: seed fixo garante reprodutibilidade
#    Mesma seed => mesmos 200 registros sempre
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)

TOTAL_CLIENTES = 200

# ---------------------------------------------------------------------------
# 2. Banco de nomes brasileiros fictícios embutido
#    Nomes comuns no Brasil — combinados aleatoriamente para gerar
#    nomes completos variados. Não representam pessoas reais.
# ---------------------------------------------------------------------------

PRIMEIROS_NOMES_M = [
    "Lucas", "Gabriel", "Matheus", "Guilherme", "Rafael",
    "Pedro", "Thiago", "Rodrigo", "Felipe", "Bruno",
    "Eduardo", "Leonardo", "Fernando", "Carlos", "Marcelo",
    "André", "Paulo", "Diego", "Vinicius", "Alexandre",
    "Henrique", "Ricardo", "Daniel", "João", "Leandro",
    "Caio", "Igor", "Gustavo", "Renato", "Fábio",
    "Márcio", "Sergio", "Rogério", "Kleber", "Edson",
    "Wilson", "Nelson", "Cláudio", "Antônio", "Roberto",
]

PRIMEIROS_NOMES_F = [
    "Ana", "Maria", "Fernanda", "Juliana", "Amanda",
    "Camila", "Bruna", "Letícia", "Vanessa", "Priscila",
    "Larissa", "Mariana", "Beatriz", "Débora", "Renata",
    "Carla", "Patrícia", "Adriana", "Cristina", "Sandra",
    "Luciana", "Roberta", "Simone", "Tatiana", "Viviane",
    "Aline", "Gabriela", "Natália", "Isabela", "Rafaela",
    "Claudia", "Denise", "Eliana", "Flávia", "Helena",
    "Jéssica", "Karina", "Lívia", "Mônica", "Nathalia",
]

SOBRENOMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Lima",
    "Pereira", "Costa", "Ferreira", "Rodrigues", "Almeida",
    "Nascimento", "Carvalho", "Freitas", "Gomes", "Martins",
    "Araújo", "Melo", "Barbosa", "Cardoso", "Moraes",
    "Ribeiro", "Pinto", "Moreira", "Correia", "Nunes",
    "Mendes", "Teixeira", "Monteiro", "Cavalcante", "Machado",
    "Dias", "Castro", "Andrade", "Rocha", "Pires",
    "Borges", "Figueiredo", "Cunha", "Miranda", "Lopes",
    "Campos", "Vieira", "Ramos", "Xavier", "Rezende",
    "Guimarães", "Batista", "Tavares", "Duarte", "Azevedo",
]


def gerar_nome() -> str:
    """
    Combina aleatoriamente primeiro nome (masculino ou feminino) com
    dois sobrenomes distintos para criar um nome completo brasileiro.
    """
    # Escolhe gênero 50/50
    if random.random() < 0.5:
        primeiro = random.choice(PRIMEIROS_NOMES_M)
    else:
        primeiro = random.choice(PRIMEIROS_NOMES_F)
    # Dois sobrenomes distintos para naturalidade
    sobrenome1, sobrenome2 = random.sample(SOBRENOMES, 2)
    return f"{primeiro} {sobrenome1} {sobrenome2}"


# ---------------------------------------------------------------------------
# 3. Geração de CPF fictício com dígitos verificadores oficiais
# ---------------------------------------------------------------------------

def _calcular_digitos_verificadores(cpf9: str) -> str:
    """
    Calcula os 2 dígitos verificadores pelo algoritmo oficial da Receita
    Federal. Os CPFs passam em validações de formato mas são fictícios —
    não pertencem a pessoas reais cadastradas na Receita Federal.
    """
    # Primeiro dígito verificador
    digitos = [int(d) for d in cpf9]
    soma = sum(d * (10 - i) for i, d in enumerate(digitos))
    resto = soma % 11
    d1 = 0 if resto < 2 else 11 - resto

    # Segundo dígito verificador
    digitos.append(d1)
    soma = sum(d * (11 - i) for i, d in enumerate(digitos))
    resto = soma % 11
    d2 = 0 if resto < 2 else 11 - resto

    return f"{d1}{d2}"


def gerar_cpf() -> str:
    """
    Gera um CPF fictício no formato 000.000.000-00.
    Evita sequências inválidas (000...000, 111...111 etc.).
    """
    sequencias_invalidas = {str(d) * 9 for d in range(10)}
    while True:
        cpf9 = "".join([str(random.randint(0, 9)) for _ in range(9)])
        if cpf9 not in sequencias_invalidas:
            break
    dvs = _calcular_digitos_verificadores(cpf9)
    return f"{cpf9[:3]}.{cpf9[3:6]}.{cpf9[6:9]}-{dvs}"


# ---------------------------------------------------------------------------
# 4. Geração de data de nascimento (18 a 80 anos)
# ---------------------------------------------------------------------------

def gerar_data_nascimento() -> str:
    """
    Gera data de nascimento aleatória entre 18 e 80 anos atrás.
    Retorna string no formato DD/MM/AAAA.
    """
    hoje = date.today()
    data_min = date(hoje.year - 80, hoje.month, hoje.day)
    data_max = date(hoje.year - 18, hoje.month, hoje.day)
    delta = (data_max - data_min).days
    nascimento = data_min + timedelta(days=random.randint(0, delta))
    return nascimento.strftime("%d/%m/%Y")


# ---------------------------------------------------------------------------
# 5. Geração de renda mensal com distribuição log-normal
#    Simulada via Box-Muller transform (sem numpy)
# ---------------------------------------------------------------------------

def _lognormal(mu: float, sigma: float) -> float:
    """Amostra de distribuição log-normal via Box-Muller."""
    u1 = random.random()
    u2 = random.random()
    # Transformação Box-Muller para normal padrão
    z = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
    return math.exp(mu + sigma * z)


def gerar_renda_mensal() -> float:
    """
    Renda mensal com distribuição log-normal truncada.
    Faixa: R$ 1.320,00 (salário mínimo 2026) a R$ 45.000,00.
    Concentração realista em R$ 2.500 a R$ 8.000.
    """
    renda_min, renda_max = 1320.0, 45000.0
    # mu=8.2, sigma=0.9 calibrados para concentrar na faixa médio-baixa
    for _ in range(10000):
        v = _lognormal(8.2, 0.9)
        if renda_min <= v <= renda_max:
            return round(v, 2)
    return round(renda_min + random.random() * (renda_max - renda_min), 2)


# ---------------------------------------------------------------------------
# 6. Geração de score Serasa com distribuição beta aproximada
#    Beta(4,3) aproximada via método de rejeição simples
# ---------------------------------------------------------------------------

def _beta_sample(a: float, b: float) -> float:
    """
    Amostra de Beta(a, b) via método de Johnk (composição de gammas
    aproximada por somas de uniformes — adequado para a, b inteiros).
    """
    # Para a=4, b=3 inteiros: usa a propriedade que Beta(a,b) = Ga/(Ga+Gb)
    # onde Ga ~ Gamma(a) e Gb ~ Gamma(b), e Gamma(n) = soma de n Exp(1)
    def gamma_int(n: int) -> float:
        # Gamma(n) = -sum of log(Ui) para n uniformes
        return -sum(math.log(random.random()) for _ in range(n))

    ga = gamma_int(int(a))
    gb = gamma_int(int(b))
    return ga / (ga + gb)


def gerar_score_serasa() -> int:
    """
    Score de crédito entre 0 e 1000.
    Distribuição Beta(4,3)*1000: concentração em 400-750,
    espelhando o perfil real do mercado brasileiro.
    """
    valor = int(_beta_sample(4, 3) * 1000)
    return max(0, min(1000, valor))


# ---------------------------------------------------------------------------
# 7. Geração de recursos investidos (20% de zeros)
# ---------------------------------------------------------------------------

def gerar_recursos_investidos() -> float:
    """
    Total investido no banco digital.
    ~20% dos clientes têm R$ 0,00 (conta sem investimentos).
    Demais: R$ 100,00 a R$ 500.000,00 via log-normal.
    """
    if random.random() < 0.20:
        return 0.0
    for _ in range(10000):
        v = _lognormal(10.0, 1.5)
        if 100.0 <= v <= 500000.0:
            return round(v, 2)
    return round(100.0 + random.random() * (500000.0 - 100.0), 2)


# ---------------------------------------------------------------------------
# 8. Geração de portabilidade de salário (~50% Sim / ~50% Não)
# ---------------------------------------------------------------------------

def gerar_portabilidade() -> str:
    """Retorna 'Sim' ou 'Não' com probabilidade ~50% cada."""
    return "Sim" if random.random() < 0.50 else "Não"


# ---------------------------------------------------------------------------
# 9. Geração dos 200 registros
# ---------------------------------------------------------------------------

print("=" * 60)
print("Gerando base de dados ficticia -- 200 clientes")
print("=" * 60)

registros = []
for _ in range(TOTAL_CLIENTES):
    registros.append({
        "nome": gerar_nome(),
        "cpf": gerar_cpf(),
        "data_nascimento": gerar_data_nascimento(),
        "renda_mensal": gerar_renda_mensal(),
        "score_serasa": gerar_score_serasa(),
        "recursos_investidos": gerar_recursos_investidos(),
        "portabilidade_salario": gerar_portabilidade(),
    })

# ---------------------------------------------------------------------------
# 10. Construção do DataFrame e validações de integridade
# ---------------------------------------------------------------------------

df = pd.DataFrame(registros)

assert len(df) == 200, "ERRO: numero de registros incorreto"
assert df["cpf"].nunique() == 200, "ERRO: CPFs duplicados"
assert df["score_serasa"].between(0, 1000).all(), "ERRO: scores fora do intervalo"
assert df["renda_mensal"].between(1320.0, 45000.0).all(), "ERRO: rendas fora do intervalo"
assert df["portabilidade_salario"].isin(["Sim", "Não"]).all(), "ERRO: valor invalido em portabilidade"

print("Validacoes de integridade: OK")

# ---------------------------------------------------------------------------
# 11. Exportação para CSV (UTF-8-BOM para compatibilidade com Excel)
# ---------------------------------------------------------------------------

output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "clientes_banco_digital.csv")

# utf-8-sig = UTF-8 com BOM -- acentos exibidos corretamente no Excel
df.to_csv(output_path, index=False, encoding="utf-8-sig", sep=",")

print(f"\nArquivo gerado: {output_path}")
print(f"   Registros: {len(df)}")
print(f"   Colunas  : {list(df.columns)}")

# ---------------------------------------------------------------------------
# 12. Estatísticas de distribuição para validação rápida
# ---------------------------------------------------------------------------

print("\n--- Estatisticas de distribuicao ---")
print(f"  Renda mensal     -- min: R$ {df['renda_mensal'].min():,.2f}"
      f" | mediana: R$ {df['renda_mensal'].median():,.2f}"
      f" | max: R$ {df['renda_mensal'].max():,.2f}")
print(f"  Score Serasa     -- min: {df['score_serasa'].min()}"
      f" | mediana: {df['score_serasa'].median()}"
      f" | max: {df['score_serasa'].max()}")
zeros = (df["recursos_investidos"] == 0).sum()
mediana_inv = df.loc[df["recursos_investidos"] > 0, "recursos_investidos"].median()
print(f"  Rec. Investidos  -- zeros: {zeros} clientes"
      f" | mediana (nao-zero): R$ {mediana_inv:,.2f}")
sim = (df["portabilidade_salario"] == "Sim").sum()
nao = (df["portabilidade_salario"] == "Não").sum()
print(f"  Portabilidade    -- Sim: {sim} | Nao: {nao}")

# ---------------------------------------------------------------------------
# 13. Preview das primeiras 5 linhas (formatado)
# ---------------------------------------------------------------------------

print("\n--- Preview: primeiras 5 linhas ---")
df_preview = df.head(5).copy()
df_preview["renda_mensal"] = df_preview["renda_mensal"].apply(lambda x: f"R$ {x:,.2f}")
df_preview["recursos_investidos"] = df_preview["recursos_investidos"].apply(lambda x: f"R$ {x:,.2f}")
print(df_preview.to_string(index=False))

print("\n" + "=" * 60)
print("Geracao concluida com sucesso.")
print("=" * 60)
