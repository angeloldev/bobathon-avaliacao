# Aurora Bank — Motor de Decisão de Crédito com Agentes de IA

**Equipe:** Equipe Fênix · BRB
**Evento:** Bob-a-thon BRB — IBM
**Duração:** 2 horas
**Ferramentas obrigatórias:** IBM Bob + IBM watsonx Orchestrate

---

## O problema

O Aurora Bank opera um sistema de concessão de crédito com 22 anos de operação. Ele decide quem recebe crédito e quanto — sem registrar o raciocínio, sem explicar ao cliente, sem deixar rastro auditável. Quatro milhões de decisões por mês. Zero justificativas entregues ao regulador.

Esta solução substitui essa caixa-preta por agentes de IA que decidem com transparência.

---

## O que a solução faz

```
Usuário
  │  envia pedido de crédito
  ▼
[Agente Orquestrador]  ← único agente com quem o usuário fala
  │
  ├─→ [Agente Carteira]   "renda + score → qual produto?"
  │         └─→ resposta estruturada com produto e elegíveis
  │
  └─→ [Agente Cliente]    "dados + produto → decisão + justificativa + JSON"
            └─→ aprovado/negado + limite + bloco JSON auditável
  │
  ▼
Resposta consolidada ao usuário
(justificativa em português + registro JSON completo)
```

| Etapa | Agente | O que acontece |
|-------|--------|---------------|
| 1 | **Orquestrador** | Recebe o pedido, coleta dados faltantes, confirma campos |
| 2 | **Orquestrador → Carteira** | Delega: "qual produto para renda X e score Y?" |
| 3 | **Agente Carteira** | Retorna produto sugerido + lista de elegíveis |
| 4 | **Orquestrador → Cliente** | Delega: dados completos + resultado do Agente Carteira |
| 5 | **Agente Cliente** | Aplica 5 regras, calcula limite, emite decisão |
| 6 | **Agente Cliente** | Gera justificativa em português claro + bloco JSON auditável |
| 7 | **Orquestrador** | Consolida e entrega tudo ao usuário |

---

## Estrutura do repositório

```
aurora-bank/
├── README.md                               ← este arquivo
├── exemplo_pedido.json                     ← JSON de exemplo para o simulador
├── simular_pedido.py                       ← simulador local (gera evidencias/*.json)
├── gerar_clientes.py                       ← gerador da base fictícia (seed 42)
│
├── data/
│   ├── clientes_banco_digital.csv          ← 200 clientes fictícios (entrada)
│   └── produtos_cartao_credito.csv         ← catálogo de produtos do banco
│
├── src/
│   ├── decisao_credito.py                  ← lógica central de decisão (Agente Cliente)
│   ├── produtos_banco.py                   ← catálogo e seleção de produtos (Agente Carteira)
│   └── api.py                              ← API REST (stdlib, sem dependências extras)
│
├── evidencias/
│   ├── agente_orquestrador_instrucoes.md   ← system prompt do Agente Orquestrador ← cole no Orchestrate
│   ├── agente_carteira_instrucoes.md       ← system prompt do Agente Carteira      ← cole no Orchestrate
│   ├── agente_cliente_instrucoes.md        ← system prompt do Agente Cliente       ← cole no Orchestrate
│   └── decisao_*.json                      ← registros auditáveis gerados localmente
│
└── docs/walkthrough/
    └── plan_BOBATHON-AURORA-...md          ← walkthrough técnico completo
```

---

## Regras de negócio implementadas

| Regra | Critério | Efeito |
|-------|----------|--------|
| Idade máxima | ≤ 80 anos | Bloqueante |
| Score mínimo | ≥ 300 (Serasa) | Bloqueante |
| Renda mínima | ≥ R$ 1.320/mês | Bloqueante |
| Limite máximo | ≤ 2,5× renda + bônus de investimentos (até +20%) | Bloqueante |
| Comprometimento | Parcela ≤ 40% da renda | Bloqueante |
| Portabilidade | +10% no limite aprovado | Não bloqueante |
| Relacionamento | Investimentos geram bônus no teto | Não bloqueante |

**Produtos disponíveis:** Internacional · Gold · Platinum · Black · Diamante  
Seleção automática pelo Agente Carteira com base em renda e score.

---

## Como usar

> O cliente informa **apenas CPF e valor desejado**. Renda, score, investimentos e demais dados são buscados automaticamente na base interna.

### Modo 1 — Simulador interativo (recomendado para demonstração)

```bash
python simular_pedido.py
# Pergunta: CPF e Valor desejado — só isso
```

### Modo 2 — Argumentos diretos

```bash
python simular_pedido.py --cpf "116.155.940-00" --valor 20000
```

### Modo 4 — Demo com casos de teste pré-configurados

```bash
python src/decisao_credito.py
```

Roda 4 casos (aprovado, negado por valor, negado por score, negado por idade).

### Subir a API REST local (opcional)

```bash
python src/api.py
# Servidor em http://localhost:5000
```

**Endpoints:**
```
GET  /health              → status do serviço
GET  /produtos            → catálogo de produtos ativos
POST /analisar-credito    → análise completa de um pedido
```

### Regenerar a base de clientes

```bash
python gerar_clientes.py
# Gera data/clientes_banco_digital.csv com 200 registros (seed fixo = 42)
```

---

## Uso do IBM Bob

O IBM Bob foi utilizado em todas as etapas de desenvolvimento:

- **Geração da base de dados:** planejamento e código do `gerar_clientes.py` — distribuições log-normal, beta, CPF com dígitos verificadores
- **Arquitetura da solução:** definição das 7 etapas, separação de responsabilidades entre Agente Carteira e Agente Cliente
- **Lógica de decisão:** refinamento iterativo das regras de negócio (`decisao_credito.py`) — teto de 2,5× renda, regra de idade ≤ 80 anos, cálculo de limite com bônus
- **Integração do catálogo:** leitura e parsing do `produtos_cartao_credito.csv` no `produtos_banco.py`
- **Instruções dos agentes:** geração das instruções em linguagem natural para entrada no Orchestrate
- **Documentação:** README, walkthrough e registro de impedimentos

O histórico completo de interações com o Bob está disponível em `bob-task-5a69269158848d3464dcf2edd4274e3e-2026-09-10.md`.

---

## Uso do IBM watsonx Orchestrate

Três agentes foram configurados no IBM watsonx Orchestrate com instruções em linguagem natural (system prompts):

| Agente | Arquivo de instrução | Papel |
|--------|---------------------|-------|
| **Agente Orquestrador** | `evidencias/agente_orquestrador_instrucoes.md` | Ponto de entrada — coordena os outros dois |
| **Agente Carteira** | `evidencias/agente_carteira_instrucoes.md` | Seleciona produto por renda + score |
| **Agente Cliente** | `evidencias/agente_cliente_instrucoes.md` | Aplica regras, decide, gera justificativa + JSON |

O usuário fala **apenas com o Orquestrador**. Ele delega para Carteira e Cliente na sequência correta e entrega a resposta consolidada — decisão em texto + bloco JSON auditável copiável.

**Impedimento registrado:** O Orchestrate ADK para tools não estava disponível no ambiente do evento. Os agentes se comunicam via delegação natural de conversa. Em uma implementação completa com ADK, o Orquestrador chamaria as tools `consultar_produto` e `analisar_credito` via API REST.

---

## Registro auditável

Cada decisão gera um arquivo JSON em `evidencias/` com:
- Timestamp da decisão
- Dados completos do cliente analisados
- Todas as regras avaliadas (com resultado: aprovado/negado por regra)
- Alertas não-bloqueantes considerados
- Produto sugerido pelo Agente Carteira
- Decisão final e limite aprovado

Isso resolve diretamente o problema do Aurora Bank: **zero justificativas entregues ao regulador** → **rastro auditável completo de cada decisão**.

---

## Dependências

```
Python 3.10+
pandas        (geração da base)
numpy         (distribuições estatísticas)
faker         (nomes brasileiros)
```

Todos os módulos da solução principal (`decisao_credito.py`, `produtos_banco.py`, `api.py`) usam apenas a **stdlib do Python** — sem instalação adicional.
