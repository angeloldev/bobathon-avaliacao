"""
Mock API - E-commerce Database
Simula os endpoints de Clientes e Pedidos para desenvolvimento e testes.
Inclui documentação OpenAPI/Swagger via flasgger.
"""

import os
from flask import Flask, jsonify, request
from flasgger import Swagger, swag_from

app = Flask(__name__)

# Swagger UI disponível em /apidocs
app.config["SWAGGER"] = {
    "title": "Customer Agent — E-commerce API",
    "uiversion": 3,
    "version": "1.0.0",
    "description": "API pública de clientes e pedidos para o Customer Agent.",
    "termsOfService": "",
}
swagger = Swagger(app, template={
    "info": {
        "title": "Customer Agent API",
        "description": "API de clientes e pedidos do e-commerce.",
        "version": "1.0.0",
    },
    "host": os.environ.get("SWAGGER_HOST", "localhost:5000"),
    "schemes": ["http", "https"],
})

# ---------------------------------------------------------------------------
# Dados fictícios
# ---------------------------------------------------------------------------

CUSTOMERS = {
    "C001": {
        "id": "C001",
        "name": "Ana Silva",
        "email": "ana.silva@email.com",
        "since": "2021-03-10",
        "tier": "gold",
    },
    "C002": {
        "id": "C002",
        "name": "Bruno Costa",
        "email": "bruno.costa@email.com",
        "since": "2022-07-22",
        "tier": "silver",
    },
    "C003": {
        "id": "C003",
        "name": "Carla Mendes",
        "email": "carla.mendes@email.com",
        "since": "2023-01-05",
        "tier": "bronze",
    },
    "C004": {
        "id": "C004",
        "name": "Diego Rocha",
        "email": "diego.rocha@email.com",
        "since": "2020-11-18",
        "tier": "gold",
    },
}

ORDERS = {
    "C001": [
        {"order_id": "O1001", "date": "2024-11-15", "status": "delivered",   "total": 349.90, "items": ["Tênis Running Pro", "Meia Esportiva (3x)"]},
        {"order_id": "O1002", "date": "2025-01-08", "status": "processing",  "total": 129.99, "items": ["Camiseta Dry-Fit"]},
    ],
    "C002": [
        {"order_id": "O2001", "date": "2024-12-20", "status": "delivered",   "total": 89.90,  "items": ["Boné Aba Curva"]},
        {"order_id": "O2002", "date": "2025-02-14", "status": "shipped",     "total": 210.00, "items": ["Shorts Treino", "Luvas de Musculação"]},
    ],
    "C003": [
        {"order_id": "O3001", "date": "2025-03-01", "status": "cancelled",   "total": 560.00, "items": ["Bicicleta Ergométrica"]},
    ],
    "C004": [
        {"order_id": "O4001", "date": "2024-10-05", "status": "delivered",   "total": 1200.00, "items": ["Smartwatch Sport X"]},
        {"order_id": "O4002", "date": "2024-12-31", "status": "delivered",   "total": 450.50,  "items": ["Kit Halteres 5kg-10kg"]},
        {"order_id": "O4003", "date": "2025-04-10", "status": "processing",  "total": 199.00,  "items": ["Corda de Pular Pro", "Tapete Yoga"]},
    ],
}

# ---------------------------------------------------------------------------
# Rotas
# ---------------------------------------------------------------------------

@app.get("/customers")
def list_customers():
    """
    Lista todos os clientes.
    ---
    tags: [Clientes]
    responses:
      200:
        description: Lista de clientes
        schema:
          type: array
          items:
            properties:
              id:    {type: string, example: C001}
              name:  {type: string, example: Ana Silva}
              email: {type: string, example: ana@email.com}
              since: {type: string, example: "2021-03-10"}
              tier:  {type: string, example: gold}
    """
    return jsonify(list(CUSTOMERS.values()))


@app.get("/customers/<customer_id>")
def get_customer(customer_id: str):
    """
    Retorna um cliente pelo ID.
    ---
    tags: [Clientes]
    parameters:
      - name: customer_id
        in: path
        type: string
        required: true
        example: C001
    responses:
      200:
        description: Dados do cliente
      404:
        description: Cliente não encontrado
    """
    customer = CUSTOMERS.get(customer_id.upper())
    if not customer:
        return jsonify({"error": f"Customer '{customer_id}' not found"}), 404
    return jsonify(customer)


@app.get("/customers/<customer_id>/orders")
def get_customer_orders(customer_id: str):
    """
    Retorna todos os pedidos de um cliente.
    ---
    tags: [Pedidos]
    parameters:
      - name: customer_id
        in: path
        type: string
        required: true
        example: C001
    responses:
      200:
        description: Lista de pedidos do cliente
      404:
        description: Cliente não encontrado
    """
    cid = customer_id.upper()
    if cid not in CUSTOMERS:
        return jsonify({"error": f"Customer '{customer_id}' not found"}), 404
    orders = ORDERS.get(cid, [])
    return jsonify(orders)


@app.get("/orders/<order_id>")
def get_order(order_id: str):
    """
    Retorna um pedido pelo ID.
    ---
    tags: [Pedidos]
    parameters:
      - name: order_id
        in: path
        type: string
        required: true
        example: O1001
    responses:
      200:
        description: Detalhes do pedido
      404:
        description: Pedido não encontrado
    """
    for orders in ORDERS.values():
        for order in orders:
            if order["order_id"] == order_id.upper():
                return jsonify(order)
    return jsonify({"error": f"Order '{order_id}' not found"}), 404


@app.get("/health")
def health():
    """
    Health check.
    ---
    tags: [Sistema]
    responses:
      200:
        description: API online
    """
    return jsonify({"status": "ok"})


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("🛒  Mock API running on http://localhost:5000")
    app.run(port=5000, debug=False)
