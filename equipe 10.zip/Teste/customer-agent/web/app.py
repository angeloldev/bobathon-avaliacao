"""
Interface Web — Customer Agent
Painel de controle para execução do agente em lote e visualização de resultados.
"""

import os
import json
import threading
from pathlib import Path
from datetime import datetime

import requests
from flask import Flask, render_template, jsonify, request, Response, stream_with_context

app = Flask(__name__)

API_BASE = os.environ.get("API_BASE", "http://localhost:5000")
OUTPUT_DIR = Path(os.environ.get("OUTPUT_DIR", "output"))
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# Estado global simples do job em execução
_job_lock = threading.Lock()
_job_running = False
_job_log: list[str] = []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _api_get(path: str):
    resp = requests.get(f"{API_BASE}{path}", timeout=10)
    resp.raise_for_status()
    return resp.json()


def _log(msg: str):
    ts = datetime.utcnow().strftime("%H:%M:%S")
    _job_log.append(f"[{ts}] {msg}")


# ---------------------------------------------------------------------------
# Rotas — Dashboard
# ---------------------------------------------------------------------------

@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/customers")
def customers():
    try:
        data = _api_get("/customers")
        return jsonify({"ok": True, "data": data})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.get("/api/customers/<customer_id>/orders")
def customer_orders(customer_id: str):
    try:
        customer = _api_get(f"/customers/{customer_id}")
        orders = _api_get(f"/customers/{customer_id}/orders")
        return jsonify({"ok": True, "customer": customer, "orders": orders})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.get("/api/results")
def results():
    """Lista os arquivos de saída já gerados."""
    report_file = OUTPUT_DIR / "batch_report.json"
    if not report_file.exists():
        return jsonify({"ok": True, "data": []})
    try:
        data = json.loads(report_file.read_text(encoding="utf-8"))
        return jsonify({"ok": True, "data": data})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.get("/api/results/<customer_id>")
def result_detail(customer_id: str):
    """Retorna o texto da mensagem gerada para um cliente."""
    txt_file = OUTPUT_DIR / f"{customer_id.upper()}.txt"
    if not txt_file.exists():
        return jsonify({"ok": False, "error": "Not found"}), 404
    return jsonify({"ok": True, "content": txt_file.read_text(encoding="utf-8")})


# ---------------------------------------------------------------------------
# Rotas — Execução do Agente em Lote (SSE streaming de log)
# ---------------------------------------------------------------------------

def _run_batch_job(api_key: str):
    """Executa o agente em lote em thread separada, populando _job_log."""
    global _job_running, _job_log

    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from agent.batch_agent import fetch_all_customers, fetch_customer_orders, generate_response
    import anthropic

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    _job_log.clear()

    try:
        _log("Buscando clientes na API...")
        customers = fetch_all_customers()
        _log(f"{len(customers)} clientes encontrados.")

        claude = anthropic.Anthropic(api_key=api_key)
        results = []

        for i, customer in enumerate(customers, 1):
            cid = customer["id"]
            _log(f"[{i}/{len(customers)}] Processando {customer['name']} ({cid})...")
            try:
                orders = fetch_customer_orders(cid)
                text = generate_response(claude, customer, orders)
                results.append({
                    "customer_id": cid,
                    "customer_name": customer["name"],
                    "customer_email": customer["email"],
                    "generated_at": datetime.utcnow().isoformat() + "Z",
                    "message": text,
                })
                out = OUTPUT_DIR / f"{cid}.txt"
                out.write_text(
                    f"Para: {customer['email']}\n"
                    f"Assunto: Olá, {customer['name'].split()[0]}! Atualização dos seus pedidos 🛒\n\n"
                    f"{text}\n",
                    encoding="utf-8",
                )
                _log(f"✅ Mensagem de {cid} gerada.")
            except Exception as e:
                _log(f"❌ Erro em {cid}: {e}")
                results.append({"customer_id": cid, "customer_name": customer["name"], "error": str(e)})

        report = OUTPUT_DIR / "batch_report.json"
        report.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        _log(f"Relatório salvo. {len([r for r in results if 'message' in r])} mensagens geradas.")
        _log("__DONE__")
    except Exception as e:
        _log(f"❌ Falha geral: {e}")
        _log("__DONE__")
    finally:
        _job_running = False


@app.post("/api/run")
def run_batch():
    global _job_running, _job_log
    with _job_lock:
        if _job_running:
            return jsonify({"ok": False, "error": "Já existe um job em execução."}), 409
        api_key = request.json.get("api_key") or ANTHROPIC_API_KEY
        if not api_key:
            return jsonify({"ok": False, "error": "ANTHROPIC_API_KEY não configurada."}), 400
        _job_running = True
        _job_log = []
        t = threading.Thread(target=_run_batch_job, args=(api_key,), daemon=True)
        t.start()
    return jsonify({"ok": True})


@app.get("/api/run/log")
def run_log_stream():
    """SSE: transmite o log do job em tempo real."""
    def generate():
        sent = 0
        import time
        while True:
            if len(_job_log) > sent:
                for line in _job_log[sent:]:
                    yield f"data: {json.dumps(line)}\n\n"
                sent = len(_job_log)
                if _job_log and _job_log[-1] == "__DONE__":
                    break
            elif not _job_running and sent == len(_job_log):
                break
            time.sleep(0.4)

    return Response(stream_with_context(generate()), mimetype="text/event-stream")


@app.get("/api/status")
def status():
    return jsonify({"running": _job_running, "log_lines": len(_job_log)})


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
