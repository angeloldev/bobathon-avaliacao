"""
Agente de Processamento em Lote - E-commerce Customer Agent
Consulta a API via MCP server e gera respostas personalizadas por cliente usando Claude.
"""

import json
import asyncio
import argparse
import sys
from pathlib import Path
from datetime import datetime

import anthropic
import requests

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------

API_BASE = "http://localhost:5000"

SYSTEM_PROMPT = """Você é um especialista em atendimento ao cliente de uma loja de e-commerce \
esportivo. Sua missão é redigir mensagens de relacionamento personalizadas, calorosas e objetivas \
para cada cliente, com base exclusivamente nos dados do perfil e do histórico de pedidos fornecidos.

## Identidade e tom
- Assine como "Equipe de Atendimento — SportStore".
- Tom: cordial, empático e profissional. Nunca informal demais; nunca frio ou burocrático.
- Língua: português brasileiro, sem jargões técnicos.

## Estrutura obrigatória (máximo 3 parágrafos)
1. **Saudação personalizada** — cumprimente pelo primeiro nome e, se aplicável, reconheça a \
   fidelidade (clientes com tier "gold" merecem agradecimento explícito pela lealdade à marca).
2. **Resumo do(s) pedido(s)** — mencione cada pedido pelo ID e pelos itens principais, indicando \
   o status de forma clara e no seguinte padrão:
   - `delivered` → "entregue com sucesso" + ofereça avaliação do produto ou suporte pós-venda.
   - `processing` → "em processamento" + informe que o prazo de envio será confirmado por e-mail.
   - `shipped` → "a caminho" + oriente o cliente a acompanhar pelo site ou app.
   - `cancelled` → "cancelado" + ofereça auxílio para re-pedido ou esclarecimento sobre reembolso.
3. **Encerramento** — convide o cliente a entrar em contato em caso de dúvidas e, se houver pedido \
   entregue ou cancelado, mencione brevemente a facilidade de novas compras na loja.

## Restrições
- Não invente dados, datas, valores ou itens além do que foi fornecido.
- Não repita o endereço de e-mail do cliente no corpo da mensagem.
- Não use markdown (negrito, asterisco, traço de lista) no texto final da mensagem — o resultado \
  deve ser texto corrido, pronto para envio de e-mail.
- Se o cliente não tiver nenhum pedido registrado, informe gentilmente e convide-o a explorar \
  as novidades da loja.
"""


# ---------------------------------------------------------------------------
# Funções de acesso à API
# ---------------------------------------------------------------------------

def fetch_all_customers() -> list[dict]:
    """Busca todos os clientes na Mock API."""
    resp = requests.get(f"{API_BASE}/customers", timeout=10)
    resp.raise_for_status()
    return resp.json()


def fetch_customer_orders(customer_id: str) -> list[dict]:
    """Busca os pedidos de um cliente específico."""
    resp = requests.get(f"{API_BASE}/customers/{customer_id}/orders", timeout=10)
    resp.raise_for_status()
    return resp.json()


# ---------------------------------------------------------------------------
# Geração de resposta via Claude
# ---------------------------------------------------------------------------

def generate_response(client: anthropic.Anthropic, customer: dict, orders: list[dict]) -> str:
    """Gera uma mensagem personalizada para o cliente usando Claude."""

    user_message = f"""Gere uma mensagem personalizada para o seguinte cliente:

**Dados do Cliente:**
{json.dumps(customer, ensure_ascii=False, indent=2)}

**Histórico de Pedidos:**
{json.dumps(orders, ensure_ascii=False, indent=2)}

Redija a mensagem agora:"""

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=512,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )

    return message.content[0].text


# ---------------------------------------------------------------------------
# Processamento em lote
# ---------------------------------------------------------------------------

def run_batch(api_key: str, output_dir: Path) -> None:
    """Processa todos os clientes em lote e salva as respostas geradas."""

    output_dir.mkdir(parents=True, exist_ok=True)
    claude = anthropic.Anthropic(api_key=api_key)

    print("🔍  Buscando clientes na API...")
    customers = fetch_all_customers()
    print(f"✅  {len(customers)} clientes encontrados.\n")

    results = []

    for i, customer in enumerate(customers, 1):
        cid = customer["id"]
        name = customer["name"]
        print(f"[{i}/{len(customers)}] Processando: {name} ({cid})...")

        try:
            orders = fetch_customer_orders(cid)
            response_text = generate_response(claude, customer, orders)

            result = {
                "customer_id": cid,
                "customer_name": name,
                "customer_email": customer["email"],
                "generated_at": datetime.utcnow().isoformat() + "Z",
                "message": response_text,
            }
            results.append(result)

            # Salva arquivo individual por cliente
            output_file = output_dir / f"{cid}.txt"
            output_file.write_text(
                f"Para: {customer['email']}\n"
                f"Assunto: Olá, {name.split()[0]}! Atualização dos seus pedidos 🛒\n\n"
                f"{response_text}\n",
                encoding="utf-8",
            )
            print(f"   ✉️  Mensagem salva em {output_file}")

        except Exception as e:
            print(f"   ❌  Erro ao processar {cid}: {e}", file=sys.stderr)
            results.append({"customer_id": cid, "customer_name": name, "error": str(e)})

    # Salva relatório consolidado JSON
    report_file = output_dir / "batch_report.json"
    report_file.write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\n📄  Relatório consolidado salvo em {report_file}")
    print(f"🎉  Processamento concluído: {len([r for r in results if 'message' in r])} mensagens geradas.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Agente de lote: gera mensagens personalizadas para clientes."
    )
    parser.add_argument(
        "--api-key",
        required=True,
        help="Chave de API da Anthropic (Claude).",
    )
    parser.add_argument(
        "--output",
        default="output",
        help="Diretório de saída das mensagens (padrão: ./output).",
    )
    args = parser.parse_args()

    run_batch(api_key=args.api_key, output_dir=Path(args.output))


if __name__ == "__main__":
    main()
