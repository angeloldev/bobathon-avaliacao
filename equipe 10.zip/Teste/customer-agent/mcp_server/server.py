"""
MCP Server - E-commerce Customer Agent
Expõe ferramentas para consultar a Mock API de clientes e pedidos.
Comunicação via stdio (protocolo MCP).
"""

import sys
import requests
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------

API_BASE = "http://localhost:5000"

app = Server("ecommerce-customer-agent")

# ---------------------------------------------------------------------------
# Ferramentas
# ---------------------------------------------------------------------------

@app.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="list_customers",
            description="Lista todos os clientes cadastrados no banco de dados.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        types.Tool(
            name="get_customer",
            description="Retorna os dados de um cliente pelo ID (ex: C001).",
            inputSchema={
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "description": "ID do cliente (ex: C001)",
                    }
                },
                "required": ["customer_id"],
            },
        ),
        types.Tool(
            name="get_customer_orders",
            description="Retorna todos os pedidos de um cliente pelo ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "description": "ID do cliente (ex: C001)",
                    }
                },
                "required": ["customer_id"],
            },
        ),
        types.Tool(
            name="get_order",
            description="Retorna os detalhes de um pedido específico pelo ID do pedido (ex: O1001).",
            inputSchema={
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "ID do pedido (ex: O1001)",
                    }
                },
                "required": ["order_id"],
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    try:
        if name == "list_customers":
            response = requests.get(f"{API_BASE}/customers", timeout=10)
            response.raise_for_status()
            return [types.TextContent(type="text", text=response.text)]

        elif name == "get_customer":
            cid = arguments["customer_id"]
            response = requests.get(f"{API_BASE}/customers/{cid}", timeout=10)
            response.raise_for_status()
            return [types.TextContent(type="text", text=response.text)]

        elif name == "get_customer_orders":
            cid = arguments["customer_id"]
            response = requests.get(f"{API_BASE}/customers/{cid}/orders", timeout=10)
            response.raise_for_status()
            return [types.TextContent(type="text", text=response.text)]

        elif name == "get_order":
            oid = arguments["order_id"]
            response = requests.get(f"{API_BASE}/orders/{oid}", timeout=10)
            response.raise_for_status()
            return [types.TextContent(type="text", text=response.text)]

        else:
            return [types.TextContent(type="text", text=f"Tool '{name}' not found.")]

    except requests.HTTPError as e:
        return [
            types.TextContent(
                type="text",
                text=f"API error {e.response.status_code}: {e.response.text}",
            )
        ]
    except Exception as e:
        return [types.TextContent(type="text", text=f"Error: {str(e)}")]


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
