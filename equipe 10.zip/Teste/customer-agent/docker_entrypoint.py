"""
Docker Entrypoint — Customer Agent
Inicia a Mock API em background e a Web UI em foreground.
"""

import os
import sys
import time
import subprocess
import urllib.request

def wait_for(url: str, retries: int = 15, delay: float = 1.0) -> bool:
    for _ in range(retries):
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(delay)
    return False


def main():
    api_port = os.environ.get("API_PORT", "5000")
    web_port = os.environ.get("PORT", "8080")

    # Inicia Mock API em background
    print(f"[entrypoint] Starting Mock API on port {api_port}...")
    api_env = {**os.environ, "FLASK_APP": "mock_api/app.py"}
    api_proc = subprocess.Popen(
        [sys.executable, "mock_api/app.py"],
        env={**os.environ, "PORT": api_port},
    )

    if not wait_for(f"http://localhost:{api_port}/health"):
        print("[entrypoint] ERROR: Mock API did not start in time.")
        api_proc.terminate()
        sys.exit(1)
    print("[entrypoint] Mock API ready.")

    # Inicia Web UI em foreground
    print(f"[entrypoint] Starting Web UI on port {web_port}...")
    web_env = {
        **os.environ,
        "API_BASE": f"http://localhost:{api_port}",
        "PORT": web_port,
    }
    web_proc = subprocess.Popen(
        [sys.executable, "web/app.py"],
        env=web_env,
    )

    try:
        web_proc.wait()
    except KeyboardInterrupt:
        pass
    finally:
        web_proc.terminate()
        api_proc.terminate()


if __name__ == "__main__":
    main()
