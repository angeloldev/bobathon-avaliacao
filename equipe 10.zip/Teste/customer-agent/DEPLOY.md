# Deploy Guide — Customer Agent

Guia de deployment do Customer Agent em infraestrutura cloud corporativa.
O projeto é containerizado via Docker e pode ser publicado em **AWS**, **Azure** ou **GCP**.

---

## Pré-requisitos

- [Docker](https://docs.docker.com/get-started/get-docker/) instalado na máquina de build
- Acesso a um container registry (ECR / ACR / Artifact Registry)
- Chave de API da Anthropic: `ANTHROPIC_API_KEY`

---

## 1. Build e Push da Imagem

```bash
# Acesse a pasta do projeto
cd customer-agent

# Build
docker build -t customer-agent:latest .

# Tag para o registry corporativo (substitua <REGISTRY> pela URL real)
docker tag customer-agent:latest <REGISTRY>/customer-agent:latest

# Push
docker push <REGISTRY>/customer-agent:latest
```

---

## 2. Execução com docker-compose (qualquer VM/servidor)

```bash
# Copie e configure as variáveis
cp .env.example .env
# Edite .env com ANTHROPIC_API_KEY e SWAGGER_HOST

# Suba o serviço
docker compose up -d

# Verifique logs
docker compose logs -f
```

Acesse em: `http://<IP-DO-SERVIDOR>:8080`
Swagger em: `http://<IP-DO-SERVIDOR>:5000/apidocs`

---

## 3. AWS — ECS Fargate (recomendado)

```bash
# 1. Autenticar no ECR
aws ecr get-login-password --region us-east-1 \
  | docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# 2. Criar repositório (uma vez)
aws ecr create-repository --repository-name customer-agent

# 3. Push da imagem
docker tag customer-agent:latest <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/customer-agent:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/customer-agent:latest

# 4. Criar Task Definition no ECS com as seguintes variáveis de ambiente:
#    ANTHROPIC_API_KEY  →  via AWS Secrets Manager
#    PORT               →  8080
#    API_PORT           →  5000
#    SWAGGER_HOST       →  <DNS-do-load-balancer>:5000

# 5. Criar Service no ECS apontando para Application Load Balancer (ALB)
#    - Listener na porta 80/443 → Target 8080 (Web UI)
#    - Listener na porta 5000   → Target 5000 (API)

# 6. Restrição de IP: Security Group do ALB — Inbound permitido apenas para o CIDR corporativo
#    Ex: 10.0.0.0/8 (rede interna)
```

---

## 4. Azure — Container Apps

```bash
# 1. Login
az login
az acr login --name <ACR_NAME>

# 2. Push
docker tag customer-agent:latest <ACR_NAME>.azurecr.io/customer-agent:latest
docker push <ACR_NAME>.azurecr.io/customer-agent:latest

# 3. Criar Container App
az containerapp create \
  --name customer-agent \
  --resource-group <RG> \
  --environment <ENV_NAME> \
  --image <ACR_NAME>.azurecr.io/customer-agent:latest \
  --target-port 8080 \
  --ingress external \
  --env-vars \
      ANTHROPIC_API_KEY=secretref:anthropic-key \
      PORT=8080 \
      API_PORT=5000

# 4. Restrição de IP: configure "IP Security Restrictions" no Container App
#    para aceitar apenas o range CIDR da rede corporativa.
```

---

## 5. Google Cloud — Cloud Run

```bash
# 1. Autenticar
gcloud auth configure-docker <REGION>-docker.pkg.dev

# 2. Push para Artifact Registry
docker tag customer-agent:latest <REGION>-docker.pkg.dev/<PROJECT>/customer-agent/app:latest
docker push <REGION>-docker.pkg.dev/<PROJECT>/customer-agent/app:latest

# 3. Deploy
gcloud run deploy customer-agent \
  --image <REGION>-docker.pkg.dev/<PROJECT>/customer-agent/app:latest \
  --region <REGION> \
  --port 8080 \
  --no-allow-unauthenticated \
  --set-env-vars PORT=8080,API_PORT=5000 \
  --set-secrets ANTHROPIC_API_KEY=anthropic-api-key:latest

# 4. Restrição de IP: use VPC Service Controls ou Cloud Armor
#    para limitar acesso ao range de IP corporativo.
```

---

## 6. Variáveis de Ambiente de Produção

| Variável            | Descrição                                     | Obrigatória |
|---------------------|-----------------------------------------------|-------------|
| `ANTHROPIC_API_KEY` | Chave de API da Anthropic (Claude)            | ✅ Sim      |
| `PORT`              | Porta da Web UI (padrão: `8080`)              | Não         |
| `API_PORT`          | Porta da Mock API (padrão: `5000`)            | Não         |
| `OUTPUT_DIR`        | Diretório de saída (padrão: `/app/output`)    | Não         |
| `SWAGGER_HOST`      | Host exibido na documentação Swagger          | Não         |

> **Segurança:** Nunca armazene `ANTHROPIC_API_KEY` em texto plano. Use:
> AWS Secrets Manager / Azure Key Vault / GCP Secret Manager.

---

## 7. URLs de Acesso

| Recurso          | URL                                   |
|------------------|---------------------------------------|
| Painel Web       | `http://<HOST>:8080`                  |
| Mock API         | `http://<HOST>:5000`                  |
| Documentação API | `http://<HOST>:5000/apidocs`          |
| Health Check     | `http://<HOST>:8080/health`           |
