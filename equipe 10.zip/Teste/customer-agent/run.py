"""
Script de execução completa do projeto Customer Agent.
Inicia a Mock API em background e depois roda o agente em lote.
"""

import os
import sys
import time
import subprocess
import argparse
from pathlib import Path


def wait_for_api(url: str, retries: int = 10, delay: float = 1.0) -> bool:
    """Aguarda a API subir verificando o endpoint /health."""
    import urllib.request
    import urllib.error

    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(f"{url}/health", timeout=3) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        print(f"   Aguardando API... ({attempt}/{retries})")
        time.sleep(delay)
    return False


def main():
    parser = argparse.ArgumentParser(
        description="Executa o Customer Agent completo (Mock API + Agente em Lote)."
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("ANTHROPIC_API_KEY"),
        help="Chave de API da Anthropic. Pode ser definida via variável de ambiente ANTHROPIC_API_KEY.",
    )
    parser.add_argument(
        "--output",
        default="output",
        help="Diretório de saída (padrão: ./output).",
    )
    parser.add_argument(
        "--skip-api",
        action="store_true",
        help="Não inicia a Mock API (use se ela já estiver rodando).",
    )
    args = parser.parse_args()

    if not args.api_key:
        print("❌  Erro: --api-key é obrigatório (ou defina ANTHROPIC_API_KEY).")
        sys.exit(1)

    project_root = Path(__file__).parent

    # ------------------------------------------------------------------
    # 1. Iniciar Mock API
    # ------------------------------------------------------------------
    api_process = None
    if not args.skip_api:
        print("🚀  Iniciando Mock API em http://localhost:5000 ...")
        api_script = project_root / "mock_api" / "app.py"
        api_process = subprocess.Popen(
            [sys.executable, str(api_script)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        if not wait_for_api("http://localhost:5000"):
            print("❌  A Mock API não respondeu a tempo. Abortando.")
            api_process.terminate()
            sys.exit(1)
        print("✅  Mock API pronta.\n")
    else:
        print("⏭️  Mock API ignorada (--skip-api).\n")

    # ------------------------------------------------------------------
    # 2. Executar agente em lote
    # ------------------------------------------------------------------
    try:
        print("🤖  Iniciando processamento em lote com Claude...\n")
        agent_script = project_root / "agent" / "batch_agent.py"
        result = subprocess.run(
            [
                sys.executable,
                str(agent_script),
                "--api-key", args.api_key,
                "--output", args.output,
            ],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        print(f"\n❌  O agente terminou com erro (código {e.returncode}).")
        sys.exit(e.returncode)
    finally:
        if api_process:
            api_process.terminate()
            print("\n🛑  Mock API encerrada.")


if __name__ == "__main__":
    main()
