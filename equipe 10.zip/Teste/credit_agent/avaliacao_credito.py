"""
Sistema de Avaliação de Limite de Crédito
==========================================
Analisa a base de clientes, classifica em 4 segmentos de risco
e gera um PDF profissional com as regras, resultados e anexo.

Dependências: reportlab, json, statistics (stdlib)
"""

import json
import math
import statistics
from datetime import date
from collections import Counter

# ---------------------------------------------------------------------------
# 1. CARREGAMENTO DA BASE
# ---------------------------------------------------------------------------

BASE_PATH = "credit_agent/base_clientes_credito.json"

with open(BASE_PATH, encoding="utf-8") as f:
    clientes = json.load(f)

print(f"[INFO] Base carregada: {len(clientes)} clientes")


# ---------------------------------------------------------------------------
# 2. ANÁLISE EXPLORATÓRIA
# ---------------------------------------------------------------------------

def analisar_campo(registros, campo):
    """Retorna estatísticas descritivas de um campo numérico."""
    valores = [r[campo] for r in registros if r.get(campo) is not None]
    if not valores:
        return {}
    valores_sorted = sorted(valores)
    n = len(valores_sorted)
    media = statistics.mean(valores)
    mediana = statistics.median(valores)
    desvio = statistics.pstdev(valores)
    minimo = min(valores)
    maximo = max(valores)
    p25 = valores_sorted[int(n * 0.25)]
    p75 = valores_sorted[int(n * 0.75)]
    p90 = valores_sorted[int(n * 0.90)]
    return {
        "n": n, "media": media, "mediana": mediana, "desvio": desvio,
        "minimo": minimo, "maximo": maximo, "p25": p25, "p75": p75, "p90": p90
    }

def analisar_categorico(registros, campo):
    """Retorna frequência dos valores de um campo categórico."""
    valores = [r.get(campo, "N/A") for r in registros]
    return dict(Counter(valores))

# Estatísticas descritivas
stats_idade          = analisar_campo(clientes, "idade")
stats_renda          = analisar_campo(clientes, "renda_liquida")
stats_relacionamento = analisar_campo(clientes, "relacionamento_meses")
freq_pagamentos      = analisar_categorico(clientes, "pagamentos_dia")
freq_emprestimos     = analisar_categorico(clientes, "emprestimos_ativos")
freq_produtos        = analisar_categorico(clientes, "usuario_produtos")

print("\n=== ANÁLISE EXPLORATÓRIA ===")
for nome, stat in [("Idade", stats_idade), ("Renda Líquida (R$)", stats_renda),
                   ("Relacionamento (meses)", stats_relacionamento)]:
    print(f"\n{nome}:")
    for k, v in stat.items():
        print(f"  {k}: {v:.2f}" if isinstance(v, float) else f"  {k}: {v}")

print(f"\nPagamentos em Dia: {freq_pagamentos}")
print(f"Empréstimos Ativos: {freq_emprestimos}")
print(f"Usuário de Produtos: {freq_produtos}")


# ---------------------------------------------------------------------------
# 3. SISTEMA DE PONTUAÇÃO E CLASSIFICAÇÃO
# ---------------------------------------------------------------------------

# ---- Thresholds definidos a partir dos percentis da base ----------------
#
# Variáveis e pesos no score (0 a 100):
#
# a) pagamentos_dia (Sim/Não) — peso 35
#    Sim  → 35 pts   |   Não → 0 pts
#    Justificativa: adimplência é o principal preditor de risco
#
# b) renda_liquida — peso 25
#    > 8.000  → 25 pts  (acima do P75)
#    4.000–8.000 → 15 pts
#    2.000–3.999 → 8 pts
#    < 2.000  → 0 pts
#    Justificativa: renda alta amplia capacidade de pagamento
#
# c) relacionamento_meses — peso 20
#    ≥ 120 meses → 20 pts  (10 anos+)
#    60–119 meses → 12 pts
#    24–59 meses  → 6 pts
#    < 24 meses   → 0 pts
#    Justificativa: relacionamento longo indica histórico positivo
#
# d) emprestimos_ativos (Sim/Não) — peso 10
#    Não → 10 pts  |  Sim → 0 pts
#    Justificativa: sem dívidas ativas reduz risco de default
#
# e) usuario_produtos (Sim/Não) — peso 10
#    Sim → 10 pts  |  Não → 0 pts
#    Justificativa: engajamento indica relacionamento saudável
#
# Score total: 0–100
#
# f) Bônus de idade: clientes 30–60 anos recebem +3 pts (menor volatilidade)
#
# Segmentos por score:
#   < 30  → Segmento 1 (Alto Risco)
#   30–54 → Segmento 2 (Risco Moderado)
#   55–74 → Segmento 3 (Baixo Risco)
#   ≥ 75  → Segmento 4 (Risco Muito Baixo)
#
# RESTRIÇÃO OBRIGATÓRIA: limite final ≤ 30% da renda líquida mensal
# Essa regra é aplicada SEMPRE como teto absoluto via calcular_teto_30pct()

# Limite por segmento é calculado como múltiplo da renda mensal:
#   Seg.1: até 0,5× a renda   (teto absoluto R$ 600)
#   Seg.2: até 1,5× a renda   (teto absoluto R$ 5.000)
#   Seg.3: até 3,0× a renda   (teto absoluto R$ 25.000)
#   Seg.4: até 5,0× a renda   (teto absoluto R$ 60.000)
# O teto de 30% da renda MENSAL (~3,6× de limite mensal efetivo) cobre
# todos os segmentos onde o múltiplo mensal supera 0.30, criando impacto
# real especialmente nos Seg.3 e Seg.4.
LIMITES_SEGMENTO = {
    1: {"nome": "Alto Risco / Sem Limite",           "multiplo": 0.50, "max_abs":   600.0},
    2: {"nome": "Risco Moderado / Limite Básico",    "multiplo": 1.50, "max_abs":  5000.0},
    3: {"nome": "Baixo Risco / Limite Intermediário","multiplo": 3.00, "max_abs": 25000.0},
    4: {"nome": "Risco Muito Baixo / Limite Premium","multiplo": 5.00, "max_abs": 60000.0},
}


def calcular_teto_30pct(renda_liquida: float) -> float:
    """
    Calcula o teto absoluto de crédito = 30% da renda líquida mensal.
    Esta função é a ÚNICA fonte de cálculo do teto e deve ser chamada
    em todo ponto onde o limite final é determinado.
    """
    return round(renda_liquida * 0.30, 2)


def calcular_score(cliente: dict) -> int:
    """Calcula o score de crédito (0–103) de um cliente."""
    score = 0

    # a) Pagamentos em dia (peso 35)
    if cliente["pagamentos_dia"] == "Sim":
        score += 35

    # b) Renda líquida (peso 25)
    r = cliente["renda_liquida"]
    if r >= 8000:
        score += 25
    elif r >= 4000:
        score += 15
    elif r >= 2000:
        score += 8
    # else: 0

    # c) Relacionamento em meses (peso 20)
    m = cliente["relacionamento_meses"]
    if m >= 120:
        score += 20
    elif m >= 60:
        score += 12
    elif m >= 24:
        score += 6
    # else: 0

    # d) Sem empréstimos ativos (peso 10)
    if cliente["emprestimos_ativos"] == "Não":
        score += 10

    # e) Usuário de produtos (peso 10)
    if cliente["usuario_produtos"] == "Sim":
        score += 10

    # f) Bônus de estabilidade etária
    idade = cliente["idade"]
    if 30 <= idade <= 60:
        score += 3

    return score


def classificar_segmento(score: int) -> int:
    """Classifica o segmento com base no score calculado."""
    if score >= 75:
        return 4
    elif score >= 55:
        return 3
    elif score >= 30:
        return 2
    else:
        return 1


def calcular_limite_segmento(cliente: dict, segmento: int) -> float:
    """
    Calcula o limite sugerido pelo segmento (múltiplo da renda mensal),
    sem aplicar o teto dos 30%. Cada segmento tem também um teto absoluto.
    """
    cfg = LIMITES_SEGMENTO[segmento]
    limite = round(cliente["renda_liquida"] * cfg["multiplo"], 2)
    limite = min(limite, cfg["max_abs"])
    return limite


def calcular_limite_final(cliente: dict, segmento: int) -> dict:
    """
    Calcula o limite final aplicando obrigatoriamente o teto de 30% da
    renda líquida via calcular_teto_30pct(). Retorna dict com score,
    segmento, limite_segmento, teto_30pct e limite_final.
    """
    score = calcular_score(cliente)
    seg = classificar_segmento(score)  # reconfirma a partir do score
    limite_seg = calcular_limite_segmento(cliente, seg)
    teto = calcular_teto_30pct(cliente["renda_liquida"])
    limite_final = min(limite_seg, teto)
    return {
        "score": score,
        "segmento": seg,
        "nome_segmento": LIMITES_SEGMENTO[seg]["nome"],
        "limite_segmento": limite_seg,
        "teto_30pct": teto,
        "limite_final": round(limite_final, 2),
        "teto_aplicado": limite_seg > teto,  # flag: teto reduziu o limite?
    }


# ---------------------------------------------------------------------------
# 4. APLICAÇÃO DAS REGRAS
# ---------------------------------------------------------------------------

resultados = []
for c in clientes:
    res = calcular_limite_final(c, 0)  # segmento calculado internamente
    resultados.append({**c, **res})

# Distribuição por segmento
dist_segmentos = Counter(r["segmento"] for r in resultados)
clientes_com_teto = sum(1 for r in resultados if r["teto_aplicado"])
reducao_media = 0.0
reducoes = [r["limite_segmento"] - r["limite_final"]
            for r in resultados if r["teto_aplicado"]]
if reducoes:
    reducao_media = statistics.mean(reducoes)

# Alias padronizado
LIMITES_SEGMENTOS = LIMITES_SEGMENTO

print("\n=== DISTRIBUIÇÃO POR SEGMENTO ===")
total = len(resultados)
for seg in [1, 2, 3, 4]:
    qtd = dist_segmentos.get(seg, 0)
    print(f"  Segmento {seg} ({LIMITES_SEGMENTOS[seg]['nome']}): "
          f"{qtd} clientes ({qtd/total*100:.1f}%)")

print(f"\n  Clientes com teto de 30% aplicado: {clientes_com_teto} "
      f"({clientes_com_teto/total*100:.1f}%)")
print(f"  Redução média do limite pelo teto: R$ {reducao_media:,.2f}")

# Stats de limite por segmento
stats_limite = {}
for seg in [1, 2, 3, 4]:
    limites = [r["limite_final"] for r in resultados if r["segmento"] == seg]
    if limites:
        stats_limite[seg] = {
            "media":   statistics.mean(limites),
            "mediana": statistics.median(limites),
            "minimo":  min(limites),
            "maximo":  max(limites),
        }


# ---------------------------------------------------------------------------
# 5. GERAÇÃO DO PDF COM REPORTLAB
# ---------------------------------------------------------------------------

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.colors import (
    HexColor, black, white, Color
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether
)
from reportlab.platypus.flowables import Flowable
from reportlab.graphics.shapes import Drawing, Rect, String, Line
from reportlab.graphics import renderPDF

# Paleta de cores
COR_AZUL      = HexColor("#1B4F72")
COR_AZUL_CLARO= HexColor("#2E86C1")
COR_CINZA_BG  = HexColor("#F4F6F7")
COR_CINZA_LIN = HexColor("#D5D8DC")
COR_VERDE     = HexColor("#1E8449")
COR_AMARELO   = HexColor("#B7950B")
COR_LARANJA   = HexColor("#CA6F1E")
COR_VERMELHO  = HexColor("#922B21")
COR_TEXTO     = HexColor("#1C2833")
COR_MUTED     = HexColor("#566573")

CORES_SEG = {1: COR_VERMELHO, 2: COR_LARANJA, 3: COR_AMARELO, 4: COR_VERDE}

OUTPUT_PATH = "avaliacao_limite_credito.pdf"

PAGE_W, PAGE_H = A4
MARGEM = 2.0 * cm


def build_styles():
    base = getSampleStyleSheet()
    estilos = {}

    estilos["titulo_capa"] = ParagraphStyle(
        "TituloCapa", parent=base["Title"],
        fontSize=28, textColor=white, alignment=TA_CENTER,
        spaceAfter=12, leading=34
    )
    estilos["sub_capa"] = ParagraphStyle(
        "SubCapa", parent=base["Normal"],
        fontSize=14, textColor=HexColor("#D6EAF8"),
        alignment=TA_CENTER, spaceAfter=6
    )
    estilos["h1"] = ParagraphStyle(
        "H1", parent=base["Heading1"],
        fontSize=16, textColor=COR_AZUL, spaceBefore=18,
        spaceAfter=8, leading=20, borderPad=4
    )
    estilos["h2"] = ParagraphStyle(
        "H2", parent=base["Heading2"],
        fontSize=13, textColor=COR_AZUL_CLARO, spaceBefore=12,
        spaceAfter=6, leading=16
    )
    estilos["body"] = ParagraphStyle(
        "Body", parent=base["Normal"],
        fontSize=10, textColor=COR_TEXTO, leading=15,
        spaceAfter=6, alignment=TA_JUSTIFY
    )
    estilos["body_bold"] = ParagraphStyle(
        "BodyBold", parent=estilos["body"],
        fontName="Helvetica-Bold"
    )
    estilos["caption"] = ParagraphStyle(
        "Caption", parent=base["Normal"],
        fontSize=8.5, textColor=COR_MUTED, alignment=TA_CENTER,
        spaceAfter=4, spaceBefore=2
    )
    estilos["toc"] = ParagraphStyle(
        "TOC", parent=base["Normal"],
        fontSize=11, textColor=COR_TEXTO, leading=18
    )
    estilos["rodape"] = ParagraphStyle(
        "Rodape", parent=base["Normal"],
        fontSize=8, textColor=COR_MUTED, alignment=TA_CENTER
    )
    return estilos


def tabela_estilo_base(col_widths, header_color=COR_AZUL, alt_color=COR_CINZA_BG):
    """Retorna um TableStyle padrão com cabeçalho colorido e linhas alternadas."""
    return TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR",     (0, 0), (-1, 0), white),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 9),
        ("ALIGN",         (0, 0), (-1, 0), "CENTER"),
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 8.5),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [white, alt_color]),
        ("GRID",          (0, 0), (-1, -1), 0.4, COR_CINZA_LIN),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ])


def criar_grafico_barras_segmentos():
    """Cria um gráfico de barras horizontais da distribuição por segmento."""
    drawing = Drawing(450, 180)
    drawing.add(Rect(0, 0, 450, 180, fillColor=COR_CINZA_BG, strokeColor=None))

    nomes = {
        1: "Seg.1 Alto Risco",
        2: "Seg.2 Risco Moderado",
        3: "Seg.3 Baixo Risco",
        4: "Seg.4 Risco Muito Baixo",
    }
    total = len(resultados)
    max_qtd = max(dist_segmentos.values())
    barra_h = 28
    barra_gap = 12
    label_w = 145
    x_start = label_w + 8
    chart_w = 450 - x_start - 20
    y_base = 20

    for i, seg in enumerate([4, 3, 2, 1]):
        qtd = dist_segmentos.get(seg, 0)
        pct = qtd / total * 100
        bar_len = (qtd / max_qtd) * chart_w if max_qtd > 0 else 0
        y = y_base + i * (barra_h + barra_gap)

        # Barra
        drawing.add(Rect(
            x_start, y, bar_len, barra_h,
            fillColor=CORES_SEG[seg], strokeColor=None
        ))
        # Label esquerdo
        drawing.add(String(
            2, y + barra_h / 2 - 4,
            nomes[seg],
            fontName="Helvetica", fontSize=8.5,
            fillColor=COR_TEXTO
        ))
        # Valor à direita da barra
        drawing.add(String(
            x_start + bar_len + 4, y + barra_h / 2 - 4,
            f"{qtd} ({pct:.1f}%)",
            fontName="Helvetica-Bold", fontSize=8.5,
            fillColor=COR_TEXTO
        ))

    return drawing


class CabecalhoPagina(Flowable):
    """Cabeçalho discreto para páginas internas."""
    def __init__(self, titulo_secao=""):
        super().__init__()
        self.titulo_secao = titulo_secao
        self.width = PAGE_W - 2 * MARGEM
        self.height = 20

    def draw(self):
        self.canv.setFillColor(COR_AZUL)
        self.canv.rect(0, 0, self.width, 2, fill=1, stroke=0)
        self.canv.setFont("Helvetica", 8)
        self.canv.setFillColor(COR_MUTED)
        self.canv.drawString(0, 5, "Sistema de Avaliação de Limite de Crédito")
        self.canv.drawRightString(self.width, 5, self.titulo_secao)


def adicionar_numero_pagina(canvas, doc):
    """Rodapé com número de página."""
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(COR_MUTED)
    canvas.drawCentredString(PAGE_W / 2, 1.2 * cm,
                              f"Página {doc.page}")
    canvas.setStrokeColor(COR_CINZA_LIN)
    canvas.line(MARGEM, 1.6 * cm, PAGE_W - MARGEM, 1.6 * cm)
    canvas.restoreState()


def gerar_pdf():
    estilos = build_styles()
    doc = SimpleDocTemplate(
        OUTPUT_PATH, pagesize=A4,
        leftMargin=MARGEM, rightMargin=MARGEM,
        topMargin=2.5 * cm, bottomMargin=2.5 * cm,
        title="Avaliação de Limite de Crédito",
        author="Sistema de Crédito Automatizado",
    )

    historia = []
    data_hoje = date.today().strftime("%d/%m/%Y")

    # =======================================================================
    # CAPA
    # =======================================================================
    from reportlab.platypus import Frame, BaseDocTemplate, PageTemplate
    from reportlab.lib.colors import HexColor

    # Capa com fundo colorido via canvas
    class CapaBackground(Flowable):
        def __init__(self):
            super().__init__()
            self.width = PAGE_W
            self.height = PAGE_H

        def draw(self):
            c = self.canv
            c.setFillColor(COR_AZUL)
            c.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
            c.setFillColor(COR_AZUL_CLARO)
            c.rect(0, PAGE_H * 0.35, PAGE_W, PAGE_H * 0.005, fill=1, stroke=0)

    historia.append(Spacer(1, 6 * cm))
    historia.append(Paragraph(
        "SISTEMA DE AVALIAÇÃO DE<br/>LIMITE DE CRÉDITO",
        estilos["titulo_capa"]
    ))
    historia.append(Spacer(1, 0.5 * cm))
    historia.append(HRFlowable(
        width="70%", thickness=1.5, color=COR_AZUL_CLARO,
        hAlign="CENTER", spaceAfter=12
    ))
    historia.append(Paragraph(
        "Classificação de Clientes em Segmentos de Risco<br/>"
        "e Definição de Limites de Crédito",
        estilos["sub_capa"]
    ))
    historia.append(Spacer(1, 1.0 * cm))
    historia.append(Paragraph(
        f"Data de Geração: {data_hoje}", estilos["sub_capa"]
    ))
    historia.append(Paragraph(
        f"Total de Clientes Analisados: {len(resultados):,}",
        estilos["sub_capa"]
    ))
    historia.append(Paragraph(
        "Versão 1.0 — Uso Interno", estilos["sub_capa"]
    ))
    historia.append(PageBreak())

    # =======================================================================
    # SUMÁRIO
    # =======================================================================
    historia.append(Paragraph("Sumário", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=1, color=COR_AZUL_CLARO,
                                spaceAfter=10))
    secoes = [
        ("1.", "Introdução"),
        ("2.", "Descrição da Base de Dados"),
        ("3.", "Metodologia"),
        ("4.", "Regras de Classificação por Segmento"),
        ("5.", "Resultados da Classificação"),
        ("6.", "Conclusão e Recomendações"),
        ("Anexo", "Tabela de Classificação Individual dos Clientes"),
    ]
    for num, titulo in secoes:
        historia.append(Paragraph(
            f"<font color='#2E86C1'><b>{num}</b></font>&nbsp;&nbsp;{titulo}",
            estilos["toc"]
        ))
    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 1 — INTRODUÇÃO
    # =======================================================================
    historia.append(Paragraph("1. Introdução", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO,
                                spaceAfter=8))
    historia.append(Paragraph(
        "O presente documento descreve o sistema automatizado de avaliação de "
        "limite de crédito desenvolvido para a classificação de clientes em "
        "quatro segmentos de risco distintos. O objetivo é fornecer uma base "
        "técnica e objetiva para a concessão de crédito, minimizando o risco "
        "de inadimplência e maximizando a oferta de crédito a clientes com "
        "perfil saudável.", estilos["body"]
    ))
    historia.append(Paragraph(
        "A avaliação é conduzida por um modelo de pontuação (<i>credit score</i>) "
        "baseado em variáveis comportamentais e cadastrais disponíveis na base de "
        "dados interna da instituição. Cada cliente recebe uma pontuação que "
        "determina o segmento ao qual pertence e, consequentemente, o limite de "
        "crédito máximo que pode ser oferecido.", estilos["body"]
    ))
    historia.append(Paragraph(
        "<b>Restrição Obrigatória de Negócio:</b> Independentemente do segmento "
        "classificado, o limite de crédito final atribuído a qualquer cliente "
        "não pode ultrapassar <b>30% da renda líquida mensal</b> desse cliente. "
        "Essa regra é implementada como teto absoluto e sobrepõe-se a qualquer "
        "outro critério de cálculo de limite.", estilos["body"]
    ))
    historia.append(Spacer(1, 0.3 * cm))
    historia.append(Paragraph("Escopo do Documento", estilos["h2"]))
    historia.append(Paragraph(
        "Este relatório abrange: (a) a descrição da base de dados utilizada com "
        "estatísticas descritivas; (b) a metodologia de scoring adotada; "
        "(c) as regras detalhadas por segmento; (d) os resultados da "
        "classificação com distribuição dos clientes; e (e) um anexo com a "
        "classificação individual de cada cliente.", estilos["body"]
    ))
    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 2 — DESCRIÇÃO DA BASE DE DADOS
    # =======================================================================
    historia.append(Paragraph("2. Descrição da Base de Dados", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO,
                                spaceAfter=8))
    historia.append(Paragraph(
        f"A base de dados contém <b>{len(clientes)} registros</b> de clientes, "
        "armazenados em formato JSON. Cada registro é composto pelas variáveis "
        "descritas na tabela abaixo.", estilos["body"]
    ))
    historia.append(Spacer(1, 0.2 * cm))

    # Tabela de variáveis
    dados_var = [
        ["Variável", "Tipo", "Descrição", "Relevância para Crédito"],
        ["id",                  "Inteiro",   "Identificador único do cliente",                "Chave primária"],
        ["nome",                "Texto",     "Nome completo do cliente",                      "Identificação"],
        ["cpf",                 "Texto",     "CPF formatado do cliente",                      "Identificação"],
        ["idade",               "Inteiro",   "Idade em anos completos",                       "Moderada"],
        ["renda_liquida",       "Decimal",   "Renda líquida mensal em R$",                    "Alta"],
        ["relacionamento_meses","Inteiro",   "Meses de relacionamento com a instituição",     "Alta"],
        ["pagamentos_dia",      "Categórico","Indicador de adimplência (Sim/Não)",             "Muito Alta"],
        ["emprestimos_ativos",  "Categórico","Possui empréstimos ativos (Sim/Não)",            "Alta"],
        ["usuario_produtos",    "Categórico","Usuário de outros produtos (Sim/Não)",           "Moderada"],
    ]
    col_widths_var = [3.5*cm, 2.2*cm, 7.0*cm, 3.8*cm]
    t_var = Table(dados_var, colWidths=col_widths_var, repeatRows=1)
    t_var.setStyle(tabela_estilo_base(col_widths_var))
    t_var.setStyle(TableStyle([
        ("ALIGN", (0, 0), (1, -1), "CENTER"),
        ("ALIGN", (2, 0), (-1, -1), "LEFT"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
    ]))
    historia.append(t_var)
    historia.append(Paragraph("Tabela 1 — Variáveis da Base de Dados", estilos["caption"]))
    historia.append(Spacer(1, 0.4 * cm))

    # Estatísticas descritivas — variáveis numéricas
    historia.append(Paragraph("2.1 Estatísticas Descritivas — Variáveis Numéricas", estilos["h2"]))
    dados_stats = [
        ["Variável", "N", "Média", "Mediana", "Desvio Pad.", "Mínimo", "Máximo", "P25", "P75", "P90"],
    ]
    for nome_v, st in [
        ("Idade", stats_idade),
        ("Renda Líquida (R$)", stats_renda),
        ("Relacionamento (meses)", stats_relacionamento),
    ]:
        dados_stats.append([
            nome_v,
            str(st["n"]),
            f"{st['media']:.1f}",
            f"{st['mediana']:.1f}",
            f"{st['desvio']:.1f}",
            f"{st['minimo']:.1f}",
            f"{st['maximo']:.1f}",
            f"{st['p25']:.1f}",
            f"{st['p75']:.1f}",
            f"{st['p90']:.1f}",
        ])
    col_w_stats = [3.8*cm, 1.0*cm, 1.5*cm, 1.5*cm, 1.8*cm, 1.5*cm, 1.5*cm, 1.5*cm, 1.5*cm, 1.5*cm]
    t_stats = Table(dados_stats, colWidths=col_w_stats, repeatRows=1)
    t_stats.setStyle(tabela_estilo_base(col_w_stats))
    t_stats.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
    ]))
    historia.append(t_stats)
    historia.append(Paragraph(
        "Tabela 2 — Estatísticas Descritivas das Variáveis Numéricas",
        estilos["caption"]
    ))
    historia.append(Spacer(1, 0.4 * cm))

    # Frequências — variáveis categóricas
    historia.append(Paragraph("2.2 Distribuição — Variáveis Categóricas", estilos["h2"]))
    total_c = len(clientes)
    dados_cat = [["Variável", "Valor", "Frequência", "Percentual"]]
    for nome_v, freq in [
        ("Pagamentos em Dia", freq_pagamentos),
        ("Empréstimos Ativos", freq_emprestimos),
        ("Usuário de Produtos", freq_produtos),
    ]:
        for val, cnt in sorted(freq.items()):
            dados_cat.append([nome_v, val, str(cnt), f"{cnt/total_c*100:.1f}%"])
    col_w_cat = [5.5*cm, 3.0*cm, 3.0*cm, 3.0*cm]
    t_cat = Table(dados_cat, colWidths=col_w_cat, repeatRows=1)
    t_cat.setStyle(tabela_estilo_base(col_w_cat))
    t_cat.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 8.5)]))
    historia.append(t_cat)
    historia.append(Paragraph("Tabela 3 — Distribuição das Variáveis Categóricas", estilos["caption"]))
    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 3 — METODOLOGIA
    # =======================================================================
    historia.append(Paragraph("3. Metodologia", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO, spaceAfter=8))
    historia.append(Paragraph("3.1 Abordagem Adotada", estilos["h2"]))
    historia.append(Paragraph(
        "O sistema utiliza um modelo de <b>pontuação de crédito (credit score)</b> "
        "baseado em regras. Cada variável relevante da base recebe um peso "
        "proporcional à sua influência sobre o risco de inadimplência, e os "
        "pontos são somados para formar o score final do cliente (escala 0–103, "
        "incluindo bônus etário).", estilos["body"]
    ))
    historia.append(Paragraph(
        "Essa abordagem foi escolhida por ser transparente, auditável, de fácil "
        "implementação e interpretação pelos analistas de negócio, não requerendo "
        "dados históricos de inadimplência para treinamento.", estilos["body"]
    ))
    historia.append(Spacer(1, 0.2 * cm))

    historia.append(Paragraph("3.2 Componentes do Score", estilos["h2"]))
    dados_score = [
        ["Variável",              "Condição",              "Pontos", "Peso (%)"],
        ["Pagamentos em Dia",     "Sim",                   "35",     "35%"],
        ["Pagamentos em Dia",     "Não",                   "0",      "—"],
        ["Renda Líquida",         "≥ R$ 8.000",            "25",     "25%"],
        ["Renda Líquida",         "R$ 4.000–7.999",        "15",     "—"],
        ["Renda Líquida",         "R$ 2.000–3.999",        "8",      "—"],
        ["Renda Líquida",         "< R$ 2.000",            "0",      "—"],
        ["Relacionamento (meses)","≥ 120 meses",           "20",     "20%"],
        ["Relacionamento (meses)","60–119 meses",          "12",     "—"],
        ["Relacionamento (meses)","24–59 meses",           "6",      "—"],
        ["Relacionamento (meses)","< 24 meses",            "0",      "—"],
        ["Empréstimos Ativos",    "Não",                   "10",     "10%"],
        ["Empréstimos Ativos",    "Sim",                   "0",      "—"],
        ["Usuário de Produtos",   "Sim",                   "10",     "10%"],
        ["Usuário de Produtos",   "Não",                   "0",      "—"],
        ["Bônus Etário (30–60a)", "Idade entre 30 e 60",  "+3",     "Bônus"],
        ["TOTAL MÁXIMO",          "—",                     "103",    "100%"],
    ]
    col_w_sc = [5.0*cm, 4.5*cm, 2.0*cm, 2.0*cm]
    t_sc = Table(dados_score, colWidths=col_w_sc, repeatRows=1)
    t_sc.setStyle(tabela_estilo_base(col_w_sc))
    t_sc.setStyle(TableStyle([
        ("FONTSIZE",   (0, 0), (-1, -1), 8.5),
        ("ALIGN",      (2, 0), (3, -1), "CENTER"),
        ("FONTNAME",   (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), COR_AZUL),
        ("TEXTCOLOR",  (0, -1), (-1, -1), white),
    ]))
    historia.append(t_sc)
    historia.append(Paragraph("Tabela 4 — Componentes e Pesos do Score de Crédito", estilos["caption"]))
    historia.append(Spacer(1, 0.3 * cm))

    historia.append(Paragraph("3.3 Classificação por Faixas de Score", estilos["h2"]))
    dados_faixas = [
        ["Score",    "Seg.", "Classificação",                          "Múltiplo da Renda", "Teto Absoluto"],
        ["0 – 29",   "1",   "Alto Risco / Sem Limite",                "0,5×",              "R$ 600"],
        ["30 – 54",  "2",   "Risco Moderado / Limite Básico",         "1,5×",              "R$ 5.000"],
        ["55 – 74",  "3",   "Baixo Risco / Limite Intermediário",     "3,0×",              "R$ 25.000"],
        ["75 – 103", "4",   "Risco Muito Baixo / Limite Premium",     "5,0×",              "R$ 60.000"],
    ]
    col_w_f = [2.0*cm, 1.5*cm, 6.0*cm, 3.0*cm, 3.0*cm]
    t_f = Table(dados_faixas, colWidths=col_w_f, repeatRows=1)
    t_f.setStyle(tabela_estilo_base(col_w_f))
    t_f.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN",    (0, 0), (1, -1), "CENTER"),
        ("BACKGROUND", (0, 1), (-1, 1), HexColor("#FADBD8")),
        ("BACKGROUND", (0, 2), (-1, 2), HexColor("#FDEBD0")),
        ("BACKGROUND", (0, 3), (-1, 3), HexColor("#FEF9E7")),
        ("BACKGROUND", (0, 4), (-1, 4), HexColor("#EAFAF1")),
    ]))
    historia.append(t_f)
    historia.append(Paragraph("Tabela 5 — Faixas de Score e Segmentos", estilos["caption"]))
    historia.append(Spacer(1, 0.3 * cm))

    historia.append(Paragraph(
        "3.4 Restrição Obrigatória: Teto de 30% da Renda Líquida", estilos["h2"]
    ))
    historia.append(Paragraph(
        "Esta é uma <b>regra inviolável de negócio</b>: independentemente do "
        "segmento atribuído ao cliente e do limite calculado pelas regras do "
        "segmento, o limite de crédito final não pode exceder <b>30% da renda "
        "líquida mensal</b> do cliente.", estilos["body"]
    ))
    historia.append(Paragraph(
        "Fórmula: <font name='Courier'>Teto = renda_liquida × 0,30</font>",
        estilos["body"]
    ))
    historia.append(Paragraph(
        "<font name='Courier'>Limite_Final = min(Limite_Segmento, Teto)</font>",
        estilos["body"]
    ))
    historia.append(Paragraph(
        "Tecnicamente, a restrição é implementada pela função centralizada "
        "<font name='Courier'>calcular_teto_30pct(renda_liquida)</font>, chamada "
        "em todos os pontos do sistema onde o limite final é determinado, "
        "garantindo auditabilidade e consistência.", estilos["body"]
    ))
    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 4 — REGRAS POR SEGMENTO
    # =======================================================================
    historia.append(Paragraph("4. Regras de Classificação por Segmento", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO, spaceAfter=8))

    def bloco_segmento(num, nome, score_range, multiplo_str, max_abs_str,
                       multiplo_val, regras, justificativa, limite_ex_renda, cor):
        bloco = []
        bloco.append(Paragraph(
            f"<font color='{cor.hexval()}'>■</font>  "
            f"Segmento {num} — {nome}",
            estilos["h2"]
        ))
        bloco.append(Paragraph(
            f"<b>Faixa de Score:</b> {score_range} &nbsp;&nbsp; "
            f"<b>Múltiplo da Renda:</b> {multiplo_str} &nbsp;&nbsp; "
            f"<b>Teto Absoluto do Segmento:</b> {max_abs_str}",
            estilos["body_bold"]
        ))
        bloco.append(Spacer(1, 0.15 * cm))
        bloco.append(Paragraph("<b>Critérios de Enquadramento:</b>", estilos["body_bold"]))
        for r in regras:
            bloco.append(Paragraph(f"• {r}", estilos["body"]))
        bloco.append(Spacer(1, 0.15 * cm))
        bloco.append(Paragraph(f"<b>Justificativa:</b> {justificativa}", estilos["body"]))
        bloco.append(Spacer(1, 0.15 * cm))
        # Exemplo de cálculo com teto de 30%
        teto_ex = calcular_teto_30pct(limite_ex_renda)
        limite_seg_ex = min(round(limite_ex_renda * multiplo_val, 2), float(max_abs_str.replace("R$ ", "").replace(".", "").replace(",", ".")))
        limite_final_ex = min(limite_seg_ex, teto_ex)
        teto_reduziu = limite_seg_ex > teto_ex
        bloco.append(Paragraph(
            f"<b>Exemplo:</b> Cliente com renda líquida de R$ {limite_ex_renda:,.2f} → "
            f"Limite do segmento: R$ {limite_seg_ex:,.2f} | "
            f"Teto 30% da renda: R$ {teto_ex:,.2f} | "
            f"<b>Limite Final: R$ {limite_final_ex:,.2f}</b>"
            + (f" <font color='#922B21'>(teto aplicado)</font>" if teto_reduziu else ""),
            estilos["body"]
        ))
        bloco.append(HRFlowable(
            width="100%", thickness=0.4, color=COR_CINZA_LIN,
            spaceBefore=10, spaceAfter=10
        ))
        return bloco

    for items in bloco_segmento(
        1, "Alto Risco / Sem Limite", "0 – 29",
        "0,5× a renda", "R$ 600,00", 0.50,
        [
            "Score total < 30 pontos",
            "Geralmente: pagamentos em atraso (Não em pagamentos_dia) E renda baixa",
            "Relacionamento < 24 meses ou ausência de histórico positivo",
            "Pode haver combinação de empréstimos ativos com renda muito baixa",
        ],
        "Clientes neste segmento apresentam múltiplos fatores de risco simultâneos. "
        "A concessão de crédito é mínima, limitada a 0,5× a renda mensal com teto "
        "absoluto de R$ 600,00. O teto de 30% da renda não reduz este segmento "
        "pois o limite já é inferior.",
        2500.0, COR_VERMELHO
    ):
        historia.append(items)

    for items in bloco_segmento(
        2, "Risco Moderado / Limite Básico", "30 – 54",
        "1,5× a renda", "R$ 5.000,00", 1.50,
        [
            "Score entre 30 e 54 pontos",
            "Pode ter pagamentos em dia, porém renda baixa ou relacionamento curto",
            "Pode ter renda intermediária, mas histórico de pagamentos instável",
            "Sem combinação de fatores suficiente para atingir score 55+",
        ],
        "Perfil moderado com algum fator positivo. Limite de 1,5× a renda mensal "
        "com teto de R$ 5.000,00. O teto de 30% da renda (equivalente a ~0,3× mensal) "
        "reduz este limite para clientes cuja renda é baixa e o teto proporcional "
        "fica abaixo do calculado pelo múltiplo.",
        3000.0, COR_LARANJA
    ):
        historia.append(items)

    for items in bloco_segmento(
        3, "Baixo Risco / Limite Intermediário", "55 – 74",
        "3,0× a renda", "R$ 25.000,00", 3.00,
        [
            "Score entre 55 e 74 pontos",
            "Tipicamente: pagamentos em dia + renda intermediária ou alta",
            "Relacionamento ≥ 24 meses com a instituição",
            "Maioria dos clientes sem empréstimos ativos",
        ],
        "Clientes com boa capacidade de pagamento e histórico positivo. Limite de "
        "3,0× a renda mensal, com teto absoluto de R$ 25.000,00. A restrição de 30% "
        "da renda mensal é aplicada como teto final e reduz o limite na maioria dos "
        "clientes deste segmento, garantindo prudência na concessão.",
        8000.0, COR_AMARELO
    ):
        historia.append(items)

    for items in bloco_segmento(
        4, "Risco Muito Baixo / Limite Premium", "75 – 103",
        "5,0× a renda", "R$ 60.000,00", 5.00,
        [
            "Score ≥ 75 pontos",
            "Pagamentos sempre em dia + renda alta (≥ R$ 8.000)",
            "Relacionamento longo (≥ 120 meses) com a instituição",
            "Sem empréstimos ativos e usuário de múltiplos produtos",
        ],
        "Perfil excelente com todos ou quase todos os fatores favoráveis. Limite "
        "potencial de 5,0× a renda mensal, com teto absoluto de R$ 60.000,00. "
        "A restrição de 30% da renda mensal é o fator limitante predominante neste "
        "segmento, garantindo que mesmo clientes premium não recebam crédito "
        "desproporcional à sua capacidade de pagamento mensal.",
        12000.0, COR_VERDE
    ):
        historia.append(items)

    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 5 — RESULTADOS
    # =======================================================================
    historia.append(Paragraph("5. Resultados da Classificação", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO, spaceAfter=8))

    historia.append(Paragraph("5.1 Distribuição dos Clientes por Segmento", estilos["h2"]))
    dados_dist = [
        ["Segmento", "Nome",                                    "Qtd", "%",    "Limite Médio Final"],
        ["1", "Alto Risco / Sem Limite",           str(dist_segmentos.get(1,0)),
         f"{dist_segmentos.get(1,0)/total*100:.1f}%",
         f"R$ {stats_limite.get(1,{}).get('media',0):,.2f}"],
        ["2", "Risco Moderado / Limite Básico",    str(dist_segmentos.get(2,0)),
         f"{dist_segmentos.get(2,0)/total*100:.1f}%",
         f"R$ {stats_limite.get(2,{}).get('media',0):,.2f}"],
        ["3", "Baixo Risco / Limite Intermediário",str(dist_segmentos.get(3,0)),
         f"{dist_segmentos.get(3,0)/total*100:.1f}%",
         f"R$ {stats_limite.get(3,{}).get('media',0):,.2f}"],
        ["4", "Risco Muito Baixo / Limite Premium",str(dist_segmentos.get(4,0)),
         f"{dist_segmentos.get(4,0)/total*100:.1f}%",
         f"R$ {stats_limite.get(4,{}).get('media',0):,.2f}"],
        ["TOTAL", "—",                             str(total), "100%", "—"],
    ]
    col_w_dist = [1.8*cm, 6.5*cm, 1.8*cm, 1.8*cm, 4.0*cm]
    t_dist = Table(dados_dist, colWidths=col_w_dist, repeatRows=1)
    t_dist.setStyle(tabela_estilo_base(col_w_dist))
    t_dist.setStyle(TableStyle([
        ("FONTSIZE",   (0, 0), (-1, -1), 8.5),
        ("ALIGN",      (0, 0), (0, -1), "CENTER"),
        ("ALIGN",      (2, 0), (3, -1), "CENTER"),
        ("BACKGROUND", (0, 1), (-1, 1), HexColor("#FADBD8")),
        ("BACKGROUND", (0, 2), (-1, 2), HexColor("#FDEBD0")),
        ("BACKGROUND", (0, 3), (-1, 3), HexColor("#FEF9E7")),
        ("BACKGROUND", (0, 4), (-1, 4), HexColor("#EAFAF1")),
        ("FONTNAME",   (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), COR_CINZA_BG),
    ]))
    historia.append(t_dist)
    historia.append(Paragraph("Tabela 6 — Distribuição dos Clientes por Segmento", estilos["caption"]))
    historia.append(Spacer(1, 0.5 * cm))

    # Gráfico de barras
    historia.append(Paragraph("5.2 Gráfico de Distribuição por Segmento", estilos["h2"]))
    grafico = criar_grafico_barras_segmentos()
    historia.append(grafico)
    historia.append(Paragraph("Figura 1 — Distribuição Absoluta e Relativa dos Clientes por Segmento",
                               estilos["caption"]))
    historia.append(Spacer(1, 0.4 * cm))

    # Impacto do teto de 30%
    historia.append(Paragraph("5.3 Impacto do Teto de 30% da Renda Líquida", estilos["h2"]))
    historia.append(Paragraph(
        "A tabela abaixo consolida o impacto da restrição de 30% da renda líquida "
        "sobre os limites calculados pelos segmentos:", estilos["body"]
    ))
    pct_teto = clientes_com_teto / total * 100

    # Por segmento: quantos tiveram teto aplicado
    teto_por_seg = {}
    for seg in [1, 2, 3, 4]:
        sub = [r for r in resultados if r["segmento"] == seg]
        com_teto = sum(1 for r in sub if r["teto_aplicado"])
        reds = [r["limite_segmento"] - r["limite_final"] for r in sub if r["teto_aplicado"]]
        teto_por_seg[seg] = {
            "total": len(sub),
            "com_teto": com_teto,
            "pct_teto": com_teto / len(sub) * 100 if sub else 0,
            "reducao_media": statistics.mean(reds) if reds else 0,
        }

    dados_teto = [
        ["Segmento", "Clientes", "Com Teto Aplicado", "% com Teto", "Redução Média (R$)"],
    ]
    for seg in [1, 2, 3, 4]:
        d = teto_por_seg[seg]
        dados_teto.append([
            str(seg),
            str(d["total"]),
            str(d["com_teto"]),
            f"{d['pct_teto']:.1f}%",
            f"R$ {d['reducao_media']:,.2f}",
        ])
    dados_teto.append([
        "TOTAL",
        str(total),
        str(clientes_com_teto),
        f"{pct_teto:.1f}%",
        f"R$ {reducao_media:,.2f}",
    ])
    col_w_teto = [2.0*cm, 2.5*cm, 3.5*cm, 2.5*cm, 4.5*cm]
    t_teto = Table(dados_teto, colWidths=col_w_teto, repeatRows=1)
    t_teto.setStyle(tabela_estilo_base(col_w_teto))
    t_teto.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN",    (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), COR_CINZA_BG),
    ]))
    historia.append(t_teto)
    historia.append(Paragraph(
        "Tabela 7 — Impacto do Teto de 30% da Renda Líquida por Segmento",
        estilos["caption"]
    ))
    historia.append(Spacer(1, 0.3 * cm))
    historia.append(Paragraph(
        f"<b>Nota:</b> {clientes_com_teto} clientes ({pct_teto:.1f}%) tiveram o "
        f"limite reduzido pela restrição de 30% da renda líquida. A redução média "
        f"sobre esses clientes foi de <b>R$ {reducao_media:,.2f}</b>.",
        estilos["body"]
    ))

    # Estatísticas de limite por segmento
    historia.append(Spacer(1, 0.3 * cm))
    historia.append(Paragraph("5.4 Estatísticas dos Limites Finais por Segmento", estilos["h2"]))
    dados_lim = [["Segmento", "Mínimo", "Mediana", "Média", "Máximo"]]
    for seg in [1, 2, 3, 4]:
        sl = stats_limite.get(seg, {})
        dados_lim.append([
            f"Seg. {seg}",
            f"R$ {sl.get('minimo', 0):,.2f}",
            f"R$ {sl.get('mediana', 0):,.2f}",
            f"R$ {sl.get('media', 0):,.2f}",
            f"R$ {sl.get('maximo', 0):,.2f}",
        ])
    col_w_lim = [2.5*cm, 3.5*cm, 3.5*cm, 3.5*cm, 3.5*cm]
    t_lim = Table(dados_lim, colWidths=col_w_lim, repeatRows=1)
    t_lim.setStyle(tabela_estilo_base(col_w_lim))
    t_lim.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN",    (0, 0), (-1, -1), "CENTER"),
    ]))
    historia.append(t_lim)
    historia.append(Paragraph(
        "Tabela 8 — Estatísticas dos Limites de Crédito Finais por Segmento",
        estilos["caption"]
    ))
    historia.append(PageBreak())

    # =======================================================================
    # SEÇÃO 6 — CONCLUSÃO
    # =======================================================================
    historia.append(Paragraph("6. Conclusão e Recomendações", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO, spaceAfter=8))
    historia.append(Paragraph(
        "O sistema de avaliação de limite de crédito desenvolvido classifica os "
        f"{total} clientes da base em quatro segmentos de risco distintos, com base "
        "em um modelo de pontuação que considera adimplência, renda, tempo de "
        "relacionamento, endividamento ativo e engajamento com produtos.", estilos["body"]
    ))
    historia.append(Paragraph(
        "A aplicação do teto obrigatório de 30% da renda líquida como regra "
        "inviolável garantiu que nenhum cliente recebesse um limite de crédito "
        "desproporcional à sua capacidade financeira real, independentemente de "
        "sua classificação por score.", estilos["body"]
    ))

    historia.append(Paragraph("Recomendações para Revisão e Melhoria:", estilos["h2"]))
    recomendacoes = [
        "Incorporar dados de histórico de inadimplência real para treinamento de "
        "modelos preditivos (regressão logística, gradient boosting), aumentando "
        "a acurácia das previsões.",
        "Adicionar variáveis de comprometimento de renda (total de dívidas / renda) "
        "e bureau de crédito externo para enriquecer o modelo.",
        "Realizar backtesting semestral comparando as classificações com o "
        "comportamento real de pagamento dos clientes.",
        "Revisar os thresholds de score e os fatores de limite anualmente, "
        "adequando-os às condições macroeconômicas.",
        "Implementar monitoramento contínuo da distribuição dos segmentos para "
        "detectar desvios populacionais (PSI — Population Stability Index).",
        "Considerar segmentação adicional por faixa etária ou tipo de produto "
        "para maior granularidade na oferta de crédito.",
    ]
    for rec in recomendacoes:
        historia.append(Paragraph(f"• {rec}", estilos["body"]))
    historia.append(PageBreak())

    # =======================================================================
    # ANEXO — TABELA INDIVIDUAL
    # =======================================================================
    historia.append(Paragraph("Anexo — Classificação Individual dos Clientes", estilos["h1"]))
    historia.append(HRFlowable(width="100%", thickness=0.8, color=COR_AZUL_CLARO, spaceAfter=8))
    historia.append(Paragraph(
        f"A tabela a seguir apresenta a classificação de todos os {total} clientes, "
        "incluindo o segmento atribuído, o limite sugerido pelo segmento e o "
        "limite final após aplicação do teto de 30% da renda líquida.",
        estilos["body"]
    ))
    historia.append(Spacer(1, 0.3 * cm))

    header_anexo = [
        "ID", "Nome", "Score", "Segmento",
        "Lim. Segmento\n(R$)", "Teto 30%\n(R$)", "Lim. Final\n(R$)"
    ]
    linhas_anexo = [header_anexo]
    for r in resultados:
        linhas_anexo.append([
            str(r["id"]),
            r["nome"][:28],  # trunca nome longo
            str(r["score"]),
            str(r["segmento"]),
            f"{r['limite_segmento']:,.2f}",
            f"{r['teto_30pct']:,.2f}",
            f"{r['limite_final']:,.2f}",
        ])

    col_w_anx = [1.2*cm, 5.5*cm, 1.5*cm, 2.0*cm, 3.0*cm, 2.8*cm, 2.8*cm]
    # Divide a tabela em chunks para não ultrapassar a página
    chunk_size = 35
    for i in range(0, len(linhas_anexo), chunk_size):
        chunk = linhas_anexo[0:1] + linhas_anexo[max(1, i):i + chunk_size]  # cabeçalho sempre
        if i == 0:
            chunk = linhas_anexo[0:chunk_size]
        t_anx = Table(chunk, colWidths=col_w_anx, repeatRows=1)
        t_anx.setStyle(tabela_estilo_base(col_w_anx))
        t_anx.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
            ("ALIGN",    (0, 0), (0, -1), "CENTER"),
            ("ALIGN",    (2, 0), (-1, -1), "CENTER"),
            ("LEFTPADDING",  (0, 0), (-1, -1), 3),
            ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ]))
        historia.append(t_anx)
        if i + chunk_size < len(linhas_anexo):
            historia.append(PageBreak())
            historia.append(Paragraph(
                "Anexo (continuação) — Classificação Individual dos Clientes",
                estilos["h2"]
            ))

    # Build do PDF
    doc.build(
        historia,
        onFirstPage=adicionar_numero_pagina,
        onLaterPages=adicionar_numero_pagina,
    )
    print(f"\n[OK] PDF gerado em: {OUTPUT_PATH}")


# ---------------------------------------------------------------------------
# EXECUÇÃO
# ---------------------------------------------------------------------------

gerar_pdf()

# Resumo final para o terminal
print("\n" + "="*60)
print("RESUMO FINAL")
print("="*60)
print(f"Total de clientes: {len(resultados)}")
print("\nDistribuição por segmento:")
for seg in [1, 2, 3, 4]:
    qtd = dist_segmentos.get(seg, 0)
    print(f"  Seg.{seg} ({LIMITES_SEGMENTOS[seg]['nome']}): "
          f"{qtd} ({qtd/len(resultados)*100:.1f}%)")
print(f"\nClientes com teto de 30% aplicado: {clientes_com_teto} "
      f"({clientes_com_teto/len(resultados)*100:.1f}%)")
print(f"Redução média pelo teto: R$ {reducao_media:,.2f}")
