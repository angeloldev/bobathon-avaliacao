"""
API Flask — Base de Clientes de Crédito.

Endpoints:
  GET  /clientes              lista com filtros opcionais
  GET  /clientes/cpf/{cpf}    busca por CPF exato
  GET  /clientes/nome/{nome}  busca por nome parcial
  GET  /health                health-check

Inicie com:
    python credit_agent/api.py
    # ou com porta customizada:
    PORT=8000 python credit_agent/api.py
"""

import json
import os
from pathlib import Path
from flask import Flask, jsonify, request, abort

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Carregamento da base
# ---------------------------------------------------------------------------

_BASE_PATH = Path(__file__).parent / "base_clientes_credito.json"

def _carregar_base() -> list[dict]:
    with open(_BASE_PATH, encoding="utf-8") as f:
        return json.load(f)

_BASE: list[dict] = _carregar_base()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _score(c: dict) -> int:
    """Score sintético de crédito 0-100."""
    s = 0
    if c["pagamentos_dia"] == "Sim":
        s += 40
    if c["emprestimos_ativos"] == "Não":
        s += 20
    if c["usuario_produtos"] == "Sim":
        s += 15
    s += min(15, int(c["relacionamento_meses"] / 120 * 15))
    s += min(10, int(c["renda_liquida"] / 10_000 * 10))
    return s


def _serializar(c: dict) -> dict:
    return {
        "id": c["id"],
        "nome": c["nome"],
        "cpf": c["cpf"],
        "idade": c["idade"],
        "renda_liquida_mensal_brl": c["renda_liquida"],
        "tempo_relacionamento_meses": c["relacionamento_meses"],
        "pagamentos_em_dia": c["pagamentos_dia"] == "Sim",
        "tem_emprestimos_ativos": c["emprestimos_ativos"] == "Sim",
        "usuario_de_produtos_bancarios": c["usuario_produtos"] == "Sim",
        "score_credito_sintetico": _score(c),
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    """Health-check da API."""
    return jsonify({"status": "ok", "total_clientes": len(_BASE)})


@app.get("/clientes")
def listar_clientes():
    """
    Lista clientes com filtros opcionais via query-string.

    Query params:
      pagamentos_em_dia        (true|false)
      tem_emprestimos_ativos   (true|false)
      usuario_de_produtos      (true|false)
      renda_minima             (float)
      renda_maxima             (float)
      limite                   (int, padrão 20, máx 200)
    """
    resultado = list(_BASE)

    def _bool(param: str) -> bool | None:
        v = request.args.get(param)
        if v is None:
            return None
        return v.lower() in ("true", "1", "sim")

    pagamentos_em_dia = _bool("pagamentos_em_dia")
    emprestimos = _bool("tem_emprestimos_ativos")
    produtos = _bool("usuario_de_produtos")
    renda_min = request.args.get("renda_minima", type=float)
    renda_max = request.args.get("renda_maxima", type=float)
    limite = min(request.args.get("limite", default=20, type=int), 200)

    if pagamentos_em_dia is not None:
        flag = "Sim" if pagamentos_em_dia else "Não"
        resultado = [c for c in resultado if c["pagamentos_dia"] == flag]

    if emprestimos is not None:
        flag = "Sim" if emprestimos else "Não"
        resultado = [c for c in resultado if c["emprestimos_ativos"] == flag]

    if produtos is not None:
        flag = "Sim" if produtos else "Não"
        resultado = [c for c in resultado if c["usuario_produtos"] == flag]

    if renda_min is not None:
        resultado = [c for c in resultado if c["renda_liquida"] >= renda_min]

    if renda_max is not None:
        resultado = [c for c in resultado if c["renda_liquida"] <= renda_max]

    return jsonify([_serializar(c) for c in resultado[:limite]])


@app.get("/clientes/cpf/<cpf>")
def buscar_por_cpf(cpf: str):
    """Retorna um cliente pelo CPF (com ou sem formatação)."""
    cpf_limpo = cpf.replace(".", "").replace("-", "").strip()
    for c in _BASE:
        if c["cpf"].replace(".", "").replace("-", "") == cpf_limpo:
            return jsonify(_serializar(c))
    abort(404, description=f"Cliente com CPF '{cpf}' não encontrado.")


@app.get("/clientes/nome/<nome>")
def buscar_por_nome(nome: str):
    """Retorna clientes cujo nome contenha o texto informado (case-insensitive)."""
    termo = nome.lower().strip()
    encontrados = [_serializar(c) for c in _BASE if termo in c["nome"].lower()]
    return jsonify(encontrados)


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"erro": str(e.description)}), 404


@app.errorhandler(400)
def bad_request(e):
    return jsonify({"erro": str(e.description)}), 400


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5001))
    print(f"API de crédito rodando em http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
