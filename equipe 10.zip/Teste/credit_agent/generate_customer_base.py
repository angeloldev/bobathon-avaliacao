"""
Gerador de base de clientes fictícios para concessão de limite de crédito.
Exporta 200 clientes em PDF e JSON com dados relevantes para análise de crédito.
"""

import json
import random
import re
from datetime import datetime
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph,
    Spacer, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# ---------------------------------------------------------------------------
# Dados fictícios para geração de nomes
# ---------------------------------------------------------------------------

PRIMEIROS_NOMES = [
    "Ana", "Bruno", "Carla", "Daniel", "Eduarda", "Felipe", "Gabriela",
    "Henrique", "Isabela", "João", "Karina", "Lucas", "Mariana", "Nicolas",
    "Olivia", "Pedro", "Quintina", "Rafael", "Sabrina", "Thiago", "Ursula",
    "Vinícius", "Wanda", "Xavier", "Yasmin", "Zélia", "Amanda", "Bernardo",
    "Camila", "Diego", "Elaine", "Fernando", "Giovanna", "Heitor", "Ingrid",
    "Júlia", "Kleber", "Larissa", "Marcos", "Nadia", "Otávio", "Patrícia",
    "Quezia", "Renato", "Sandra", "Tânia", "Úrsula", "Vagner", "Wendy",
]

SOBRENOMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves",
    "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho",
    "Almeida", "Lopes", "Sousa", "Fernandes", "Vieira", "Barbosa", "Rocha",
    "Dias", "Nascimento", "Andrade", "Moreira", "Nunes", "Marques", "Melo",
    "Cavalcanti", "Teixeira", "Pinto", "Cardoso", "Medeiros", "Moraes",
    "Araújo", "Correia", "Ramos", "Mendes", "Castro", "Campos",
]


# ---------------------------------------------------------------------------
# Funções auxiliares
# ---------------------------------------------------------------------------

def gerar_cpf() -> str:
    """Gera um CPF fictício formatado."""
    nums = [random.randint(0, 9) for _ in range(9)]
    # dígito 1
    s = sum((10 - i) * nums[i] for i in range(9))
    d1 = 0 if (s % 11) < 2 else 11 - (s % 11)
    nums.append(d1)
    # dígito 2
    s = sum((11 - i) * nums[i] for i in range(10))
    d2 = 0 if (s % 11) < 2 else 11 - (s % 11)
    nums.append(d2)
    return f"{nums[0]}{nums[1]}{nums[2]}.{nums[3]}{nums[4]}{nums[5]}.{nums[6]}{nums[7]}{nums[8]}-{nums[9]}{nums[10]}"


def gerar_nome() -> str:
    return f"{random.choice(PRIMEIROS_NOMES)} {random.choice(SOBRENOMES)} {random.choice(SOBRENOMES)}"


def gerar_renda(idade: int) -> float:
    """Renda líquida mensal em R$ com distribuição realista por faixa etária."""
    if idade < 25:
        base = random.uniform(1_200, 3_500)
    elif idade < 35:
        base = random.uniform(2_000, 8_000)
    elif idade < 50:
        base = random.uniform(2_500, 15_000)
    elif idade < 65:
        base = random.uniform(2_000, 12_000)
    else:
        base = random.uniform(1_500, 6_000)
    return round(base, 2)


def gerar_cliente(id_cliente: int, cpfs_usados: set) -> dict:
    """Gera um cliente fictício com dados de crédito."""
    nome = gerar_nome()
    idade = random.randint(18, 80)
    renda = gerar_renda(idade)
    relacionamento_meses = random.randint(1, 240)

    # Lógica de correlação realista
    pagamentos_dia = random.choices([True, False], weights=[75, 25])[0]
    emprestimos_ativos = random.choices([True, False], weights=[40, 60])[0]
    usuario_produtos = random.choices([True, False], weights=[65, 35])[0]

    # CPF único
    while True:
        cpf = gerar_cpf()
        if cpf not in cpfs_usados:
            cpfs_usados.add(cpf)
            break

    return {
        "id": id_cliente,
        "nome": nome,
        "cpf": cpf,
        "idade": idade,
        "renda_liquida": renda,
        "relacionamento_meses": relacionamento_meses,
        "pagamentos_dia": "Sim" if pagamentos_dia else "Não",
        "emprestimos_ativos": "Sim" if emprestimos_ativos else "Não",
        "usuario_produtos": "Sim" if usuario_produtos else "Não",
    }


def gerar_base(n: int = 200) -> list[dict]:
    cpfs_usados: set = set()
    return [gerar_cliente(i + 1, cpfs_usados) for i in range(n)]


# ---------------------------------------------------------------------------
# Geração do PDF
# ---------------------------------------------------------------------------

def gerar_pdf(clientes: list[dict], caminho_saida: str = "base_clientes_credito.pdf") -> str:
    doc = SimpleDocTemplate(
        caminho_saida,
        pagesize=landscape(A4),
        rightMargin=1 * cm,
        leftMargin=1 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
    )

    styles = getSampleStyleSheet()
    titulo_style = ParagraphStyle(
        "Titulo",
        parent=styles["Heading1"],
        fontSize=14,
        alignment=TA_CENTER,
        spaceAfter=4,
        textColor=colors.HexColor("#1a3a5c"),
    )
    subtitulo_style = ParagraphStyle(
        "Subtitulo",
        parent=styles["Normal"],
        fontSize=9,
        alignment=TA_CENTER,
        spaceAfter=2,
        textColor=colors.HexColor("#57606a"),
    )
    rodape_style = ParagraphStyle(
        "Rodape",
        parent=styles["Normal"],
        fontSize=7,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#57606a"),
    )

    # Cabeçalho da tabela
    cabecalho = [
        "#",
        "Nome Completo",
        "CPF",
        "Idade",
        "Renda Líquida (R$)",
        "Relacionamento\n(meses)",
        "Pagamentos\nem Dia",
        "Empréstimos\nAtivos",
        "Usuário de\nProdutos",
    ]

    linhas = [cabecalho]
    for c in clientes:
        linhas.append([
            str(c["id"]),
            c["nome"],
            c["cpf"],
            str(c["idade"]),
            f"R$ {c['renda_liquida']:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."),
            str(c["relacionamento_meses"]),
            c["pagamentos_dia"],
            c["emprestimos_ativos"],
            c["usuario_produtos"],
        ])

    # Larguras das colunas (total ~ 27 cm em landscape A4)
    col_widths = [1.0*cm, 5.5*cm, 3.2*cm, 1.4*cm, 3.2*cm, 2.4*cm, 2.4*cm, 2.4*cm, 2.4*cm]

    tabela = Table(linhas, colWidths=col_widths, repeatRows=1)

    sim_color = colors.HexColor("#d4edda")
    nao_color = colors.HexColor("#f8d7da")
    header_color = colors.HexColor("#1a3a5c")
    alt_color = colors.HexColor("#f0f4f8")

    estilo_base = [
        # Cabeçalho
        ("BACKGROUND", (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 7),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("VALIGN", (0, 0), (-1, 0), "MIDDLE"),
        # Corpo
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 1), (-1, -1), 7),
        ("ALIGN", (0, 1), (0, -1), "CENTER"),   # id
        ("ALIGN", (1, 1), (1, -1), "LEFT"),      # nome
        ("ALIGN", (2, 1), (2, -1), "CENTER"),    # cpf
        ("ALIGN", (3, 1), (5, -1), "CENTER"),    # idade / renda / relacionamento
        ("ALIGN", (6, 1), (8, -1), "CENTER"),    # flags
        ("VALIGN", (0, 1), (-1, -1), "MIDDLE"),
        # Grade
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#c0c8d4")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, alt_color]),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]

    # Colorir células Sim / Não
    for row_idx, cliente in enumerate(clientes, start=1):
        for col_idx, campo in [(6, "pagamentos_dia"), (7, "emprestimos_ativos"), (8, "usuario_produtos")]:
            cor = sim_color if cliente[campo] == "Sim" else nao_color
            estilo_base.append(("BACKGROUND", (col_idx, row_idx), (col_idx, row_idx), cor))

    tabela.setStyle(TableStyle(estilo_base))

    # Estatísticas resumidas
    total = len(clientes)
    pct_pagam_dia = sum(1 for c in clientes if c["pagamentos_dia"] == "Sim") / total * 100
    pct_emprestimo = sum(1 for c in clientes if c["emprestimos_ativos"] == "Sim") / total * 100
    pct_produtos = sum(1 for c in clientes if c["usuario_produtos"] == "Sim") / total * 100
    renda_media = sum(c["renda_liquida"] for c in clientes) / total
    rel_medio = sum(c["relacionamento_meses"] for c in clientes) / total

    resumo_txt = (
        f"Total de clientes: <b>{total}</b>  |  "
        f"Pagam em dia: <b>{pct_pagam_dia:.1f}%</b>  |  "
        f"Com empréstimos ativos: <b>{pct_emprestimo:.1f}%</b>  |  "
        f"Usuários de produtos: <b>{pct_produtos:.1f}%</b>  |  "
        f"Renda média: <b>R$ {renda_media:,.2f}</b>  |  "
        f"Relacionamento médio: <b>{rel_medio:.0f} meses</b>"
    ).replace(",", "X").replace(".", ",").replace("X", ".")

    # Montagem do documento
    elementos = [
        Paragraph("Base de Clientes — Concessão de Limite de Crédito", titulo_style),
        Paragraph(f"Banco Fictício S.A.  •  Gerado em {datetime.now().strftime('%d/%m/%Y %H:%M')}  •  Dados Simulados", subtitulo_style),
        HRFlowable(width="100%", thickness=1, color=colors.HexColor("#1a3a5c"), spaceAfter=6),
        tabela,
        Spacer(1, 0.3 * cm),
        Paragraph(resumo_txt, rodape_style),
    ]

    doc.build(elementos)
    return caminho_saida


def gerar_json(clientes: list[dict], caminho_saida: str = "base_clientes_credito.json") -> str:
    """Exporta a base de clientes como JSON para consumo pela tool do Orchestrate."""
    with open(caminho_saida, "w", encoding="utf-8") as f:
        json.dump(clientes, f, ensure_ascii=False, indent=2)
    return caminho_saida


# ---------------------------------------------------------------------------
# Ponto de entrada
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Gerando base de 200 clientes fictícios...")
    clientes = gerar_base(200)

    arquivo_pdf = gerar_pdf(clientes, "credit_agent/base_clientes_credito.pdf")
    print(f"PDF gerado com sucesso: {arquivo_pdf}")

    arquivo_json = gerar_json(clientes, "credit_agent/base_clientes_credito.json")
    print(f"JSON gerado com sucesso: {arquivo_json}")
