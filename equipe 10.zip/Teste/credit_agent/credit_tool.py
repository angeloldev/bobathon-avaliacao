"""
Tool para watsonx Orchestrate: Consulta de Perfil de Crédito de Clientes.

Expõe três funções para o agente:
  - buscar_cliente_por_cpf   : retorna dados completos de um cliente pelo CPF
  - buscar_cliente_por_nome  : busca por nome parcial (case-insensitive)
  - listar_clientes_credito  : lista clientes com filtros opcionais

O JSON da base é carregado uma única vez ao importar o módulo (cache em memória).
"""

import json
import os
from typing import Optional

from ibm_watsonx_orchestrate.agent_builder.tools import tool

# ---------------------------------------------------------------------------
# Carregamento da base (caminho relativo ao arquivo da tool)
# ---------------------------------------------------------------------------

_BASE_PATH = os.path.join(os.path.dirname(__file__), "base_clientes_credito.json")

def _carregar_base() -> list[dict]:
    with open(_BASE_PATH, encoding="utf-8") as f:
        return json.load(f)

_BASE_CLIENTES: list[dict] = _carregar_base()


# ---------------------------------------------------------------------------
# Tool 1 — buscar por CPF (correspondência exata)
# ---------------------------------------------------------------------------

@tool
def buscar_cliente_por_cpf(cpf: str) -> dict:
    """
    Retorna os dados de crédito de um cliente a partir do CPF informado.

    Args:
        cpf: CPF do cliente no formato XXX.XXX.XXX-XX ou apenas dígitos.

    Returns:
        Dicionário com os dados do cliente ou mensagem de erro se não encontrado.
    """
    cpf_limpo = cpf.replace(".", "").replace("-", "").strip()

    for cliente in _BASE_CLIENTES:
        cpf_base = cliente["cpf"].replace(".", "").replace("-", "")
        if cpf_base == cpf_limpo:
            return _formatar_cliente(cliente)

    return {"erro": f"Cliente com CPF {cpf} não encontrado na base."}


# ---------------------------------------------------------------------------
# Tool 2 — buscar por nome (correspondência parcial)
# ---------------------------------------------------------------------------

@tool
def buscar_cliente_por_nome(nome: str) -> list[dict]:
    """
    Busca clientes cujo nome contenha o texto informado (sem distinção de maiúsculas).

    Args:
        nome: Texto a procurar no nome completo do cliente (ex: "Ana Silva").

    Returns:
        Lista de clientes encontrados (pode ser vazia).
    """
    termo = nome.lower().strip()
    resultados = [
        _formatar_cliente(c)
        for c in _BASE_CLIENTES
        if termo in c["nome"].lower()
    ]
    return resultados


# ---------------------------------------------------------------------------
# Tool 3 — listagem filtrada
# ---------------------------------------------------------------------------

@tool
def listar_clientes_credito(
    pagamentos_em_dia: Optional[bool] = None,
    tem_emprestimos_ativos: Optional[bool] = None,
    usuario_de_produtos: Optional[bool] = None,
    renda_minima: Optional[float] = None,
    renda_maxima: Optional[float] = None,
    limite: int = 20,
) -> list[dict]:
    """
    Lista clientes da base com filtros opcionais de perfil de crédito.

    Args:
        pagamentos_em_dia: True para clientes adimplentes, False para inadimplentes.
        tem_emprestimos_ativos: True para quem possui empréstimos ativos.
        usuario_de_produtos: True para usuários de produtos bancários.
        renda_minima: Filtrar por renda líquida mensal mínima (R$).
        renda_maxima: Filtrar por renda líquida mensal máxima (R$).
        limite: Número máximo de registros retornados (padrão: 20, máximo: 200).

    Returns:
        Lista de clientes que atendem aos filtros aplicados.
    """
    resultado = list(_BASE_CLIENTES)

    if pagamentos_em_dia is not None:
        valor = "Sim" if pagamentos_em_dia else "Não"
        resultado = [c for c in resultado if c["pagamentos_dia"] == valor]

    if tem_emprestimos_ativos is not None:
        valor = "Sim" if tem_emprestimos_ativos else "Não"
        resultado = [c for c in resultado if c["emprestimos_ativos"] == valor]

    if usuario_de_produtos is not None:
        valor = "Sim" if usuario_de_produtos else "Não"
        resultado = [c for c in resultado if c["usuario_produtos"] == valor]

    if renda_minima is not None:
        resultado = [c for c in resultado if c["renda_liquida"] >= renda_minima]

    if renda_maxima is not None:
        resultado = [c for c in resultado if c["renda_liquida"] <= renda_maxima]

    return [_formatar_cliente(c) for c in resultado[: min(limite, 200)]]


# ---------------------------------------------------------------------------
# Helper interno
# ---------------------------------------------------------------------------

def _formatar_cliente(c: dict) -> dict:
    """Normaliza e enriquece o registro antes de retornar ao agente."""
    return {
        "id": c["id"],
        "nome": c["nome"],
        "cpf": c["cpf"],
        "idade": c["idade"],
        "renda_liquida_mensal_brl": c["renda_liquida"],
        "tempo_relacionamento_meses": c["relacionamento_meses"],
        "pagamentos_em_dia": c["pagamentos_dia"] == "Sim",
        "tem_emprestimos_ativos": c["emprestimos_ativos"] == "Sim",
        "usuario_de_produtos_bancarios": c["usuario_produtos"] == "Sim",
        # Score sintético de crédito (0–100) baseado nos indicadores disponíveis
        "score_credito_sintetico": _calcular_score(c),
    }


def _calcular_score(c: dict) -> int:
    """
    Score sintético de crédito (0–100) derivado dos campos da base.

    Componentes:
      - Adimplência         : +40 pts
      - Sem empréstimos     : +20 pts
      - Usuário de produtos : +15 pts
      - Relacionamento      : até +15 pts (máx em 120 meses)
      - Renda               : até +10 pts (máx em R$ 10.000)
    """
    score = 0
    if c["pagamentos_dia"] == "Sim":
        score += 40
    if c["emprestimos_ativos"] == "Não":
        score += 20
    if c["usuario_produtos"] == "Sim":
        score += 15
    score += min(15, int(c["relacionamento_meses"] / 120 * 15))
    score += min(10, int(c["renda_liquida"] / 10_000 * 10))
    return score
