"""Nó 2: Monta a carteira de investimentos com base no perfil classificado."""

from investment_agent.models.state import AgentState
from investment_agent.engines.allocation_engine import montar_carteira


def node_montar_carteira(state: AgentState) -> AgentState:
    """
    Recebe a classificação e o questionário e produz a carteira recomendada.
    Popula: state['carteira']
    """
    questionario = state["questionario"]
    classificacao = state["classificacao"]

    carteira = montar_carteira(questionario, classificacao)

    print(
        f"[alocacao] Carteira montada com {len(carteira.alocacoes)} classes de ativos "
        f"| Retorno esperado: {carteira.retorno_esperado_anual_pct}% a.a."
    )

    return {**state, "carteira": carteira}
