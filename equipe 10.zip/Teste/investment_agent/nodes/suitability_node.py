"""Nó 1: Classifica o perfil do investidor via engine de suitability."""

from investment_agent.models.state import AgentState
from investment_agent.engines.suitability_engine import classificar_investidor


def node_classificar_perfil(state: AgentState) -> AgentState:
    """
    Recebe o questionário e produz a classificação do investidor.
    Popula: state['classificacao']
    """
    questionario = state["questionario"]
    classificacao = classificar_investidor(questionario)

    print(
        f"[suitability] Perfil: {classificacao.perfil.value.upper()} "
        f"| Score: {classificacao.score}/{classificacao.score_maximo} "
        f"({classificacao.percentual}%)"
    )

    return {**state, "classificacao": classificacao}
