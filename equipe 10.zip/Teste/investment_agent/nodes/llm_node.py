"""
Nó 3: Gera a justificativa textual da carteira usando um LLM (OpenAI / ChatOpenAI).

A justificativa é inserida no objeto Portfolio já construído pelo nó anterior.
"""

import os
from textwrap import dedent

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

from investment_agent.models.state import AgentState
from investment_agent.models.portfolio import Portfolio
from investment_agent.models.suitability import SuitabilityQuestionnaire, InvestorClassification


def _build_prompt(
    q: SuitabilityQuestionnaire,
    classificacao: InvestorClassification,
    carteira: Portfolio,
) -> str:
    """Monta o prompt enviado ao LLM com todos os dados relevantes."""

    alocacao_str = "\n".join(
        f"  - {a.classe} / {a.subclasse}: {a.percentual * 100:.1f}%"
        f"  (R$ {a.valor_estimado:,.2f})"
        f" | Exemplos: {', '.join(a.exemplos)}"
        for a in carteira.alocacoes
    )

    alertas_str = (
        "\n".join(f"  - {av}" for av in carteira.alertas)
        if carteira.alertas
        else "  Nenhum."
    )

    return dedent(f"""
        Você é um consultor financeiro especializado em carteiras de investimento para o mercado brasileiro.
        Com base nos dados abaixo, escreva uma justificativa personalizada, profissional e clara para o cliente,
        explicando por que essa carteira foi montada para ele. Use linguagem acessível, mas técnica.
        Seja direto e objetivo. Escreva em PT-BR. Máximo 5 parágrafos.

        === DADOS DO CLIENTE ===
        Nome: {q.nome}
        Idade: {q.idade} anos
        Renda mensal: R$ {q.renda_mensal:,.2f}
        Patrimônio total: R$ {q.patrimonio_total:,.2f}
        Valor a investir: R$ {q.valor_a_investir:,.2f}
        Objetivo: {q.objetivo.value.replace("_", " ").title()}
        Horizonte: {q.horizonte.value.replace("_", " ").title()}
        Tolerância a perda (1-5): {q.tolerancia_perda}
        Experiência no mercado (1-5): {q.experiencia_mercado}
        Tem reserva de emergência: {"Sim" if q.tem_reserva_emergencia else "Não"}
        Tem dívidas: {"Sim" if q.tem_dividas else "Não"}

        === PERFIL CLASSIFICADO ===
        Perfil: {classificacao.perfil.value.upper()}
        Score: {classificacao.score}/{classificacao.score_maximo} ({classificacao.percentual}%)
        Fatores observados: {"; ".join(classificacao.fatores_de_risco) or "Nenhum."}

        === CARTEIRA RECOMENDADA ===
        Retorno esperado (a.a.): {carteira.retorno_esperado_anual_pct}%
        Volatilidade esperada (a.a.): {carteira.volatilidade_esperada_pct}%
        Alocações:
{alocacao_str}

        Alertas:
{alertas_str}
    """).strip()


def node_gerar_justificativa(state: AgentState) -> AgentState:
    """
    Chama o LLM para gerar a justificativa textual e a insere na carteira.
    Popula: state['carteira'].justificativa, state['justificativa']
    """
    q = state["questionario"]
    classificacao = state["classificacao"]
    carteira = state["carteira"]

    model_name = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    llm = ChatOpenAI(model=model_name, temperature=0.4)

    prompt = _build_prompt(q, classificacao, carteira)

    print(f"[llm] Gerando justificativa com modelo {model_name}...")

    messages = [
        SystemMessage(
            content=(
                "Você é um consultor financeiro certificado (CFP) com foco no mercado "
                "brasileiro. Responda sempre em português (PT-BR)."
            )
        ),
        HumanMessage(content=prompt),
    ]

    response = llm.invoke(messages)
    justificativa = response.content.strip()

    # Injeta na carteira
    carteira.justificativa = justificativa

    print("[llm] Justificativa gerada com sucesso.")

    return {**state, "carteira": carteira, "justificativa": justificativa}
