"""Estado compartilhado do grafo LangGraph."""

from typing import Optional, TypedDict
from investment_agent.models.suitability import SuitabilityQuestionnaire, InvestorClassification
from investment_agent.models.portfolio import Portfolio


class AgentState(TypedDict, total=False):
    """Estado mutável que flui entre os nós do grafo."""

    # Entrada
    questionario: SuitabilityQuestionnaire

    # Saída do nó de classificação
    classificacao: InvestorClassification

    # Saída do nó de alocação
    carteira: Portfolio

    # Saída do nó LLM
    justificativa: str

    # Controle de erros
    erro: Optional[str]
