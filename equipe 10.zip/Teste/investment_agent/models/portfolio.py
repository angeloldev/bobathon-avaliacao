"""Modelos de dados para carteira de investimentos recomendada."""

from dataclasses import dataclass, field
from typing import Optional
from investment_agent.models.suitability import InvestorProfile


@dataclass
class AssetAllocation:
    """Alocação de um único tipo de ativo dentro da carteira."""

    classe: str                  # ex: "Renda Fixa", "Renda Variável"
    subclasse: str               # ex: "CDB/LCI/LCA", "Ações BR", "BTC/ETH"
    percentual: float            # percentual da carteira (0.0 a 1.0)
    valor_estimado: float        # valor em R$ baseado no patrimônio a investir
    exemplos: list[str] = field(default_factory=list)   # produtos exemplares
    racional: str = ""           # justificativa curta para essa alocação


@dataclass
class Portfolio:
    """Carteira de investimentos completa recomendada para um cliente."""

    perfil: InvestorProfile
    valor_total: float
    alocacoes: list[AssetAllocation] = field(default_factory=list)

    # Métricas esperadas
    retorno_esperado_anual_pct: float = 0.0   # % ao ano estimado
    volatilidade_esperada_pct: float = 0.0    # % ao ano estimado

    # Texto gerado pelo LLM
    justificativa: str = ""
    alertas: list[str] = field(default_factory=list)

    @property
    def resumo_alocacao(self) -> dict[str, float]:
        """Retorna dicionário {classe: percentual} para fácil visualização."""
        resumo: dict[str, float] = {}
        for a in self.alocacoes:
            resumo[a.classe] = resumo.get(a.classe, 0.0) + a.percentual
        return resumo

    def __str__(self) -> str:
        linhas = [
            f"=== CARTEIRA RECOMENDADA — PERFIL {self.perfil.value.upper()} ===",
            f"Valor total investido: R$ {self.valor_total:,.2f}",
            f"Retorno esperado (a.a.): {self.retorno_esperado_anual_pct:.1f}%",
            f"Volatilidade esperada (a.a.): {self.volatilidade_esperada_pct:.1f}%",
            "",
            "ALOCAÇÃO:",
        ]
        for a in self.alocacoes:
            linhas.append(
                f"  {a.classe} / {a.subclasse}: {a.percentual * 100:.1f}%"
                f"  =>  R$ {a.valor_estimado:,.2f}"
            )
            if a.exemplos:
                linhas.append(f"     Exemplos: {', '.join(a.exemplos)}")
        if self.alertas:
            linhas += ["", "⚠ ALERTAS:"] + [f"  • {av}" for av in self.alertas]
        if self.justificativa:
            linhas += ["", "JUSTIFICATIVA:", self.justificativa]
        return "\n".join(linhas)
