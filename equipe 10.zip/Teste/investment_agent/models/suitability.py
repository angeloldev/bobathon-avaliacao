"""Modelos de dados para o questionário de suitability e perfil do investidor."""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional


class InvestorProfile(str, Enum):
    """Perfis de investidor baseados em tolerância a risco."""
    CONSERVADOR = "conservador"
    MODERADO = "moderado"
    ARROJADO = "arrojado"
    AGRESSIVO = "agressivo"


class InvestmentObjective(str, Enum):
    """Objetivos de investimento declarados pelo cliente."""
    PRESERVACAO_CAPITAL = "preservacao_capital"
    RENDA = "renda"
    CRESCIMENTO_MODERADO = "crescimento_moderado"
    CRESCIMENTO_AGRESSIVO = "crescimento_agressivo"
    ESPECULACAO = "especulacao"


class TimeHorizon(str, Enum):
    """Horizonte de tempo do investimento."""
    CURTO_PRAZO = "curto_prazo"        # até 2 anos
    MEDIO_PRAZO = "medio_prazo"        # 2 a 5 anos
    LONGO_PRAZO = "longo_prazo"        # 5 a 10 anos
    MUITO_LONGO_PRAZO = "muito_longo_prazo"  # acima de 10 anos


@dataclass
class SuitabilityQuestionnaire:
    """Questionário completo de suitability preenchido pelo cliente."""

    # Dados pessoais
    nome: str
    idade: int

    # Financeiro
    renda_mensal: float          # em R$
    patrimonio_total: float      # em R$
    valor_a_investir: float      # em R$

    # Objetivo e horizonte
    objetivo: InvestmentObjective
    horizonte: TimeHorizon

    # Tolerância a risco (respostas de 1 a 5)
    tolerancia_perda: int        # 1 = não tolera perdas; 5 = aceita perdas elevadas
    experiencia_mercado: int     # 1 = nenhuma; 5 = especialista
    reacao_queda_10pct: int      # 1 = vende tudo; 5 = compra mais
    dependencia_do_capital: int  # 1 = depende totalmente; 5 = não depende

    # Contexto
    tem_reserva_emergencia: bool = True
    tem_dividas: bool = False
    observacoes: Optional[str] = None


@dataclass
class InvestorClassification:
    """Resultado da classificação do perfil após análise do questionário."""

    perfil: InvestorProfile
    score: int                   # pontuação total calculada
    score_maximo: int            # pontuação máxima possível
    percentual: float            # score / score_maximo * 100
    fatores_de_risco: list[str] = field(default_factory=list)
    observacoes: list[str] = field(default_factory=list)
