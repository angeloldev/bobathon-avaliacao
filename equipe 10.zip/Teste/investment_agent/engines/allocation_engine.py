"""
Engine de alocação de ativos.

Define as carteiras-modelo para cada perfil e monta a alocação personalizada
com base no valor a investir e nas características do cliente.
"""

from investment_agent.models.suitability import (
    InvestorProfile,
    InvestorClassification,
    SuitabilityQuestionnaire,
    TimeHorizon,
)
from investment_agent.models.portfolio import Portfolio, AssetAllocation


# ---------------------------------------------------------------------------
# Carteiras-modelo por perfil
# (classe, subclasse, percentual-base, exemplos, retorno_esp_aa, volatilidade_esp_aa)
# ---------------------------------------------------------------------------

_CARTEIRAS_MODELO: dict[InvestorProfile, dict] = {
    InvestorProfile.CONSERVADOR: {
        "retorno_esperado": 10.5,
        "volatilidade_esperada": 2.0,
        "alocacoes": [
            ("Renda Fixa", "Tesouro Selic / CDB DI", 0.50,
             ["Tesouro Selic 2027", "CDB 100% CDI"]),
            ("Renda Fixa", "CDB/LCI/LCA prefixado ou IPCA+", 0.30,
             ["CDB IPCA+5%", "LCI IPCA+4,5%", "Tesouro IPCA+ 2029"]),
            ("Fundos", "Fundos de Renda Fixa / Multimercado Baixo Risco", 0.15,
             ["Fundo RF Simples", "Fundo Multimercado Conservador"]),
            ("Renda Variável", "FIIs (Fundos Imobiliários)", 0.05,
             ["HGLG11", "MXRF11"]),
        ],
    },
    InvestorProfile.MODERADO: {
        "retorno_esperado": 13.0,
        "volatilidade_esperada": 7.0,
        "alocacoes": [
            ("Renda Fixa", "Tesouro Selic / CDB DI", 0.25,
             ["Tesouro Selic 2027", "CDB 110% CDI"]),
            ("Renda Fixa", "CDB/LCI/LCA prefixado ou IPCA+", 0.25,
             ["LCI IPCA+5%", "Tesouro IPCA+ 2035"]),
            ("Renda Variável", "Ações BR (ETFs ou Carteira Diversificada)", 0.20,
             ["BOVA11", "IVVB11 (S&P 500 em R$)"]),
            ("Renda Variável", "FIIs (Fundos Imobiliários)", 0.10,
             ["HGRE11", "XPML11"]),
            ("Fundos", "Fundos Multimercado", 0.10,
             ["Fundo Macro Long/Short", "Fundo de Crédito Privado"]),
            ("Exterior", "ETFs internacionais (via conta BR)", 0.10,
             ["IVVB11", "HASH11"]),
        ],
    },
    InvestorProfile.ARROJADO: {
        "retorno_esperado": 18.0,
        "volatilidade_esperada": 15.0,
        "alocacoes": [
            ("Renda Fixa", "Tesouro / CDB IPCA+", 0.15,
             ["Tesouro IPCA+ 2045", "CDB IPCA+6%"]),
            ("Renda Variável", "Ações BR (seleção ativa ou ETF)", 0.30,
             ["BOVA11", "Carteira 10 ações small caps"]),
            ("Renda Variável", "FIIs", 0.10,
             ["HGRU11", "TRXF11"]),
            ("Exterior", "Ações EUA / ETFs globais", 0.20,
             ["BDR de AAPL, MSFT", "IVVB11"]),
            ("Fundos", "Fundos de Ações / Multimercado Agressivo", 0.15,
             ["Fundo de Ações Small Caps", "Fundo Macro Global"]),
            ("Criptoativos", "BTC / ETH (via ETF ou exchange regulada)", 0.10,
             ["QBTC11", "ETHE11"]),
        ],
    },
    InvestorProfile.AGRESSIVO: {
        "retorno_esperado": 25.0,
        "volatilidade_esperada": 30.0,
        "alocacoes": [
            ("Renda Fixa", "Mínimo de liquidez", 0.05,
             ["Tesouro Selic"]),
            ("Renda Variável", "Ações BR (alta convicção / small caps)", 0.25,
             ["Seleção de small e micro caps"]),
            ("Exterior", "Ações EUA + mercados emergentes", 0.25,
             ["BDRs", "ETF ACWI via conta global"]),
            ("Fundos", "Fundos Long Biased / Long Only", 0.15,
             ["Fundo de ações concentrado", "Fundo de PE/VC"]),
            ("Criptoativos", "BTC, ETH e altcoins selecionadas", 0.20,
             ["BTC via ETF", "ETH via ETF", "altcoins < 5% cada"]),
            ("Alternativos", "Startups / FIP / Crowdfunding", 0.10,
             ["FIP Tech", "Plataforma de equity crowdfunding"]),
        ],
    },
}


# ---------------------------------------------------------------------------
# Função principal
# ---------------------------------------------------------------------------

def montar_carteira(
    q: SuitabilityQuestionnaire,
    classificacao: InvestorClassification,
) -> Portfolio:
    """
    Monta e retorna o objeto Portfolio com base no perfil classificado.
    Ajusta percentuais conforme características extras do cliente.
    """
    perfil = classificacao.perfil
    modelo = _CARTEIRAS_MODELO[perfil]
    valor = q.valor_a_investir

    alertas: list[str] = []

    # Copia alocações do modelo
    alocacoes_base = [list(a) for a in modelo["alocacoes"]]  # [classe, sub, pct, exemplos]

    # --- Ajuste: sem reserva de emergência → aumentar liquidez ---
    if not q.tem_reserva_emergencia:
        alocacoes_base = _aumentar_liquidez(alocacoes_base, delta=0.05)
        alertas.append(
            "Liquidez aumentada em 5 p.p. por ausência de reserva de emergência."
        )

    # --- Ajuste: horizonte curto → reduzir risco ---
    if q.horizonte == TimeHorizon.CURTO_PRAZO and perfil in (
        InvestorProfile.ARROJADO, InvestorProfile.AGRESSIVO
    ):
        alocacoes_base = _reduzir_risco(alocacoes_base, delta=0.10)
        alertas.append(
            "Exposição a risco reduzida em 10 p.p. pelo horizonte de curto prazo."
        )

    # --- Ajuste: dívidas → reforçar liquidez ---
    if q.tem_dividas:
        alertas.append(
            "Cliente possui dívidas. Considere amortizá-las antes de alocar "
            "em ativos de maior risco."
        )

    # Normaliza percentuais para somar 100%
    alocacoes_base = _normalizar(alocacoes_base)

    # Monta objetos AssetAllocation
    alocacoes = [
        AssetAllocation(
            classe=a[0],
            subclasse=a[1],
            percentual=round(a[2], 4),
            valor_estimado=round(a[2] * valor, 2),
            exemplos=a[3],
        )
        for a in alocacoes_base
    ]

    return Portfolio(
        perfil=perfil,
        valor_total=valor,
        alocacoes=alocacoes,
        retorno_esperado_anual_pct=modelo["retorno_esperado"],
        volatilidade_esperada_pct=modelo["volatilidade_esperada"],
        alertas=alertas,
    )


# ---------------------------------------------------------------------------
# Helpers de ajuste
# ---------------------------------------------------------------------------

def _aumentar_liquidez(alocacoes: list, delta: float) -> list:
    """Aumenta a alocação em Renda Fixa de liquidez e reduz proporcionalmente os demais."""
    # Encontra o primeiro ativo de liquidez (Tesouro Selic / CDB DI)
    idx_liq = next(
        (i for i, a in enumerate(alocacoes) if "Selic" in a[1] or "DI" in a[1]), 0
    )
    alocacoes[idx_liq][2] += delta
    # Reduz proporcionalmente os outros
    outros = [i for i in range(len(alocacoes)) if i != idx_liq]
    reducao_por_item = delta / len(outros)
    for i in outros:
        alocacoes[i][2] = max(0.0, alocacoes[i][2] - reducao_por_item)
    return alocacoes


def _reduzir_risco(alocacoes: list, delta: float) -> list:
    """Move delta de ativos de risco para renda fixa."""
    idx_rf = next(
        (i for i, a in enumerate(alocacoes) if a[0] == "Renda Fixa"), 0
    )
    ativos_risco = [
        i for i, a in enumerate(alocacoes)
        if a[0] in ("Renda Variável", "Criptoativos", "Alternativos") and i != idx_rf
    ]
    if not ativos_risco:
        return alocacoes
    reducao_por_item = delta / len(ativos_risco)
    for i in ativos_risco:
        alocacoes[i][2] = max(0.0, alocacoes[i][2] - reducao_por_item)
    alocacoes[idx_rf][2] += delta
    return alocacoes


def _normalizar(alocacoes: list) -> list:
    """Garante que os percentuais somem exatamente 1.0."""
    total = sum(a[2] for a in alocacoes)
    if total == 0:
        return alocacoes
    for a in alocacoes:
        a[2] = a[2] / total
    return alocacoes
