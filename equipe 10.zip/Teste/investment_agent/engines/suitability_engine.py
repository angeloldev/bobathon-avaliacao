"""
Engine de suitability baseada em regras.

Pontua o questionário e classifica o investidor em um dos quatro perfis:
  Conservador | Moderado | Arrojado | Agressivo
"""

from investment_agent.models.suitability import (
    SuitabilityQuestionnaire,
    InvestorClassification,
    InvestorProfile,
    InvestmentObjective,
    TimeHorizon,
)


# ---------------------------------------------------------------------------
# Mapeamentos de pontuação
# ---------------------------------------------------------------------------

_OBJETIVO_SCORE: dict[InvestmentObjective, int] = {
    InvestmentObjective.PRESERVACAO_CAPITAL: 1,
    InvestmentObjective.RENDA: 2,
    InvestmentObjective.CRESCIMENTO_MODERADO: 3,
    InvestmentObjective.CRESCIMENTO_AGRESSIVO: 4,
    InvestmentObjective.ESPECULACAO: 5,
}

_HORIZONTE_SCORE: dict[TimeHorizon, int] = {
    TimeHorizon.CURTO_PRAZO: 1,
    TimeHorizon.MEDIO_PRAZO: 2,
    TimeHorizon.LONGO_PRAZO: 4,
    TimeHorizon.MUITO_LONGO_PRAZO: 5,
}

# Score máximo possível = 5+5+5+5+5+5 = 30 (6 dimensões, máx 5 cada)
_SCORE_MAXIMO = 30

# Limites de classificação (percentual do score máximo)
_LIMITES_PERFIL = [
    (0.40, InvestorProfile.CONSERVADOR),
    (0.60, InvestorProfile.MODERADO),
    (0.80, InvestorProfile.ARROJADO),
    (1.00, InvestorProfile.AGRESSIVO),
]


# ---------------------------------------------------------------------------
# Função principal
# ---------------------------------------------------------------------------

def classificar_investidor(q: SuitabilityQuestionnaire) -> InvestorClassification:
    """
    Aplica as regras de suitability e retorna a classificação do investidor.

    A pontuação é composta de 6 dimensões (máx 5 pts cada = 30 pts total):
      1. Objetivo de investimento
      2. Horizonte de tempo
      3. Tolerância a perdas (declarada)
      4. Experiência no mercado
      5. Reação a queda de 10%
      6. Independência do capital investido
    """
    fatores: list[str] = []
    observacoes: list[str] = []

    # --- 1. Objetivo ---
    score_objetivo = _OBJETIVO_SCORE[q.objetivo]

    # --- 2. Horizonte ---
    score_horizonte = _HORIZONTE_SCORE[q.horizonte]

    # --- 3-6. Respostas diretas (1-5) ---
    score_tolerancia = q.tolerancia_perda
    score_experiencia = q.experiencia_mercado
    score_reacao = q.reacao_queda_10pct
    score_independencia = q.dependencia_do_capital

    total = (
        score_objetivo
        + score_horizonte
        + score_tolerancia
        + score_experiencia
        + score_reacao
        + score_independencia
    )

    # --- Penalidades e alertas ---
    if q.tem_dividas:
        total = max(0, total - 3)
        fatores.append("Possui dívidas: score reduzido em 3 pontos.")
        observacoes.append(
            "Recomenda-se quitar dívidas de alto custo antes de investir."
        )

    if not q.tem_reserva_emergencia:
        total = max(0, total - 2)
        fatores.append("Sem reserva de emergência: score reduzido em 2 pontos.")
        observacoes.append(
            "Recomenda-se manter de 3 a 6 meses de despesas em liquidez antes "
            "de diversificar em ativos de maior risco."
        )

    if q.idade >= 60:
        total = max(0, total - 2)
        fatores.append("Idade ≥ 60 anos: score reduzido em 2 pontos.")
        observacoes.append(
            "Investidores na faixa de 60+ geralmente se beneficiam de maior "
            "alocação em renda fixa e ativos de baixa volatilidade."
        )

    # Percentual e perfil
    percentual = total / _SCORE_MAXIMO
    perfil = _determinar_perfil(percentual)

    return InvestorClassification(
        perfil=perfil,
        score=total,
        score_maximo=_SCORE_MAXIMO,
        percentual=round(percentual * 100, 1),
        fatores_de_risco=fatores,
        observacoes=observacoes,
    )


def _determinar_perfil(percentual: float) -> InvestorProfile:
    for limite, perfil in _LIMITES_PERFIL:
        if percentual <= limite:
            return perfil
    return InvestorProfile.AGRESSIVO
