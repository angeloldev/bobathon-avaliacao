"""
Grafo principal do agente de investimentos (LangGraph).

Fluxo:
  START
    └─► classificar_perfil   (engine de suitability — regras)
          └─► montar_carteira  (engine de alocação — regras)
                └─► gerar_justificativa  (LLM)
                      └─► END
"""

from langgraph.graph import StateGraph, START, END

from investment_agent.models.state import AgentState
from investment_agent.nodes.suitability_node import node_classificar_perfil
from investment_agent.nodes.allocation_node import node_montar_carteira
from investment_agent.nodes.llm_node import node_gerar_justificativa


def build_agent() -> StateGraph:
    """
    Constrói e compila o grafo LangGraph do agente de investimentos.

    Returns:
        Grafo compilado pronto para ser invocado com `.invoke(state)`.
    """
    builder = StateGraph(AgentState)

    # Registra os nós
    builder.add_node("classificar_perfil", node_classificar_perfil)
    builder.add_node("montar_carteira", node_montar_carteira)
    builder.add_node("gerar_justificativa", node_gerar_justificativa)

    # Define as arestas (fluxo sequencial)
    builder.add_edge(START, "classificar_perfil")
    builder.add_edge("classificar_perfil", "montar_carteira")
    builder.add_edge("montar_carteira", "gerar_justificativa")
    builder.add_edge("gerar_justificativa", END)

    return builder.compile()


# Instância pronta para importar
investment_agent_graph = build_agent()
