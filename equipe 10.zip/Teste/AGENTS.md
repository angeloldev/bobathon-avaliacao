# Customer Agent — E-commerce

Projeto de agente em lote que consulta dados de clientes e pedidos via API
e gera mensagens personalizadas usando Claude (Anthropic) como LLM.
Inclui painel web para uso da equipe e API pública com documentação Swagger.

## Estrutura do Projeto

```
customer-agent/
├── mock_api/
│   └── app.py               # Mock API Flask (clientes + pedidos + Swagger)
├── mcp_server/
│   └── server.py            # MCP Server Python (ferramentas para o Bob IDE)
├── agent/
│   └── batch_agent.py       # Agente de processamento em lote
├── web/
│   ├── app.py               # Interface web (painel da equipe)
│   └── templates/
│       └── index.html       # UI do painel
├── Dockerfile               # Containerização
├── docker-compose.yml       # Orquestração local/produção
├── docker_entrypoint.py     # Inicia API + Web UI no container
├── run.py                   # Execução local sem Docker
├── requirements.txt         # Dependências Python
├── .env.example             # Template de variáveis de ambiente
└── DEPLOY.md                # Guia de deploy (AWS / Azure / GCP)
```

## URLs de Acesso (produção)

| Recurso             | URL                              |
|---------------------|----------------------------------|
| Painel Web          | `http://<HOST>:8080`             |
| Mock API            | `http://<HOST>:5000`             |
| Documentação Swagger| `http://<HOST>:5000/apidocs`     |
| Health Check        | `http://<HOST>:8080/health`      |

## Ferramentas MCP (Bob IDE)

O MCP server expõe 4 ferramentas para o Bob consultar a API:

| Ferramenta             | Descrição                                   |
|------------------------|---------------------------------------------|
| `list_customers`       | Lista todos os clientes                     |
| `get_customer`         | Dados de um cliente pelo ID (ex: C001)      |
| `get_customer_orders`  | Pedidos de um cliente pelo ID               |
| `get_order`            | Detalhes de um pedido pelo ID (ex: O1001)   |

## Como Executar Localmente (sem Docker)

```bash
# 1. Instalar dependências
python -m pip install -r customer-agent/requirements.txt

# 2. Definir chave da Anthropic
$env:ANTHROPIC_API_KEY = "sua-chave"   # Windows PowerShell

# 3. Iniciar Mock API (terminal 1)
python customer-agent/mock_api/app.py

# 4. Iniciar Web UI (terminal 2)
python customer-agent/web/app.py

# 5. OU rodar o agente em lote direto (sem UI)
python customer-agent/run.py
```

## Como Executar com Docker

```bash
cd customer-agent

# Copiar e editar variáveis
cp .env.example .env
# Editar .env com ANTHROPIC_API_KEY

# Subir
docker compose up -d

# Logs
docker compose logs -f
```

## Deploy em Cloud Corporativa

Veja [`DEPLOY.md`](DEPLOY.md) para instruções detalhadas de deploy em:
- **AWS** — ECS Fargate + ECR + ALB
- **Azure** — Container Apps + ACR
- **Google Cloud** — Cloud Run + Artifact Registry

## Variáveis de Ambiente

| Variável              | Descrição                        | Obrigatória |
|-----------------------|----------------------------------|-------------|
| `ANTHROPIC_API_KEY`   | Chave de API da Anthropic        | Sim         |
| `PORT`                | Porta da Web UI (padrão: 8080)   | Não         |
| `API_PORT`            | Porta da Mock API (padrão: 5000) | Não         |
| `OUTPUT_DIR`          | Diretório de saída das mensagens | Não         |
| `SWAGGER_HOST`        | Host do Swagger (produção)       | Não         |

## Tecnologias

- **LLM:** Claude (Anthropic) via SDK Python
- **MCP:** Python MCP SDK (stdio transport, para Bob IDE)
- **Mock API:** Flask + Flasgger (Swagger)
- **Web UI:** Flask + Jinja2 + SSE (streaming de logs)
- **Container:** Docker + docker-compose
- **HTTP Client:** requests
