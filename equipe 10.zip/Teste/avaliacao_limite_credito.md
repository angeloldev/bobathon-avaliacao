# Sistema de Avaliação de Limite de Crédito

**Data de Geração:** 2025  
**Total de Clientes Analisados:** 200  
**Versão:** 1.0 — Uso Interno

---

## Sumário

1. [Introdução](#1-introdução)
2. [Descrição da Base de Dados](#2-descrição-da-base-de-dados)
3. [Metodologia](#3-metodologia)
4. [Regras de Classificação por Segmento](#4-regras-de-classificação-por-segmento)
5. [Resultados da Classificação](#5-resultados-da-classificação)
6. [Conclusão e Recomendações](#6-conclusão-e-recomendações)
7. [Anexo — Classificação Individual dos Clientes](#anexo--classificação-individual-dos-clientes)

---

## 1. Introdução

O presente documento descreve o sistema automatizado de avaliação de limite de crédito desenvolvido para a classificação de clientes em quatro segmentos de risco distintos. O objetivo é fornecer uma base técnica e objetiva para a concessão de crédito, minimizando o risco de inadimplência e maximizando a oferta de crédito a clientes com perfil saudável.

A avaliação é conduzida por um modelo de pontuação (*credit score*) baseado em variáveis comportamentais e cadastrais disponíveis na base de dados interna da instituição. Cada cliente recebe uma pontuação que determina o segmento ao qual pertence e, consequentemente, o limite de crédito máximo que pode ser oferecido.

> **⚠️ Restrição Obrigatória de Negócio:** Independentemente do segmento classificado, o limite de crédito final atribuído a qualquer cliente **não pode ultrapassar 30% da renda líquida mensal** desse cliente. Essa regra é implementada como teto absoluto e sobrepõe-se a qualquer outro critério de cálculo de limite.

### Escopo do Documento

Este relatório abrange:

- **(a)** A descrição da base de dados utilizada com estatísticas descritivas
- **(b)** A metodologia de scoring adotada
- **(c)** As regras detalhadas por segmento
- **(d)** Os resultados da classificação com distribuição dos clientes
- **(e)** Um anexo com a classificação individual de cada cliente

---

## 2. Descrição da Base de Dados

A base de dados contém **200 registros** de clientes, armazenados em formato JSON. Cada registro é composto pelas variáveis descritas abaixo.

### 2.1 Variáveis Disponíveis

| Variável | Tipo | Descrição | Relevância para Crédito |
|---|---|---|---|
| `id` | Inteiro | Identificador único do cliente | Chave primária |
| `nome` | Texto | Nome completo do cliente | Identificação |
| `cpf` | Texto | CPF formatado do cliente | Identificação |
| `idade` | Inteiro | Idade em anos completos | Moderada |
| `renda_liquida` | Decimal | Renda líquida mensal em R$ | **Alta** |
| `relacionamento_meses` | Inteiro | Meses de relacionamento com a instituição | **Alta** |
| `pagamentos_dia` | Categórico | Indicador de adimplência (Sim/Não) | **Muito Alta** |
| `emprestimos_ativos` | Categórico | Possui empréstimos ativos (Sim/Não) | **Alta** |
| `usuario_produtos` | Categórico | Usuário de outros produtos (Sim/Não) | Moderada |

### 2.2 Estatísticas Descritivas — Variáveis Numéricas

| Variável | N | Média | Mediana | Desvio Pad. | Mínimo | Máximo | P25 | P75 | P90 |
|---|---|---|---|---|---|---|---|---|---|
| Idade (anos) | 200 | 48,7 | 49,0 | 18,8 | 18,0 | 80,0 | 32,0 | 66,0 | 74,0 |
| Renda Líquida (R$) | 200 | 5.476,91 | 4.790,86 | 3.271,76 | 1.251,09 | 14.942,94 | 2.858,70 | 7.604,98 | 10.530,57 |
| Relacionamento (meses) | 200 | 115,4 | 113,0 | 67,1 | 1,0 | 239,0 | 61,0 | 172,0 | 212,0 |

### 2.3 Distribuição — Variáveis Categóricas

| Variável | Valor | Frequência | Percentual |
|---|---|---|---|
| Pagamentos em Dia | Sim | 150 | 75,0% |
| Pagamentos em Dia | Não | 50 | 25,0% |
| Empréstimos Ativos | Não | 119 | 59,5% |
| Empréstimos Ativos | Sim | 81 | 40,5% |
| Usuário de Produtos | Sim | 126 | 63,0% |
| Usuário de Produtos | Não | 74 | 37,0% |

---

## 3. Metodologia

### 3.1 Abordagem Adotada

O sistema utiliza um modelo de **pontuação de crédito (credit score)** baseado em regras. Cada variável relevante da base recebe um peso proporcional à sua influência sobre o risco de inadimplência, e os pontos são somados para formar o score final do cliente (escala 0–103, incluindo bônus etário).

Essa abordagem foi escolhida por ser transparente, auditável, de fácil implementação e interpretação pelos analistas de negócio, não requerendo dados históricos de inadimplência para treinamento.

### 3.2 Componentes do Score

| Variável | Condição | Pontos | Peso (%) |
|---|---|---|---|
| Pagamentos em Dia | Sim | 35 | 35% |
| Pagamentos em Dia | Não | 0 | — |
| Renda Líquida | ≥ R$ 8.000 | 25 | 25% |
| Renda Líquida | R$ 4.000 – 7.999 | 15 | — |
| Renda Líquida | R$ 2.000 – 3.999 | 8 | — |
| Renda Líquida | < R$ 2.000 | 0 | — |
| Relacionamento (meses) | ≥ 120 meses | 20 | 20% |
| Relacionamento (meses) | 60 – 119 meses | 12 | — |
| Relacionamento (meses) | 24 – 59 meses | 6 | — |
| Relacionamento (meses) | < 24 meses | 0 | — |
| Empréstimos Ativos | Não | 10 | 10% |
| Empréstimos Ativos | Sim | 0 | — |
| Usuário de Produtos | Sim | 10 | 10% |
| Usuário de Produtos | Não | 0 | — |
| Bônus Etário (30–60 anos) | Idade entre 30 e 60 | +3 | Bônus |
| **TOTAL MÁXIMO** | — | **103** | **100%** |

### 3.3 Classificação por Faixas de Score

| Score | Seg. | Classificação | Múltiplo da Renda | Teto Absoluto |
|---|---|---|---|---|
| 0 – 29 | 1 | Alto Risco / Sem Limite | 0,5× | R$ 600 |
| 30 – 54 | 2 | Risco Moderado / Limite Básico | 1,5× | R$ 5.000 |
| 55 – 74 | 3 | Baixo Risco / Limite Intermediário | 3,0× | R$ 25.000 |
| 75 – 103 | 4 | Risco Muito Baixo / Limite Premium | 5,0× | R$ 60.000 |

### 3.4 Restrição Obrigatória: Teto de 30% da Renda Líquida

Esta é uma **regra inviolável de negócio**: independentemente do segmento atribuído ao cliente e do limite calculado pelas regras do segmento, o limite de crédito final não pode exceder **30% da renda líquida mensal** do cliente.

```
Teto         = renda_liquida × 0,30
Limite_Final = min(Limite_Segmento, Teto)
```

Tecnicamente, a restrição é implementada pela função centralizada `calcular_teto_30pct(renda_liquida)`, chamada em todos os pontos do sistema onde o limite final é determinado, garantindo auditabilidade e consistência.

---

## 4. Regras de Classificação por Segmento

---

### 🔴 Segmento 1 — Alto Risco / Sem Limite

**Faixa de Score:** 0 – 29 | **Múltiplo da Renda:** 0,5× | **Teto Absoluto:** R$ 600,00

**Critérios de Enquadramento:**
- Score total < 30 pontos
- Geralmente: pagamentos em atraso (Não em `pagamentos_dia`) E renda baixa
- Relacionamento < 24 meses ou ausência de histórico positivo
- Pode haver combinação de empréstimos ativos com renda muito baixa

**Justificativa:** Clientes neste segmento apresentam múltiplos fatores de risco simultâneos. A concessão de crédito é mínima, limitada a 0,5× a renda mensal com teto absoluto de R$ 600,00. O teto de 30% da renda não reduz este segmento pois o limite já é inferior.

**Exemplo:** Cliente com renda líquida de R$ 2.500,00 → Limite do segmento: R$ 600,00 | Teto 30% da renda: R$ 750,00 | **Limite Final: R$ 600,00**

---

### 🟠 Segmento 2 — Risco Moderado / Limite Básico

**Faixa de Score:** 30 – 54 | **Múltiplo da Renda:** 1,5× | **Teto Absoluto:** R$ 5.000,00

**Critérios de Enquadramento:**
- Score entre 30 e 54 pontos
- Pode ter pagamentos em dia, porém renda baixa ou relacionamento curto
- Pode ter renda intermediária, mas histórico de pagamentos instável
- Sem combinação de fatores suficiente para atingir score 55+

**Justificativa:** Perfil moderado com algum fator positivo. Limite de 1,5× a renda mensal com teto de R$ 5.000,00. O teto de 30% da renda (equivalente a ~0,3× mensal) reduz este limite para clientes cuja renda é baixa e o teto proporcional fica abaixo do calculado pelo múltiplo.

**Exemplo:** Cliente com renda líquida de R$ 3.000,00 → Limite do segmento: R$ 4.500,00 | Teto 30% da renda: R$ 900,00 | **Limite Final: R$ 900,00** *(teto aplicado)*

---

### 🟡 Segmento 3 — Baixo Risco / Limite Intermediário

**Faixa de Score:** 55 – 74 | **Múltiplo da Renda:** 3,0× | **Teto Absoluto:** R$ 25.000,00

**Critérios de Enquadramento:**
- Score entre 55 e 74 pontos
- Tipicamente: pagamentos em dia + renda intermediária ou alta
- Relacionamento ≥ 24 meses com a instituição
- Maioria dos clientes sem empréstimos ativos

**Justificativa:** Clientes com boa capacidade de pagamento e histórico positivo. Limite de 3,0× a renda mensal, com teto absoluto de R$ 25.000,00. A restrição de 30% da renda mensal é aplicada como teto final e reduz o limite na maioria dos clientes deste segmento, garantindo prudência na concessão.

**Exemplo:** Cliente com renda líquida de R$ 8.000,00 → Limite do segmento: R$ 24.000,00 | Teto 30% da renda: R$ 2.400,00 | **Limite Final: R$ 2.400,00** *(teto aplicado)*

---

### 🟢 Segmento 4 — Risco Muito Baixo / Limite Premium

**Faixa de Score:** 75 – 103 | **Múltiplo da Renda:** 5,0× | **Teto Absoluto:** R$ 60.000,00

**Critérios de Enquadramento:**
- Score ≥ 75 pontos
- Pagamentos sempre em dia + renda alta (≥ R$ 8.000)
- Relacionamento longo (≥ 120 meses) com a instituição
- Sem empréstimos ativos e usuário de múltiplos produtos

**Justificativa:** Perfil excelente com todos ou quase todos os fatores favoráveis. Limite potencial de 5,0× a renda mensal, com teto absoluto de R$ 60.000,00. A restrição de 30% da renda mensal é o fator limitante predominante neste segmento, garantindo que mesmo clientes premium não recebam crédito desproporcional à sua capacidade de pagamento mensal.

**Exemplo:** Cliente com renda líquida de R$ 12.000,00 → Limite do segmento: R$ 60.000,00 | Teto 30% da renda: R$ 3.600,00 | **Limite Final: R$ 3.600,00** *(teto aplicado)*

---

## 5. Resultados da Classificação

### 5.1 Distribuição dos Clientes por Segmento

| Segmento | Nome | Qtd | % | Lim. Médio do Segmento | Lim. Médio Final |
|---|---|---|---|---|---|
| 1 | Alto Risco / Sem Limite | 14 | 7,0% | R$ 600,00 | R$ 564,91 |
| 2 | Risco Moderado / Limite Básico | 41 | 20,5% | R$ 4.222,27 | R$ 1.331,95 |
| 3 | Baixo Risco / Limite Intermediário | 67 | 33,5% | R$ 12.473,10 | R$ 1.259,26 |
| 4 | Risco Muito Baixo / Limite Premium | 78 | 39,0% | R$ 37.037,21 | R$ 2.271,17 |
| **Total** | — | **200** | **100%** | — | — |

### 5.2 Distribuição Visual por Segmento

```
Seg.4 Risco Muito Baixo  ████████████████████████████████████████  78 (39,0%)
Seg.3 Baixo Risco        █████████████████████████████████         67 (33,5%)
Seg.2 Risco Moderado     ████████████████████                      41 (20,5%)
Seg.1 Alto Risco         ███████                                   14  (7,0%)
```

### 5.3 Impacto do Teto de 30% da Renda Líquida

| Segmento | Clientes | Com Teto Aplicado | % com Teto | Redução Média (R$) |
|---|---|---|---|---|
| 1 | 14 | 5 | 35,7% | R$ 19,24 *(aprox.)* |
| 2 | 41 | 41 | 100,0% | R$ 2.890,32 *(aprox.)* |
| 3 | 67 | 67 | 100,0% | R$ 11.213,84 *(aprox.)* |
| 4 | 78 | 78 | 100,0% | R$ 34.766,04 *(aprox.)* |
| **Total** | **200** | **191** | **95,5%** | **R$ 18.754,31** |

> **Nota:** 191 clientes (95,5%) tiveram o limite reduzido pela restrição de 30% da renda líquida. A redução média sobre esses clientes foi de **R$ 18.754,31**. A redução máxima individual registrada foi de **R$ 56.357,84** e a mínima de **R$ 19,24**.

### 5.4 Estatísticas dos Limites Finais por Segmento

| Segmento | Mínimo | Mediana | Média | Máximo |
|---|---|---|---|---|
| Seg. 1 | R$ 375,33 | R$ 570,00 | R$ 564,91 | R$ 600,00 |
| Seg. 2 | R$ 375,33 | R$ 1.290,14 | R$ 1.331,95 | R$ 2.400,00 |
| Seg. 3 | R$ 375,33 | R$ 1.213,02 | R$ 1.259,26 | R$ 2.400,00 |
| Seg. 4 | R$ 375,33 | R$ 2.132,32 | R$ 2.271,17 | R$ 4.482,88 |

---

## 6. Conclusão e Recomendações

O sistema de avaliação de limite de crédito desenvolvido classifica os 200 clientes da base em quatro segmentos de risco distintos, com base em um modelo de pontuação que considera adimplência, renda, tempo de relacionamento, endividamento ativo e engajamento com produtos.

A aplicação do teto obrigatório de 30% da renda líquida como regra inviolável garantiu que nenhum cliente recebesse um limite de crédito desproporcional à sua capacidade financeira real, independentemente de sua classificação por score.

### Recomendações para Revisão e Melhoria

1. **Dados históricos de inadimplência:** Incorporar histórico real para treinamento de modelos preditivos (regressão logística, gradient boosting), aumentando a acurácia das previsões.
2. **Enriquecimento de variáveis:** Adicionar variáveis de comprometimento de renda (total de dívidas / renda) e bureau de crédito externo.
3. **Backtesting semestral:** Comparar as classificações com o comportamento real de pagamento dos clientes.
4. **Revisão anual dos thresholds:** Adequar os thresholds de score e os fatores de limite às condições macroeconômicas vigentes.
5. **Monitoramento contínuo:** Implementar PSI (*Population Stability Index*) para detectar desvios populacionais ao longo do tempo.
6. **Segmentação adicional:** Considerar segmentação por faixa etária ou tipo de produto para maior granularidade na oferta de crédito.

---

## Anexo — Classificação Individual dos Clientes

> Tabela gerada a partir da base `base_clientes_credito.json` com 200 registros.  
> Colunas: **ID** | **Nome** | **Score** | **Segmento** | **Limite do Segmento (R$)** | **Teto 30% (R$)** | **Limite Final (R$)**

| ID | Nome | Score | Seg. | Lim. Segmento (R$) | Teto 30% (R$) | Lim. Final (R$) |
|---|---|---|---|---|---|---|
| 1 | Eduarda Castro Lopes | 69 | 3 | 25,000.00 | 2,627.78 | 2,627.78 |
| 2 | Carla Campos Almeida | 69 | 3 | 22,882.29 | 2,288.23 | 2,288.23 |
| 3 | João Teixeira Fernandes | 103 | 4 | 42,136.15 | 2,528.17 | 2,528.17 |
| 4 | Karina Fernandes Moraes | 57 | 3 | 4,965.00 | 496.50 | 496.50 |
| 5 | Lucas Medeiros Lopes | 80 | 4 | 34,664.70 | 2,079.88 | 2,079.88 |
| 6 | Mariana Mendes Oliveira | 90 | 4 | 20,278.00 | 1,216.68 | 1,216.68 |
| 7 | Nadia Alves Vieira | 65 | 3 | 6,793.83 | 679.38 | 679.38 |
| 8 | Vagner Ferreira Carvalho | 79 | 4 | 37,730.35 | 2,263.82 | 2,263.82 |
| 9 | Vinícius Martins Dias | 30 | 2 | 3,809.27 | 761.85 | 761.85 |
| 10 | Nicolas Sousa Cavalcanti | 58 | 3 | 25,000.00 | 2,913.73 | 2,913.73 |
| 11 | Thiago Teixeira Nascimento | 70 | 3 | 16,332.81 | 1,633.28 | 1,633.28 |
| 12 | Pedro Cardoso Medeiros | 72 | 3 | 14,595.96 | 1,459.60 | 1,459.60 |
| 13 | Vinícius Pinto Ribeiro | 53 | 2 | 5,000.00 | 1,136.95 | 1,136.95 |
| 14 | Camila Costa Vieira | 45 | 2 | 5,000.00 | 1,631.96 | 1,631.96 |
| 15 | João Campos Carvalho | 75 | 4 | 9,516.85 | 571.01 | 571.01 |
| 16 | Vinícius Barbosa Rocha | 73 | 3 | 7,272.66 | 727.27 | 727.27 |
| 17 | Carla Souza Martins | 73 | 3 | 10,389.99 | 1,039.00 | 1,039.00 |
| 18 | Lucas Moraes Dias | 68 | 3 | 8,838.21 | 883.82 | 883.82 |
| 19 | Vagner Alves Silva | 68 | 3 | 8,265.24 | 826.52 | 826.52 |
| 20 | Elaine Correia Medeiros | 40 | 2 | 5,000.00 | 2,215.67 | 2,215.67 |
| 21 | Giovanna Dias Dias | 93 | 4 | 52,652.85 | 3,159.17 | 3,159.17 |
| 22 | Úrsula Almeida Rodrigues | 69 | 3 | 25,000.00 | 2,759.34 | 2,759.34 |
| 23 | Ursula Lima Marques | 61 | 3 | 4,561.68 | 456.17 | 456.17 |
| 24 | Heitor Araújo Correia | 50 | 2 | 5,000.00 | 2,542.62 | 2,542.62 |
| 25 | Giovanna Cardoso Ferreira | 72 | 3 | 18,164.94 | 1,816.49 | 1,816.49 |
| 26 | Lucas Dias Oliveira | 93 | 4 | 34,067.75 | 2,044.07 | 2,044.07 |
| 27 | Kleber Pinto Ramos | 35 | 2 | 2,726.68 | 545.34 | 545.34 |
| 28 | Gabriela Campos Mendes | 53 | 2 | 4,099.39 | 819.88 | 819.88 |
| 29 | Ana Ferreira Pereira | 69 | 3 | 15,893.64 | 1,589.36 | 1,589.36 |
| 30 | Felipe Moraes Castro | 28 | 1 | 600.00 | 655.27 | 600.00 |
| 31 | Quezia Cardoso Marques | 72 | 3 | 14,386.08 | 1,438.61 | 1,438.61 |
| 32 | Elaine Moreira Ribeiro | 93 | 4 | 43,866.85 | 2,632.01 | 2,632.01 |
| 33 | Quezia Castro Barbosa | 73 | 3 | 8,929.89 | 892.99 | 892.99 |
| 34 | Tânia Oliveira Costa | 73 | 3 | 15,916.59 | 1,591.66 | 1,591.66 |
| 35 | Kleber Marques Marques | 86 | 4 | 14,632.90 | 877.97 | 877.97 |
| 36 | Bruno Lopes Correia | 69 | 3 | 19,957.95 | 1,995.79 | 1,995.79 |
| 37 | Xavier Carvalho Costa | 85 | 4 | 56,931.40 | 3,415.88 | 3,415.88 |
| 38 | Mariana Silva Marques | 75 | 4 | 34,667.95 | 2,080.08 | 2,080.08 |
| 39 | Felipe Rocha Moreira | 47 | 2 | 2,529.48 | 505.90 | 505.90 |
| 40 | Larissa Moraes Castro | 80 | 4 | 21,198.85 | 1,271.93 | 1,271.93 |
| 41 | Nadia Nascimento Correia | 93 | 4 | 25,547.95 | 1,532.88 | 1,532.88 |
| 42 | Bernardo Araújo Ribeiro | 11 | 1 | 600.00 | 796.69 | 600.00 |
| 43 | Marcos Dias Ferreira | 50 | 2 | 5,000.00 | 1,420.32 | 1,420.32 |
| 44 | Larissa Moreira Moreira | 89 | 4 | 60,000.00 | 4,482.88 | 4,482.88 |
| 45 | Júlia Lima Nunes | 83 | 4 | 26,961.20 | 1,617.67 | 1,617.67 |
| 46 | Diego Martins Ribeiro | 95 | 4 | 49,093.60 | 2,945.62 | 2,945.62 |
| 47 | Wanda Mendes Almeida | 103 | 4 | 60,000.00 | 4,132.33 | 4,132.33 |
| 48 | Gabriela Pinto Lopes | 103 | 4 | 58,460.60 | 3,507.64 | 3,507.64 |
| 49 | Júlia Martins Sousa | 79 | 4 | 38,024.90 | 2,281.49 | 2,281.49 |
| 50 | Sabrina Campos Almeida | 103 | 4 | 60,000.00 | 3,948.18 | 3,948.18 |
| 51 | Mariana Costa Melo | 93 | 4 | 45,947.70 | 2,756.86 | 2,756.86 |
| 52 | Daniel Santos Moreira | 49 | 2 | 3,306.90 | 661.38 | 661.38 |
| 53 | Renato Correia Mendes | 58 | 3 | 12,168.18 | 1,216.82 | 1,216.82 |
| 54 | Sandra Andrade Sousa | 55 | 3 | 5,303.61 | 530.36 | 530.36 |
| 55 | Bernardo Ribeiro Dias | 50 | 2 | 5,000.00 | 1,679.75 | 1,679.75 |
| 56 | Diego Dias Ribeiro | 66 | 3 | 9,858.93 | 985.89 | 985.89 |
| 57 | Ursula Correia Carvalho | 93 | 4 | 48,247.25 | 2,894.84 | 2,894.84 |
| 58 | Júlia Cardoso Campos | 38 | 2 | 5,000.00 | 2,048.38 | 2,048.38 |
| 59 | Carla Gomes Mendes | 86 | 4 | 13,894.75 | 833.68 | 833.68 |
| 60 | Amanda Vieira Correia | 95 | 4 | 42,583.25 | 2,554.99 | 2,554.99 |
| 61 | João Castro Martins | 48 | 2 | 5,000.00 | 1,031.71 | 1,031.71 |
| 62 | Patrícia Moraes Alves | 73 | 3 | 12,818.46 | 1,281.85 | 1,281.85 |
| 63 | Nadia Teixeira Lima | 48 | 2 | 4,805.44 | 961.09 | 961.09 |
| 64 | Fernando Pinto Gomes | 31 | 2 | 5,000.00 | 1,216.73 | 1,216.73 |
| 65 | Henrique Oliveira Moreira | 75 | 4 | 6,255.45 | 375.33 | 375.33 |
| 66 | Bernardo Nunes Moraes | 44 | 2 | 5,000.00 | 3,651.84 | 3,651.84 |
| 67 | Vinícius Alves Moreira | 90 | 4 | 20,582.90 | 1,234.97 | 1,234.97 |
| 68 | Wanda Araújo Mendes | 80 | 4 | 39,710.90 | 2,382.65 | 2,382.65 |
| 69 | Mariana Dias Castro | 34 | 2 | 5,000.00 | 2,171.05 | 2,171.05 |
| 70 | Bernardo Pinto Rocha | 58 | 3 | 20,752.32 | 2,075.23 | 2,075.23 |
| 71 | Quintina Lima Costa | 20 | 1 | 600.00 | 967.54 | 600.00 |
| 72 | Elaine Souza Moraes | 40 | 2 | 2,617.10 | 523.42 | 523.42 |
| 73 | Wendy Alves Lopes | 93 | 4 | 21,752.35 | 1,305.14 | 1,305.14 |
| 74 | João Teixeira Costa | 49 | 2 | 4,462.34 | 892.47 | 892.47 |
| 75 | Amanda Santos Ribeiro | 58 | 3 | 16,045.32 | 1,604.53 | 1,604.53 |
| 76 | Zélia Oliveira Correia | 47 | 2 | 5,000.00 | 1,490.60 | 1,490.60 |
| 77 | Eduarda Nunes Sousa | 24 | 1 | 600.00 | 750.40 | 600.00 |
| 78 | Sandra Almeida Oliveira | 70 | 3 | 14,733.18 | 1,473.32 | 1,473.32 |
| 79 | Vagner Andrade Carvalho | 35 | 2 | 2,343.54 | 468.71 | 468.71 |
| 80 | Larissa Pereira Fernandes | 62 | 3 | 7,269.12 | 726.91 | 726.91 |
| 81 | Wanda Almeida Cavalcanti | 63 | 3 | 10,950.00 | 1,095.00 | 1,095.00 |
| 82 | Otávio Cardoso Rocha | 73 | 3 | 7,192.65 | 719.26 | 719.26 |
| 83 | Carla Andrade Martins | 93 | 4 | 41,319.10 | 2,479.15 | 2,479.15 |
| 84 | Bruno Pereira Marques | 69 | 3 | 8,614.11 | 861.41 | 861.41 |
| 85 | Diego Correia Alves | 58 | 3 | 23,646.12 | 2,364.61 | 2,364.61 |
| 86 | Tânia Sousa Barbosa | 72 | 3 | 22,357.05 | 2,235.70 | 2,235.70 |
| 87 | Vagner Andrade Andrade | 76 | 4 | 22,206.95 | 1,332.42 | 1,332.42 |
| 88 | Nadia Lopes Marques | 93 | 4 | 33,797.90 | 2,027.87 | 2,027.87 |
| 89 | Thiago Rocha Nascimento | 62 | 3 | 14,459.07 | 1,445.91 | 1,445.91 |
| 90 | Sandra Ferreira Santos | 65 | 3 | 9,844.92 | 984.49 | 984.49 |
| 91 | Vinícius Medeiros Santos | 65 | 3 | 14,291.49 | 1,429.15 | 1,429.15 |
| 92 | Isabela Lima Lopes | 73 | 3 | 11,712.42 | 1,171.24 | 1,171.24 |
| 93 | Fernando Pereira Cavalcanti | 103 | 4 | 45,020.45 | 2,701.23 | 2,701.23 |
| 94 | Amanda Ramos Melo | 83 | 4 | 22,015.00 | 1,320.90 | 1,320.90 |
| 95 | Diego Martins Sousa | 93 | 4 | 24,192.10 | 1,451.53 | 1,451.53 |
| 96 | Wendy Moraes Rocha | 76 | 4 | 24,791.85 | 1,487.51 | 1,487.51 |
| 97 | Gabriela Campos Marques | 38 | 2 | 4,364.22 | 872.84 | 872.84 |
| 98 | Sandra Dias Santos | 73 | 3 | 8,576.10 | 857.61 | 857.61 |
| 99 | Olivia Costa Alves | 93 | 4 | 32,359.60 | 1,941.58 | 1,941.58 |
| 100 | Daniel Alves Cardoso | 35 | 2 | 2,102.51 | 420.50 | 420.50 |
| 101 | Camila Araújo Nascimento | 93 | 4 | 59,930.50 | 3,595.83 | 3,595.83 |
| 102 | Nicolas Barbosa Cavalcanti | 48 | 2 | 5,000.00 | 2,200.51 | 2,200.51 |
| 103 | Mariana Moraes Silva | 65 | 3 | 7,627.38 | 762.74 | 762.74 |
| 104 | Heitor Correia Pereira | 75 | 4 | 28,864.10 | 1,731.85 | 1,731.85 |
| 105 | Fernando Melo Gomes | 83 | 4 | 12,067.35 | 724.04 | 724.04 |
| 106 | Lucas Sousa Andrade | 70 | 3 | 15,571.29 | 1,557.13 | 1,557.13 |
| 107 | Nicolas Campos Rodrigues | 20 | 1 | 600.00 | 497.49 | 497.49 |
| 108 | Karina Fernandes Ferreira | 93 | 4 | 39,905.60 | 2,394.34 | 2,394.34 |
| 109 | Patrícia Ferreira Melo | 103 | 4 | 60,000.00 | 4,380.95 | 4,380.95 |
| 110 | Bernardo Oliveira Andrade | 35 | 2 | 5,000.00 | 2,190.36 | 2,190.36 |
| 111 | Ursula Lima Souza | 30 | 2 | 3,072.80 | 614.56 | 614.56 |
| 112 | Karina Souza Moraes | 95 | 4 | 48,543.00 | 2,912.58 | 2,912.58 |
| 113 | Ingrid Pereira Fernandes | 93 | 4 | 37,430.95 | 2,245.86 | 2,245.86 |
| 114 | Giovanna Oliveira Mendes | 83 | 4 | 57,537.40 | 3,452.24 | 3,452.24 |
| 115 | Marcos Santos Almeida | 48 | 2 | 4,008.20 | 801.64 | 801.64 |
| 116 | Fernando Araújo Sousa | 27 | 1 | 600.00 | 2,038.36 | 600.00 |
| 117 | Renato Campos Fernandes | 44 | 2 | 5,000.00 | 3,154.79 | 3,154.79 |
| 118 | Zélia Cardoso Lopes | 89 | 4 | 41,546.40 | 2,492.78 | 2,492.78 |
| 119 | Júlia Rodrigues Almeida | 80 | 4 | 37,267.90 | 2,236.07 | 2,236.07 |
| 120 | Eduarda Rodrigues Cardoso | 40 | 2 | 3,852.06 | 770.41 | 770.41 |
| 121 | Marcos Moraes Martins | 48 | 2 | 3,582.66 | 716.53 | 716.53 |
| 122 | Karina Silva Ferreira | 59 | 3 | 11,343.87 | 1,134.39 | 1,134.39 |
| 123 | Júlia Moraes Campos | 63 | 3 | 6,419.04 | 641.90 | 641.90 |
| 124 | Heitor Almeida Dias | 45 | 2 | 2,697.80 | 539.56 | 539.56 |
| 125 | Bruno Pinto Mendes | 103 | 4 | 51,146.40 | 3,068.78 | 3,068.78 |
| 126 | Camila Almeida Gomes | 65 | 3 | 9,915.00 | 991.50 | 991.50 |
| 127 | Ursula Oliveira Gomes | 38 | 2 | 4,916.16 | 983.23 | 983.23 |
| 128 | João Rodrigues Costa | 95 | 4 | 52,021.20 | 3,121.27 | 3,121.27 |
| 129 | Zélia Rocha Alves | 73 | 3 | 12,333.87 | 1,233.39 | 1,233.39 |
| 130 | Nicolas Medeiros Ferreira | 103 | 4 | 43,891.40 | 2,633.48 | 2,633.48 |
| 131 | Olivia Melo Fernandes | 89 | 4 | 54,571.65 | 3,274.30 | 3,274.30 |
| 132 | Vagner Mendes Pereira | 69 | 3 | 23,070.57 | 2,307.06 | 2,307.06 |
| 133 | Zélia Rocha Andrade | 103 | 4 | 58,922.40 | 3,535.34 | 3,535.34 |
| 134 | Vagner Gomes Souza | 45 | 2 | 5,000.00 | 1,558.66 | 1,558.66 |
| 135 | Otávio Pinto Nascimento | 103 | 4 | 60,000.00 | 4,444.84 | 4,444.84 |
| 136 | Xavier Nunes Oliveira | 28 | 1 | 600.00 | 899.11 | 600.00 |
| 137 | Giovanna Oliveira Moraes | 65 | 3 | 16,882.92 | 1,688.29 | 1,688.29 |
| 138 | Felipe Ribeiro Cardoso | 65 | 3 | 9,907.38 | 990.74 | 990.74 |
| 139 | João Moreira Marques | 25 | 1 | 600.00 | 1,612.87 | 600.00 |
| 140 | Júlia Mendes Marques | 48 | 2 | 5,000.00 | 1,588.73 | 1,588.73 |
| 141 | Sandra Campos Souza | 20 | 1 | 600.00 | 580.76 | 580.76 |
| 142 | Nadia Alves Rocha | 45 | 2 | 2,732.36 | 546.47 | 546.47 |
| 143 | Marcos Oliveira Andrade | 50 | 2 | 5,000.00 | 2,307.33 | 2,307.33 |
| 144 | Eduarda Castro Vieira | 83 | 4 | 12,621.30 | 757.28 | 757.28 |
| 145 | Nadia Moreira Nascimento | 83 | 4 | 15,407.65 | 924.46 | 924.46 |
| 146 | Marcos Gomes Nunes | 63 | 3 | 7,836.12 | 783.61 | 783.61 |
| 147 | Elaine Silva Ferreira | 72 | 3 | 17,814.90 | 1,781.49 | 1,781.49 |
| 148 | Isabela Rocha Marques | 30 | 2 | 3,018.43 | 603.69 | 603.69 |
| 149 | Heitor Ferreira Moreira | 73 | 3 | 9,538.05 | 953.80 | 953.80 |
| 150 | Diego Fernandes Martins | 65 | 3 | 9,556.02 | 955.60 | 955.60 |
| 151 | Felipe Rocha Ferreira | 66 | 3 | 7,544.01 | 754.40 | 754.40 |
| 152 | Eduarda Souza Mendes | 83 | 4 | 12,263.90 | 735.83 | 735.83 |
| 153 | Tânia Medeiros Lopes | 20 | 1 | 600.00 | 453.74 | 453.74 |
| 154 | Karina Mendes Oliveira | 73 | 3 | 9,660.87 | 966.09 | 966.09 |
| 155 | Tânia Melo Nascimento | 90 | 4 | 23,931.85 | 1,435.91 | 1,435.91 |
| 156 | Ingrid Martins Pereira | 66 | 3 | 17,294.37 | 1,729.44 | 1,729.44 |
| 157 | Thiago Ramos Campos | 103 | 4 | 60,000.00 | 3,986.17 | 3,986.17 |
| 158 | Nadia Dias Ribeiro | 78 | 4 | 19,479.75 | 1,168.78 | 1,168.78 |
| 159 | Ana Ferreira Lopes | 57 | 3 | 4,652.67 | 465.27 | 465.27 |
| 160 | Yasmin Melo Carvalho | 57 | 3 | 5,693.67 | 569.37 | 569.37 |
| 161 | João Santos Barbosa | 83 | 4 | 15,917.30 | 955.04 | 955.04 |
| 162 | Heitor Cavalcanti Costa | 85 | 4 | 58,434.90 | 3,506.09 | 3,506.09 |
| 163 | Quintina Lopes Pereira | 69 | 3 | 13,602.90 | 1,360.29 | 1,360.29 |
| 164 | Xavier Cardoso Gomes | 93 | 4 | 58,810.25 | 3,528.61 | 3,528.61 |
| 165 | Úrsula Moreira Alves | 83 | 4 | 19,635.15 | 1,178.11 | 1,178.11 |
| 166 | Vinícius Vieira Fernandes | 62 | 3 | 10,652.16 | 1,065.22 | 1,065.22 |
| 167 | Olivia Sousa Rodrigues | 75 | 4 | 39,500.55 | 2,370.03 | 2,370.03 |
| 168 | Gabriela Rocha Santos | 59 | 3 | 11,501.19 | 1,150.12 | 1,150.12 |
| 169 | Quezia Lima Correia | 15 | 1 | 600.00 | 1,497.14 | 600.00 |
| 170 | Quezia Sousa Lopes | 53 | 2 | 5,000.00 | 1,548.55 | 1,548.55 |
| 171 | Wanda Lopes Alves | 65 | 3 | 4,044.27 | 404.43 | 404.43 |
| 172 | Fernando Nascimento Pereira | 93 | 4 | 56,673.80 | 3,400.43 | 3,400.43 |
| 173 | Sabrina Ferreira Ramos | 48 | 2 | 5,000.00 | 1,131.79 | 1,131.79 |
| 174 | Felipe Mendes Correia | 75 | 4 | 10,778.50 | 646.71 | 646.71 |
| 175 | Yasmin Silva Carvalho | 55 | 3 | 10,162.47 | 1,016.25 | 1,016.25 |
| 176 | Diego Oliveira Correia | 86 | 4 | 52,465.90 | 3,147.95 | 3,147.95 |
| 177 | Kleber Rocha Dias | 72 | 3 | 14,834.67 | 1,483.47 | 1,483.47 |
| 178 | Patrícia Martins Sousa | 83 | 4 | 55,224.85 | 3,313.49 | 3,313.49 |
| 179 | Zélia Pereira Teixeira | 85 | 4 | 43,640.45 | 2,618.43 | 2,618.43 |
| 180 | Sandra Ramos Moreira | 50 | 2 | 5,000.00 | 3,069.16 | 3,069.16 |
| 181 | Úrsula Marques Cavalcanti | 100 | 4 | 40,090.75 | 2,405.44 | 2,405.44 |
| 182 | Eduarda Alves Moraes | 67 | 3 | 4,016.46 | 401.65 | 401.65 |
| 183 | Rafael Correia Nascimento | 20 | 1 | 600.00 | 535.50 | 535.50 |
| 184 | Rafael Cavalcanti Pinto | 82 | 4 | 25,664.65 | 1,539.88 | 1,539.88 |
| 185 | Marcos Campos Martins | 55 | 3 | 15,876.69 | 1,587.67 | 1,587.67 |
| 186 | Júlia Barbosa Alves | 62 | 3 | 6,524.19 | 652.42 | 652.42 |
| 187 | Sabrina Dias Souza | 10 | 1 | 600.00 | 441.21 | 441.21 |
| 188 | Nadia Lopes Andrade | 43 | 2 | 3,065.87 | 613.17 | 613.17 |
| 189 | Yasmin Ramos Castro | 72 | 3 | 14,795.73 | 1,479.57 | 1,479.57 |
| 190 | Carla Mendes Barbosa | 89 | 4 | 55,988.10 | 3,359.29 | 3,359.29 |
| 191 | Giovanna Gomes Andrade | 28 | 1 | 600.00 | 755.90 | 600.00 |
| 192 | Ingrid Vieira Teixeira | 82 | 4 | 22,153.75 | 1,329.22 | 1,329.22 |
| 193 | Vagner Medeiros Barbosa | 66 | 3 | 9,794.97 | 979.50 | 979.50 |
| 194 | Carla Santos Pinto | 83 | 4 | 31,273.65 | 1,876.42 | 1,876.42 |
| 195 | Xavier Alves Marques | 76 | 4 | 12,178.05 | 730.68 | 730.68 |
| 196 | Xavier Souza Campos | 83 | 4 | 21,163.40 | 1,269.80 | 1,269.80 |
| 197 | Renato Campos Ramos | 90 | 4 | 28,019.80 | 1,681.19 | 1,681.19 |
| 198 | Sabrina Moreira Correia | 95 | 4 | 60,000.00 | 3,642.16 | 3,642.16 |
| 199 | Carla Santos Araújo | 62 | 3 | 13,490.46 | 1,349.05 | 1,349.05 |
| 200 | Lucas Castro Correia | 90 | 4 | 28,827.50 | 1,729.65 | 1,729.65 |

---

*Sistema de Avaliação de Limite de Crédito — v1.0*
