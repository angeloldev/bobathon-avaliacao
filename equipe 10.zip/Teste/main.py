"""
Exemplo de uso do agente de investimentos.

Execute:
    python main.py

Variáveis de ambiente necessárias:
    OPENAI_API_KEY  — chave da API da OpenAI
    OPENAI_MODEL    — (opcional) modelo a usar, padrão: gpt-4o-mini
"""

import os
from dotenv import load_dotenv

load_dotenv()  # carrega .env se existir

from investment_agent import investment_agent_graph
from investment_agent.models import (
    SuitabilityQuestionnaire,
    InvestmentObjective,
    TimeHorizon,
    AgentState,
)


def main() -> None:
    # ------------------------------------------------------------------
    # Exemplo 1 — Cliente conservador, sem experiência, curto prazo
    # ------------------------------------------------------------------
    cliente_conservador = SuitabilityQuestionnaire(
        nome="Ana Beatriz Silva",
        idade=62,
        renda_mensal=8_000.0,
        patrimonio_total=150_000.0,
        valor_a_investir=50_000.0,
        objetivo=InvestmentObjective.RENDA,
        horizonte=TimeHorizon.MEDIO_PRAZO,
        tolerancia_perda=1,
        experiencia_mercado=1,
        reacao_queda_10pct=1,
        dependencia_do_capital=4,
        tem_reserva_emergencia=True,
        tem_dividas=False,
        observacoes="Aposentada, precisa de renda mensal complementar.",
    )

    # ------------------------------------------------------------------
    # Exemplo 2 — Cliente agressivo, experiente, longo prazo
    # ------------------------------------------------------------------
    cliente_agressivo = SuitabilityQuestionnaire(
        nome="Carlos Eduardo Mendes",
        idade=30,
        renda_mensal=25_000.0,
        patrimonio_total=500_000.0,
        valor_a_investir=200_000.0,
        objetivo=InvestmentObjective.CRESCIMENTO_AGRESSIVO,
        horizonte=TimeHorizon.MUITO_LONGO_PRAZO,
        tolerancia_perda=5,
        experiencia_mercado=4,
        reacao_queda_10pct=5,
        dependencia_do_capital=1,
        tem_reserva_emergencia=True,
        tem_dividas=False,
        observacoes="Empreendedor, já opera na bolsa há 5 anos.",
    )

    # ------------------------------------------------------------------
    # Escolha o cliente para rodar (ou itere pelos dois)
    # ------------------------------------------------------------------
    for cliente in [cliente_conservador, cliente_agressivo]:
        print("\n" + "=" * 70)
        print(f"PROCESSANDO: {cliente.nome}")
        print("=" * 70)

        estado_inicial: AgentState = {"questionario": cliente}

        resultado = investment_agent_graph.invoke(estado_inicial)

        carteira = resultado["carteira"]
        print("\n")
        print(carteira)
        print("\n")


if __name__ == "__main__":
    main()
