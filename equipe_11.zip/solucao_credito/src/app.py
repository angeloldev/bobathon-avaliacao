"""
app.py — Frontend web da Solução de Concessão de Crédito.

Servidor Flask que expõe uma interface HTML para submissão de pedidos
e consulta de logs de auditoria, reaproveitando o orquestrador existente.

Uso:
    cd solucao_credito/src
    python app.py

Endpoints:
    GET  /                  → formulário de pedido
    POST /analisar          → processa o pedido e exibe o resultado
    GET  /auditoria         → lista todos os logs de auditoria gerados
    GET  /auditoria/<nome>  → exibe o conteúdo de um log específico
    GET  /api/produtos      → JSON com todos os produtos da carteira (autocomplete)
"""

import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from flask import Flask, jsonify, redirect, render_template, request, url_for

import config
from agentes.agente_carteira import _carregar_carteira
from orquestrador import processar_pedido
from api_agentes import api as api_agentes_blueprint

app = Flask(__name__)
app.secret_key = "credito-secret-key-local"

app.register_blueprint(api_agentes_blueprint, url_prefix="/api/v1")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _formatar_moeda(valor) -> str:
    if valor is None:
        return "—"
    try:
        return f"R$ {float(valor):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except (TypeError, ValueError):
        return str(valor)


def _formatar_taxa(valor) -> str:
    if valor is None:
        return "—"
    try:
        return f"{float(valor) * 100:.2f}%".replace(".", ",")
    except (TypeError, ValueError):
        return str(valor)


def _listar_logs() -> list[dict]:
    """Retorna metadados de todos os logs de auditoria, do mais recente ao mais antigo."""
    dir_audit = Path(config.DIR_AUDITORIA)
    if not dir_audit.exists():
        return []
    logs = []
    for f in sorted(dir_audit.glob("log_*.json"), reverse=True):
        try:
            dados = json.loads(f.read_text(encoding="utf-8"))
            logs.append({
                "nome": f.name,
                "pedido_id": dados.get("pedido_id", ""),
                "timestamp": dados.get("timestamp_inicio", ""),
                "cliente": dados.get("pedido", {}).get("cliente", ""),
                "produto": dados.get("pedido", {}).get("produto", ""),
                "valor": dados.get("pedido", {}).get("valor_solicitado", 0),
                "aprovado": dados.get("decisao", {}).get("aprovado"),
                "motivo": dados.get("decisao", {}).get("motivo_codigo", ""),
                "modo": dados.get("modo_execucao", "local"),
            })
        except Exception:
            pass
    return logs


# ---------------------------------------------------------------------------
# Rotas
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    """Exibe o formulário de solicitação de crédito."""
    try:
        produtos = _carregar_carteira()
    except Exception:
        produtos = []
    return render_template("index.html", produtos=produtos)


@app.route("/analisar", methods=["POST"])
def analisar():
    """Recebe o formulário, processa o pedido e exibe o resultado."""
    cliente = request.form.get("cliente", "").strip()
    produto = request.form.get("produto", "").strip()
    valor_str = request.form.get("valor_solicitado", "0").strip().replace(",", ".")

    erros = []
    if not cliente:
        erros.append("Informe o nome do cliente ou número da conta.")
    if not produto:
        erros.append("Selecione ou informe o produto de crédito.")
    try:
        valor = float(valor_str)
        if valor <= 0:
            erros.append("O valor solicitado deve ser maior que zero.")
    except ValueError:
        erros.append("Valor solicitado inválido.")
        valor = 0.0

    if erros:
        try:
            produtos = _carregar_carteira()
        except Exception:
            produtos = []
        return render_template("index.html", produtos=produtos, erros=erros,
                               form={"cliente": cliente, "produto": produto,
                                     "valor_solicitado": valor_str})

    pedido = {"cliente": cliente, "produto": produto, "valor_solicitado": valor}
    decisao = processar_pedido(pedido)

    # Formata valores para exibição
    decisao["_valor_fmt"] = _formatar_moeda(decisao.get("valor_solicitado"))
    decisao["_aprovado_fmt"] = _formatar_moeda(decisao.get("valor_aprovado"))
    decisao["_taxa_fmt"] = _formatar_taxa(decisao.get("taxa_juros_am"))

    return render_template("resultado.html", pedido=pedido, decisao=decisao)


@app.route("/auditoria")
def auditoria():
    """Lista todos os logs de auditoria gerados."""
    logs = _listar_logs()
    return render_template("auditoria.html", logs=logs,
                           formatar_moeda=_formatar_moeda)


@app.route("/auditoria/<nome>")
def auditoria_detalhe(nome: str):
    """Exibe o conteúdo formatado de um log de auditoria específico."""
    caminho = Path(config.DIR_AUDITORIA) / nome
    if not caminho.exists() or not caminho.name.startswith("log_"):
        return "Log não encontrado.", 404
    dados = json.loads(caminho.read_text(encoding="utf-8"))
    conteudo = json.dumps(dados, ensure_ascii=False, indent=2)
    return render_template("auditoria_detalhe.html", nome=nome,
                           dados=dados, conteudo=conteudo)


@app.route("/api/produtos")
def api_produtos():
    """Retorna JSON com todos os produtos ativos da carteira (para autocomplete)."""
    try:
        produtos = _carregar_carteira()
        return jsonify([
            {
                "codigo": p.get("codigo"),
                "nome": p.get("produto"),
                "modalidade": p.get("modalidade"),
                "limite_min": p.get("limite_minimo"),
                "limite_max": p.get("limite_maximo"),
                "taxa": p.get("taxa_juros_am"),
                "prazo": p.get("prazo_max_meses"),
                "status": p.get("status"),
            }
            for p in produtos if p.get("status") == "Ativo"
        ])
    except Exception as exc:
        return jsonify({"erro": str(exc)}), 500


# ---------------------------------------------------------------------------
# Ponto de entrada
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("\n  Solução de Concessão de Crédito — Frontend Web")
    print("  Acesse: http://localhost:5000\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
