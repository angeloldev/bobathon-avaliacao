"""
config.py — Módulo de configuração central da solução de concessão de crédito.

Todos os parâmetros globais (caminhos, credenciais, regras de negócio) são
definidos aqui e importados pelos demais módulos.
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Caminhos dos arquivos de dados
# Os caminhos são resolvidos em relação ao diretório deste próprio arquivo
# (solucao_credito/src/), garantindo portabilidade independente do diretório
# de trabalho atual.
# ---------------------------------------------------------------------------
_BASE_DIR = Path(__file__).parent

CAMINHO_CLIENTES: Path = _BASE_DIR / "dados" / "base_clientes.xlsx"
CAMINHO_CARTEIRA: Path = _BASE_DIR / "dados" / "carteira_credito.xlsx"

# ---------------------------------------------------------------------------
# Diretório de auditoria (criado em runtime pelo orquestrador)
# ---------------------------------------------------------------------------
DIR_AUDITORIA: Path = _BASE_DIR / "auditoria"

# ---------------------------------------------------------------------------
# Credenciais do IBM watsonx Orchestrate (lidas de variáveis de ambiente)
# Se qualquer uma delas for None, o orquestrador usará o modo local.
# ---------------------------------------------------------------------------
ORCHESTRATE_URL: str | None = os.getenv("ORCHESTRATE_URL")
ORCHESTRATE_API_KEY: str | None = os.getenv("ORCHESTRATE_API_KEY")
ORCHESTRATE_INSTANCE_ID: str | None = os.getenv("ORCHESTRATE_INSTANCE_ID")

# ---------------------------------------------------------------------------
# Regras de negócio
# ---------------------------------------------------------------------------
# Pontuação mínima de score de crédito para aprovação
SCORE_MINIMO: int = 600

# Valores aceitos de Capacidade de Pagamento para aprovação
CAPACIDADES_APROVADAS: list[str] = ["Alta", "Media"]
