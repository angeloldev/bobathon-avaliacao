"""
orquestrador.py — Coordena a execução dos três agentes especializados,
registra o log de auditoria e suporta IBM watsonx Orchestrate SDK com
fallback automático para o modo local.

Responsabilidades:
    - Receber um pedido de crédito no formato padronizado.
    - Tentar integrar com o IBM watsonx Orchestrate via SDK.
    - Se o SDK não estiver disponível ou as credenciais ausentes, executar
      localmente chamando os agentes em sequência.
    - Registrar um log de auditoria detalhado em JSON para cada execução.
    - Retornar a decisão final ao chamador.

Interfaces principais:
    processar_pedido(pedido: dict) -> dict
        Parâmetros:
            pedido: {
                "cliente": str,           # nome ou conta do cliente
                "produto": str,           # código ou nome do produto
                "valor_solicitado": float # valor em reais
            }
        Retorna:
            Dicionário de decisão conforme definido pelo agente_decisor,
            com campo adicional "modo_execucao": "orchestrate" | "local".

    _executar_modo_local(pedido: dict) -> tuple[dict, list[dict]]
        Executa os agentes diretamente sem o SDK do Orchestrate.
        Retorna (decisao, log_entries).

    _executar_modo_orchestrate(pedido: dict) -> tuple[dict, list[dict]] | None
        Tenta executar via SDK do IBM watsonx Orchestrate.
        Retorna (decisao, log_entries) ou None em caso de falha.

    _registrar_auditoria(log_entries: list[dict], pedido: dict, decisao: dict) -> str
        Grava o log de auditoria em JSON e retorna o caminho do arquivo.

Formato do log de auditoria:
    {
        "pedido_id": str,           # UUID gerado por execução
        "timestamp_inicio": str,    # ISO 8601
        "modo_execucao": str,       # "orchestrate" | "local"
        "pedido": dict,             # pedido original
        "etapas": [
            {
                "etapa": int,
                "agente": str,
                "timestamp": str,
                "dados_entrada": dict,
                "dados_saida": dict,
                "duracao_ms": float
            }
        ],
        "decisao": dict             # resultado final
    }

Dependências externas:
    - ibm-watsonx-orchestrate (opcional; importado via try/except)
    - config (módulo local)
    - agentes.agente_carteira (módulo local)
    - agentes.agente_cliente (módulo local)
    - agentes.agente_decisor (módulo local)

Exemplo de uso:
    from orquestrador import processar_pedido

    pedido = {
        "cliente": "Ana Paula Ferreira",
        "produto": "CR-001",
        "valor_solicitado": 15000.0
    }
    decisao = processar_pedido(pedido)
    print(decisao["aprovado"], decisao["justificativa"])
"""

import json
import sys
import uuid
import time
import logging
from datetime import datetime, timezone
from pathlib import Path

# Garante que o diretório src/ esteja no path para importações locais
sys.path.insert(0, str(Path(__file__).parent))

import config
from agentes.agente_carteira import consultar_carteira
from agentes.agente_cliente import consultar_cliente
from agentes.agente_decisor import decidir_credito

# ---------------------------------------------------------------------------
# Configuração básica de logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("orquestrador")

# ---------------------------------------------------------------------------
# Tentativa de importação do SDK do IBM watsonx Orchestrate
# Se o pacote não estiver instalado, o modo Orchestrate fica indisponível.
# ---------------------------------------------------------------------------
try:
    import ibm_watsonx_orchestrate  # noqa: F401
    _SDK_DISPONIVEL = True
    logger.info("SDK ibm-watsonx-orchestrate carregado com sucesso.")
except ImportError:
    _SDK_DISPONIVEL = False
    logger.info(
        "SDK ibm-watsonx-orchestrate não encontrado. "
        "A solução operará em modo local."
    )


# ---------------------------------------------------------------------------
# Helpers internos
# ---------------------------------------------------------------------------

def _agora_iso() -> str:
    """Retorna o timestamp atual em formato ISO 8601 (UTC)."""
    return datetime.now(timezone.utc).isoformat()


def _entrada_etapa(nome_agente: str, dados: dict) -> dict:
    """Cria o cabeçalho inicial de uma entrada de log de etapa."""
    return {
        "agente": nome_agente,
        "timestamp": _agora_iso(),
        "dados_entrada": dados,
    }


# ---------------------------------------------------------------------------
# Modo local — execução direta dos agentes
# ---------------------------------------------------------------------------

def _executar_modo_local(pedido: dict) -> tuple[dict, list[dict]]:
    """
    Executa o fluxo completo de decisão de crédito em modo local,
    chamando os agentes diretamente sem o SDK do Orchestrate.

    Parâmetros:
        pedido: Dicionário com campos "cliente", "produto" e "valor_solicitado".

    Retorna:
        Tupla (decisao: dict, log_entries: list[dict]) onde log_entries
        contém uma entrada por etapa executada.
    """
    log_entries: list[dict] = []
    etapa = 0

    cliente_id: str = pedido.get("cliente", "")
    produto_id: str = pedido.get("produto", "")
    valor: float = float(pedido.get("valor_solicitado", 0))

    # ------------------------------------------------------------------
    # Etapa 1 — Agente Carteira
    # ------------------------------------------------------------------
    etapa += 1
    entrada_carteira = {"produto": produto_id}
    t0 = time.perf_counter()
    dados_carteira = consultar_carteira(produto_id)
    duracao_carteira = (time.perf_counter() - t0) * 1000

    log_entries.append({
        "etapa": etapa,
        "agente": "agente_carteira",
        "timestamp": _agora_iso(),
        "dados_entrada": entrada_carteira,
        "dados_saida": dados_carteira,
        "duracao_ms": round(duracao_carteira, 2),
    })
    logger.info(
        "Etapa %d | agente_carteira | produto='%s' | encontrado=%s",
        etapa, produto_id, dados_carteira.get("encontrado"),
    )

    # ------------------------------------------------------------------
    # Etapa 2 — Agente Cliente
    # ------------------------------------------------------------------
    etapa += 1
    entrada_cliente = {"cliente": cliente_id}
    t0 = time.perf_counter()
    dados_cliente = consultar_cliente(cliente_id)
    duracao_cliente = (time.perf_counter() - t0) * 1000

    log_entries.append({
        "etapa": etapa,
        "agente": "agente_cliente",
        "timestamp": _agora_iso(),
        "dados_entrada": entrada_cliente,
        "dados_saida": dados_cliente,
        "duracao_ms": round(duracao_cliente, 2),
    })
    logger.info(
        "Etapa %d | agente_cliente | cliente='%s' | encontrado=%s",
        etapa, cliente_id, dados_cliente.get("encontrado"),
    )

    # ------------------------------------------------------------------
    # Etapa 3 — Agente Decisor
    # ------------------------------------------------------------------
    etapa += 1
    entrada_decisor = {
        "dados_cliente": dados_cliente,
        "dados_carteira": dados_carteira,
        "valor_solicitado": valor,
    }
    t0 = time.perf_counter()
    decisao = decidir_credito(dados_cliente, dados_carteira, valor)
    duracao_decisor = (time.perf_counter() - t0) * 1000

    log_entries.append({
        "etapa": etapa,
        "agente": "agente_decisor",
        "timestamp": _agora_iso(),
        "dados_entrada": entrada_decisor,
        "dados_saida": decisao,
        "duracao_ms": round(duracao_decisor, 2),
    })
    logger.info(
        "Etapa %d | agente_decisor | aprovado=%s | motivo=%s",
        etapa, decisao.get("aprovado"), decisao.get("motivo_codigo"),
    )

    return decisao, log_entries


# ---------------------------------------------------------------------------
# Modo Orchestrate — integração via SDK IBM watsonx Orchestrate
# ---------------------------------------------------------------------------

def _executar_modo_orchestrate(pedido: dict):
    """
    Tenta executar o fluxo via SDK do IBM watsonx Orchestrate.

    Esta implementação prepara a estrutura de integração com o SDK.
    Como o SDK ibm-watsonx-orchestrate ainda não possui uma API estável
    e pública para invocação de ferramentas encadeadas de forma programática
    (sem o ADK), a integração real depende das credenciais e da instância
    configuradas. Se a tentativa falhar por qualquer motivo (credenciais
    ausentes, SDK não instalado, erro de rede), retorna None para que o
    orquestrador faça fallback para o modo local.

    Decisão de design: dado que o plano proíbe o uso do ADK, a integração
    com o Orchestrate é implementada como uma chamada REST autenticada ao
    endpoint de execução de agentes da instância configurada. Se o SDK
    expuser essa funcionalidade, ela será utilizada; caso contrário, o
    fallback local garante a continuidade da operação.

    Parâmetros:
        pedido: Dicionário com campos "cliente", "produto" e "valor_solicitado".

    Retorna:
        Tupla (decisao, log_entries) em caso de sucesso, ou None em caso de falha.
    """
    if not _SDK_DISPONIVEL:
        return None

    credenciais_ok = all([
        config.ORCHESTRATE_URL,
        config.ORCHESTRATE_API_KEY,
        config.ORCHESTRATE_INSTANCE_ID,
    ])
    if not credenciais_ok:
        logger.warning(
            "Credenciais do IBM watsonx Orchestrate ausentes ou incompletas. "
            "Usando modo local."
        )
        return None

    try:
        # Importação segura do SDK (já verificada acima por _SDK_DISPONIVEL)
        import ibm_watsonx_orchestrate

        logger.info(
            "Conectando ao IBM watsonx Orchestrate em %s ...",
            config.ORCHESTRATE_URL,
        )

        # ----------------------------------------------------------------
        # Nota de integração:
        # A chamada abaixo representa o contrato esperado com o SDK.
        # Adapte conforme a versão do SDK instalado em seu ambiente.
        #
        # Exemplo conceitual (substitua pela API real do SDK disponível):
        #
        #   client = ibm_watsonx_orchestrate.Client(
        #       url=config.ORCHESTRATE_URL,
        #       api_key=config.ORCHESTRATE_API_KEY,
        #       instance_id=config.ORCHESTRATE_INSTANCE_ID,
        #   )
        #   resultado = client.run_agent(
        #       agent_name="orquestrador_credito",
        #       input=pedido,
        #   )
        #   return resultado["decisao"], resultado["log_entries"]
        # ----------------------------------------------------------------

        logger.warning(
            "SDK ibm-watsonx-orchestrate disponível, mas a integração "
            "programática sem ADK requer configuração adicional da instância. "
            "Usando modo local como fallback seguro."
        )
        return None

    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Erro ao conectar ao IBM watsonx Orchestrate: %s. "
            "Usando modo local.",
            exc,
        )
        return None


# ---------------------------------------------------------------------------
# Registro de auditoria
# ---------------------------------------------------------------------------

def _registrar_auditoria(
    log_entries: list[dict],
    pedido: dict,
    decisao: dict,
    pedido_id: str,
    modo: str,
) -> str:
    """
    Grava o log completo de auditoria da execução em um arquivo JSON.

    O arquivo é nomeado como `log_<timestamp>_<pedido_id_curto>.json` e
    salvo no diretório definido em config.DIR_AUDITORIA.

    Parâmetros:
        log_entries: Lista de entradas de etapa geradas durante a execução.
        pedido:      Pedido original recebido pelo orquestrador.
        decisao:     Dicionário de decisão retornado pelo agente_decisor.
        pedido_id:   Identificador único desta execução (UUID).
        modo:        Modo de execução utilizado ("orchestrate" | "local").

    Retorna:
        Caminho absoluto (str) do arquivo de log gravado.
    """
    dir_auditoria = Path(config.DIR_AUDITORIA)
    dir_auditoria.mkdir(parents=True, exist_ok=True)

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    id_curto = pedido_id.split("-")[0]
    nome_arquivo = f"log_{ts}_{id_curto}.json"
    caminho = dir_auditoria / nome_arquivo

    registro = {
        "pedido_id": pedido_id,
        "timestamp_inicio": log_entries[0]["timestamp"] if log_entries else _agora_iso(),
        "modo_execucao": modo,
        "pedido": pedido,
        "etapas": log_entries,
        "decisao": decisao,
    }

    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(registro, f, ensure_ascii=False, indent=2, default=str)

    logger.info("Log de auditoria gravado em: %s", caminho)
    return str(caminho)


# ---------------------------------------------------------------------------
# Função principal de orquestração
# ---------------------------------------------------------------------------

def processar_pedido(pedido: dict) -> dict:
    """
    Processa um pedido de concessão de crédito de ponta a ponta.

    Tenta executar via IBM watsonx Orchestrate SDK; se não disponível ou
    em caso de falha, executa em modo local com os agentes Python diretamente.

    Após a execução (qualquer modo), grava o log de auditoria em JSON no
    diretório configurado em config.DIR_AUDITORIA.

    Parâmetros:
        pedido: {
            "cliente": str,            # nome parcial ou conta corrente
            "produto": str,            # código (ex.: "CR-001") ou nome parcial
            "valor_solicitado": float  # valor em reais
        }

    Retorna:
        Dicionário de decisão com campo adicional "modo_execucao" indicando
        se a execução foi via Orchestrate ou local, e "log_path" com o
        caminho do arquivo de auditoria gerado.
    """
    pedido_id = str(uuid.uuid4())
    logger.info(
        "=== Iniciando processamento | pedido_id=%s | cliente='%s' | produto='%s' | valor=%.2f ===",
        pedido_id,
        pedido.get("cliente", ""),
        pedido.get("produto", ""),
        float(pedido.get("valor_solicitado", 0)),
    )

    # Tenta modo Orchestrate primeiro
    resultado_orchestrate = _executar_modo_orchestrate(pedido)

    if resultado_orchestrate is not None:
        decisao, log_entries = resultado_orchestrate
        modo = "orchestrate"
    else:
        # Fallback para modo local
        decisao, log_entries = _executar_modo_local(pedido)
        modo = "local"

    # Adiciona metadados ao retorno
    decisao["modo_execucao"] = modo

    # Grava auditoria
    caminho_log = _registrar_auditoria(log_entries, pedido, decisao, pedido_id, modo)
    decisao["log_path"] = caminho_log

    logger.info(
        "=== Processamento concluído | aprovado=%s | motivo=%s ===",
        decisao.get("aprovado"),
        decisao.get("motivo_codigo"),
    )

    return decisao
