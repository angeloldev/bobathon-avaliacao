"""
api_agentes.py — Endpoints REST para integração com IBM watsonx Orchestrate.

Expõe cada agente como um endpoint HTTP independente no padrão esperado
pelo Orchestrate para registro de Skills/Tools externas.

Endpoints:
    POST /agentes/carteira   → agente_carteira.consultar_carteira()
    POST /agentes/cliente    → agente_cliente.consultar_cliente()
    POST /agentes/decisor    → agente_decisor.decidir_credito()
    GET  /openapi.json       → especificação OpenAPI 3.0 (para importar no Orchestrate)

Autenticação:
    Bearer token via header Authorization.
    Configure AGENTS_API_KEY como variável de ambiente.
    Se não configurado, a verificação é desabilitada (apenas para desenvolvimento).

Uso (integrado ao app.py):
    A Blueprint 'api_agentes' é registrada em app.py com prefixo /api/v1

Uso standalone (para testes):
    cd solucao_credito/src
    python api_agentes.py
"""

import json
import os
import sys
from functools import wraps
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from flask import Blueprint, jsonify, request

from agentes.agente_carteira import consultar_carteira
from agentes.agente_cliente import consultar_cliente
from agentes.agente_decisor import decidir_credito

# Blueprint registrada em app.py com url_prefix="/api/v1"
api = Blueprint("api_agentes", __name__)

# Chave de API para autenticação dos endpoints (opcional em dev)
_API_KEY = os.getenv("AGENTS_API_KEY")


# ---------------------------------------------------------------------------
# Middleware de autenticação
# ---------------------------------------------------------------------------

def _requer_auth(f):
    """
    Decorator que verifica o token Bearer no header Authorization.
    Se AGENTS_API_KEY não estiver definida, a verificação é ignorada.
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        if _API_KEY:
            auth = request.headers.get("Authorization", "")
            if not auth.startswith("Bearer ") or auth[7:] != _API_KEY:
                return jsonify({"erro": "Não autorizado."}), 401
        return f(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Endpoint 1 — Agente Carteira
# ---------------------------------------------------------------------------

@api.route("/agentes/carteira", methods=["POST"])
@_requer_auth
def endpoint_carteira():
    """
    Consulta um produto de crédito na carteira do banco.

    Body JSON:
        { "produto": "CR-001" }

    Retorna os dados completos do produto ou mensagem de não encontrado.
    """
    corpo = request.get_json(silent=True) or {}
    produto = str(corpo.get("produto", "")).strip()

    if not produto:
        return jsonify({"erro": "Campo 'produto' é obrigatório."}), 400

    resultado = consultar_carteira(produto)
    status = 200 if resultado.get("encontrado") else 404
    return jsonify(resultado), status


# ---------------------------------------------------------------------------
# Endpoint 2 — Agente Cliente
# ---------------------------------------------------------------------------

@api.route("/agentes/cliente", methods=["POST"])
@_requer_auth
def endpoint_cliente():
    """
    Consulta o perfil de um cliente na base de dados.

    Body JSON:
        { "identificador": "Ana Paula Ferreira" }
        ou
        { "identificador": "001-12345-6" }

    Retorna os dados completos do cliente ou mensagem de não encontrado.
    """
    corpo = request.get_json(silent=True) or {}
    identificador = str(corpo.get("identificador", "")).strip()

    if not identificador:
        return jsonify({"erro": "Campo 'identificador' é obrigatório."}), 400

    resultado = consultar_cliente(identificador)
    status = 200 if resultado.get("encontrado") else 404
    return jsonify(resultado), status


# ---------------------------------------------------------------------------
# Endpoint 3 — Agente Decisor
# ---------------------------------------------------------------------------

@api.route("/agentes/decisor", methods=["POST"])
@_requer_auth
def endpoint_decisor():
    """
    Aplica as regras de negócio e retorna a decisão de crédito.

    Body JSON:
        {
            "dados_cliente":   { ...retorno do endpoint /agentes/cliente },
            "dados_carteira":  { ...retorno do endpoint /agentes/carteira },
            "valor_solicitado": 15000.0
        }

    Retorna a decisão completa com justificativa e motivo.
    """
    corpo = request.get_json(silent=True) or {}
    dados_cliente = corpo.get("dados_cliente")
    dados_carteira = corpo.get("dados_carteira")
    valor = corpo.get("valor_solicitado")

    if dados_cliente is None or dados_carteira is None or valor is None:
        return jsonify({
            "erro": "Campos obrigatórios: 'dados_cliente', 'dados_carteira', 'valor_solicitado'."
        }), 400

    try:
        valor_float = float(valor)
    except (TypeError, ValueError):
        return jsonify({"erro": "'valor_solicitado' deve ser numérico."}), 400

    resultado = decidir_credito(dados_cliente, dados_carteira, valor_float)
    return jsonify(resultado), 200


# ---------------------------------------------------------------------------
# Especificação OpenAPI 3.0 (para importar no Orchestrate)
# ---------------------------------------------------------------------------

@api.route("/openapi.json", methods=["GET"])
def openapi_spec():
    """
    Retorna a especificação OpenAPI 3.0 dos endpoints de agentes.
    Use este arquivo para registrar as Skills no IBM watsonx Orchestrate.
    """
    spec = {
        "openapi": "3.0.3",
        "info": {
            "title": "Agentes de Concessão de Crédito",
            "description": (
                "API REST dos três agentes especializados da solução de "
                "concessão de crédito: carteira, cliente e decisor."
            ),
            "version": "1.0.0",
        },
        "servers": [
            {
                "url": request.host_url.rstrip("/") + "/api/v1",
                "description": "Servidor local (modo dev)",
            }
        ],
        "security": [{"bearerAuth": []}],
        "components": {
            "securitySchemes": {
                "bearerAuth": {
                    "type": "http",
                    "scheme": "bearer",
                    "bearerFormat": "API Key",
                }
            }
        },
        "paths": {
            "/agentes/carteira": {
                "post": {
                    "operationId": "consultar_carteira",
                    "summary": "Consulta produto de crédito na carteira",
                    "description": (
                        "Busca um produto da carteira de crédito por código "
                        "exato (ex: CR-001) ou por nome parcial (ex: pessoal)."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["produto"],
                                    "properties": {
                                        "produto": {
                                            "type": "string",
                                            "description": "Código (ex: CR-001) ou nome parcial do produto",
                                            "example": "CR-001",
                                        }
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {"description": "Produto encontrado"},
                        "404": {"description": "Produto não encontrado"},
                    },
                }
            },
            "/agentes/cliente": {
                "post": {
                    "operationId": "consultar_cliente",
                    "summary": "Consulta perfil do cliente",
                    "description": (
                        "Busca um cliente pelo nome parcial (case-insensitive) "
                        "ou pelo número exato da conta corrente."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["identificador"],
                                    "properties": {
                                        "identificador": {
                                            "type": "string",
                                            "description": "Nome parcial ou número de conta (ex: 001-12345-6)",
                                            "example": "Ana Paula Ferreira",
                                        }
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {"description": "Cliente encontrado"},
                        "404": {"description": "Cliente não encontrado"},
                    },
                }
            },
            "/agentes/decisor": {
                "post": {
                    "operationId": "decidir_credito",
                    "summary": "Aplica regras de negócio e decide o crédito",
                    "description": (
                        "Recebe os dados do cliente e do produto e aplica as "
                        "8 regras de negócio em sequência, retornando a decisão "
                        "de aprovação ou negativa com justificativa."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["dados_cliente", "dados_carteira", "valor_solicitado"],
                                    "properties": {
                                        "dados_cliente": {
                                            "type": "object",
                                            "description": "Retorno do endpoint /agentes/cliente",
                                        },
                                        "dados_carteira": {
                                            "type": "object",
                                            "description": "Retorno do endpoint /agentes/carteira",
                                        },
                                        "valor_solicitado": {
                                            "type": "number",
                                            "description": "Valor em reais solicitado pelo cliente",
                                            "example": 15000.0,
                                        },
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {"description": "Decisão gerada com sucesso"},
                        "400": {"description": "Dados inválidos"},
                    },
                }
            },
        },
    }
    return jsonify(spec)


# ---------------------------------------------------------------------------
# Execução standalone (para testes sem app.py)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from flask import Flask
    _app = Flask(__name__)
    _app.register_blueprint(api, url_prefix="/api/v1")
    print("\n  Endpoints disponíveis:")
    print("  POST http://localhost:5001/api/v1/agentes/carteira")
    print("  POST http://localhost:5001/api/v1/agentes/cliente")
    print("  POST http://localhost:5001/api/v1/agentes/decisor")
    print("  GET  http://localhost:5001/api/v1/openapi.json\n")
    _app.run(debug=True, port=5001)
