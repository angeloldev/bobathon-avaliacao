"""
agente_cliente.py — Agente responsável por consultar o perfil de clientes
na base de dados a partir do arquivo base_clientes.xlsx.

Responsabilidades:
    - Ler e cachear os clientes da planilha de base de clientes.
    - Buscar um cliente por nome parcial (case-insensitive) ou por número de
      conta corrente exato.
    - Retornar um dicionário padronizado com todos os campos do cliente.

Estrutura de arquivos e classes:
    agente_cliente.py
        └── consultar_cliente(identificador: str) -> dict
        └── _carregar_clientes() -> list[dict]   (função interna / cache)

Interfaces principais:
    consultar_cliente(identificador: str) -> dict
        Parâmetros:
            identificador: nome parcial (ex.: "Ana Paula") ou número de conta
                           exato (ex.: "001-12345-6")
        Retorno (cliente encontrado):
            {
                "encontrado": True,
                "id": int,
                "nome": str,
                "conta": str,
                "historico": str,        # "Excelente" | "Bom" | "Regular" | "Ruim"
                "score": int,
                "renda_mensal": float,
                "limite_credito": float,
                "dividas_ativas": float,
                "capacidade": str,       # "Alta" | "Media" | "Baixa" | "Muito Baixa"
                "observacao": str
            }
        Retorno (não encontrado):
            {"encontrado": False, "mensagem": str}

Dependências externas:
    - openpyxl >= 3.1
    - config (módulo local)

Exemplo de uso:
    from agentes.agente_cliente import consultar_cliente

    resultado = consultar_cliente("Ana Paula")
    if resultado["encontrado"]:
        print(resultado["nome"], resultado["score"])
    else:
        print(resultado["mensagem"])

    # Busca por conta
    resultado = consultar_cliente("001-12345-6")
"""

import sys
from pathlib import Path

# Garante que o diretório src/ esteja no path para importar config
sys.path.insert(0, str(Path(__file__).parent.parent))

import openpyxl
import config

# ---------------------------------------------------------------------------
# Mapeamento entre os cabeçalhos exatos da planilha e as chaves do dicionário
# Ordem: colunas A→J (conforme especificado no plano)
# ---------------------------------------------------------------------------
_MAPA_COLUNAS = {
    "ID": "id",
    "Nome": "nome",
    "Conta Corrente": "conta",
    "Historico de Credito": "historico",
    "Score": "score",
    "Renda Mensal (R$)": "renda_mensal",
    "Limite de Credito (R$)": "limite_credito",
    "Dividas Ativas (R$)": "dividas_ativas",
    "Capacidade de Pagamento": "capacidade",
    "Observacao": "observacao",
}

# Cache em memória para evitar leituras repetidas do arquivo xlsx
_cache_clientes: list[dict] | None = None


def _carregar_clientes() -> list[dict]:
    """
    Carrega e retorna todos os clientes da planilha base_clientes.xlsx.

    A leitura ignora as linhas 1 e 2 (título e subtítulo).
    A linha 3 contém os cabeçalhos das colunas.
    Os dados começam na linha 4.

    Utiliza cache em memória: lê o arquivo apenas na primeira chamada.

    Retorna:
        Lista de dicionários, cada um representando um cliente.

    Lança:
        FileNotFoundError: se o arquivo xlsx não for encontrado.
    """
    global _cache_clientes
    if _cache_clientes is not None:
        return _cache_clientes

    caminho = config.CAMINHO_CLIENTES
    if not Path(caminho).exists():
        raise FileNotFoundError(
            f"Arquivo de clientes não encontrado: {caminho}"
        )

    wb = openpyxl.load_workbook(caminho, data_only=True)
    ws = wb.active

    # Lê cabeçalhos da linha 3
    cabecalhos = {}
    for col_idx, cell in enumerate(ws[3], start=1):
        valor = cell.value
        if valor is not None:
            cabecalhos[col_idx] = str(valor).strip()

    clientes = []
    # Dados a partir da linha 4
    for row in ws.iter_rows(min_row=4, values_only=True):
        # Ignora linhas completamente vazias
        if all(v is None for v in row):
            continue

        cliente_dict = {}
        for col_idx_zero, valor in enumerate(row):
            col_idx_one = col_idx_zero + 1
            nome_cabecalho = cabecalhos.get(col_idx_one)
            if nome_cabecalho and nome_cabecalho in _MAPA_COLUNAS:
                chave = _MAPA_COLUNAS[nome_cabecalho]
                cliente_dict[chave] = valor

        if cliente_dict:
            clientes.append(cliente_dict)

    _cache_clientes = clientes
    return clientes


def consultar_cliente(identificador: str) -> dict:
    """
    Consulta um cliente na base de dados por nome parcial ou número de conta.

    A busca por nome é por substring case-insensitive.
    A busca por conta corrente é exata (ex.: "001-12345-6").

    Parâmetros:
        identificador: Parte do nome do cliente (ex.: "Ana Paula", "Ferreira")
                       ou número de conta exato (ex.: "001-12345-6").

    Retorna:
        Dicionário com todos os campos do cliente e "encontrado": True,
        ou {"encontrado": False, "mensagem": str} quando não localizado.
    """
    try:
        clientes = _carregar_clientes()
    except FileNotFoundError as exc:
        return {"encontrado": False, "mensagem": str(exc)}

    termo = identificador.strip().lower()

    for item in clientes:
        nome = str(item.get("nome", "")).strip().lower()
        conta = str(item.get("conta", "")).strip().lower()

        if termo in nome or conta == termo:
            resultado = dict(item)
            resultado["encontrado"] = True
            return resultado

    return {
        "encontrado": False,
        "mensagem": (
            f"Cliente '{identificador}' não encontrado na base de dados. "
            "Verifique o nome ou o número da conta corrente."
        ),
    }
