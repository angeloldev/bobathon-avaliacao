"""
agente_carteira.py — Agente responsável por consultar produtos de crédito
na carteira do banco a partir do arquivo carteira_credito.xlsx.

Responsabilidades:
    - Ler e cachear os produtos da planilha de carteira de crédito.
    - Buscar um produto por código exato (ex.: "CR-001") ou por nome parcial
      (case-insensitive).
    - Retornar um dicionário padronizado com todos os campos do produto.

Estrutura de arquivos e classes:
    agente_carteira.py
        └── consultar_carteira(produto: str) -> dict
        └── _carregar_carteira() -> list[dict]   (função interna / cache)

Interfaces principais:
    consultar_carteira(produto: str) -> dict
        Parâmetros:
            produto: código exato (ex.: "CR-001") ou nome parcial (ex.: "pessoal")
        Retorno (produto encontrado):
            {
                "encontrado": True,
                "codigo": str,
                "produto": str,
                "modalidade": str,
                "publico_alvo": str,
                "prazo_max_meses": int,
                "taxa_juros_am": float,      # ex.: 0.0299 = 2,99% a.m.
                "limite_minimo": float,
                "limite_maximo": float,
                "limite_total_carteira": float,
                "limite_utilizado": float,
                "saldo_disponivel": float,
                "utilizacao_pct": float,     # ex.: 0.624 = 62,4%
                "status": str
            }
        Retorno (não encontrado):
            {"encontrado": False, "mensagem": str}

Dependências externas:
    - openpyxl >= 3.1
    - config (módulo local)

Exemplo de uso:
    from agentes.agente_carteira import consultar_carteira

    resultado = consultar_carteira("CR-001")
    if resultado["encontrado"]:
        print(resultado["produto"], resultado["taxa_juros_am"])
    else:
        print(resultado["mensagem"])
"""

import sys
import os
from pathlib import Path

# Garante que o diretório src/ esteja no path para importar config
sys.path.insert(0, str(Path(__file__).parent.parent))

import openpyxl
import config

# ---------------------------------------------------------------------------
# Mapeamento entre os cabeçalhos exatos da planilha e as chaves do dicionário
# Ordem: colunas A→M (conforme especificado no plano)
# ---------------------------------------------------------------------------
_MAPA_COLUNAS = {
    "Codigo": "codigo",
    "Produto": "produto",
    "Modalidade": "modalidade",
    "Publico-Alvo": "publico_alvo",
    "Prazo Max. (meses)": "prazo_max_meses",
    "Taxa Juros (% a.m.)": "taxa_juros_am",
    "Limite Min. (R$)": "limite_minimo",
    "Limite Max. (R$)": "limite_maximo",
    "Limite Total Carteira (R$)": "limite_total_carteira",
    "Limite Utilizado (R$)": "limite_utilizado",
    "Saldo Disponivel (R$)": "saldo_disponivel",
    "Utilizacao (%)": "utilizacao_pct",
    "Status": "status",
}

# Cache em memória para evitar leituras repetidas do arquivo xlsx
_cache_carteira: list[dict] | None = None


def _carregar_carteira() -> list[dict]:
    """
    Carrega e retorna todos os produtos da planilha carteira_credito.xlsx.

    A leitura ignora as linhas 1 e 2 (título e subtítulo).
    A linha 3 contém os cabeçalhos das colunas.
    Os dados começam na linha 4.
    A linha de totais ("TOTAL DA CARTEIRA") é ignorada automaticamente.

    Utiliza cache em memória: lê o arquivo apenas na primeira chamada.

    Retorna:
        Lista de dicionários, cada um representando um produto da carteira.

    Lança:
        FileNotFoundError: se o arquivo xlsx não for encontrado.
    """
    global _cache_carteira
    if _cache_carteira is not None:
        return _cache_carteira

    caminho = config.CAMINHO_CARTEIRA
    if not Path(caminho).exists():
        raise FileNotFoundError(
            f"Arquivo de carteira não encontrado: {caminho}"
        )

    wb = openpyxl.load_workbook(caminho, data_only=True)
    ws = wb.active

    # Lê cabeçalhos da linha 3
    cabecalhos = {}
    for col_idx, cell in enumerate(ws[3], start=1):
        valor = cell.value
        if valor is not None:
            cabecalhos[col_idx] = str(valor).strip()

    produtos = []
    # Dados a partir da linha 4
    for row in ws.iter_rows(min_row=4, values_only=True):
        # Ignora linhas completamente vazias
        if all(v is None for v in row):
            continue

        # Identifica a célula A (índice 0) — ignora linha de totais
        valor_a = row[0]
        if valor_a is None:
            continue
        if "TOTAL" in str(valor_a).upper():
            continue

        produto_dict = {}
        for col_idx_zero, valor in enumerate(row):
            col_idx_one = col_idx_zero + 1
            nome_cabecalho = cabecalhos.get(col_idx_one)
            if nome_cabecalho and nome_cabecalho in _MAPA_COLUNAS:
                chave = _MAPA_COLUNAS[nome_cabecalho]
                produto_dict[chave] = valor

        if produto_dict:
            produtos.append(produto_dict)

    _cache_carteira = produtos
    return produtos


def consultar_carteira(produto: str) -> dict:
    """
    Consulta um produto da carteira de crédito por código ou nome.

    A busca por código é exata e case-insensitive (ex.: "cr-001" == "CR-001").
    A busca por nome é por substring case-insensitive (ex.: "pessoal" encontra
    "Credito Pessoal").

    Parâmetros:
        produto: Código exato do produto (ex.: "CR-001") ou parte do nome
                 (ex.: "pessoal", "consignado").

    Retorna:
        Dicionário com todos os campos do produto e "encontrado": True,
        ou {"encontrado": False, "mensagem": str} quando não localizado.
    """
    try:
        carteira = _carregar_carteira()
    except FileNotFoundError as exc:
        return {"encontrado": False, "mensagem": str(exc)}

    termo = produto.strip().lower()

    for item in carteira:
        codigo = str(item.get("codigo", "")).strip().lower()
        nome = str(item.get("produto", "")).strip().lower()

        if codigo == termo or termo in nome:
            resultado = dict(item)
            resultado["encontrado"] = True
            return resultado

    return {
        "encontrado": False,
        "mensagem": (
            f"Produto '{produto}' não encontrado na carteira de crédito. "
            "Verifique o código ou o nome do produto."
        ),
    }
