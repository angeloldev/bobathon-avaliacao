"""
agente_decisor.py — Agente responsável por aplicar as regras de negócio e
emitir a decisão final de concessão ou negativa de crédito.

Responsabilidades:
    - Receber os dados consolidados do cliente e do produto de crédito.
    - Aplicar 8 regras de negócio em sequência, com curto-circuito na primeira
      negativa.
    - Gerar justificativas em linguagem simples, respeitosa e em 2ª pessoa.
    - Retornar um dicionário de decisão padronizado e auditável.

Estrutura de arquivos e classes:
    agente_decisor.py
        └── decidir_credito(dados_cliente, dados_carteira, valor_solicitado) -> dict
        └── _resumo_cliente(dados_cliente) -> dict   (função interna)
        └── _resumo_produto(dados_carteira) -> dict  (função interna)

Interfaces principais:
    decidir_credito(
        dados_cliente: dict,
        dados_carteira: dict,
        valor_solicitado: float
    ) -> dict

    Parâmetros:
        dados_cliente:    Dicionário retornado por agente_cliente.consultar_cliente()
        dados_carteira:   Dicionário retornado por agente_carteira.consultar_carteira()
        valor_solicitado: Valor em reais solicitado pelo cliente

    Retorno:
        {
            "aprovado": bool,
            "motivo_codigo": str,     # ex.: "APROVADO", "SCORE_INSUFICIENTE"
            "justificativa": str,     # texto cordial em 2ª pessoa
            "dados_cliente": dict,    # resumo do cliente
            "dados_produto": dict,    # resumo do produto
            "valor_solicitado": float,
            "valor_aprovado": float | None,  # None se negado
            "taxa_juros_am": float | None,   # None se negado
            "prazo_max_meses": int | None    # None se negado
        }

Códigos de motivo:
    APROVADO                    — Crédito aprovado
    CLIENTE_NAO_ENCONTRADO      — Dados do cliente não localizados
    PRODUTO_NAO_ENCONTRADO      — Produto de crédito não localizado
    SCORE_INSUFICIENTE          — Score abaixo do mínimo exigido
    CAPACIDADE_INSUFICIENTE     — Capacidade de pagamento baixa para o valor
    VALOR_ABAIXO_MINIMO         — Valor solicitado abaixo do limite mínimo
    VALOR_ACIMA_MAXIMO          — Valor solicitado acima do limite máximo
    SALDO_CARTEIRA_INSUFICIENTE — Saldo disponível na carteira insuficiente

Dependências externas:
    - config (módulo local)

Exemplo de uso:
    from agentes.agente_cliente import consultar_cliente
    from agentes.agente_carteira import consultar_carteira
    from agentes.agente_decisor import decidir_credito

    cliente = consultar_cliente("Ana Paula Ferreira")
    carteira = consultar_carteira("CR-001")
    decisao = decidir_credito(cliente, carteira, valor_solicitado=15000.0)

    print(decisao["aprovado"], decisao["justificativa"])
"""

import sys
from pathlib import Path

# Garante que o diretório src/ esteja no path para importar config
sys.path.insert(0, str(Path(__file__).parent.parent))

import config


# ---------------------------------------------------------------------------
# Funções auxiliares de resumo
# ---------------------------------------------------------------------------

def _resumo_cliente(dados: dict) -> dict:
    """
    Extrai um resumo dos campos mais relevantes do cliente para o log.

    Parâmetros:
        dados: Dicionário completo retornado pelo agente_cliente.

    Retorna:
        Dicionário com campos selecionados para exibição e auditoria.
    """
    return {
        "id": dados.get("id"),
        "nome": dados.get("nome"),
        "conta": dados.get("conta"),
        "score": dados.get("score"),
        "capacidade": dados.get("capacidade"),
        "historico": dados.get("historico"),
        "renda_mensal": dados.get("renda_mensal"),
        "limite_credito": dados.get("limite_credito"),
        "dividas_ativas": dados.get("dividas_ativas"),
    }


def _resumo_produto(dados: dict) -> dict:
    """
    Extrai um resumo dos campos mais relevantes do produto para o log.

    Parâmetros:
        dados: Dicionário completo retornado pelo agente_carteira.

    Retorna:
        Dicionário com campos selecionados para exibição e auditoria.
    """
    return {
        "codigo": dados.get("codigo"),
        "produto": dados.get("produto"),
        "modalidade": dados.get("modalidade"),
        "taxa_juros_am": dados.get("taxa_juros_am"),
        "prazo_max_meses": dados.get("prazo_max_meses"),
        "limite_minimo": dados.get("limite_minimo"),
        "limite_maximo": dados.get("limite_maximo"),
        "saldo_disponivel": dados.get("saldo_disponivel"),
        "status": dados.get("status"),
    }


# ---------------------------------------------------------------------------
# Função principal de decisão
# ---------------------------------------------------------------------------

def decidir_credito(
    dados_cliente: dict,
    dados_carteira: dict,
    valor_solicitado: float,
) -> dict:
    """
    Aplica as regras de negócio de concessão de crédito e retorna a decisão.

    As regras são avaliadas em ordem de prioridade. A primeira negativa
    interrompe o processamento (curto-circuito).

    Regras (em ordem):
        1. Cliente não encontrado → negar (CLIENTE_NAO_ENCONTRADO)
        2. Produto não encontrado → negar (PRODUTO_NAO_ENCONTRADO)
        3. Score < SCORE_MINIMO   → negar (SCORE_INSUFICIENTE)
        4. Capacidade fora de CAPACIDADES_APROVADAS e valor > limite_minimo
                                  → negar (CAPACIDADE_INSUFICIENTE)
        5. Valor < limite_minimo  → negar (VALOR_ABAIXO_MINIMO)
        6. Valor > limite_maximo  → negar (VALOR_ACIMA_MAXIMO)
        7. Saldo disponível < valor → negar (SALDO_CARTEIRA_INSUFICIENTE)
        8. Demais casos           → aprovar (APROVADO)

    Parâmetros:
        dados_cliente:    Dicionário retornado por agente_cliente.consultar_cliente().
        dados_carteira:   Dicionário retornado por agente_carteira.consultar_carteira().
        valor_solicitado: Valor em reais solicitado pelo cliente.

    Retorna:
        Dicionário de decisão com campos: aprovado, motivo_codigo, justificativa,
        dados_cliente, dados_produto, valor_solicitado, valor_aprovado,
        taxa_juros_am, prazo_max_meses.
    """

    def _negar(codigo: str, justificativa: str) -> dict:
        """Constrói e retorna um dicionário de decisão negativa."""
        return {
            "aprovado": False,
            "motivo_codigo": codigo,
            "justificativa": justificativa,
            "dados_cliente": resumo_cliente,
            "dados_produto": resumo_produto,
            "valor_solicitado": valor_solicitado,
            "valor_aprovado": None,
            "taxa_juros_am": None,
            "prazo_max_meses": None,
        }

    # Resumos pré-calculados (usados mesmo nas negativas)
    resumo_cliente = _resumo_cliente(dados_cliente) if dados_cliente else {}
    resumo_produto = _resumo_produto(dados_carteira) if dados_carteira else {}

    # ------------------------------------------------------------------
    # Regra 1 — Cliente não encontrado
    # ------------------------------------------------------------------
    if not dados_cliente.get("encontrado", False):
        return _negar(
            "CLIENTE_NAO_ENCONTRADO",
            "Não foi possível localizar seus dados em nossa base de clientes. "
            "Por favor, verifique as informações fornecidas ou entre em contato "
            "com a sua agência para regularizar seu cadastro.",
        )

    # ------------------------------------------------------------------
    # Regra 2 — Produto não encontrado
    # ------------------------------------------------------------------
    if not dados_carteira.get("encontrado", False):
        return _negar(
            "PRODUTO_NAO_ENCONTRADO",
            "O produto de crédito solicitado não foi identificado em nossa "
            "carteira. Verifique o código ou o nome do produto e tente novamente.",
        )

    # ------------------------------------------------------------------
    # Dados extraídos do cliente e do produto para as regras seguintes
    # ------------------------------------------------------------------
    score: int = int(dados_cliente.get("score") or 0)
    capacidade: str = str(dados_cliente.get("capacidade") or "").strip()
    nome_cliente: str = str(dados_cliente.get("nome") or "você")

    limite_minimo: float = float(dados_carteira.get("limite_minimo") or 0)
    limite_maximo: float = float(dados_carteira.get("limite_maximo") or 0)
    saldo_disponivel: float = float(dados_carteira.get("saldo_disponivel") or 0)
    taxa_juros_am: float = float(dados_carteira.get("taxa_juros_am") or 0)
    prazo_max_meses: int = int(dados_carteira.get("prazo_max_meses") or 0)
    nome_produto: str = str(dados_carteira.get("produto") or "produto solicitado")

    # ------------------------------------------------------------------
    # Regra 3 — Score insuficiente
    # ------------------------------------------------------------------
    if score < config.SCORE_MINIMO:
        return _negar(
            "SCORE_INSUFICIENTE",
            f"Infelizmente, seu score de crédito atual ({score} pontos) está "
            f"abaixo do mínimo exigido ({config.SCORE_MINIMO} pontos) para este "
            "produto. Recomendamos quitar pendências financeiras e aguardar a "
            "atualização do seu score antes de uma nova solicitação.",
        )

    # ------------------------------------------------------------------
    # Regra 4 — Capacidade de pagamento insuficiente para o valor pedido
    # ------------------------------------------------------------------
    if capacidade not in config.CAPACIDADES_APROVADAS and valor_solicitado > limite_minimo:
        return _negar(
            "CAPACIDADE_INSUFICIENTE",
            f"Com base no seu perfil financeiro atual (capacidade de pagamento: "
            f"{capacidade}), não é possível aprovar o valor de "
            f"R$ {valor_solicitado:,.2f} para este produto. "
            "Sugerimos solicitar o valor mínimo do produto ou buscar alternativas "
            "com condições mais adequadas ao seu momento financeiro.",
        )

    # ------------------------------------------------------------------
    # Regra 5 — Valor abaixo do limite mínimo do produto
    # ------------------------------------------------------------------
    if valor_solicitado < limite_minimo:
        return _negar(
            "VALOR_ABAIXO_MINIMO",
            f"O valor solicitado (R$ {valor_solicitado:,.2f}) é inferior ao "
            f"valor mínimo permitido para o {nome_produto} "
            f"(R$ {limite_minimo:,.2f}). Por favor, ajuste o valor e tente novamente.",
        )

    # ------------------------------------------------------------------
    # Regra 6 — Valor acima do limite máximo do produto
    # ------------------------------------------------------------------
    if valor_solicitado > limite_maximo:
        return _negar(
            "VALOR_ACIMA_MAXIMO",
            f"O valor solicitado (R$ {valor_solicitado:,.2f}) ultrapassa o "
            f"limite máximo do {nome_produto} (R$ {limite_maximo:,.2f}). "
            f"Caso deseje, podemos aprovar até R$ {limite_maximo:,.2f}. "
            "Entre em contato com a sua agência para ajustar o pedido.",
        )

    # ------------------------------------------------------------------
    # Regra 7 — Saldo disponível na carteira insuficiente
    # ------------------------------------------------------------------
    if saldo_disponivel < valor_solicitado:
        return _negar(
            "SALDO_CARTEIRA_INSUFICIENTE",
            f"No momento, o saldo disponível na carteira do {nome_produto} "
            f"(R$ {saldo_disponivel:,.2f}) é insuficiente para atender ao seu "
            f"pedido de R$ {valor_solicitado:,.2f}. "
            "Recomendamos aguardar a recomposição do saldo ou consultar outros "
            "produtos disponíveis.",
        )

    # ------------------------------------------------------------------
    # Regra 8 — Aprovação
    # ------------------------------------------------------------------
    taxa_percentual = taxa_juros_am * 100
    return {
        "aprovado": True,
        "motivo_codigo": "APROVADO",
        "justificativa": (
            f"Parabéns, {nome_cliente.split()[0]}! Sua solicitação de crédito foi "
            f"aprovada no valor de R$ {valor_solicitado:,.2f} para o {nome_produto}. "
            f"A taxa de juros é de {taxa_percentual:.2f}% ao mês, "
            f"com prazo máximo de {prazo_max_meses} meses. "
            "Em breve você receberá os detalhes para assinatura do contrato."
        ),
        "dados_cliente": resumo_cliente,
        "dados_produto": resumo_produto,
        "valor_solicitado": valor_solicitado,
        "valor_aprovado": valor_solicitado,
        "taxa_juros_am": taxa_juros_am,
        "prazo_max_meses": prazo_max_meses,
    }
