"""
executar_pedido.py — Script de entrada da solução de concessão de crédito.

Lê os pedidos de pedido_exemplo.json, processa cada um via orquestrador
e exibe o resultado formatado no terminal.

Uso:
    # A partir do diretório solucao_credito/src/
    python executar_pedido.py

    # Ou com um arquivo de pedidos alternativo:
    python executar_pedido.py meus_pedidos.json
"""

import json
import sys
from pathlib import Path

# Garante que src/ está no path para importações locais
sys.path.insert(0, str(Path(__file__).parent))

from orquestrador import processar_pedido

# ---------------------------------------------------------------------------
# Constantes de formatação
# ---------------------------------------------------------------------------
_SEPARADOR = "=" * 70
_SEPARADOR_LEVE = "-" * 70
_ICONE_APROVADO = "[APROVADO]"
_ICONE_NEGADO = "[NEGADO]"


def _formatar_moeda(valor) -> str:
    """Formata um valor numérico como moeda BRL."""
    if valor is None:
        return "—"
    try:
        return f"R$ {float(valor):,.2f}"
    except (TypeError, ValueError):
        return str(valor)


def _formatar_percentual(valor) -> str:
    """Formata um valor decimal como percentual (ex.: 0.0299 → '2,99%')."""
    if valor is None:
        return "—"
    try:
        return f"{float(valor) * 100:.2f}%"
    except (TypeError, ValueError):
        return str(valor)


def _imprimir_decisao(numero: int, pedido: dict, decisao: dict) -> None:
    """
    Imprime a decisão de um pedido de forma legível no terminal.

    Parâmetros:
        numero:  Número sequencial do pedido (exibido no cabeçalho).
        pedido:  Dicionário do pedido original.
        decisao: Dicionário de decisão retornado pelo orquestrador.
    """
    aprovado = decisao.get("aprovado", False)
    icone = _ICONE_APROVADO if aprovado else _ICONE_NEGADO
    modo = decisao.get("modo_execucao", "local").upper()

    print()
    print(_SEPARADOR)
    print(f"  PEDIDO #{numero}  {icone}  [MODO: {modo}]")
    print(_SEPARADOR)

    # Dados do pedido
    print(f"  Cliente  : {pedido.get('cliente', '—')}")
    print(f"  Produto  : {pedido.get('produto', '—')}")
    print(f"  Valor    : {_formatar_moeda(pedido.get('valor_solicitado'))}")
    print(_SEPARADOR_LEVE)

    # Decisão
    print(f"  Resultado: {icone}")
    print(f"  Motivo   : {decisao.get('motivo_codigo', '—')}")
    print()
    print("  Justificativa:")
    justificativa = decisao.get("justificativa", "")
    # Quebra em linhas de ~65 caracteres para melhor leitura no terminal
    palavras = justificativa.split()
    linha_atual = "    "
    for palavra in palavras:
        if len(linha_atual) + len(palavra) + 1 > 68:
            print(linha_atual)
            linha_atual = "    " + palavra
        else:
            linha_atual += (" " if linha_atual.strip() else "") + palavra
    if linha_atual.strip():
        print(linha_atual)

    # Detalhes da aprovação (apenas se aprovado)
    if aprovado:
        print()
        print("  Detalhes da aprovação:")
        print(f"    Valor aprovado  : {_formatar_moeda(decisao.get('valor_aprovado'))}")
        print(f"    Taxa de juros   : {_formatar_percentual(decisao.get('taxa_juros_am'))} a.m.")
        print(f"    Prazo máximo    : {decisao.get('prazo_max_meses', '—')} meses")

    # Caminho do log de auditoria
    log_path = decisao.get("log_path", "")
    if log_path:
        print()
        print(f"  Log de auditoria: {log_path}")

    print(_SEPARADOR)


def main() -> None:
    """
    Ponto de entrada principal do script.

    Lê o arquivo de pedidos (padrão: pedido_exemplo.json no mesmo diretório),
    processa cada pedido e exibe o resultado formatado.
    """
    # Arquivo de pedidos: argumento CLI ou padrão
    if len(sys.argv) > 1:
        caminho_pedidos = Path(sys.argv[1])
    else:
        caminho_pedidos = Path(__file__).parent / "pedido_exemplo.json"

    if not caminho_pedidos.exists():
        print(f"Erro: arquivo de pedidos não encontrado: {caminho_pedidos}")
        sys.exit(1)

    with open(caminho_pedidos, encoding="utf-8") as f:
        pedidos = json.load(f)

    print()
    print(_SEPARADOR)
    print("  SOLUÇÃO DE CONCESSÃO DE CRÉDITO — IBM watsonx Orchestrate")
    print(f"  Arquivo de pedidos: {caminho_pedidos.name}")
    print(f"  Total de pedidos  : {len(pedidos)}")
    print(_SEPARADOR)

    total_aprovados = 0
    total_negados = 0

    for i, pedido in enumerate(pedidos, start=1):
        # Remove campo de comentário interno (não é dado de negócio)
        pedido_limpo = {k: v for k, v in pedido.items() if not k.startswith("_")}

        try:
            decisao = processar_pedido(pedido_limpo)
        except Exception as exc:  # noqa: BLE001
            print(f"\n[ERRO] Pedido #{i} falhou inesperadamente: {exc}")
            continue

        _imprimir_decisao(i, pedido_limpo, decisao)

        if decisao.get("aprovado"):
            total_aprovados += 1
        else:
            total_negados += 1

    # Sumário final
    print()
    print(_SEPARADOR)
    print("  RESUMO DA EXECUÇÃO")
    print(_SEPARADOR_LEVE)
    print(f"  Pedidos processados : {len(pedidos)}")
    print(f"  Aprovados           : {total_aprovados}")
    print(f"  Negados             : {total_negados}")
    print(_SEPARADOR)
    print()


if __name__ == "__main__":
    main()
