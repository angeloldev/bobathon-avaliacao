# Solução de Concessão de Crédito com Múltiplos Agentes

> Solução Python modular de concessão de crédito coordenada pelo **IBM watsonx Orchestrate**,
> com fallback automático para execução local.

---

## Sumário

1. [Visão Geral](#1-visão-geral)
2. [Arquitetura e Fluxo de Orquestração](#2-arquitetura-e-fluxo-de-orquestração)
3. [Estrutura de Diretórios](#3-estrutura-de-diretórios)
4. [Pré-requisitos e Instalação](#4-pré-requisitos-e-instalação)
5. [Variáveis de Ambiente](#5-variáveis-de-ambiente)
6. [Como Executar](#6-como-executar)
7. [Agentes Especializados](#7-agentes-especializados)
8. [Regras de Negócio](#8-regras-de-negócio)
9. [Log de Auditoria](#9-log-de-auditoria)

---

## 1. Visão Geral

Esta solução automatiza a análise e decisão de concessão de crédito para pessoas
físicas utilizando três agentes Python independentes coordenados por um orquestrador
central. Os dados de clientes e produtos de crédito são lidos de arquivos Excel
(`.xlsx`) sem necessidade de banco de dados.

**Características:**

| Característica          | Detalhe                                                     |
|-------------------------|-------------------------------------------------------------|
| Linguagem               | Python 3.12+                                                |
| Leitura de dados        | `openpyxl` (arquivos `.xlsx`)                               |
| Orquestração            | IBM watsonx Orchestrate SDK (ou fallback local automático)  |
| Auditoria               | Log JSON por execução em `src/auditoria/`                   |
| Interface               | Script de linha de comando (`executar_pedido.py`)           |
| Dependências externas   | `openpyxl` (obrigatório); `ibm-watsonx-orchestrate` (opt.) |

**Fora do escopo:**
- Interface web ou API REST
- Persistência em banco de dados
- Integração real com sistemas bancários

---

## 2. Arquitetura e Fluxo de Orquestração

```
┌─────────────────────────────────────────────────────────────────┐
│                     executar_pedido.py                          │
│           (lê pedido_exemplo.json e inicia o fluxo)             │
└───────────────────────────┬─────────────────────────────────────┘
                            │ pedido: {cliente, produto, valor}
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                       orquestrador.py                           │
│                                                                 │
│  1. Tenta IBM watsonx Orchestrate SDK                           │
│     └─ Se falhar (sem credenciais / SDK ausente) → modo local   │
│                                                                 │
│  2. Modo local — sequência de agentes:                          │
│     ┌──────────────────┐   ┌──────────────────┐                │
│     │  agente_carteira │   │  agente_cliente  │                │
│     │  (consulta xlsx) │   │  (consulta xlsx) │                │
│     └────────┬─────────┘   └────────┬─────────┘                │
│              └───────────┬──────────┘                           │
│                          ▼                                      │
│              ┌───────────────────────┐                          │
│              │    agente_decisor     │                          │
│              │  (aplica 8 regras)    │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│  3. Grava log de auditoria JSON                                 │
└──────────────────────────┼──────────────────────────────────────┘
                           │ decisão final
                           ▼
                    Terminal / stdout
```

### Fallback Local

Se o IBM watsonx Orchestrate não estiver disponível (SDK não instalado ou
variáveis de ambiente ausentes), o orquestrador executa os três agentes
diretamente em memória, sem qualquer dependência de rede. O comportamento
da decisão e do log de auditoria é idêntico em ambos os modos.

---

## 3. Estrutura de Diretórios

```
solucao_credito/
├── requirements.txt              ← dependências do projeto
├── README.md                     ← este arquivo
└── src/
    ├── config.py                 ← configuração central (caminhos, regras, credenciais)
    ├── orquestrador.py           ← coordenador do fluxo + auditoria
    ├── executar_pedido.py        ← ponto de entrada CLI  ⬅ execute este arquivo
    ├── pedido_exemplo.json       ← 3 pedidos de exemplo
    ├── agentes/
    │   ├── __init__.py
    │   ├── agente_carteira.py    ← consulta produtos de crédito (carteira_credito.xlsx)
    │   ├── agente_cliente.py     ← consulta perfil do cliente (base_clientes.xlsx)
    │   └── agente_decisor.py     ← aplica regras e emite decisão
    ├── auditoria/                ← criado automaticamente em runtime
    │   └── log_YYYYMMDD_HHMMSS_<id>.json
    └── dados/
        ├── base_clientes.xlsx
        └── carteira_credito.xlsx
```

---

## 4. Pré-requisitos e Instalação

### Requisitos

- Python **3.12** ou superior
- `pip` atualizado

### Passos

```bash
# 1. Clone ou copie o projeto
cd solucao_credito

# 2. (Recomendado) Crie um ambiente virtual
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux / macOS:
source .venv/bin/activate

# 3. Instale as dependências obrigatórias
pip install -r requirements.txt

# 4. (Opcional) Instale o SDK do IBM watsonx Orchestrate
pip install ibm-watsonx-orchestrate
```

### Arquivos de dados

Certifique-se de que os arquivos abaixo estão presentes:

```
solucao_credito/src/dados/base_clientes.xlsx
solucao_credito/src/dados/carteira_credito.xlsx
```

---

## 5. Variáveis de Ambiente

As variáveis abaixo são necessárias **apenas** para o modo IBM watsonx Orchestrate.
Se não forem definidas, a solução opera automaticamente em modo local.

| Variável                  | Descrição                                             | Obrigatória para Orchestrate |
|---------------------------|-------------------------------------------------------|------------------------------|
| `ORCHESTRATE_URL`         | URL base da instância do IBM watsonx Orchestrate      | Sim                          |
| `ORCHESTRATE_API_KEY`     | Chave de API para autenticação                        | Sim                          |
| `ORCHESTRATE_INSTANCE_ID` | ID da instância do Orchestrate                        | Sim                          |

### Como definir (Windows PowerShell)

```powershell
$env:ORCHESTRATE_URL         = "https://seu-orchestrate.ibm.com"
$env:ORCHESTRATE_API_KEY     = "sua-api-key"
$env:ORCHESTRATE_INSTANCE_ID = "seu-instance-id"
```

### Como definir (Linux / macOS)

```bash
export ORCHESTRATE_URL="https://seu-orchestrate.ibm.com"
export ORCHESTRATE_API_KEY="sua-api-key"
export ORCHESTRATE_INSTANCE_ID="seu-instance-id"
```

Se qualquer uma das variáveis estiver ausente ou vazia, o orquestrador
usa o modo local automaticamente e registra um aviso no log.

---

## 6. Como Executar

O ponto de entrada é `src/executar_pedido.py`.
Execute sempre **a partir do diretório `src/`**:

```bash
cd solucao_credito/src
python executar_pedido.py
```

Para usar um arquivo de pedidos alternativo:

```bash
python executar_pedido.py meus_pedidos.json
```

### Exemplo de saída no terminal

```
======================================================================
  SOLUÇÃO DE CONCESSÃO DE CRÉDITO — IBM watsonx Orchestrate
  Arquivo de pedidos: pedido_exemplo.json
  Total de pedidos  : 3
======================================================================

======================================================================
  PEDIDO #1  [APROVADO ✓]  [MODO: LOCAL]
======================================================================
  Cliente  : Ana Paula Ferreira
  Produto  : CR-001
  Valor    : R$ 15.000,00
----------------------------------------------------------------------
  Resultado: [APROVADO ✓]
  Motivo   : APROVADO

  Justificativa:
    Parabéns, Ana! Sua solicitação de crédito foi aprovada no valor de
    R$ 15.000,00 para o Credito Pessoal. A taxa de juros é de 2,99% ao
    mês, com prazo máximo de 60 meses. Em breve você receberá os
    detalhes para assinatura do contrato.

  Detalhes da aprovação:
    Valor aprovado  : R$ 15.000,00
    Taxa de juros   : 2,99% a.m.
    Prazo máximo    : 60 meses

  Log de auditoria: .../src/auditoria/log_20250101_120000_abc12345.json
======================================================================

======================================================================
  PEDIDO #2  [NEGADO ✗]  [MODO: LOCAL]
======================================================================
  Cliente  : Felipe Goncalves
  Produto  : CR-001
  Valor    : R$ 5.000,00
----------------------------------------------------------------------
  Resultado: [NEGADO ✗]
  Motivo   : SCORE_INSUFICIENTE

  Justificativa:
    Infelizmente, seu score de crédito atual (320 pontos) está abaixo do
    mínimo exigido (600 pontos) para este produto. Recomendamos quitar
    pendências financeiras e aguardar a atualização do seu score antes
    de uma nova solicitação.
======================================================================
```

---

## 7. Agentes Especializados

> Os agentes são **módulos Python independentes** criados manualmente.
> Não utilizam o ADK (Agent Development Kit) do IBM watsonx.

### `agente_carteira.py`

**Responsabilidade:** Consultar produtos de crédito disponíveis na carteira do banco.

| Item                | Detalhe                                                                |
|---------------------|------------------------------------------------------------------------|
| Fonte de dados      | `dados/carteira_credito.xlsx` (linha 3 = cabeçalhos, dados da linha 4) |
| Função principal    | `consultar_carteira(produto: str) -> dict`                             |
| Busca por código    | Exata, case-insensitive (ex.: `"cr-001"` → `"CR-001"`)                 |
| Busca por nome      | Substring, case-insensitive (ex.: `"pessoal"` → `"Credito Pessoal"`)  |
| Cache               | Em memória (lê o xlsx apenas uma vez por execução)                     |

### `agente_cliente.py`

**Responsabilidade:** Consultar o perfil financeiro de clientes.

| Item                | Detalhe                                                                |
|---------------------|------------------------------------------------------------------------|
| Fonte de dados      | `dados/base_clientes.xlsx` (linha 3 = cabeçalhos, dados da linha 4)   |
| Função principal    | `consultar_cliente(identificador: str) -> dict`                        |
| Busca por nome      | Substring, case-insensitive                                            |
| Busca por conta     | Exata (ex.: `"001-12345-6"`)                                           |
| Cache               | Em memória (lê o xlsx apenas uma vez por execução)                     |

### `agente_decisor.py`

**Responsabilidade:** Aplicar as regras de negócio e emitir a decisão de crédito.

| Item                | Detalhe                                                                |
|---------------------|------------------------------------------------------------------------|
| Entradas            | `dados_cliente`, `dados_carteira`, `valor_solicitado`                  |
| Função principal    | `decidir_credito(dados_cliente, dados_carteira, valor_solicitado)`     |
| Regras              | 8 regras em sequência (ver seção 8)                                    |
| Justificativas      | Em 2ª pessoa, linguagem simples e respeitosa                           |

---

## 8. Regras de Negócio

As regras são avaliadas em sequência. A primeira que falha interrompe o processo
(curto-circuito). Todas as constantes são configuráveis em `config.py`.

| # | Condição                                                        | Código de Motivo           | Decisão |
|---|-----------------------------------------------------------------|----------------------------|---------|
| 1 | Cliente não encontrado na base                                  | `CLIENTE_NAO_ENCONTRADO`   | Negar   |
| 2 | Produto não encontrado na carteira                              | `PRODUTO_NAO_ENCONTRADO`   | Negar   |
| 3 | Score < 600 (`SCORE_MINIMO`)                                    | `SCORE_INSUFICIENTE`       | Negar   |
| 4 | Capacidade ≠ "Alta"/"Media" **e** valor > limite mínimo         | `CAPACIDADE_INSUFICIENTE`  | Negar   |
| 5 | Valor solicitado < limite mínimo do produto                     | `VALOR_ABAIXO_MINIMO`      | Negar   |
| 6 | Valor solicitado > limite máximo do produto                     | `VALOR_ACIMA_MAXIMO`       | Negar   |
| 7 | Saldo disponível na carteira < valor solicitado                 | `SALDO_CARTEIRA_INSUFICIENTE` | Negar |
| 8 | Todas as regras anteriores satisfeitas                          | `APROVADO`                 | Aprovar |

**Parâmetros configuráveis em `config.py`:**

```python
SCORE_MINIMO = 600
CAPACIDADES_APROVADAS = ["Alta", "Media"]
```

---

## 9. Log de Auditoria

Um arquivo JSON é gerado em `src/auditoria/` para cada execução de pedido.
O nome segue o padrão: `log_YYYYMMDD_HHMMSS_<id_curto>.json`.

### Estrutura do arquivo de log

```json
{
  "pedido_id": "uuid-completo",
  "timestamp_inicio": "2025-01-01T12:00:00+00:00",
  "modo_execucao": "local",
  "pedido": {
    "cliente": "Ana Paula Ferreira",
    "produto": "CR-001",
    "valor_solicitado": 15000.0
  },
  "etapas": [
    {
      "etapa": 1,
      "agente": "agente_carteira",
      "timestamp": "2025-01-01T12:00:00.001000+00:00",
      "dados_entrada": { "produto": "CR-001" },
      "dados_saida": { "encontrado": true, "codigo": "CR-001", "produto": "Credito Pessoal", "..." : "..." },
      "duracao_ms": 12.34
    },
    {
      "etapa": 2,
      "agente": "agente_cliente",
      "timestamp": "2025-01-01T12:00:00.015000+00:00",
      "dados_entrada": { "cliente": "Ana Paula Ferreira" },
      "dados_saida": { "encontrado": true, "nome": "Ana Paula Ferreira", "score": 820, "..." : "..." },
      "duracao_ms": 5.67
    },
    {
      "etapa": 3,
      "agente": "agente_decisor",
      "timestamp": "2025-01-01T12:00:00.022000+00:00",
      "dados_entrada": { "..." : "..." },
      "dados_saida": { "aprovado": true, "motivo_codigo": "APROVADO", "..." : "..." },
      "duracao_ms": 0.45
    }
  ],
  "decisao": {
    "aprovado": true,
    "motivo_codigo": "APROVADO",
    "justificativa": "Parabéns, Ana! ...",
    "valor_solicitado": 15000.0,
    "valor_aprovado": 15000.0,
    "taxa_juros_am": 0.0299,
    "prazo_max_meses": 60,
    "modo_execucao": "local"
  }
}
```

O log é válido e completo independentemente do modo de execução (Orchestrate ou local).

---

*Solução desenvolvida para fins demonstrativos com dados fictícios.*
