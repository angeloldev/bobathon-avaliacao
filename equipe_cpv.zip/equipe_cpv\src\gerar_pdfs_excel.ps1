$ErrorActionPreference = "Stop"
$DataDir = Join-Path $PSScriptRoot "data"

$colorHeader  = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(27, 58, 107))
$colorWhite   = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::White)
$colorZebra   = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(240, 244, 251))
$colorBorder  = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(209, 213, 219))

$rankColors = @{
    "A+"        = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(22, 163, 74))
    "A"         = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(34, 197, 94))
    "B"         = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(59, 130, 212))
    "C"         = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(217, 119, 6))
    "D"         = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(220, 38, 38))
    "E"         = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(127, 29, 29))
    "Baixo"     = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(22, 163, 74))
    "Medio"     = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(59, 130, 212))
    "Alto"      = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(217, 119, 6))
    "MuitoAlto" = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(220, 38, 38))
}
$colorRed  = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(220, 38, 38))
$colorGreen = [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb(22, 163, 74))

function Build-Sheet {
    param($ws, $xl, [string]$CsvPath, [string]$Title)

    $rows = Import-Csv -Path $CsvPath -Encoding UTF8
    $headers = @($rows[0].PSObject.Properties.Name)
    $nCols = $headers.Count
    $nRows = $rows.Count

    # Row 1 = title banner
    $titleCell = $ws.Range($ws.Cells.Item(1,1), $ws.Cells.Item(1,$nCols))
    $titleCell.Merge() | Out-Null
    $titleCell.Value2 = $Title
    $titleCell.Font.Bold = $true
    $titleCell.Font.Size = 11
    $titleCell.Font.Name = "Segoe UI"
    $titleCell.Font.Color = $colorWhite
    $titleCell.Interior.Color = $colorHeader
    $titleCell.HorizontalAlignment = -4108
    $titleCell.RowHeight = 26

    # Row 2 = column headers
    for ($c = 0; $c -lt $nCols; $c++) {
        $cell = $ws.Cells.Item(2, $c + 1)
        $cell.Value2 = $headers[$c]
        $cell.Font.Bold = $true
        $cell.Font.Size = 8
        $cell.Font.Name = "Segoe UI"
        $cell.Font.Color = $colorWhite
        $cell.Interior.Color = $colorHeader
        $cell.HorizontalAlignment = -4108
        $cell.RowHeight = 18
        $cell.WrapText = $false
    }

    # Data rows start at row 3
    $rIdx = 3
    foreach ($row in $rows) {
        $bgColor = if ($rIdx % 2 -eq 1) { $colorZebra } else { [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::White) }
        for ($c = 0; $c -lt $nCols; $c++) {
            $cell = $ws.Cells.Item($rIdx, $c + 1)
            $cell.Value2 = $row.($headers[$c])
            $cell.Font.Size = 8
            $cell.Font.Name = "Segoe UI"
            $cell.Interior.Color = $bgColor
            $cell.RowHeight = 15
        }
        $rIdx++
    }

    # Special column coloring
    $rankCol   = [array]::IndexOf($headers, "ranking_sisbacen") + 1
    $riscoCol  = [array]::IndexOf($headers, "grau_risco") + 1
    $atrasoCol = [array]::IndexOf($headers, "houve_atraso") + 1

    for ($r = 3; $r -le ($nRows + 2); $r++) {
        if ($rankCol -gt 0) {
            $v = $ws.Cells.Item($r, $rankCol).Value2
            if ($rankColors.ContainsKey($v)) {
                $ws.Cells.Item($r, $rankCol).Interior.Color = $rankColors[$v]
                $ws.Cells.Item($r, $rankCol).Font.Color = $colorWhite
                $ws.Cells.Item($r, $rankCol).Font.Bold = $true
                $ws.Cells.Item($r, $rankCol).HorizontalAlignment = -4108
            }
        }
        if ($riscoCol -gt 0) {
            $raw = $ws.Cells.Item($r, $riscoCol).Value2
            $key = $raw -replace " ", "" -replace "é","e"
            if ($rankColors.ContainsKey($key)) {
                $ws.Cells.Item($r, $riscoCol).Interior.Color = $rankColors[$key]
                $ws.Cells.Item($r, $riscoCol).Font.Color = $colorWhite
                $ws.Cells.Item($r, $riscoCol).Font.Bold = $true
                $ws.Cells.Item($r, $riscoCol).HorizontalAlignment = -4108
            }
        }
        if ($atrasoCol -gt 0) {
            $v = $ws.Cells.Item($r, $atrasoCol).Value2
            if ($v -eq "Sim") {
                $ws.Cells.Item($r, $atrasoCol).Font.Color = $colorRed
                $ws.Cells.Item($r, $atrasoCol).Font.Bold = $true
            } elseif ($v -eq "Nao") {
                $ws.Cells.Item($r, $atrasoCol).Font.Color = $colorGreen
            }
        }
    }

    # Borders
    $used = $ws.Range($ws.Cells.Item(1,1), $ws.Cells.Item($nRows+2, $nCols))
    $used.Borders.LineStyle = 1
    $used.Borders.Weight = 2
    $used.Borders.Color = $colorBorder

    # AutoFit
    $used.EntireColumn.AutoFit() | Out-Null

    # Page setup
    $ws.PageSetup.Orientation = 2
    $ws.PageSetup.Zoom = $false
    $ws.PageSetup.FitToPagesWide = 1
    # FitToPagesTall = 0 causes COM error; omit to let Excel auto-fit height
    $ws.PageSetup.LeftMargin  = $xl.InchesToPoints(0.35)
    $ws.PageSetup.RightMargin = $xl.InchesToPoints(0.35)
    $ws.PageSetup.TopMargin   = $xl.InchesToPoints(0.35)
    $ws.PageSetup.BottomMargin = $xl.InchesToPoints(0.35)
    $ws.PageSetup.CenterHorizontally = $true
    $ws.PageSetup.PrintTitleRows = "`$2:`$2"
}

# ---- CLIENTES ----
Write-Host "Gerando clientes.pdf..."
$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false
$xl.DisplayAlerts = $false
$wb = $xl.Workbooks.Add()
$ws = $wb.Worksheets.Item(1)
$ws.Name = "Clientes"

$t1 = "BASE DE CLIENTES - Pipeline de Concessao de Credito - Banco Digital S.A. - Dados Ficticios"
Build-Sheet -ws $ws -xl $xl `
    -CsvPath (Join-Path $DataDir "clientes.csv") `
    -Title $t1

$pdfPath = Join-Path $DataDir "clientes.pdf"
$wb.ExportAsFixedFormat(0, $pdfPath, 0, $true, $false)
$wb.Close($false)
$xl.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl) | Out-Null
Write-Host "OK -> $pdfPath"

Start-Sleep -Seconds 2

# ---- PRODUTOS ----
Write-Host "Gerando produtos_credito.pdf..."
$xl2 = New-Object -ComObject Excel.Application
$xl2.Visible = $false
$xl2.DisplayAlerts = $false
$wb2 = $xl2.Workbooks.Add()
$ws2 = $wb2.Worksheets.Item(1)
$ws2.Name = "Produtos"

$t2 = "PORTFOLIO DE PRODUTOS DE CREDITO - Banco Digital S.A. - Dados Ficticios para Demonstracao"
Build-Sheet -ws $ws2 -xl $xl2 `
    -CsvPath (Join-Path $DataDir "produtos_credito.csv") `
    -Title $t2

$pdfPath2 = Join-Path $DataDir "produtos_credito.pdf"
$wb2.ExportAsFixedFormat(0, $pdfPath2, 0, $true, $false)
$wb2.Close($false)
$xl2.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl2) | Out-Null
Write-Host "OK -> $pdfPath2"
Write-Host ""
Write-Host "Concluido. PDFs salvos em: $DataDir"
