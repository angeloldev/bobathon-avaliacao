"""
Pipeline de Concessão de Crédito Bancário
==========================================
Arquitetura: 2 Agentes Especialistas + 1 Agente Orquestrador

Agentes:
  - RiskAnalystAgent   : Analisa o perfil do cliente e calcula o Score de Risco Interno (SRI)
  - ProductMatcherAgent: Mapeia produtos elegíveis com base no SRI e perfil do cliente
  - CreditOrchestrator : Coordena os agentes, consolida a decisão e gera justificativa ao cliente
"""

import csv
import json
import uuid
from datetime import date, timedelta
from dataclasses import dataclass, field
from typing import Optional


# ─────────────────────────────────────────────
# DATA MODELS
# ─────────────────────────────────────────────

@dataclass
class Cliente:
    id_cliente: int
    nome: str
    cpf: str
    movimentacao_mensal_media: float
    tempo_banco_anos: float
    renda_mensal: float
    qtd_emprestimos_ativos: int
    houve_atraso: bool
    dias_atraso_max: int
    valor_total_atraso: float
    ranking_sisbacen: str
    comportamento_consumo: str


@dataclass
class Produto:
    id_produto: int
    nome_produto: str
    categoria: str
    limite_minimo: float
    limite_maximo: float
    taxa_juros_mensal_min: float
    taxa_juros_mensal_max: float
    prazo_minimo_meses: int
    prazo_maximo_meses: int
    grau_risco: str
    ranking_sisbacen_minimo: str
    renda_minima: float
    tempo_banco_minimo_anos: float
    score_interno_minimo: int
    descricao: str


@dataclass
class RelatorioRisco:
    id_cliente: int
    nome: str
    sri: float
    faixa_risco: str
    flags: list
    detalhamento: dict
    recomendacao_agente1: str


@dataclass
class ProdutoAprovado:
    id_produto: int
    nome_produto: str
    limite_aprovado: float
    taxa_aplicada: float
    motivo_aprovacao: str


@dataclass
class ProdutoRecusado:
    id_produto: int
    nome_produto: str
    motivo_recusa: str


@dataclass
class ResultadoProdutos:
    produtos_aprovados: list = field(default_factory=list)
    produtos_recusados: list = field(default_factory=list)


@dataclass
class DecisaoFinal:
    id_solicitacao: str
    id_cliente: int
    data_analise: str
    decisao_final: str
    produto_solicitado: str
    produtos_aprovados: list
    produtos_alternativos: list
    sri: float
    faixa_risco: str
    flags_ativos: list
    justificativa_cliente: str
    recomendacoes_cliente: list
    proxima_revisao_sugerida: str


# ─────────────────────────────────────────────
# DATA LOADERS
# ─────────────────────────────────────────────

def carregar_clientes(caminho: str) -> list[Cliente]:
    clientes = []
    with open(caminho, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            clientes.append(Cliente(
                id_cliente=int(row["id_cliente"]),
                nome=row["nome"],
                cpf=row["cpf"],
                movimentacao_mensal_media=float(row["movimentacao_mensal_media"]),
                tempo_banco_anos=float(row["tempo_banco_anos"]),
                renda_mensal=float(row["renda_mensal"]),
                qtd_emprestimos_ativos=int(row["qtd_emprestimos_ativos"]),
                houve_atraso=row["houve_atraso"].strip().lower() == "sim",
                dias_atraso_max=int(row["dias_atraso_max"]),
                valor_total_atraso=float(row["valor_total_atraso"]),
                ranking_sisbacen=row["ranking_sisbacen"].strip(),
                comportamento_consumo=row["comportamento_consumo"].strip(),
            ))
    return clientes


def carregar_produtos(caminho: str) -> list[Produto]:
    produtos = []
    with open(caminho, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            produtos.append(Produto(
                id_produto=int(row["id_produto"]),
                nome_produto=row["nome_produto"],
                categoria=row["categoria"],
                limite_minimo=float(row["limite_minimo"]),
                limite_maximo=float(row["limite_maximo"]),
                taxa_juros_mensal_min=float(row["taxa_juros_mensal_min"]),
                taxa_juros_mensal_max=float(row["taxa_juros_mensal_max"]),
                prazo_minimo_meses=int(row["prazo_minimo_meses"]),
                prazo_maximo_meses=int(row["prazo_maximo_meses"]),
                grau_risco=row["grau_risco"],
                ranking_sisbacen_minimo=row["ranking_sisbacen_minimo"].strip(),
                renda_minima=float(row["renda_minima"]),
                tempo_banco_minimo_anos=float(row["tempo_banco_minimo_anos"]),
                score_interno_minimo=int(row["score_interno_minimo"]),
                descricao=row["descricao"],
            ))
    return produtos


# ─────────────────────────────────────────────
# AGENT 1 — RISK ANALYST AGENT
# ─────────────────────────────────────────────

class RiskAnalystAgent:
    """
    Analisa o perfil do cliente e calcula o Score de Risco Interno (SRI).
    Não toma decisão de concessão — apenas produz análise de risco.
    """

    RANKING_HIERARCHY = {"A+": 6, "A": 5, "B": 4, "C": 3, "D": 2, "E": 1}

    def analisar(self, cliente: Cliente) -> RelatorioRisco:
        sisbacen_score = self._score_sisbacen(cliente.ranking_sisbacen)
        pagamento_score = self._score_pagamento(cliente.houve_atraso, cliente.dias_atraso_max)
        comprometimento_score = self._score_comprometimento(cliente.qtd_emprestimos_ativos, cliente.renda_mensal)
        tempo_score = self._score_tempo(cliente.tempo_banco_anos)
        movimentacao_score = self._score_movimentacao(cliente.movimentacao_mensal_media, cliente.renda_mensal)

        sri = (
            sisbacen_score * 0.30 +
            pagamento_score * 0.25 +
            comprometimento_score * 0.20 +
            tempo_score * 0.15 +
            movimentacao_score * 0.10
        )

        faixa_risco = self._classificar_faixa(sri)
        flags = self._detectar_flags(cliente)
        recomendacao = self._recomendar(sri, flags)

        return RelatorioRisco(
            id_cliente=cliente.id_cliente,
            nome=cliente.nome,
            sri=round(sri, 2),
            faixa_risco=faixa_risco,
            flags=flags,
            detalhamento={
                "sisbacen_score": sisbacen_score,
                "pagamento_score": pagamento_score,
                "comprometimento_score": comprometimento_score,
                "tempo_score": tempo_score,
                "movimentacao_score": movimentacao_score,
            },
            recomendacao_agente1=recomendacao,
        )

    def _score_sisbacen(self, ranking: str) -> float:
        mapping = {"A+": 100, "A": 80, "B": 60, "C": 40, "D": 20, "E": 0}
        return float(mapping.get(ranking, 0))

    def _score_pagamento(self, houve_atraso: bool, dias_max: int) -> float:
        if not houve_atraso:
            return 100.0
        if dias_max <= 15:
            return 70.0
        if dias_max <= 30:
            return 50.0
        if dias_max <= 60:
            return 30.0
        return 10.0

    def _score_comprometimento(self, qtd_emprestimos: int, renda: float) -> float:
        comprometimento_pct = (qtd_emprestimos * 0.15)
        if comprometimento_pct < 0.30:
            return 100.0
        if comprometimento_pct < 0.50:
            return 60.0
        return 20.0

    def _score_tempo(self, anos: float) -> float:
        if anos >= 10:
            return 100.0
        if anos >= 5:
            return 70.0
        if anos >= 2:
            return 50.0
        if anos >= 1:
            return 30.0
        return 10.0

    def _score_movimentacao(self, movimentacao: float, renda: float) -> float:
        if renda == 0:
            return 0.0
        ratio = movimentacao / renda
        if ratio >= 1.5:
            return 100.0
        if ratio >= 1.0:
            return 70.0
        if ratio >= 0.5:
            return 40.0
        return 10.0

    def _classificar_faixa(self, sri: float) -> str:
        if sri >= 80:
            return "BAIXO RISCO"
        if sri >= 60:
            return "RISCO MODERADO"
        if sri >= 40:
            return "RISCO ELEVADO"
        return "ALTO RISCO"

    def _detectar_flags(self, cliente: Cliente) -> list:
        flags = []
        if cliente.dias_atraso_max > 60:
            flags.append("FLAG_ATRASO_GRAVE")
        if cliente.qtd_emprestimos_ativos >= 4:
            flags.append("FLAG_SUPERENDIVIDAMENTO")
        if "crítico" in cliente.comportamento_consumo.lower():
            flags.append("FLAG_CONSUMO_CRITICO")
        if cliente.ranking_sisbacen in ("D", "E"):
            flags.append("FLAG_RESTRICAO_BUREAU")
        return flags

    def _recomendar(self, sri: float, flags: list) -> str:
        if not flags and sri >= 80:
            return "Cliente com excelente perfil. Recomendar produtos premium."
        if sri >= 60:
            return "Perfil adequado para produtos padrão. Atentar para flags ativas."
        if sri >= 40:
            return "Aprovar apenas produtos de baixo risco com limites conservadores."
        return "Perfil de alto risco. Recomendar recusa ou microcrédito com garantia."


# ─────────────────────────────────────────────
# AGENT 2 — PRODUCT MATCHER AGENT
# ─────────────────────────────────────────────

class ProductMatcherAgent:
    """
    Mapeia produtos elegíveis com base no SRI e perfil do cliente.
    Não cria produtos nem altera regras — apenas aplica critérios da base.
    """

    RANKING_HIERARCHY = {"A+": 6, "A": 5, "B": 4, "C": 3, "D": 2, "E": 1}

    def processar(
        self,
        cliente: Cliente,
        relatorio_risco: RelatorioRisco,
        produtos: list[Produto],
        produto_solicitado: Optional[str] = None,
    ) -> ResultadoProdutos:

        resultado = ResultadoProdutos()

        for produto in produtos:
            elegivel, motivo = self._verificar_elegibilidade(cliente, relatorio_risco, produto)
            if elegivel:
                limite = self._calcular_limite(cliente, relatorio_risco, produto)
                taxa = self._calcular_taxa(relatorio_risco, produto)
                motivo_aprov = self._motivo_aprovacao(cliente, relatorio_risco, produto)
                resultado.produtos_aprovados.append(
                    ProdutoAprovado(
                        id_produto=produto.id_produto,
                        nome_produto=produto.nome_produto,
                        limite_aprovado=round(limite, 2),
                        taxa_aplicada=round(taxa, 2),
                        motivo_aprovacao=motivo_aprov,
                    )
                )
            else:
                resultado.produtos_recusados.append(
                    ProdutoRecusado(
                        id_produto=produto.id_produto,
                        nome_produto=produto.nome_produto,
                        motivo_recusa=motivo,
                    )
                )

        # Priorizar produto solicitado
        if produto_solicitado:
            resultado.produtos_aprovados.sort(
                key=lambda p: (0 if produto_solicitado.lower() in p.nome_produto.lower() else 1, p.taxa_aplicada)
            )

        return resultado

    def _ranking_valor(self, ranking: str) -> int:
        return self.RANKING_HIERARCHY.get(ranking, 0)

    def _verificar_elegibilidade(self, cliente: Cliente, risco: RelatorioRisco, produto: Produto):
        if cliente.renda_mensal < produto.renda_minima:
            return False, f"Renda mensal insuficiente (mín: R$ {produto.renda_minima:,.2f})"
        if cliente.tempo_banco_anos < produto.tempo_banco_minimo_anos:
            return False, f"Tempo de relacionamento insuficiente (mín: {produto.tempo_banco_minimo_anos} anos)"
        if self._ranking_valor(cliente.ranking_sisbacen) < self._ranking_valor(produto.ranking_sisbacen_minimo):
            return False, f"Ranking SISBACEN abaixo do mínimo exigido ({produto.ranking_sisbacen_minimo})"
        if risco.sri < produto.score_interno_minimo:
            return False, f"Score de risco interno insuficiente (mín: {produto.score_interno_minimo}, obtido: {risco.sri})"
        if risco.faixa_risco == "ALTO RISCO" and produto.grau_risco == "Muito Alto":
            return False, "Produto de risco muito alto indisponível para perfil de alto risco"
        return True, ""

    def _calcular_limite(self, cliente: Cliente, risco: RelatorioRisco, produto: Produto) -> float:
        limite_calculado = (cliente.renda_mensal * 3) * (risco.sri / 100)
        return min(produto.limite_maximo, max(produto.limite_minimo, limite_calculado))

    def _calcular_taxa(self, risco: RelatorioRisco, produto: Produto) -> float:
        # Quanto menor o SRI, mais próxima da taxa máxima
        fator = 1 - (risco.sri / 100)
        taxa = produto.taxa_juros_mensal_min + (produto.taxa_juros_mensal_max - produto.taxa_juros_mensal_min) * fator
        return taxa

    def _motivo_aprovacao(self, cliente: Cliente, risco: RelatorioRisco, produto: Produto) -> str:
        return (
            f"Cliente elegível: SISBACEN {cliente.ranking_sisbacen}, "
            f"SRI {risco.sri} (mín {produto.score_interno_minimo}), "
            f"renda R$ {cliente.renda_mensal:,.2f} (mín R$ {produto.renda_minima:,.2f})"
        )


# ─────────────────────────────────────────────
# ORCHESTRATOR — CREDIT ORCHESTRATOR AGENT
# ─────────────────────────────────────────────

class CreditOrchestratorAgent:
    """
    Coordena RiskAnalystAgent e ProductMatcherAgent, consolida a decisão
    e gera a justificativa oficial ao cliente em linguagem humanizada.
    """

    def __init__(self, produtos: list[Produto]):
        self.risk_agent = RiskAnalystAgent()
        self.product_agent = ProductMatcherAgent()
        self.produtos = produtos

    def processar_solicitacao(
        self,
        cliente: Cliente,
        produto_solicitado: Optional[str] = None,
    ) -> DecisaoFinal:

        # Passo 1: Análise de risco
        relatorio_risco = self.risk_agent.analisar(cliente)

        # Passo 2: Match de produtos
        resultado_produtos = self.product_agent.processar(
            cliente, relatorio_risco, self.produtos, produto_solicitado
        )

        # Passo 3: Aplicar regras de consolidação do orquestrador
        aprovados, alternativos = self._consolidar_decisao(relatorio_risco, resultado_produtos)

        # Passo 4: Determinar decisão final
        produto_sol_aprovado = any(
            produto_solicitado and produto_solicitado.lower() in p.nome_produto.lower()
            for p in aprovados
        ) if produto_solicitado else bool(aprovados)

        if produto_solicitado:
            if produto_sol_aprovado:
                decisao = "APROVADO"
            elif aprovados:
                decisao = "APROVADO_PARCIAL"
            else:
                decisao = "RECUSADO"
        else:
            decisao = "APROVADO" if aprovados else "RECUSADO"

        # Passo 5: Gerar justificativa ao cliente
        justificativa = self._gerar_justificativa(
            cliente, relatorio_risco, decisao, produto_solicitado, aprovados, alternativos
        )

        # Passo 6: Gerar recomendações
        recomendacoes = self._gerar_recomendacoes(relatorio_risco, decisao)

        # Passo 7: Sugerir próxima revisão
        proxima_revisao = self._sugerir_revisao(relatorio_risco, decisao)

        return DecisaoFinal(
            id_solicitacao=str(uuid.uuid4())[:8].upper(),
            id_cliente=cliente.id_cliente,
            data_analise=date.today().isoformat(),
            decisao_final=decisao,
            produto_solicitado=produto_solicitado or "Não especificado",
            produtos_aprovados=[vars(p) for p in aprovados],
            produtos_alternativos=[vars(p) for p in alternativos],
            sri=relatorio_risco.sri,
            faixa_risco=relatorio_risco.faixa_risco,
            flags_ativos=relatorio_risco.flags,
            justificativa_cliente=justificativa,
            recomendacoes_cliente=recomendacoes,
            proxima_revisao_sugerida=proxima_revisao,
        )

    def _consolidar_decisao(self, risco: RelatorioRisco, resultado: ResultadoProdutos):
        aprovados = list(resultado.produtos_aprovados)
        flags = risco.flags

        # FLAG_RESTRICAO_BUREAU: bloquear produtos de risco não-baixo
        if "FLAG_RESTRICAO_BUREAU" in flags:
            aprovados = [p for p in aprovados if self._grau_risco_produto(p) == "Baixo"]

        # FLAG_SUPERENDIVIDAMENTO: limitar a 1 produto
        if "FLAG_SUPERENDIVIDAMENTO" in flags:
            aprovados = aprovados[:1]

        # FLAG_ATRASO_GRAVE + FLAG_CONSUMO_CRITICO: bloquear tudo
        if "FLAG_ATRASO_GRAVE" in flags and "FLAG_CONSUMO_CRITICO" in flags:
            aprovados = []

        # Produtos alternativos: aprovados que não são o produto solicitado
        alternativos = [p for p in aprovados if p not in aprovados[:1]] if len(aprovados) > 1 else []

        return aprovados, alternativos

    def _grau_risco_produto(self, produto_aprovado: ProdutoAprovado) -> str:
        for p in self.produtos:
            if p.id_produto == produto_aprovado.id_produto:
                return p.grau_risco
        return "Médio"

    def _gerar_justificativa(
        self,
        cliente: Cliente,
        risco: RelatorioRisco,
        decisao: str,
        produto_solicitado: Optional[str],
        aprovados: list,
        alternativos: list,
    ) -> str:
        nome = cliente.nome.split()[0]  # primeiro nome

        if decisao == "APROVADO":
            prod = aprovados[0]
            return (
                f"Prezado(a) {nome}, temos o prazer de informar que seu pedido de "
                f"{prod.nome_produto} foi APROVADO. Seu histórico conosco e sua "
                f"movimentação financeira demonstram solidez e responsabilidade. "
                f"O limite aprovado é de R$ {prod.limite_aprovado:,.2f} com taxa de "
                f"{prod.taxa_aplicada:.2f}% ao mês. Em breve você receberá as instruções "
                f"para ativação do seu produto."
            )

        if decisao == "APROVADO_PARCIAL":
            prod_alt = aprovados[0] if aprovados else None
            motivos = self._extrair_motivos_recusa(risco)
            alt_texto = (
                f"Identificamos que você possui perfil elegível para {prod_alt.nome_produto} "
                f"com limite de R$ {prod_alt.limite_aprovado:,.2f}."
                if prod_alt else "No momento não há produtos alternativos disponíveis."
            )
            return (
                f"Prezado(a) {nome}, analisamos seu pedido de {produto_solicitado}. "
                f"Não foi possível aprovar este produto no momento. {alt_texto} "
                f"O fator principal que impactou esta análise foi: {motivos[0] if motivos else 'histórico de crédito'}. "
                f"Continue mantendo seus pagamentos em dia para ampliar suas opções de crédito."
            )

        # RECUSADO
        motivos = self._extrair_motivos_recusa(risco)
        motivos_texto = "; ".join(motivos[:3]) if motivos else "perfil de risco elevado no momento"
        return (
            f"Prezado(a) {nome}, após análise cuidadosa do seu perfil, não foi possível "
            f"aprovar seu pedido de crédito neste momento. Os principais fatores que "
            f"influenciaram esta decisão foram: {motivos_texto}. "
            f"Recomendamos regularizar eventuais pendências e manter um histórico de "
            f"pagamentos positivo para que possamos reavaliar sua solicitação em breve."
        )

    def _extrair_motivos_recusa(self, risco: RelatorioRisco) -> list:
        motivos = []
        flags_map = {
            "FLAG_ATRASO_GRAVE": "histórico de atrasos significativos nos últimos meses",
            "FLAG_SUPERENDIVIDAMENTO": "elevado número de compromissos de crédito em aberto",
            "FLAG_CONSUMO_CRITICO": "padrão de consumo financeiro que requer atenção",
            "FLAG_RESTRICAO_BUREAU": "restrições identificadas no bureau de crédito",
        }
        for flag in risco.flags:
            if flag in flags_map:
                motivos.append(flags_map[flag])
        if risco.sri < 40 and not motivos:
            motivos.append("score de crédito abaixo do mínimo exigido para os produtos solicitados")
        return motivos

    def _gerar_recomendacoes(self, risco: RelatorioRisco, decisao: str) -> list:
        recs = []
        if "FLAG_ATRASO_GRAVE" in risco.flags:
            recs.append("Regularize as parcelas em atraso e mantenha pagamentos em dia por 6 meses.")
        if "FLAG_SUPERENDIVIDAMENTO" in risco.flags:
            recs.append("Reduza o número de compromissos de crédito ativos antes de solicitar novo crédito.")
        if "FLAG_RESTRICAO_BUREAU" in risco.flags:
            recs.append("Verifique e regularize pendências junto ao SISBACEN / bureaus de crédito.")
        if "FLAG_CONSUMO_CRITICO" in risco.flags:
            recs.append("Busque orientação financeira para reorganização do orçamento mensal.")
        if not recs:
            recs.append("Continue mantendo seu excelente histórico financeiro com o banco.")
        return recs

    def _sugerir_revisao(self, risco: RelatorioRisco, decisao: str) -> str:
        if decisao == "APROVADO":
            return "Não necessário — crédito aprovado."
        if risco.sri >= 60:
            return (date.today() + timedelta(days=90)).isoformat()
        if risco.sri >= 40:
            return (date.today() + timedelta(days=180)).isoformat()
        return (date.today() + timedelta(days=365)).isoformat()


# ─────────────────────────────────────────────
# MAIN — DEMONSTRATION
# ─────────────────────────────────────────────

def main():
    import os

    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    clientes = carregar_clientes(os.path.join(data_dir, "clientes.csv"))
    produtos = carregar_produtos(os.path.join(data_dir, "produtos_credito.csv"))

    orquestrador = CreditOrchestratorAgent(produtos)

    # Cenários de demonstração
    cenarios = [
        (clientes[0],  "Cartão de Crédito Platinum"),   # Ana — bom perfil
        (clientes[1],  "Empréstimo Pessoal Standard"),  # Bruno — risco médio/alto
        (clientes[4],  "Financiamento Imobiliário Standard"),  # Elaine — alto risco
        (clientes[2],  "Cartão de Crédito Black"),      # Carla — perfil premium
        (clientes[7],  "Empréstimo Pessoal Express"),   # Hugo — crítico
        (clientes[9],  "Limite Pré-aprovado Digital"),  # João — moderado
    ]

    resultados = []
    for cliente, produto_desejado in cenarios:
        decisao = orquestrador.processar_solicitacao(cliente, produto_desejado)
        resultados.append(decisao)

        print("=" * 70)
        print(f"SOLICITAÇÃO: {decisao.id_solicitacao}")
        print(f"Cliente    : {cliente.nome} (ID {cliente.id_cliente})")
        print(f"Produto    : {decisao.produto_solicitado}")
        print(f"SRI        : {decisao.sri} — {decisao.faixa_risco}")
        print(f"Flags      : {', '.join(decisao.flags_ativos) or 'nenhuma'}")
        print(f"Decisão    : {decisao.decisao_final}")
        print(f"\nJUSTIFICATIVA AO CLIENTE:")
        print(f"  {decisao.justificativa_cliente}")
        if decisao.recomendacoes_cliente:
            print(f"\nRECOMENDAÇÕES:")
            for r in decisao.recomendacoes_cliente:
                print(f"  • {r}")
        if decisao.produtos_aprovados:
            print(f"\nPRODUTOS APROVADOS:")
            for p in decisao.produtos_aprovados:
                print(f"  • {p['nome_produto']} | Limite: R$ {p['limite_aprovado']:,.2f} | Taxa: {p['taxa_aplicada']:.2f}%/mês")
        print(f"\nPróxima revisão sugerida: {decisao.proxima_revisao_sugerida}")

    # Exportar resultados para JSON
    output_path = os.path.join(base_dir, "resultados_pipeline.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(
            [vars(r) for r in resultados],
            f,
            ensure_ascii=False,
            indent=2,
        )
    print(f"\n✓ Resultados exportados para: {output_path}")


if __name__ == "__main__":
    main()
