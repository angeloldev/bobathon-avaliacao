# Pipeline de Concessão de Crédito Bancário

> **Banco Digital S.A. — Sistema Multi-Agente de Análise e Decisão de Crédito**  
> Versão 1.0 · Julho/2025 · Dados fictícios para fins de demonstração

---

## Sumário

1. [Visão Geral](#1-visão-geral)
2. [Arquitetura do Sistema](#2-arquitetura-do-sistema)
3. [Estrutura de Pastas](#3-estrutura-de-pastas)
4. [Bases de Dados](#4-bases-de-dados)
5. [Agentes — Comportamentos Detalhados](#5-agentes--comportamentos-detalhados)
6. [Fluxo de Execução](#6-fluxo-de-execução)
7. [Modelo de Score de Risco Interno (SRI)](#7-modelo-de-score-de-risco-interno-sri)
8. [Regras de Flags e Consolidação](#8-regras-de-flags-e-consolidação)
9. [Cálculo de Limites e Taxas](#9-cálculo-de-limites-e-taxas)
10. [Geração de Justificativas ao Cliente](#10-geração-de-justificativas-ao-cliente)
11. [Como Executar](#11-como-executar)
12. [Dependências](#12-dependências)
13. [Exemplos de Saída](#13-exemplos-de-saída)
14. [Decisões de Projeto](#14-decisões-de-projeto)
15. [Roadmap](#15-roadmap)

---

## 1. Visão Geral

Este projeto implementa um **pipeline de concessão de crédito bancário** baseado em **arquitetura multi-agente**, composto por:

| Componente | Papel |
|---|---|
| `RiskAnalystAgent` | Calcula o Score de Risco Interno (SRI) do cliente |
| `ProductMatcherAgent` | Mapeia produtos elegíveis com base no SRI e perfil |
| `CreditOrchestratorAgent` | Coordena os dois agentes e gera a decisão final com justificativa ao cliente |

O sistema processa clientes de uma base de dados, aplica regras de negócio bancário reais (SISBACEN, comprometimento de renda, histórico de pagamentos) e produz uma **decisão estruturada** — APROVADO, APROVADO_PARCIAL ou RECUSADO — com **justificativa em linguagem natural humanizada**, em conformidade com o Código de Defesa do Consumidor.

---

## 2. Arquitetura do Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                    CREDIT ORCHESTRATOR AGENT                    │
│  (Coordena · Consolida · Decide · Gera Justificativa)          │
└─────────────────┬───────────────────────┬───────────────────────┘
                  │                       │
      ┌───────────▼──────────┐  ┌────────▼────────────────┐
      │   RISK ANALYST       │  │   PRODUCT MATCHER        │
      │   AGENT              │  │   AGENT                  │
      │                      │  │                          │
      │  • Calcula SRI       │  │  • Filtra elegibilidade  │
      │  • Classifica risco  │  │  • Calcula limites       │
      │  • Detecta flags     │  │  • Calcula taxas         │
      │  • Gera relatório    │  │  • Prioriza produtos     │
      └───────────┬──────────┘  └────────┬────────────────┘
                  │                       │
      ┌───────────▼──────────┐  ┌────────▼────────────────┐
      │   clientes.csv       │  │  produtos_credito.csv    │
      └──────────────────────┘  └─────────────────────────┘
```

**Fluxo sequencial:**
1. Orquestrador recebe a solicitação (cliente + produto desejado)
2. Aciona o `RiskAnalystAgent` → recebe `RelatorioRisco`
3. Passa o relatório ao `ProductMatcherAgent` → recebe `ResultadoProdutos`
4. Aplica regras de consolidação (flags globais)
5. Determina a decisão final
6. Gera justificativa humanizada ao cliente
7. Exporta `DecisaoFinal` em JSON

---

## 3. Estrutura de Pastas

```
credit_pipeline/
├── README.md                    ← Este arquivo
├── pipeline.py                  ← Código principal do pipeline
├── gerar_pdfs.py                ← Gerador de PDFs das bases (requer reportlab)
├── resultados_pipeline.json     ← Saída gerada após execução
├── data/
│   ├── clientes.csv             ← Base de clientes (20 registros)
│   ├── produtos_credito.csv     ← Portfólio de produtos (20 produtos)
│   ├── clientes.pdf             ← Versão PDF da base de clientes
│   └── produtos_credito.pdf     ← Versão PDF do portfólio de produtos
└── agents/
    └── behaviors.md             ← Definição formal dos comportamentos dos agentes
```

---

## 4. Bases de Dados

### 4.1 Base de Clientes (`clientes.csv`)

| Campo | Tipo | Descrição |
|---|---|---|
| `id_cliente` | int | Identificador único |
| `nome` | string | Nome completo |
| `cpf` | string | CPF no formato 000.000.000-00 |
| `movimentacao_mensal_media` | float | Média de movimentação bancária mensal (R$) |
| `tempo_banco_anos` | float | Tempo de relacionamento com o banco (anos) |
| `renda_mensal` | float | Renda mensal declarada (R$) |
| `qtd_emprestimos_ativos` | int | Número de empréstimos/financiamentos em aberto |
| `houve_atraso` | string | "Sim" ou "Nao" — se houve atraso em algum pagamento |
| `dias_atraso_max` | int | Maior número de dias em atraso registrado |
| `valor_total_atraso` | float | Valor total das parcelas em atraso (R$) |
| `ranking_sisbacen` | string | Classificação no bureau: A+, A, B, C, D, E |
| `comportamento_consumo` | string | Descrição qualitativa do padrão de consumo |

**20 clientes** com perfis variados: premium (A+), regulares (A/B), irregulares (C), restritos (D/E).

### 4.2 Base de Produtos de Crédito (`produtos_credito.csv`)

| Campo | Tipo | Descrição |
|---|---|---|
| `id_produto` | int | Identificador único |
| `nome_produto` | string | Nome comercial do produto |
| `categoria` | string | Categoria do produto |
| `limite_minimo` | float | Menor valor concedível (R$) |
| `limite_maximo` | float | Maior valor concedível (R$) |
| `taxa_juros_mensal_min` | float | Taxa mínima para perfil excelente (%/mês) |
| `taxa_juros_mensal_max` | float | Taxa máxima para perfil de maior risco (%/mês) |
| `prazo_minimo_meses` | int | Prazo mínimo em meses (0 = sem prazo, ex.: cartão) |
| `prazo_maximo_meses` | int | Prazo máximo em meses |
| `grau_risco` | string | Baixo / Médio / Alto / Muito Alto |
| `ranking_sisbacen_minimo` | string | Ranking mínimo exigido do cliente |
| `renda_minima` | float | Renda mensal mínima exigida (R$) |
| `tempo_banco_minimo_anos` | float | Tempo mínimo de relacionamento exigido |
| `score_interno_minimo` | int | SRI mínimo exigido (0–100) |
| `descricao` | string | Descrição comercial do produto |

**20 produtos** cobrindo: Cartões (4), Empréstimos Pessoais (3), Consignado (2), Veicular (2), Imobiliário (2), Cheque Especial (1), Empresarial (2), Especializado (2), Reestruturação (1), Digital (1).

---

## 5. Agentes — Comportamentos Detalhados

> Documento completo em [`agents/behaviors.md`](agents/behaviors.md)

### 5.1 RiskAnalystAgent

**Responsabilidade única:** Analisar o perfil financeiro do cliente e produzir um **Score de Risco Interno (SRI)** entre 0 e 100.

- Não decide sobre concessão
- Detecta flags de alerta automáticas
- Produz relatório estruturado em JSON

### 5.2 ProductMatcherAgent

**Responsabilidade única:** Receber o `RelatorioRisco` e mapear quais produtos do portfólio o cliente é elegível.

- Aplica 5 critérios de elegibilidade em sequência
- Calcula limite personalizado por produto
- Calcula taxa individualizada pelo SRI
- Retorna listas de aprovados e recusados com motivos

### 5.3 CreditOrchestratorAgent

**Responsabilidade única:** Coordenar os dois agentes, consolidar a decisão com regras globais de flag e gerar a comunicação oficial ao cliente.

- Nunca analisa risco diretamente
- Aplica regras de negócio de nível executivo (superendividamento, bureau crítico)
- Gera justificativa em linguagem natural humanizada
- Sugere próxima data de revisão

---

## 6. Fluxo de Execução

```
Cliente solicita crédito (ID + produto desejado)
            │
            ▼
[RiskAnalystAgent]
  ├── Calcula SRI (5 critérios ponderados)
  ├── Classifica faixa de risco
  ├── Detecta flags ativas
  └── Retorna RelatorioRisco
            │
            ▼
[ProductMatcherAgent]
  ├── Recebe RelatorioRisco
  ├── Filtra produtos elegíveis (5 regras)
  ├── Calcula limite personalizado por produto
  ├── Calcula taxa baseada no SRI
  └── Retorna ResultadoProdutos {aprovados, recusados}
            │
            ▼
[CreditOrchestratorAgent]
  ├── Aplica regras de consolidação de flags
  ├── Determina: APROVADO | APROVADO_PARCIAL | RECUSADO
  ├── Seleciona produtos alternativos (se aplicável)
  ├── Gera justificativa humanizada ao cliente
  ├── Gera recomendações de melhoria
  └── Retorna DecisaoFinal (JSON)
```

---

## 7. Modelo de Score de Risco Interno (SRI)

O SRI é calculado como média ponderada de 5 dimensões:

| Dimensão | Peso | Escala de pontuação |
|---|---|---|
| **Ranking SISBACEN** | 30% | A+=100, A=80, B=60, C=40, D=20, E=0 |
| **Histórico de pagamento** | 25% | Sem atraso=100; ≤15d=70; ≤30d=50; ≤60d=30; >60d=10 |
| **Comprometimento de renda** | 20% | <30% comprometido=100; <50%=60; ≥50%=20 |
| **Tempo de relacionamento** | 15% | ≥10a=100; ≥5a=70; ≥2a=50; ≥1a=30; <1a=10 |
| **Movimentação relativa** | 10% | Mov/Renda: ≥1.5=100; ≥1.0=70; ≥0.5=40; <0.5=10 |

**Faixas de risco:**

| SRI | Classificação |
|---|---|
| ≥ 80 | BAIXO RISCO — cliente premium |
| 60–79 | RISCO MODERADO — análise padrão |
| 40–59 | RISCO ELEVADO — restrições aplicáveis |
| < 40 | ALTO RISCO — crédito muito limitado ou negado |

---

## 8. Regras de Flags e Consolidação

### Flags detectadas pelo RiskAnalystAgent

| Flag | Critério de ativação |
|---|---|
| `FLAG_ATRASO_GRAVE` | `dias_atraso_max > 60` |
| `FLAG_SUPERENDIVIDAMENTO` | `qtd_emprestimos_ativos >= 4` |
| `FLAG_CONSUMO_CRITICO` | Comportamento contém "crítico" |
| `FLAG_RESTRICAO_BUREAU` | Ranking SISBACEN = D ou E |

### Regras de consolidação do Orquestrador

| Combinação de flags | Ação |
|---|---|
| `FLAG_RESTRICAO_BUREAU` | Bloquear todos os produtos com `grau_risco != "Baixo"` |
| `FLAG_SUPERENDIVIDAMENTO` | Limitar a no máximo 1 produto aprovado |
| `FLAG_ATRASO_GRAVE` + `FLAG_CONSUMO_CRITICO` | Recusar todos os produtos |

---

## 9. Cálculo de Limites e Taxas

### Limite personalizado

```python
limite = min(
    limite_maximo_produto,
    max(limite_minimo_produto, (renda_mensal * 3) * (SRI / 100))
)
```

### Taxa personalizada

```python
fator = 1 - (SRI / 100)
taxa = taxa_min + (taxa_max - taxa_min) * fator
```

> Quanto maior o SRI (menor risco), mais próximo da taxa mínima.  
> Quanto menor o SRI (maior risco), mais próximo da taxa máxima.

---

## 10. Geração de Justificativas ao Cliente

O orquestrador gera 3 modelos de justificativa:

### Aprovação Total
> "Prezado(a) [Nome], temos o prazer de informar que seu pedido de [produto] foi APROVADO. Seu histórico conosco e sua movimentação financeira demonstram solidez e responsabilidade. O limite aprovado é de R$ [valor] com taxa de [x]% ao mês..."

### Aprovação Parcial (produto alternativo)
> "Prezado(a) [Nome], analisamos seu pedido de [produto solicitado]. Não foi possível aprovar este produto no momento. Identificamos que você possui perfil elegível para [produto alternativo] com limite de R$ [valor]..."

### Recusa Total
> "Prezado(a) [Nome], após análise cuidadosa do seu perfil, não foi possível aprovar seu pedido de crédito neste momento. Os principais fatores que influenciaram esta decisão foram: [lista de motivos]. Recomendamos [ações corretivas]..."

**Regras de comunicação:**
- Linguagem empática, objetiva, em conformidade com o CDC
- Nunca expor scores internos, fórmulas ou dados de bureau ao cliente
- Sempre sugerir próximo passo ou ação corretiva
- Sempre informar prazo sugerido para reavaliação

---

## 11. Como Executar

### Pré-requisitos

```bash
Python 3.11+
pip install reportlab  # apenas para geração de PDFs
```

### Executar o pipeline

```bash
cd credit_pipeline
python pipeline.py
```

A saída será impressa no terminal e exportada para `resultados_pipeline.json`.

### Gerar PDFs das bases

```bash
python gerar_pdfs.py
# Gera: data/clientes.pdf e data/produtos_credito.pdf
```

### Processar um cliente específico

```python
from pipeline import carregar_clientes, carregar_produtos, CreditOrchestratorAgent

clientes = carregar_clientes("data/clientes.csv")
produtos  = carregar_produtos("data/produtos_credito.csv")

orquestrador = CreditOrchestratorAgent(produtos)

# Processar cliente de ID 1 pedindo Cartão Platinum
decisao = orquestrador.processar_solicitacao(clientes[0], "Cartão de Crédito Platinum")

print(decisao.decisao_final)
print(decisao.justificativa_cliente)
```

---

## 12. Dependências

| Biblioteca | Uso | Obrigatoriedade |
|---|---|---|
| `csv` (stdlib) | Leitura das bases de dados | Obrigatória |
| `json` (stdlib) | Exportação de resultados | Obrigatória |
| `uuid` (stdlib) | Geração de IDs de solicitação | Obrigatória |
| `datetime` (stdlib) | Datas de análise e revisão | Obrigatória |
| `dataclasses` (stdlib) | Modelos de dados | Obrigatória |
| `reportlab` | Geração de PDFs | Opcional (apenas `gerar_pdfs.py`) |

---

## 13. Exemplos de Saída

### Cliente 1 — Ana Carolina Ferreira (perfil A, RISCO MODERADO)
```
Decisão    : APROVADO
SRI        : 71.5 — RISCO MODERADO
Produto    : Cartão de Crédito Platinum
Limite     : R$ 18.600,00
Taxa       : 1,77%/mês
Justificativa: "Prezado(a) Ana, temos o prazer de informar que seu pedido de
Cartão de Crédito Platinum foi APROVADO..."
```

### Cliente 5 — Elaine Costa Barbosa (perfil D, ALTO RISCO)
```
Decisão    : RECUSADO
SRI        : 18.0 — ALTO RISCO
Flags      : FLAG_ATRASO_GRAVE, FLAG_RESTRICAO_BUREAU, FLAG_CONSUMO_CRITICO
Justificativa: "Prezado(a) Elaine, após análise cuidadosa do seu perfil,
não foi possível aprovar... restrições identificadas no bureau de crédito;
histórico de atrasos significativos..."
```

### Cliente 10 — João Pedro Vieira (perfil B, RISCO MODERADO)
```
Decisão    : APROVADO
SRI        : 64.0 — RISCO MODERADO
Produto    : Limite Pré-aprovado Digital
Limite     : R$ 11.520,00
Taxa       : 4,29%/mês
```

---

## 14. Decisões de Projeto

| Decisão | Justificativa |
|---|---|
| **Separação clara entre agentes** | Cada agente tem responsabilidade única (SRP). O orquestrador não analisa risco nem valida produtos. |
| **SRI como número único** | Facilita comparação com `score_interno_minimo` dos produtos sem lógica condicional complexa. |
| **Flags como lista de strings** | Permite que o orquestrador aplique regras compostas de forma declarativa. |
| **Limite e taxa personalizados por produto** | Reflete a prática bancária real de precificação baseada em risco individual. |
| **Justificativa sem scores internos** | Conformidade com LGPD e CDC — o cliente tem direito a informação clara, não a dados de modelos internos. |
| **Sem framework de IA externo** | O pipeline é puro Python para máxima portabilidade. Pode ser integrado a LangChain, CrewAI ou IBM watsonx via adaptadores. |

---

## 15. Roadmap

- [ ] Integração com API REST (FastAPI)
- [ ] Interface web de simulação de crédito
- [ ] Integração com IBM watsonx.ai para análise de linguagem natural das justificativas
- [ ] Módulo de backtesting com base histórica de aprovações
- [ ] Suporte a PJ (Pessoa Jurídica) com critérios específicos
- [ ] Logging estruturado com auditoria de decisões (trail para compliance)
- [ ] Testes unitários e de integração (pytest)
- [ ] Docker + CI/CD pipeline

---

*Banco Digital S.A. — Pipeline de Crédito v1.0 · Documento confidencial para uso interno.*  
*Todos os dados de clientes e produtos são fictícios, gerados exclusivamente para fins de demonstração.*
