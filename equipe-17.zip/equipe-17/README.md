# Sistema de Concessao de Credito — Equipe-17

> **Bobathon** | IBM watsonx Orchestrate + IBM Bob

---

## Identificacao da Equipe

| | |
|---|---|
| **Equipe** | Equipe-17 |
| **Componentes** | Wendel, Yuri, Thiago, Diogo, Walmor e Wanessa |
| **Projeto** | Sistema multiagente de concessao de credito |
| **Plataforma** | IBM watsonx Orchestrate (ADK v2.16.1) |
| **Assistente de desenvolvimento** | IBM Bob |

---

## Sobre o Projeto

Este projeto implementa um **sistema multiagente de concessao de credito** no IBM watsonx Orchestrate.
O sistema analisa solicitacoes de credito de clientes, verifica restricoes, avalia renda e
movimentacao, seleciona o produto de credito adequado e calcula o limite a ser concedido —
tudo orquestrado por uma equipe de 5 agentes especializados.

---

## Arquitetura da Solucao

```mermaid
graph TD
    Operador[Operador] -->|"Solicita credito para [cliente]"| AP[agente_avaliador_pedido]
    AP -->|Encaminha pedido| OR[agente_orquestrador_credito]
    OR -->|Consulta perfil| PC[agente_perfil_cliente]
    PC -->|Consulta| KB1[(kb_clientes_credito)]
    PC -->|Parecer| OR
    OR -->|"Se sem restricao: consulta produtos"| PR[agente_produtos_credito]
    PR -->|Consulta| KB2[(kb_produtos_credito)]
    PR -->|Produto + Limite| OR
    OR -->|Dados consolidados| DC[agente_decisao_concessao]
    DC -->|Decisao + Justificativa| OR
    OR -->|Resultado consolidado| AP
    AP -->|"Resultado final ao operador"| Operador

    style AP fill:#4A90E2,stroke:#2E5C8A,color:#fff
    style OR fill:#7C3AED,stroke:#5B21B6,color:#fff
    style PC fill:#059669,stroke:#065F46,color:#fff
    style PR fill:#D97706,stroke:#92400E,color:#fff
    style DC fill:#DC2626,stroke:#991B1B,color:#fff
    style KB1 fill:#F3F4F6,stroke:#6B7280,color:#111
    style KB2 fill:#F3F4F6,stroke:#6B7280,color:#111
```

---

## Fluxo de Decisao

```mermaid
flowchart TD
    Start([PEDIDO RECEBIDO]) --> AP[Avaliador de Pedido\nrecepciona e encaminha]
    AP --> OR[Orquestrador\ncoordena o fluxo]
    OR --> PC[Analista de Perfil\nconsulta kb_clientes_credito]
    PC --> Restricao{Restricao\nativa?}
    Restricao -->|Sim| NEG1[Encaminha para\nDecisao - NEGADO]
    Restricao -->|Nao| PR[Especialista em Produtos\nconsulta kb_produtos_credito]
    Restricao -->|Cliente nao encontrado| NEG2[Encaminha para\nDecisao - NEGADO]
    PR --> Calculo[Calcula limite:\nmax(3x renda, 2x movimentacao)\n+ 20% se >= 2 anos de relacionamento]
    Calculo --> Enquadra[Enquadra na faixa\ndo produto selecionado]
    Enquadra --> DC[Decisor de Concessao\nemite decisao final]
    NEG1 --> DC
    NEG2 --> DC
    DC --> Resultado([RESULTADO CONSOLIDADO\nAO OPERADOR])

    style Start fill:#2ECC71,stroke:#27AE60,color:#fff
    style Resultado fill:#3B82F6,stroke:#1D4ED8,color:#fff
    style NEG1 fill:#EF4444,stroke:#B91C1C,color:#fff
    style NEG2 fill:#EF4444,stroke:#B91C1C,color:#fff
    style Restricao fill:#F59E0B,stroke:#D97706,color:#fff
```

---

## Agentes

| Agente | Funcao | Visivel no Chat | Knowledge Bases |
|---|---|---|---|
| `agente_avaliador_pedido` | Ponto de entrada; recepciona e apresenta resultado | **Sim** | - |
| `agente_orquestrador_credito` | Coordena o fluxo e aciona os especializados | Nao (hidden) | - |
| `agente_perfil_cliente` | Verifica restricoes, renda e movimentacao | Nao (hidden) | `kb_clientes_credito` |
| `agente_produtos_credito` | Seleciona produto e calcula limite | Nao (hidden) | `kb_produtos_credito` |
| `agente_decisao_concessao` | Emite a decisao final com justificativa | Nao (hidden) | - |

---

## Bases de Conhecimento

### Base 1 — `kb_clientes_credito`

**Arquivo:** `knowledge-bases/docs/base_clientes_credito.pdf`

Contem 210 clientes ficticios com:
- ID unico (CLI-001 a CLI-210)
- Nome completo
- Renda mensal bruta (R$)
- Descricao da movimentacao financeira
- Restricao ativa no Serasa/Sisbacen (Sim / Nao)
- Tempo de relacionamento com a instituicao

Regras embutidas no PDF:
- Restricao = Sim → NEGADO imediatamente
- Limite = max(3x renda, 2x movimentacao)
- Bonus de +20% para relacionamento >= 2 anos

### Base 2 — `kb_produtos_credito`

**Arquivo:** `knowledge-bases/docs/base_produtos_credito.pdf`

Contem 8 produtos de credito com faixas de limite:

| Produto | Limite Minimo | Limite Maximo |
|---|---|---|
| Cartao de Credito Basico | R$ 500 | R$ 3.000 |
| Cartao de Credito Intermediario | R$ 3.001 | R$ 12.000 |
| Cartao de Credito Premium | R$ 12.001 | R$ 50.000 |
| Emprestimo Pessoal Basico | R$ 1.000 | R$ 10.000 |
| Emprestimo Pessoal Avancado | R$ 10.001 | R$ 80.000 |
| Credito Consignado | R$ 1.000 | R$ 100.000 |
| Cheque Especial | R$ 200 | R$ 8.000 |
| Credito Imobiliario | R$ 80.000 | R$ 1.500.000 |

---

## Logica de Concessao

### Negativa imediata

```
Se Restricao (Serasa/Sisbacen) = Sim → NEGADO
Produto: N/A | Limite: N/A
```

### Calculo do limite (apenas para clientes sem restricao)

```
Criterio A = 3 x renda mensal bruta
Criterio B = 2 x media mensal de movimentacao
Limite base = max(Criterio A, Criterio B)

Se tempo de relacionamento >= 2 anos:
    Limite final = Limite base x 1.20  (bonus de +20%)
Senao:
    Limite final = Limite base

Limite final deve estar dentro da faixa do produto selecionado:
    Se > maximo da faixa → usar maximo
    Se < minimo da faixa → usar minimo
```

### Selecao do produto

O produto e selecionado com base na renda do cliente e no limite calculado,
consultando a matriz de produtos x perfil na base `kb_produtos_credito`.

---

## Estrutura de Arquivos

```
equipe-17/
├── agents/
│   ├── BEHAVIOR_avaliador_pedido.md       # Behavior: avaliador
│   ├── BEHAVIOR_perfil_cliente.md         # Behavior: analista de perfil
│   ├── BEHAVIOR_produtos_credito.md       # Behavior: especialista em produtos
│   ├── BEHAVIOR_orquestrador.md           # Behavior: orquestrador
│   ├── BEHAVIOR_decisao_concessao.md      # Behavior: decisor de concessao
│   ├── agente_avaliador_pedido.yaml       # YAML do agente avaliador
│   ├── agente_perfil_cliente.yaml         # YAML do agente de perfil
│   ├── agente_produtos_credito.yaml       # YAML do agente de produtos
│   ├── agente_decisao_concessao.yaml      # YAML do agente decisor
│   └── agente_orquestrador_credito.yaml   # YAML do orquestrador
├── knowledge-bases/
│   ├── docs/
│   │   ├── base_clientes_credito.pdf      # PDF: 210 clientes com dados de credito
│   │   └── base_produtos_credito.pdf      # PDF: produtos de credito e faixas
│   ├── kb_clientes_credito.yaml           # KB spec: base de clientes
│   └── kb_produtos_credito.yaml           # KB spec: base de produtos
├── evidencias/                            # Exportacoes e logs (gerado por export-evidencias.sh)
├── generate_pdfs.py                       # Script gerador dos PDFs
├── import-all.sh                          # Importa todos os assets
├── export-evidencias.sh                   # Exporta agentes e gera logs
└── README.md                              # Este arquivo
```

---

## Como Usar o IBM Bob para Desenvolvimento

O **IBM Bob** foi utilizado como assistente de desenvolvimento neste projeto. Veja como replicar:

### 1. Abrir o workspace no Bob

```
Workspace: /equipe-17/
Bob Mode: Agent
```

### 2. Comandos uteis no Bob

**Listar agentes no Orchestrate:**
Use a ferramenta `list_agents` via MCP do Orchestrate.

**Importar um agente:**
Use `import_agent` ou `create_or_update_agent` diretamente no Bob.

**Checar versao do ADK:**
Use `check_version` — retorna a versao do MCP server ativo.

**Conversar com um agente:**
Use `chat_with_agent` para testar sem sair do Bob.

### 3. Boas praticas seguidas neste projeto

- Behaviors documentados em markdown antes de criar os YAMLs
- Agentes especializados com `config.hidden: true` para nao poluir o chat
- Ponto de entrada unico (`agente_avaliador_pedido`) visivel ao usuario
- Knowledge bases com `ibm/slate-125m-english-rtrvr-v2` para embeddings
- Instrucoes em texto simples (sem acentos) para compatibilidade maxima
- Logica de concessao documentada nos PDFs E nas instrucoes dos agentes
- Resposta padrao para incerteza: "Nao tenho informacoes suficientes..."

---

## Passo a Passo para Executar

### 1. Ativar o ambiente

```bash
./venv/bin/orchestrate env activate ap-southeast-1-68ff61c8
# Informe sua API Key quando solicitado
```

### 2. Importar os assets

```bash
./equipe-17/import-all.sh
```

Aguarde a indexacao das knowledge bases (2 a 5 minutos apos o import).

### 3. Testar via chat

```bash
./venv/bin/orchestrate chat start
# Selecione: agente_avaliador_pedido
```

**Exemplos de teste:**
```
Solicite credito para Ana Silva.
Quero analisar o limite de cartao para Bruno Santos.
Avalie o pedido de emprestimo para Carlos Oliveira.
```

### 4. Exportar evidencias

```bash
./equipe-17/export-evidencias.sh
# Gera ZIPs dos agentes e log em evidencias/
```

---

## Exemplos de Resultado Esperado

### Cliente sem restricao (aprovado)

```
## Resultado da Analise de Credito

Cliente: Ana Clara Ferreira (CLI-001)
Decisao: APROVADO

Criterio de concessao:
Sem restricao ativa. Renda mensal: R$ 5.000,00. Movimentacao media: R$ 12.000,00.
Criterio B (movimentacao) foi mais vantajoso: 2x R$ 12.000 = R$ 24.000,00.
Bonus de +20% aplicado (relacionamento de 5 anos): R$ 28.800,00.
Enquadrado no Cartao de Credito Intermediario, Faixa 2 (max: R$ 12.000).
Limite ajustado ao maximo da faixa.

Produto concedido: Cartao de Credito Intermediario
Limite atribuido: R$ 12.000,00
Faixa do produto: Faixa 2
```

### Cliente com restricao (negado)

```
## Resultado da Analise de Credito

Cliente: Daniel Torres Lima (CLI-004)
Decisao: NEGADO

Criterio de concessao:
Restricao ativa identificada no Serasa/Sisbacen. A politica da instituicao
nao permite concessao de credito para clientes com restricao ativa.

Produto concedido: Nao aplicavel
Limite atribuido: Nao aplicavel

Justificativa completa:
O cliente possui restricao ativa em orgaos de protecao ao credito (Serasa/Sisbacen).
Para regularizar sua situacao, o cliente deve quitar os debitos pendentes junto
aos credores e solicitar a baixa da restricao. Apos a regularizacao, uma nova
analise pode ser solicitada.
```

---

## Evidencias

A subpasta `evidencias/` contem:
- Exportacoes ZIP dos agentes (geradas por `export-evidencias.sh`)
- Logs de execucao com timestamp
- Registros de listagem de agentes e knowledge bases no ambiente

Para gerar novas evidencias apos o import:
```bash
./equipe-17/export-evidencias.sh
```
