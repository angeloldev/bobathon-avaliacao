"""
Gera os dois PDFs de base de conhecimento para o sistema de concessao de credito.

Uso: ./venv/bin/python equipe-17/generate_pdfs.py
"""

import random
from fpdf import FPDF
from pathlib import Path

random.seed(42)

OUT_DIR = Path(__file__).parent / "knowledge-bases" / "docs"
OUT_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Helpers PDF
# ---------------------------------------------------------------------------

def _safe(text: str) -> str:
    table = {
        "\u2014": "-", "\u2013": "-", "\u2019": "'", "\u2018": "'",
        "\u201c": '"', "\u201d": '"', "\u2022": "*", "\u00e7": "c",
        "\u00e3": "a", "\u00e2": "a", "\u00e1": "a", "\u00e0": "a",
        "\u00ea": "e", "\u00e9": "e", "\u00ea": "e",
        "\u00ed": "i", "\u00f3": "o", "\u00f4": "o", "\u00f5": "o",
        "\u00fa": "u", "\u00fc": "u", "\u00f1": "n",
        "\u00c7": "C", "\u00c3": "A", "\u00c2": "A", "\u00c1": "A",
        "\u00ca": "E", "\u00c9": "E", "\u00cd": "I", "\u00d3": "O",
        "\u00d4": "O", "\u00d5": "O", "\u00da": "U",
        "\u00b0": " graus", "\u00aa": "a", "\u00ba": "o",
    }
    for orig, rep in table.items():
        text = text.replace(orig, rep)
    return text


def make_pdf() -> FPDF:
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_margins(15, 15, 15)
    pdf.add_page()
    return pdf


def h1(pdf: FPDF, text: str):
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(10, 40, 100)
    pdf.multi_cell(0, 10, _safe(text), align="C")
    pdf.set_draw_color(10, 40, 100)
    pdf.set_line_width(0.6)
    pdf.line(15, pdf.get_y() + 2, 195, pdf.get_y() + 2)
    pdf.ln(6)


def h2(pdf: FPDF, text: str):
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(255, 255, 255)
    pdf.set_fill_color(10, 40, 100)
    pdf.multi_cell(0, 8, _safe(f"  {text}"), fill=True)
    pdf.ln(2)


def body(pdf: FPDF, text: str):
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(30, 30, 30)
    pdf.multi_cell(0, 6, _safe(text))
    pdf.ln(1)


def table_header(pdf: FPDF, cols: list, widths: list):
    pdf.set_font("Helvetica", "B", 8)
    pdf.set_fill_color(210, 220, 240)
    pdf.set_text_color(10, 40, 100)
    for col, w in zip(cols, widths):
        pdf.cell(w, 7, _safe(col), border=1, fill=True, align="C")
    pdf.ln()


def table_row(pdf: FPDF, cells: list, widths: list, fill: bool = False):
    pdf.set_font("Helvetica", "", 7.5)
    pdf.set_text_color(30, 30, 30)
    pdf.set_fill_color(245, 247, 252)
    for cell, w in zip(cells, widths):
        pdf.cell(w, 6, _safe(str(cell)), border=1, fill=fill, align="L")
    pdf.ln()


# ---------------------------------------------------------------------------
# Dados Base 1 - Clientes
# ---------------------------------------------------------------------------

FIRST_NAMES = [
    "Ana", "Bruno", "Carlos", "Daniela", "Eduardo", "Fernanda", "Gabriel",
    "Helena", "Igor", "Juliana", "Kevin", "Larissa", "Marcos", "Natalia",
    "Otavio", "Patricia", "Rafael", "Sandra", "Thiago", "Ursula", "Victor",
    "Wanessa", "Xavier", "Yuri", "Zelia", "Andre", "Beatriz", "Caio",
    "Diana", "Elton", "Flavia", "Gustavo", "Heloisa", "Ivan", "Joana",
    "Leandro", "Mariana", "Nilton", "Olivia", "Pedro", "Queila", "Ricardo",
    "Simone", "Tania", "Ulisses", "Vanessa", "Wendel", "Ximena", "Yasmin",
    "Zenon", "Adriano", "Bruna", "Claudio", "Debora", "Emerson", "Fabio",
    "Giovana", "Hudson", "Irene", "Jose", "Katia", "Luis", "Milena",
    "Nayara", "Osmar", "Paula", "Quesia", "Rodrigo", "Stella", "Tulio",
    "Valentina", "Wagner", "Ximena", "Yolanda", "Zito", "Alessandra",
    "Bernardo", "Cintia", "Deivid", "Erica", "Felipe", "Graziela",
    "Henrique", "Isabela", "Joao", "Keila", "Luciano", "Monique",
    "Nivaldo", "Ophelie", "Priscila", "Quintino", "Renata", "Silvio",
    "Tatiane", "Umberto", "Vera", "Willian", "Xuxa", "Ylana", "Zarife",
    "Diogo", "Walmor", "Esther", "Fabricio", "Gisele", "Humberto",
]

LAST_NAMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira",
    "Alves", "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins",
    "Carvalho", "Rocha", "Araujo", "Mendes", "Barbosa", "Cardoso", "Dias",
    "Nascimento", "Moura", "Cavalcanti", "Castro", "Monteiro", "Pinto",
    "Teixeira", "Correia", "Azevedo", "Xavier", "Vieira", "Nunes", "Cruz",
    "Machado", "Leal", "Moreira", "Lopes", "Cunha", "Ramos", "Melo",
    "Duarte", "Campos", "Freitas", "Torres", "Pires", "Fonseca", "Borges",
    "Andrade", "Medeiros", "Mesquita",
]

MOVIMENTACAO_LABELS = [
    "Regular com creditos mensais acima de R$ 5.000",
    "Movimentacao alta, media mensal acima de R$ 10.000",
    "Movimentacao baixa, media mensal de R$ 1.500",
    "Movimentacao media, media mensal de R$ 3.500",
    "Movimentacao alta, media mensal acima de R$ 20.000",
    "Irregular, sem creditos frequentes",
    "Creditos esporadicos, media R$ 2.000",
    "Movimentacao muito alta, media acima de R$ 50.000",
    "Movimentacao minima, menos de R$ 500 por mes",
    "Creditos regulares, media R$ 7.500",
]

TEMPO_LABELS = [
    "6 meses", "1 ano", "2 anos", "3 anos", "5 anos",
    "7 anos", "10 anos", "12 anos", "15 anos", "20 anos",
]


def gerar_clientes(n: int = 210) -> list:
    usados = set()
    clientes = []
    idx = 0
    tentativas = 0
    while len(clientes) < n and tentativas < n * 10:
        tentativas += 1
        fn = FIRST_NAMES[idx % len(FIRST_NAMES)]
        ln = random.choice(LAST_NAMES)
        nome = f"{fn} {ln}"
        if nome in usados:
            idx += 1
            continue
        usados.add(nome)
        idx += 1

        renda = random.choice([
            1200, 1500, 1800, 2000, 2500, 3000, 3500, 4000, 5000,
            6000, 7000, 8000, 10000, 12000, 15000, 20000, 25000, 30000,
            40000, 50000,
        ])
        mov_label = random.choice(MOVIMENTACAO_LABELS)
        # extrai valor numerico medio da movimentacao para uso logico
        mov_val = renda * random.uniform(0.8, 3.5)

        restricao = random.choices(["Sim", "Nao"], weights=[20, 80])[0]
        tempo = random.choice(TEMPO_LABELS)

        clientes.append({
            "id": f"CLI-{len(clientes)+1:03d}",
            "nome": nome,
            "renda": renda,
            "mov_label": mov_label,
            "mov_val": round(mov_val, 2),
            "restricao": restricao,
            "tempo": tempo,
        })
    return clientes


def gerar_base_clientes(clientes: list):
    pdf = make_pdf()
    h1(pdf, "Base de Conhecimento - Clientes de Credito")

    body(pdf,
        "Este documento contem o cadastro de clientes elegíveis para analise de credito. "
        "Para cada cliente sao informados: renda mensal bruta declarada, comportamento de "
        "movimentacao financeira na conta, existencia de restricoes no Serasa/Sisbacen "
        "(Sim = ha restricao ativa; Nao = sem restricao) e tempo de relacionamento com a "
        "instituicao. Utilize estas informacoes para avaliar a elegibilidade e o limite "
        "de credito de cada cliente."
    )
    pdf.ln(3)

    h2(pdf, "Regras de elegibilidade para analise")
    body(pdf,
        "- Clientes com restricao (Serasa/Sisbacen = Sim) sao AUTOMATICAMENTE NEGADOS, "
        "independentemente de renda ou movimentacao.\n"
        "- Para clientes sem restricao, o limite pode ser calculado por:\n"
        "  (a) Multiplo da renda: ate 3x a renda mensal bruta.\n"
        "  (b) Multiplo da movimentacao: ate 2x a media mensal de movimentacao.\n"
        "  O criterio mais vantajoso ao cliente deve ser adotado.\n"
        "- Tempo de relacionamento >= 2 anos permite bonificacao de +20% no limite calculado.\n"
        "- O limite final deve ser enquadrado na faixa do produto de credito correspondente."
    )
    pdf.ln(3)

    h2(pdf, "Cadastro de Clientes")

    cols = ["ID", "Nome", "Renda Mensal (R$)", "Movimentacao", "Restricao", "Tempo Rel."]
    widths = [18, 48, 28, 60, 20, 26]

    table_header(pdf, cols, widths)
    for i, c in enumerate(clientes):
        table_row(pdf, [
            c["id"],
            c["nome"],
            f"R$ {c['renda']:,.2f}",
            c["mov_label"],
            c["restricao"],
            c["tempo"],
        ], widths, fill=(i % 2 == 0))

    path = OUT_DIR / "base_clientes_credito.pdf"
    pdf.output(str(path))
    print(f"[OK] {path}  ({len(clientes)} clientes)")
    return clientes


# ---------------------------------------------------------------------------
# Dados Base 2 - Produtos de Credito
# ---------------------------------------------------------------------------

PRODUTOS = [
    {
        "nome": "Cartao de Credito Basico",
        "descricao": (
            "Cartao de credito para clientes de baixa renda ou inicio de relacionamento. "
            "Aceita clientes sem historico extenso. Limite conservador vinculado a renda declarada."
        ),
        "publico": "Clientes com renda entre R$ 1.200 e R$ 3.000 e tempo de relacionamento ate 2 anos.",
        "faixas": [
            ("Faixa 1", "R$ 500", "R$ 1.500", "Renda mensal ate R$ 1.800"),
            ("Faixa 2", "R$ 1.501", "R$ 3.000", "Renda mensal entre R$ 1.801 e R$ 3.000"),
        ],
        "criterio": "Limite = 0.8x a renda mensal. Minimo R$ 500, maximo R$ 3.000.",
    },
    {
        "nome": "Cartao de Credito Intermediario",
        "descricao": (
            "Cartao de credito para clientes de renda media com historico de movimentacao regular. "
            "Permite parcelamento de compras e programa de pontos."
        ),
        "publico": "Clientes com renda entre R$ 3.001 e R$ 8.000 ou movimentacao media mensal entre R$ 4.000 e R$ 12.000.",
        "faixas": [
            ("Faixa 1", "R$ 3.001", "R$ 6.000", "Renda entre R$ 3.001 e R$ 5.000 ou mov. proporcional"),
            ("Faixa 2", "R$ 6.001", "R$ 12.000", "Renda entre R$ 5.001 e R$ 8.000 ou mov. proporcional"),
        ],
        "criterio": "Limite = max(2x renda, 1.5x movimentacao). Minimo R$ 3.001, maximo R$ 12.000.",
    },
    {
        "nome": "Cartao de Credito Premium",
        "descricao": (
            "Cartao de credito de alto padrao para clientes com renda elevada e longo relacionamento. "
            "Inclui beneficios como sala VIP, seguro viagem e cashback."
        ),
        "publico": "Clientes com renda acima de R$ 8.001 e tempo de relacionamento >= 3 anos.",
        "faixas": [
            ("Faixa 1", "R$ 12.001", "R$ 25.000", "Renda entre R$ 8.001 e R$ 15.000"),
            ("Faixa 2", "R$ 25.001", "R$ 50.000", "Renda acima de R$ 15.001 ou mov. muito alta"),
        ],
        "criterio": "Limite = max(3x renda, 2x movimentacao). Minimo R$ 12.001, maximo R$ 50.000.",
    },
    {
        "nome": "Emprestimo Pessoal Basico",
        "descricao": (
            "Emprestimo pessoal para clientes com renda baixa a media e sem restricoes. "
            "Prazo de 12 a 36 meses. Taxa de juros baseada no perfil de risco."
        ),
        "publico": "Clientes com renda entre R$ 1.500 e R$ 5.000 e tempo de relacionamento >= 1 ano.",
        "faixas": [
            ("Faixa 1", "R$ 1.000", "R$ 5.000", "Renda ate R$ 3.000"),
            ("Faixa 2", "R$ 5.001", "R$ 10.000", "Renda entre R$ 3.001 e R$ 5.000"),
        ],
        "criterio": "Limite = 2x renda mensal. Minimo R$ 1.000, maximo R$ 10.000.",
    },
    {
        "nome": "Emprestimo Pessoal Avancado",
        "descricao": (
            "Emprestimo pessoal de maior valor para clientes com renda elevada e bom historico. "
            "Prazo de 24 a 60 meses. Taxas diferenciadas para clientes antigos."
        ),
        "publico": "Clientes com renda acima de R$ 5.001 e tempo de relacionamento >= 2 anos.",
        "faixas": [
            ("Faixa 1", "R$ 10.001", "R$ 30.000", "Renda entre R$ 5.001 e R$ 12.000"),
            ("Faixa 2", "R$ 30.001", "R$ 80.000", "Renda acima de R$ 12.001 com alta movimentacao"),
        ],
        "criterio": "Limite = max(3x renda, 2.5x movimentacao). Minimo R$ 10.001, maximo R$ 80.000.",
    },
    {
        "nome": "Credito Consignado",
        "descricao": (
            "Credito com desconto em folha para servidores publicos, aposentados e pensionistas. "
            "Taxas de juros reduzidas e prazo estendido ate 84 meses."
        ),
        "publico": "Servidores publicos, aposentados ou pensionistas com margem consignavel disponivel.",
        "faixas": [
            ("Faixa 1", "R$ 1.000", "R$ 20.000", "Margem consignavel ate R$ 600/mes"),
            ("Faixa 2", "R$ 20.001", "R$ 100.000", "Margem consignavel acima de R$ 601/mes"),
        ],
        "criterio": "Limite = 35% da renda x prazo (meses). Maximo R$ 100.000.",
    },
    {
        "nome": "Cheque Especial",
        "descricao": (
            "Limite de credito rotativo vinculado a conta corrente. Disponivel automaticamente "
            "para clientes elegíveis. Uso imediato sem solicitacao previa."
        ),
        "publico": "Clientes com conta corrente ativa ha pelo menos 6 meses e renda acima de R$ 2.000.",
        "faixas": [
            ("Faixa 1", "R$ 200", "R$ 2.000", "Renda entre R$ 2.000 e R$ 5.000"),
            ("Faixa 2", "R$ 2.001", "R$ 8.000", "Renda acima de R$ 5.001"),
        ],
        "criterio": "Limite = 0.5x renda mensal. Minimo R$ 200, maximo R$ 8.000.",
    },
    {
        "nome": "Credito Imobiliario",
        "descricao": (
            "Financiamento de imoveis residenciais ou comerciais. Prazo de ate 360 meses. "
            "Requer comprovacao de renda e avaliacao do imovel."
        ),
        "publico": "Clientes com renda acima de R$ 5.000 e tempo de relacionamento >= 6 meses.",
        "faixas": [
            ("Faixa 1", "R$ 80.000", "R$ 300.000", "Renda entre R$ 5.000 e R$ 15.000"),
            ("Faixa 2", "R$ 300.001", "R$ 1.500.000", "Renda acima de R$ 15.001"),
        ],
        "criterio": "Limite = max(30x renda mensal, 25x movimentacao). Comprometimento de renda ate 30%.",
    },
]


def gerar_base_produtos():
    pdf = make_pdf()
    h1(pdf, "Base de Conhecimento - Produtos de Credito e Faixas de Limite")

    body(pdf,
        "Este documento define os produtos de credito disponiveis na instituicao, incluindo "
        "descricao, publico-alvo, faixas de limite por perfil de cliente e criterio de calculo "
        "do limite. O agente de concessao deve consultar esta base apos a aprovacao do cliente "
        "para determinar qual produto e qual faixa de limite sao mais adequados ao perfil."
    )
    pdf.ln(3)

    h2(pdf, "Matriz de Produtos x Perfil")
    cols = ["Produto", "Renda Minima", "Renda Maxima", "Limite Minimo", "Limite Maximo"]
    widths = [55, 25, 25, 28, 28]
    table_header(pdf, cols, widths)
    matrix = [
        ("Cartao Basico",          "R$ 1.200",  "R$ 3.000",  "R$ 500",     "R$ 3.000"),
        ("Cartao Intermediario",   "R$ 3.001",  "R$ 8.000",  "R$ 3.001",   "R$ 12.000"),
        ("Cartao Premium",         "R$ 8.001",  "sem limite","R$ 12.001",  "R$ 50.000"),
        ("Emprestimo Basico",      "R$ 1.500",  "R$ 5.000",  "R$ 1.000",   "R$ 10.000"),
        ("Emprestimo Avancado",    "R$ 5.001",  "sem limite","R$ 10.001",  "R$ 80.000"),
        ("Credito Consignado",     "qualquer",  "qualquer",  "R$ 1.000",   "R$ 100.000"),
        ("Cheque Especial",        "R$ 2.000",  "sem limite","R$ 200",     "R$ 8.000"),
        ("Credito Imobiliario",    "R$ 5.000",  "sem limite","R$ 80.000",  "R$ 1.500.000"),
    ]
    for i, row in enumerate(matrix):
        table_row(pdf, list(row), widths, fill=(i % 2 == 0))
    pdf.ln(4)

    for prod in PRODUTOS:
        h2(pdf, prod["nome"])
        body(pdf, prod["descricao"])
        body(pdf, f"Publico-alvo: {prod['publico']}")
        body(pdf, f"Criterio de calculo do limite: {prod['criterio']}")
        pdf.ln(1)

        cols2 = ["Faixa", "Limite Minimo", "Limite Maximo", "Criterio de Enquadramento"]
        widths2 = [20, 30, 30, 98]
        table_header(pdf, cols2, widths2)
        for i, faixa in enumerate(prod["faixas"]):
            table_row(pdf, list(faixa), widths2, fill=(i % 2 == 0))
        pdf.ln(4)

    path = OUT_DIR / "base_produtos_credito.pdf"
    pdf.output(str(path))
    print(f"[OK] {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    clientes = gerar_base_clientes(gerar_clientes(210))
    gerar_base_produtos()
    print(f"\n[DONE] PDFs gerados em: {OUT_DIR}")
