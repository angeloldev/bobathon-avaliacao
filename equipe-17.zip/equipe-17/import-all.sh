#!/usr/bin/env bash
# =============================================================================
# import-all.sh — Importa todos os assets da Equipe-17 no watsonx Orchestrate
# =============================================================================
# Uso:
#   ./equipe-17/import-all.sh
#
# Pre-requisito: ambiente ativo
#   ./venv/bin/orchestrate env activate ap-southeast-1-68ff61c8
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
ORCHESTRATE="${SCRIPT_DIR}/../venv/bin/orchestrate"

echo "============================================================"
echo "  Equipe-17 | Sistema de Concessao de Credito"
echo "  Importacao de Assets — watsonx Orchestrate"
echo "============================================================"
echo ""

"${ORCHESTRATE}" env list

# -----------------------------------------------------------------------
# STEP 1: Bases de Conhecimento
# -----------------------------------------------------------------------
echo ""
echo "[STEP 1/3] Importando bases de conhecimento..."
echo "  AVISO: A indexacao dos PDFs pode levar alguns minutos apos o import."

for kb in kb_clientes_credito.yaml kb_produtos_credito.yaml; do
  echo "  -> ${kb}"
  "${ORCHESTRATE}" knowledge-bases import -f "${SCRIPT_DIR}/knowledge-bases/${kb}"
done
echo "[OK] Bases de conhecimento importadas."

# -----------------------------------------------------------------------
# STEP 2: Agentes especializados (hidden — sem UI, acionados pelo orquestrador)
# -----------------------------------------------------------------------
echo ""
echo "[STEP 2/3] Importando agentes especializados..."

# Ordem importa: especializados antes do orquestrador, orquestrador antes do avaliador
for agent in \
  agente_perfil_cliente.yaml \
  agente_produtos_credito.yaml \
  agente_decisao_concessao.yaml \
  agente_orquestrador_credito.yaml \
  agente_avaliador_pedido.yaml; do
  echo "  -> ${agent}"
  "${ORCHESTRATE}" agents import -f "${SCRIPT_DIR}/agents/${agent}"
done
echo "[OK] Agentes importados."

# -----------------------------------------------------------------------
# STEP 3: Verificacao
# -----------------------------------------------------------------------
echo ""
echo "[STEP 3/3] Verificando assets importados..."
echo ""
echo "  Knowledge Bases:"
"${ORCHESTRATE}" knowledge-bases list 2>/dev/null || true
echo ""
echo "  Agentes:"
"${ORCHESTRATE}" agents list 2>/dev/null || true

# -----------------------------------------------------------------------
# Resumo
# -----------------------------------------------------------------------
echo ""
echo "============================================================"
echo "  Importacao concluida com sucesso!"
echo ""
echo "  Para testar:"
echo "    ${ORCHESTRATE} chat start"
echo "    -> Selecione: agente_avaliador_pedido"
echo "    -> Teste: 'Solicite credito para [nome de um cliente do PDF]'"
echo ""
echo "  Para exportar evidencias:"
echo "    ./equipe-17/export-evidencias.sh"
echo "============================================================"
