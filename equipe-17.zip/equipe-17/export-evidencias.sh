#!/usr/bin/env bash
# =============================================================================
# export-evidencias.sh — Exporta os agentes para a subpasta evidencias/
# =============================================================================
# Uso: ./equipe-17/export-evidencias.sh
# Pre-requisito: ambiente ativo e agentes ja importados
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
ORCHESTRATE="${SCRIPT_DIR}/../venv/bin/orchestrate"
EVIDENCIAS="${SCRIPT_DIR}/evidencias"

mkdir -p "${EVIDENCIAS}"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${EVIDENCIAS}/export_log_${TIMESTAMP}.txt"

echo "============================================================" | tee -a "${LOG_FILE}"
echo "  Equipe-17 | Exportacao de Evidencias" | tee -a "${LOG_FILE}"
echo "  Timestamp: ${TIMESTAMP}" | tee -a "${LOG_FILE}"
echo "============================================================" | tee -a "${LOG_FILE}"
echo "" | tee -a "${LOG_FILE}"

AGENTS=(
  "agente_avaliador_pedido"
  "agente_perfil_cliente"
  "agente_produtos_credito"
  "agente_decisao_concessao"
  "agente_orquestrador_credito"
)

for agent_name in "${AGENTS[@]}"; do
  OUT_FILE="${EVIDENCIAS}/${agent_name}_${TIMESTAMP}.zip"
  echo "  Exportando ${agent_name}..." | tee -a "${LOG_FILE}"
  "${ORCHESTRATE}" agents export \
    --name "${agent_name}" \
    --output "${OUT_FILE}" 2>&1 | tee -a "${LOG_FILE}" || \
    echo "  [AVISO] Falha ao exportar ${agent_name} — verifique se foi importado." | tee -a "${LOG_FILE}"
done

echo "" | tee -a "${LOG_FILE}"
echo "[INFO] Listando agentes ativos no ambiente:" | tee -a "${LOG_FILE}"
"${ORCHESTRATE}" agents list 2>&1 | tee -a "${LOG_FILE}" || true

echo "" | tee -a "${LOG_FILE}"
echo "[INFO] Listando knowledge bases ativas:" | tee -a "${LOG_FILE}"
"${ORCHESTRATE}" knowledge-bases list 2>&1 | tee -a "${LOG_FILE}" || true

echo "" | tee -a "${LOG_FILE}"
echo "============================================================" | tee -a "${LOG_FILE}"
echo "  Exportacao concluida." | tee -a "${LOG_FILE}"
echo "  Arquivos gerados em: ${EVIDENCIAS}" | tee -a "${LOG_FILE}"
echo "  Log: ${LOG_FILE}" | tee -a "${LOG_FILE}"
echo "============================================================" | tee -a "${LOG_FILE}"
