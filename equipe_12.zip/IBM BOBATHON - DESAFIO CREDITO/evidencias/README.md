# Evidências — Aurora Bank · Grupo 12
### Checklist de Prova de Uso do watsonx Orchestrate

> Este arquivo orienta o que precisa ser capturado (print, export ou log)
> como evidência de uso real do IBM watsonx Orchestrate para a entrega do desafio.

---

## Checklist de Evidências

### A. Setup e Autenticação

- [ ] **Print da tela de login** do watsonx Orchestrate com o tenant do Grupo 12 visível
- [ ] **Print do comando** `orchestrate env list` mostrando o environment ativo
- [ ] **Print ou log** de `orchestrate --version` com a versão do ADK instalada

---

### B. Importação das Tools

- [ ] **Terminal com saída** do comando de importação:
  ```bash
  orchestrate tools import -k python -f src/tools/aurora_tools.py
  ```
  Saída esperada: confirmação de 4 tools registradas (`buscar_cliente`, `listar_produtos`, `avaliar_politica`, `registrar_decisao`)

- [ ] **Print da tela "Tools"** no Orchestrate UI mostrando as 4 tools listadas

---

### C. Importação dos Agentes

- [ ] **Terminal com saída** de cada importação de agente:
  ```bash
  orchestrate agents import -f src/agents/agente_carteira.yaml
  orchestrate agents import -f src/agents/agente_cliente.yaml
  orchestrate agents import -f src/agents/agente_decisor.yaml
  orchestrate agents import -f src/agents/agente_justificativa.yaml
  orchestrate agents import -f src/agents/agente_orquestrador_credito.yaml
  ```
- [ ] **Print da tela "Agents"** no Orchestrate UI mostrando os 5 agentes listados
- [ ] **Print da tela de detalhe** do `agente_orquestrador_credito` exibindo os 4 colaboradores vinculados

---

### D. Execução do Fluxo — Caso APROVADO (C001)

- [ ] **Terminal com saída** ou **print do chat** da invocação:
  ```bash
  orchestrate agents invoke agente_orquestrador_credito \
    --input '{"id_cliente": "C001", "valor_solicitado": 20000}'
  ```
- [ ] **Saída esperada** visível:
  - `decisao_final: APROVADO`
  - `limite: 28050.00`
  - `carta_ao_cliente` citando renda_comprovada e parcela_simulada
  - `id_decisao` no formato `DEC-XXXXXXXXXXXX`

---

### E. Execução do Fluxo — Caso NEGADO (C003)

- [ ] **Terminal/chat** da invocação para C003
- [ ] **Saída esperada**:
  - `decisao_final: NEGADO`
  - `regras_acionadas[0].codigo: R-003`
  - Carta mencionando "restrição de crédito"

---

### F. Execução do Fluxo — Caso INCONCLUSIVO (C006)

- [ ] **Terminal/chat** da invocação para C006
- [ ] **Saída esperada**:
  - `decisao_final: INCONCLUSIVO`
  - `dados_faltantes` com 7 campos listados
  - Carta mencionando "encaminhado para analista humano"
  - **Evidência de parada antecipada**: `agente_decisor` NÃO aparece no trace de execução

---

### G. Trilha de Auditoria

- [ ] **Print ou export** do arquivo `src/audit/trilha_auditoria.jsonl` gerado após as execuções acima
- [ ] **Print** do comando de validação do schema (ou saída do script `gerar_trilha_auditoria.py`):
  ```
  OK   C001 (APROVADO)      — DEC-XXXXXXXXXXXX
  OK   C003 (NEGADO)        — DEC-XXXXXXXXXXXX
  OK   C006 (INCONCLUSIVO)  — DEC-XXXXXXXXXXXX
  TODOS OS 3 REGISTROS CONFORMES COM O SCHEMA.
  ```

---

### H. Teste Local (sem Orchestrate) — Validação de Baseline

- [ ] **Terminal com saída** de `python src/policy/politica_credito.py`:
  ```
  RESULTADO: 12/12 acertos
  ```
- [ ] **Terminal com saída** de `python src/tools/orquestracao.py` mostrando o resumo final dos 12 clientes

---

### I. Opcional — Evidências de Qualidade

- [ ] **Print do Agent Lab** do Orchestrate mostrando o fluxo de um dos agentes
- [ ] **Print do trace/log** de uma execução completa no Orchestrate, evidenciando a sequência dos 5 passos
- [ ] **Export do YAML** de um dos agentes diretamente do Orchestrate UI (confirma que o import foi bem-sucedido)

---

## Nomenclatura dos Arquivos de Evidência

Salve os prints/exports nesta pasta com a seguinte convenção:

```
evidencias/
├── README.md                          ← este arquivo
├── A1_login_orchestrate.png
├── A2_env_list.png
├── B1_tools_import_terminal.png
├── B2_tools_ui_lista.png
├── C1_agents_import_terminal.png
├── C2_agents_ui_lista.png
├── C3_orquestrador_colaboradores.png
├── D1_caso_aprovado_C001.png
├── E1_caso_negado_C003.png
├── F1_caso_inconclusivo_C006.png
├── G1_trilha_jsonl.png
├── G2_validacao_schema.png
├── H1_testes_politica_12_12.png
└── H2_orquestracao_12_clientes.png
```

---

## O Que Torna Esta Evidência Suficiente?

Para o regulador (e para o avaliador do desafio), a combinação das evidências acima demonstra:

1. **Uso real do Orchestrate**: agentes importados, tools registradas, execução via SDK
2. **Fluxo multi-agente funcionando**: 4 colaboradores coordenados pelo orquestrador
3. **Política determinística**: mesma entrada → mesma saída (evidenciada pelos 12/12 testes)
4. **Anti-alucinação**: C006 gera INCONCLUSIVO sem inventar dados (evidenciada pela parada antecipada)
5. **Auditabilidade**: trilha JSONL com hash SHA-256 e conformidade com schema

---

*Grupo 12 · IBM Bobathon · Aurora Bank · 2025*
