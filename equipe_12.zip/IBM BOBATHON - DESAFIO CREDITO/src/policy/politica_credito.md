# Política de Crédito — Aurora Bank
**Versão:** 1.0.0  
**Vigência:** 2025-01-01  
**Status:** FICTÍCIA — criada exclusivamente para o desafio IBM Bobathon / Aurora Bank.

---

## 1. Princípios Fundamentais

1. **Determinismo**: toda decisão é calculada por regras explícitas, sem margem de interpretação subjetiva. O mesmo conjunto de dados sempre produz o mesmo resultado.
2. **Auditabilidade**: cada regra tem um código estável (R-001…R-014). A justificativa entregue ao cliente cita o código + o valor que acionou a regra.
3. **Anti-alucinação**: se qualquer campo obrigatório estiver ausente (`null`), a política classifica imediatamente como **INCONCLUSIVO** e não prossegue com cálculos.
4. **Separação de responsabilidades**: a política calcula; o LLM apenas traduz o resultado em linguagem humana.

---

## 2. Campos Obrigatórios para Avaliação

Os campos abaixo são obrigatórios. A ausência de **qualquer um** aciona R-001 (INCONCLUSIVO):

| Campo | Tipo | Descrição |
|---|---|---|
| `idade` | int | Idade do solicitante em anos |
| `renda_comprovada` | float | Renda mensal com documentação |
| `parcelas_mensais_atuais` | float | Soma das parcelas vigentes |
| `score_interno_0_1000` | int | Score interno do Aurora Bank |
| `restricao_externa` | bool | Presença de restrição em bureaus externos |
| `divida_total_atual` | float | Saldo devedor total consolidado |
| `saldo_medio_12m` | float | Saldo médio em conta nos últimos 12 meses |
| `valor_solicitado` | float | Valor pleiteado pelo cliente |
| `atrasos_ultimos_12m` | object | `{quantidade, dias_max}` |
| `finalidade_pedido` | string | Tipo de produto solicitado |

---

## 3. Regras — Hard Rules (corte imediato)

As regras abaixo são **eliminatórias**: se acionada, a decisão é **NEGADO** (ou INCONCLUSIVO para R-001) e a avaliação para.

| Código | Critério | Limiar | Efeito | Mensagem ao cliente |
|--------|----------|--------|--------|---------------------|
| **R-001** | Dado obrigatório ausente (`null`) | qualquer campo da seção 2 | **INCONCLUSIVO** | "Não foi possível concluir a análise por ausência de dado obrigatório: `{campo}`. O pedido foi encaminhado para análise humana." |
| **R-002** | Idade mínima | `idade < 18` | **NEGADO** | "A concessão de crédito exige idade mínima de 18 anos. O solicitante tem {idade} anos." |
| **R-003** | Restrição externa ativa | `restricao_externa == true` | **NEGADO** | "Há restrição de crédito registrada em órgãos de proteção ao crédito. Pedido negado até regularização." |
| **R-004** | Score interno mínimo absoluto | `score_interno_0_1000 < 400` | **NEGADO** | "O score interno do solicitante ({score}) está abaixo do mínimo absoluto exigido (400 pontos)." |
| **R-005** | Score mínimo do produto | `score_interno_0_1000 < produto.score_minimo` | **NEGADO** | "O score interno ({score}) está abaixo do mínimo exigido para o produto {produto} ({score_minimo} pontos)." |
| **R-006** | Renda comprovada mínima | `renda_comprovada < 1500.00` | **NEGADO** | "A renda comprovada (R$ {renda}) está abaixo do mínimo exigido de R$ 1.500,00." |
| **R-007** | Comprometimento de renda pós-crédito | `(parcelas_atuais + parcela_simulada) / renda_comprovada > produto.comprometimento_renda_maximo` | **NEGADO** | "Com a parcela simulada de R$ {parcela_sim}, o comprometimento de renda atingiria {comp_pct}%, acima do limite de {limite_pct}% para este produto." |

---

## 4. Cálculos Auxiliares

### 4.1 Parcela Simulada (Price)
```
parcela_simulada = valor_aprovado * (taxa_am * (1 + taxa_am)^prazo) / ((1 + taxa_am)^prazo - 1)
```
- `taxa_am` = taxa mensal do produto escolhido
- `prazo` = `prazo_max_meses` do produto (conservador; usa o prazo máximo para minimizar a parcela simulada)

### 4.2 Comprometimento de Renda
```
comprometimento = (parcelas_mensais_atuais + parcela_simulada) / renda_comprovada
```
- Teto por produto definido em `produtos.json` → campo `comprometimento_renda_maximo`

### 4.3 Limite Sugerido
```
limite_por_saldo    = saldo_medio_12m * 3.0          # múltiplo de saldo médio
limite_por_renda    = renda_comprovada * 4.0          # múltiplo de renda
limite_pelo_teto    = max_parcela_disponivel * prazo  # onde max_parcela = (teto_comp - comp_atual) * renda_comprovada
limite_bruto        = min(limite_por_saldo, limite_por_renda, limite_pelo_teto, produto.limite_max)
limite_sugerido     = max(limite_bruto, produto.limite_min)   # nunca abaixo do mínimo do produto
```
- Se `limite_bruto < produto.limite_min` → não há limite viável → **NEGADO** por R-007 (comprometimento inviável)

---

## 5. Regras de Ressalva (soft rules — não eliminatórias, reduzem limite)

| Código | Critério | Efeito | Desconto no Limite |
|--------|----------|--------|--------------------|
| **R-008** | `atrasos_ultimos_12m.quantidade >= 2 AND dias_max <= 30` | APROVADO_COM_RESSALVA | Limite reduzido em 25% |
| **R-009** | `atrasos_ultimos_12m.quantidade >= 1 AND dias_max > 30 AND dias_max <= 60` | APROVADO_COM_RESSALVA | Limite reduzido em 40% |
| **R-010** | `tempo_relacionamento_meses < 6` | APROVADO_COM_RESSALVA | Limite reduzido em 30% |
| **R-011** | `tempo_relacionamento_meses >= 6 AND tempo_relacionamento_meses < 12` | APROVADO_COM_RESSALVA | Limite reduzido em 15% |
| **R-012** | `score_interno_0_1000 >= produto.score_minimo AND score_interno_0_1000 < produto.score_minimo + 100` | APROVADO_COM_RESSALVA | Limite reduzido em 20% |

> Ressalvas são cumulativas: cada regra acionada aplica seu desconto multiplicativamente sobre o limite já calculado.

---

## 6. Regras de Melhoria (bônus de confiança)

| Código | Critério | Efeito |
|--------|----------|--------|
| **R-013** | `tempo_relacionamento_meses >= 60 AND score_interno_0_1000 >= 750` | Confiança += 0.10; limite pode chegar até `produto.limite_max` |
| **R-014** | `atrasos_ultimos_12m.quantidade == 0 AND saldo_medio_12m >= renda_comprovada * 0.5` | Confiança += 0.05 |

---

## 7. Faixas de Decisão Final

| Decisão | Condição |
|---------|----------|
| **INCONCLUSIVO** | Qualquer campo obrigatório ausente (R-001) |
| **NEGADO** | Qualquer hard rule (R-002 a R-007) acionada |
| **APROVADO_COM_RESSALVA** | Nenhuma hard rule acionada + pelo menos uma soft rule (R-008 a R-012) |
| **APROVADO** | Nenhuma hard rule, nenhuma soft rule |

---

## 8. Objeto de Retorno da Política

```json
{
  "decisao": "APROVADO | APROVADO_COM_RESSALVA | NEGADO | INCONCLUSIVO",
  "limite_sugerido": 0.00,
  "produto_recomendado": "PROD001",
  "regras_acionadas": [
    {"codigo": "R-007", "descricao": "...", "valor_acionador": "..."}
  ],
  "dados_utilizados": {
    "renda_comprovada": 0.00,
    "parcelas_mensais_atuais": 0.00,
    "score_interno_0_1000": 0,
    "restricao_externa": false
  },
  "dados_faltantes": [],
  "confianca": 0.85,
  "parcela_simulada": 0.00,
  "comprometimento_pos_credito": 0.00,
  "versao_politica": "1.0.0"
}
```

---

## 9. Histórico de Versões

| Versão | Data | Alteração |
|--------|------|-----------|
| 1.0.0 | 2025-01-01 | Versão inicial — desafio IBM Bobathon |
