"""
politica_credito.py
===================
Política determinística de crédito — Aurora Bank
Versão: 1.0.0
Status: FICTÍCIO — desafio IBM Bobathon.

REGRA DE OURO: nenhuma função aqui inventa dados.
Se um campo obrigatório for None, retorna INCONCLUSIVO imediatamente.
O LLM NUNCA chama esta função com dados parcialmente preenchidos "por conta própria".
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any

# ---------------------------------------------------------------------------
# Constantes da política
# ---------------------------------------------------------------------------

VERSAO_POLITICA = "1.0.0"

RENDA_MINIMA = 1_500.00          # R-006
SCORE_MINIMO_ABSOLUTO = 400      # R-004
MULTIPLO_SALDO = 3.0             # limite_por_saldo
MULTIPLO_RENDA = 4.0             # limite_por_renda

# Campos obrigatórios — ausência de qualquer um aciona R-001
CAMPOS_OBRIGATORIOS = [
    "idade",
    "renda_comprovada",
    "parcelas_mensais_atuais",
    "score_interno_0_1000",
    "restricao_externa",
    "divida_total_atual",
    "saldo_medio_12m",
    "valor_solicitado",
    "atrasos_ultimos_12m",
    "finalidade_pedido",
]

# Produto padrão de fallback (usado em testes sem produto explícito)
PRODUTO_PADRAO = {
    "id": "PROD001",
    "nome": "Crédito Pessoal Aurora",
    "tipo": "credito_pessoal",
    "taxa_am": 0.0299,
    "prazo_max_meses": 60,
    "prazo_min_meses": 6,
    "limite_min": 1_000.00,
    "limite_max": 50_000.00,
    "score_minimo": 600,
    "comprometimento_renda_maximo": 0.30,
    "tempo_relacionamento_minimo_meses": 6,
}

# ---------------------------------------------------------------------------
# Estruturas de dados
# ---------------------------------------------------------------------------

@dataclass
class RegraAcionada:
    codigo: str
    descricao: str
    valor_acionador: str


@dataclass
class ResultadoPolitica:
    decisao: str                                   # APROVADO | APROVADO_COM_RESSALVA | NEGADO | INCONCLUSIVO
    limite_sugerido: float
    produto_recomendado: str
    regras_acionadas: list[RegraAcionada] = field(default_factory=list)
    dados_utilizados: dict[str, Any] = field(default_factory=dict)
    dados_faltantes: list[str] = field(default_factory=list)
    confianca: float = 0.0
    parcela_simulada: float = 0.0
    comprometimento_pos_credito: float = 0.0
    versao_politica: str = VERSAO_POLITICA

    def to_dict(self) -> dict:
        d = asdict(self)
        d["regras_acionadas"] = [asdict(r) for r in self.regras_acionadas]
        return d


# ---------------------------------------------------------------------------
# Funções auxiliares
# ---------------------------------------------------------------------------

def _parcela_price(valor: float, taxa_am: float, prazo: int) -> float:
    """Cálculo de parcela pelo sistema Price (juros compostos)."""
    if taxa_am == 0:
        return valor / prazo
    fator = (taxa_am * (1 + taxa_am) ** prazo) / ((1 + taxa_am) ** prazo - 1)
    return round(valor * fator, 2)


def _campos_faltantes(cliente: dict) -> list[str]:
    """Retorna lista de campos obrigatórios ausentes (None ou inexistentes)."""
    faltantes = []
    for campo in CAMPOS_OBRIGATORIOS:
        valor = cliente.get(campo)
        if valor is None:
            faltantes.append(campo)
        # atrasos_ultimos_12m é dict — verificar sub-campos
        if campo == "atrasos_ultimos_12m" and isinstance(valor, dict):
            if valor.get("quantidade") is None or valor.get("dias_max") is None:
                if campo not in faltantes:
                    faltantes.append(campo)
    return faltantes


# ---------------------------------------------------------------------------
# Função principal
# ---------------------------------------------------------------------------

def avaliar_politica(
    cliente: dict,
    produto: dict | None = None,
    valor_solicitado: float | None = None,
) -> ResultadoPolitica:
    """
    Avalia um pedido de crédito com base na política determinística.

    Parâmetros
    ----------
    cliente         : dict com os campos de clientes.json
    produto         : dict com os campos de produtos.json (opcional; usa PRODUTO_PADRAO)
    valor_solicitado: valor pleiteado (usa cliente['valor_solicitado'] se None)

    Retorno
    -------
    ResultadoPolitica com decisão, limite, regras acionadas e dados utilizados.
    """

    if produto is None:
        produto = PRODUTO_PADRAO

    valor = valor_solicitado if valor_solicitado is not None else cliente.get("valor_solicitado")

    regras: list[RegraAcionada] = []
    dados_faltantes: list[str] = []

    # ------------------------------------------------------------------
    # R-001 — Dado obrigatório ausente
    # ------------------------------------------------------------------
    dados_faltantes = _campos_faltantes(cliente)
    if valor is None:
        dados_faltantes.append("valor_solicitado")
    if dados_faltantes:
        regras.append(RegraAcionada(
            codigo="R-001",
            descricao="Dado obrigatório ausente — decisão INCONCLUSIVA.",
            valor_acionador=f"Campos faltantes: {', '.join(dados_faltantes)}",
        ))
        return ResultadoPolitica(
            decisao="INCONCLUSIVO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados={},
            dados_faltantes=dados_faltantes,
            confianca=0.0,
        )

    # Atalhos para campos garantidamente presentes a partir daqui
    idade: int                  = cliente["idade"]
    renda: float                = float(cliente["renda_comprovada"])
    parcelas_atuais: float      = float(cliente["parcelas_mensais_atuais"])
    score: int                  = int(cliente["score_interno_0_1000"])
    restricao: bool             = bool(cliente["restricao_externa"])
    saldo_medio: float          = float(cliente["saldo_medio_12m"])
    atrasos: dict               = cliente["atrasos_ultimos_12m"]
    qtd_atrasos: int            = int(atrasos["quantidade"])
    dias_max: int               = int(atrasos["dias_max"])
    tempo_rel: int              = int(cliente.get("tempo_relacionamento_meses", 0))

    taxa_am: float              = float(produto["taxa_am"])
    prazo_max: int              = int(produto["prazo_max_meses"])
    limite_min: float           = float(produto["limite_min"])
    limite_max: float           = float(produto["limite_max"])
    score_minimo_prod: int      = int(produto["score_minimo"])
    comp_maximo: float          = float(produto["comprometimento_renda_maximo"])
    tempo_rel_minimo: int       = int(produto.get("tempo_relacionamento_minimo_meses", 0))

    dados_utilizados = {
        "idade": idade,
        "renda_comprovada": renda,
        "parcelas_mensais_atuais": parcelas_atuais,
        "score_interno_0_1000": score,
        "restricao_externa": restricao,
        "saldo_medio_12m": saldo_medio,
        "divida_total_atual": float(cliente["divida_total_atual"]),
        "valor_solicitado": float(valor),
        "qtd_atrasos_12m": qtd_atrasos,
        "dias_max_atraso": dias_max,
        "tempo_relacionamento_meses": tempo_rel,
        "produto_id": produto["id"],
        "taxa_am": taxa_am,
        "prazo_max_meses": prazo_max,
        "comprometimento_maximo_produto": comp_maximo,
    }

    # ------------------------------------------------------------------
    # HARD RULES (eliminatórias)
    # ------------------------------------------------------------------

    # R-002 — Idade mínima
    if idade < 18:
        regras.append(RegraAcionada(
            codigo="R-002",
            descricao="Idade abaixo do mínimo legal (18 anos).",
            valor_acionador=f"idade={idade}",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
        )

    # R-003 — Restrição externa
    if restricao:
        regras.append(RegraAcionada(
            codigo="R-003",
            descricao="Restrição de crédito ativa em bureau externo.",
            valor_acionador="restricao_externa=true",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
        )

    # R-004 — Score mínimo absoluto
    if score < SCORE_MINIMO_ABSOLUTO:
        regras.append(RegraAcionada(
            codigo="R-004",
            descricao=f"Score interno abaixo do mínimo absoluto ({SCORE_MINIMO_ABSOLUTO}).",
            valor_acionador=f"score={score}",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
        )

    # R-005 — Score mínimo do produto
    if score < score_minimo_prod:
        regras.append(RegraAcionada(
            codigo="R-005",
            descricao=f"Score interno abaixo do mínimo do produto {produto['nome']} ({score_minimo_prod}).",
            valor_acionador=f"score={score}, score_minimo_produto={score_minimo_prod}",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
        )

    # R-006 — Renda mínima
    if renda < RENDA_MINIMA:
        regras.append(RegraAcionada(
            codigo="R-006",
            descricao=f"Renda comprovada abaixo do mínimo exigido (R$ {RENDA_MINIMA:,.2f}).",
            valor_acionador=f"renda_comprovada={renda:.2f}",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
        )

    # ------------------------------------------------------------------
    # Cálculo de limite bruto (antes de R-007)
    # ------------------------------------------------------------------
    limite_por_saldo = saldo_medio * MULTIPLO_SALDO
    limite_por_renda = renda * MULTIPLO_RENDA
    margem_disponivel = (comp_maximo * renda) - parcelas_atuais
    margem_disponivel = max(margem_disponivel, 0.0)
    limite_pelo_teto = _parcela_price(1.0, taxa_am, prazo_max)  # parcela por R$1
    # Limite que resulta em margem_disponivel de parcela
    if limite_pelo_teto > 0:
        limite_pelo_comp = margem_disponivel / limite_pelo_teto
    else:
        limite_pelo_comp = 0.0

    limite_bruto = min(limite_por_saldo, limite_por_renda, limite_pelo_comp, limite_max)
    limite_bruto = max(limite_bruto, 0.0)

    # Parcela simulada com o menor entre valor_solicitado e limite_bruto
    valor_a_simular = min(float(valor), limite_bruto) if limite_bruto > 0 else float(valor)
    parcela_sim = _parcela_price(valor_a_simular, taxa_am, prazo_max)
    comp_pos = (parcelas_atuais + parcela_sim) / renda if renda > 0 else 1.0

    # R-007 — Comprometimento de renda pós-crédito
    if comp_pos > comp_maximo or limite_bruto < limite_min:
        regras.append(RegraAcionada(
            codigo="R-007",
            descricao=(
                f"Comprometimento de renda pós-crédito ({comp_pos*100:.1f}%) "
                f"ultrapassa o limite do produto ({comp_maximo*100:.0f}%) "
                f"ou limite calculado (R$ {limite_bruto:.2f}) abaixo do mínimo do produto (R$ {limite_min:.2f})."
            ),
            valor_acionador=(
                f"parcelas_atuais={parcelas_atuais:.2f}, "
                f"parcela_simulada={parcela_sim:.2f}, "
                f"renda_comprovada={renda:.2f}, "
                f"comprometimento={comp_pos*100:.1f}%"
            ),
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
            parcela_simulada=parcela_sim,
            comprometimento_pos_credito=round(comp_pos, 4),
        )

    # ------------------------------------------------------------------
    # SOFT RULES (ressalvas — reduzem limite, não eliminam)
    # ------------------------------------------------------------------
    limite_final = limite_bruto
    confianca = 0.70  # base
    decisao = "APROVADO"

    # R-008 — Atrasos leves
    if qtd_atrasos >= 2 and dias_max <= 30:
        regras.append(RegraAcionada(
            codigo="R-008",
            descricao="2 ou mais atrasos nos últimos 12 meses (até 30 dias). Limite reduzido em 25%.",
            valor_acionador=f"qtd_atrasos={qtd_atrasos}, dias_max={dias_max}",
        ))
        limite_final *= 0.75
        decisao = "APROVADO_COM_RESSALVA"

    # R-009 — Atrasos moderados
    if qtd_atrasos >= 1 and 30 < dias_max <= 60:
        regras.append(RegraAcionada(
            codigo="R-009",
            descricao="Atraso entre 31 e 60 dias nos últimos 12 meses. Limite reduzido em 40%.",
            valor_acionador=f"qtd_atrasos={qtd_atrasos}, dias_max={dias_max}",
        ))
        limite_final *= 0.60
        decisao = "APROVADO_COM_RESSALVA"

    # R-010 — Relacionamento muito curto
    if tempo_rel < 6:
        regras.append(RegraAcionada(
            codigo="R-010",
            descricao="Tempo de relacionamento inferior a 6 meses. Limite reduzido em 30%.",
            valor_acionador=f"tempo_relacionamento_meses={tempo_rel}",
        ))
        limite_final *= 0.70
        decisao = "APROVADO_COM_RESSALVA"

    # R-011 — Relacionamento curto
    elif 6 <= tempo_rel < 12:
        regras.append(RegraAcionada(
            codigo="R-011",
            descricao="Tempo de relacionamento entre 6 e 11 meses. Limite reduzido em 15%.",
            valor_acionador=f"tempo_relacionamento_meses={tempo_rel}",
        ))
        limite_final *= 0.85
        decisao = "APROVADO_COM_RESSALVA"

    # R-012 — Score na faixa de entrada do produto
    if score_minimo_prod <= score < score_minimo_prod + 100:
        regras.append(RegraAcionada(
            codigo="R-012",
            descricao=(
                f"Score ({score}) está na faixa de entrada do produto "
                f"(entre {score_minimo_prod} e {score_minimo_prod+99}). Limite reduzido em 20%."
            ),
            valor_acionador=f"score={score}, score_minimo_produto={score_minimo_prod}",
        ))
        limite_final *= 0.80
        decisao = "APROVADO_COM_RESSALVA"

    # ------------------------------------------------------------------
    # BÔNUS DE CONFIANÇA
    # ------------------------------------------------------------------

    # R-013 — Cliente sênior com score alto
    if tempo_rel >= 60 and score >= 750:
        regras.append(RegraAcionada(
            codigo="R-013",
            descricao="Cliente com 5+ anos de relacionamento e score >= 750. Confiança aumentada.",
            valor_acionador=f"tempo_relacionamento_meses={tempo_rel}, score={score}",
        ))
        confianca += 0.10
        limite_final = min(limite_final * 1.10, limite_max)

    # R-014 — Sem atrasos + saldo saudável
    if qtd_atrasos == 0 and saldo_medio >= renda * 0.5:
        regras.append(RegraAcionada(
            codigo="R-014",
            descricao="Sem atrasos nos últimos 12 meses e saldo médio >= 50% da renda. Confiança aumentada.",
            valor_acionador=f"qtd_atrasos=0, saldo_medio={saldo_medio:.2f}, renda={renda:.2f}",
        ))
        confianca += 0.05

    # ------------------------------------------------------------------
    # Arredondamentos e limites finais
    # ------------------------------------------------------------------
    limite_final = round(min(max(limite_final, limite_min), limite_max), 2)
    # Se limite final ficou abaixo do mínimo após ressalvas — situação rara, mas tratar
    if limite_final < limite_min:
        regras.append(RegraAcionada(
            codigo="R-007",
            descricao="Após ressalvas, o limite calculado ficou abaixo do mínimo do produto.",
            valor_acionador=f"limite_apos_ressalvas={limite_final:.2f}, limite_min={limite_min:.2f}",
        ))
        return ResultadoPolitica(
            decisao="NEGADO",
            limite_sugerido=0.0,
            produto_recomendado=produto["id"],
            regras_acionadas=regras,
            dados_utilizados=dados_utilizados,
            dados_faltantes=[],
            confianca=0.0,
            parcela_simulada=parcela_sim,
            comprometimento_pos_credito=round(comp_pos, 4),
        )

    confianca = round(min(confianca, 1.0), 4)

    return ResultadoPolitica(
        decisao=decisao,
        limite_sugerido=limite_final,
        produto_recomendado=produto["id"],
        regras_acionadas=regras,
        dados_utilizados=dados_utilizados,
        dados_faltantes=[],
        confianca=confianca,
        parcela_simulada=round(parcela_sim, 2),
        comprometimento_pos_credito=round(comp_pos, 4),
    )


# ---------------------------------------------------------------------------
# Testes rápidos com os 12 clientes
# ---------------------------------------------------------------------------

def _carregar_dados() -> tuple[list[dict], list[dict]]:
    import pathlib
    base = pathlib.Path(__file__).parent.parent / "data"
    with open(base / "clientes.json", encoding="utf-8") as f:
        clientes_raw = json.load(f)["clientes"]
    with open(base / "produtos.json", encoding="utf-8") as f:
        produtos_raw = {p["tipo"]: p for p in json.load(f)["produtos"]}
    return clientes_raw, produtos_raw


def _selecionar_produto(cliente: dict, produtos: dict) -> dict:
    """Seleciona produto pelo campo finalidade_pedido do cliente."""
    finalidade = cliente.get("finalidade_pedido", "credito_pessoal")
    return produtos.get(finalidade, produtos.get("credito_pessoal", PRODUTO_PADRAO))


def rodar_testes() -> None:
    """Executa a política para todos os 12 clientes e imprime os resultados."""
    clientes, produtos = _carregar_dados()

    SEPARADOR = "=" * 70
    ESPERADOS = {
        "C001": "APROVADO",
        "C002": "NEGADO",         # R-007 comprometimento
        "C003": "NEGADO",         # R-003 restrição
        "C004": "APROVADO_COM_RESSALVA",
        "C005": "APROVADO_COM_RESSALVA",
        "C006": "INCONCLUSIVO",   # R-001 dado faltante
        "C007": "APROVADO",
        "C008": "NEGADO",         # R-004 score baixo
        "C009": "APROVADO",
        "C010": "NEGADO",         # R-002 menor de idade
        "C011": "APROVADO_COM_RESSALVA",
        "C012": "NEGADO",         # R-007 comprometimento
    }

    print(SEPARADOR)
    print("TESTES DA POLÍTICA DE CRÉDITO — AURORA BANK v1.0.0")
    print(SEPARADOR)

    acertos = 0
    for cliente in clientes:
        cid = cliente["id"]
        produto = _selecionar_produto(cliente, produtos)
        resultado = avaliar_politica(cliente, produto)

        esperado = ESPERADOS.get(cid, "?")
        ok = "OK" if resultado.decisao == esperado else "FALHOU"
        if resultado.decisao == esperado:
            acertos += 1

        print(f"\n{ok} [{cid}] {cliente['nome']}")
        print(f"   Caso          : {cliente.get('caso_teste','')}")
        print(f"   Produto       : {produto['nome']}")
        print(f"   Decisão       : {resultado.decisao}  (esperado: {esperado})")
        print(f"   Limite        : R$ {resultado.limite_sugerido:,.2f}")
        print(f"   Confiança     : {resultado.confianca:.0%}")
        print(f"   Parcela sim.  : R$ {resultado.parcela_simulada:,.2f}")
        print(f"   Comprometiment: {resultado.comprometimento_pos_credito*100:.1f}%")
        print(f"   Regras        : {[r.codigo for r in resultado.regras_acionadas]}")
        if resultado.dados_faltantes:
            print(f"   Faltantes     : {resultado.dados_faltantes}")

    print(f"\n{SEPARADOR}")
    print(f"RESULTADO: {acertos}/12 acertos")
    print(SEPARADOR)


if __name__ == "__main__":
    rodar_testes()
