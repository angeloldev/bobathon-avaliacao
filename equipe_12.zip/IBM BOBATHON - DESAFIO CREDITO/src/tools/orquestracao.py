"""
orquestracao.py
===============
Orquestrador local do fluxo de decisão de crédito — Aurora Bank.
Versão: 1.0.0
Status: FICTÍCIO — desafio IBM Bobathon.

Este módulo implementa o mesmo fluxo do agente_orquestrador_credito.yaml,
mas em Python puro — para testes locais e demonstrações sem o Orchestrate.

Em produção, esse fluxo é executado pelo watsonx Orchestrate,
que chama cada agente colaborador conforme definido no YAML do orquestrador.
"""

from __future__ import annotations

import json
import sys
import pathlib

# Garante que os módulos locais sejam encontrados
_ROOT = pathlib.Path(__file__).parent.parent
for _p in [str(_ROOT / "tools"), str(_ROOT / "policy")]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from aurora_tools import (  # type: ignore[import]
    buscar_cliente,
    listar_produtos,
    avaliar_politica,
    registrar_decisao,
)


def _unwrap(resp):
    """Desencapsula ToolResponse do SDK do Orchestrate, se necessário."""
    if hasattr(resp, "content"):
        return resp.content
    return resp


# ---------------------------------------------------------------------------
# Mapeamento de finalidade → tipo de produto
# ---------------------------------------------------------------------------
FINALIDADE_PARA_TIPO = {
    "credito_pessoal":    "credito_pessoal",
    "consignado":         "consignado",
    "cartao_credito":     "cartao_credito",
    "capital_de_giro_pj": "capital_de_giro_pj",
}


# ---------------------------------------------------------------------------
# Simulação das "instruções" de cada agente (sem LLM real)
# Em produção, cada bloco abaixo seria substituído por uma chamada ao
# agente Orchestrate correspondente.
# ---------------------------------------------------------------------------

def _simular_agente_carteira(id_cliente: str) -> dict:
    """
    Simula agente_carteira: identifica produtos elegíveis para o cliente.
    Em produção: chamada ao agente_carteira no Orchestrate.
    """
    cliente = _unwrap(buscar_cliente(id_cliente))
    if "erro" in cliente:
        return {"produtos_elegiveis": [], "erro": cliente["erro"]}

    finalidade = cliente.get("finalidade_pedido", "credito_pessoal")
    tipo = FINALIDADE_PARA_TIPO.get(finalidade, "credito_pessoal")
    resultado_produtos = _unwrap(listar_produtos(tipo=tipo))
    produtos = resultado_produtos["produtos"]

    # Filtro básico de público-alvo PF/PJ
    publico_necessario = (
        "pessoa_juridica_mpe"
        if finalidade == "capital_de_giro_pj"
        else "pessoa_fisica"
    )
    elegiveis = [
        p for p in produtos
        if publico_necessario in p.get("publico_alvo", "")
        or p.get("publico_alvo") == publico_necessario
        or (publico_necessario == "pessoa_fisica" and "servidor" in p.get("publico_alvo", ""))
    ]

    return {
        "produtos_elegiveis": elegiveis,
        "finalidade_pedido": finalidade,
        "fonte": "produtos.json v1.0.0",
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }


def _simular_agente_cliente(id_cliente: str) -> dict:
    """
    Simula agente_cliente: analisa perfil e retorna sumário de risco.
    Em produção: chamada ao agente_cliente no Orchestrate.
    """
    cliente = _unwrap(buscar_cliente(id_cliente))
    if "erro" in cliente:
        return {
            "confiabilidade": "BAIXA",
            "dados_faltantes": ["cliente_nao_encontrado"],
            "erro": cliente["erro"],
        }

    CAMPOS_CRITICOS = [
        "renda_comprovada", "score_interno_0_1000",
        "restricao_externa", "parcelas_mensais_atuais",
    ]
    CAMPOS_OPCIONAIS = ["saldo_medio_12m", "divida_total_atual", "atrasos_ultimos_12m"]

    faltantes_criticos = [c for c in CAMPOS_CRITICOS if cliente.get(c) is None]
    faltantes_opcionais = [c for c in CAMPOS_OPCIONAIS if cliente.get(c) is None]
    # atrasos_ultimos_12m é dict — sub-campos
    atrasos = cliente.get("atrasos_ultimos_12m")
    if isinstance(atrasos, dict):
        if atrasos.get("quantidade") is None or atrasos.get("dias_max") is None:
            if "atrasos_ultimos_12m" not in faltantes_criticos:
                faltantes_criticos.append("atrasos_ultimos_12m")

    dados_faltantes = faltantes_criticos + faltantes_opcionais

    if faltantes_criticos:
        confiabilidade = "BAIXA"
    elif len(faltantes_opcionais) >= 2:
        confiabilidade = "BAIXA"
    elif len(faltantes_opcionais) == 1:
        confiabilidade = "MEDIA"
    else:
        confiabilidade = "ALTA"

    # Cálculos auxiliares (somente se dados disponíveis)
    indicadores: dict = {}
    sinalizadores: list[str] = []

    renda = cliente.get("renda_comprovada")
    parcelas = cliente.get("parcelas_mensais_atuais")
    score = cliente.get("score_interno_0_1000")
    restricao = cliente.get("restricao_externa")
    divida = cliente.get("divida_total_atual")
    saldo = cliente.get("saldo_medio_12m")
    atrasos_q = atrasos.get("quantidade") if isinstance(atrasos, dict) else None
    atrasos_d = atrasos.get("dias_max") if isinstance(atrasos, dict) else None
    tempo_rel = cliente.get("tempo_relacionamento_meses")

    indicadores["score_interno"] = score
    indicadores["restricao_externa"] = restricao
    indicadores["qtd_atrasos_12m"] = atrasos_q
    indicadores["dias_max_atraso"] = atrasos_d
    indicadores["tempo_relacionamento_meses"] = tempo_rel
    indicadores["idade"] = cliente.get("idade")

    if renda and parcelas is not None:
        comp = parcelas / renda
        indicadores["comprometimento_atual_pct"] = round(comp * 100, 2)
        if comp > 0.30:
            sinalizadores.append(
                f"ATENCAO: comprometimento atual {comp*100:.1f}% "
                f"(parcelas_mensais_atuais={parcelas} / renda_comprovada={renda})"
            )
    else:
        indicadores["comprometimento_atual_pct"] = None

    if renda and divida is not None:
        indicadores["ratio_divida_renda"] = round(divida / renda, 2)
    else:
        indicadores["ratio_divida_renda"] = None

    if renda and saldo is not None:
        indicadores["cobertura_saldo"] = round(saldo / renda, 2)
    else:
        indicadores["cobertura_saldo"] = None

    if score and score >= 750:
        sinalizadores.append(f"POSITIVO: score alto (score_interno_0_1000={score})")
    elif score and score < 500:
        sinalizadores.append(f"ATENCAO: score baixo (score_interno_0_1000={score})")

    if restricao is True:
        sinalizadores.append("CRITICO: restricao_externa=true")

    if atrasos_q == 0:
        sinalizadores.append(f"POSITIVO: sem atrasos nos ultimos 12 meses (atrasos_ultimos_12m.quantidade=0)")
    elif atrasos_q and atrasos_q > 0:
        sinalizadores.append(
            f"ATENCAO: {atrasos_q} atraso(s) nos ultimos 12 meses, "
            f"maximo {atrasos_d} dias (atrasos_ultimos_12m)"
        )

    resumo = (
        f"Cliente com score {score}, "
        f"comprometimento atual {indicadores.get('comprometimento_atual_pct', 'N/D')}%, "
        f"restricao_externa={restricao}."
    )
    if confiabilidade == "BAIXA":
        resumo += (
            " ATENCAO: sumario INCONCLUSIVO por dados insuficientes. "
            "Encaminhar para analise humana sem prosseguir para o agente_decisor."
        )

    return {
        "id_cliente": id_cliente,
        "nome": cliente.get("nome"),
        "confiabilidade": confiabilidade,
        "dados_faltantes": dados_faltantes,
        "indicadores": indicadores,
        "sinalizadores": sinalizadores,
        "resumo_texto": resumo,
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }


def _simular_agente_justificativa(resultado_decisor: dict, nome_cliente: str) -> dict:
    """
    Simula agente_justificativa: redige carta em linguagem simples.
    Em produção: chamada ao agente_justificativa no Orchestrate (com LLM).
    Aqui usamos templates determinísticos — sem LLM — para o teste local.
    """
    decisao = resultado_decisor.get("decisao", "INCONCLUSIVO")
    limite = resultado_decisor.get("limite_sugerido", 0.0)
    parcela = resultado_decisor.get("parcela_simulada", 0.0)
    comp = resultado_decisor.get("comprometimento_pos_credito", 0.0)
    regras = resultado_decisor.get("regras_acionadas", [])
    faltantes = resultado_decisor.get("dados_faltantes", [])
    dados = resultado_decisor.get("dados_utilizados", {})

    TRADUCAO_REGRAS = {
        "R-001": "ausência de informação obrigatória",
        "R-002": "idade mínima não atingida",
        "R-003": "restrição de crédito registrada",
        "R-004": "histórico de crédito abaixo do necessário",
        "R-005": "histórico de crédito abaixo do mínimo para o produto",
        "R-006": "renda comprovada abaixo do mínimo",
        "R-007": "comprometimento de renda ultrapassaria o limite permitido",
        "R-008": "atrasos recentes identificados (até 30 dias)",
        "R-009": "atraso relevante identificado (até 60 dias)",
        "R-010": "tempo de relacionamento com o banco ainda curto",
        "R-011": "tempo de relacionamento com o banco ainda em fase inicial",
        "R-012": "perfil de crédito na faixa de entrada do produto",
        "R-013": "histórico sólido e de longa data reconhecido",
        "R-014": "histórico de pontualidade reconhecido",
    }

    motivos_legíveis = [
        TRADUCAO_REGRAS.get(r["codigo"], r["codigo"])
        for r in regras
        if r["codigo"] not in ("R-013", "R-014")
    ]

    nome = nome_cliente or "Cliente"

    if decisao == "APROVADO":
        carta = (
            f"Prezado(a) {nome}, "
            f"temos o prazer de informar que seu pedido de crédito foi APROVADO. "
            f"O limite aprovado é de R$ {limite:,.2f}, com parcela estimada de "
            f"R$ {parcela:,.2f}/mês, resultando em comprometimento de renda de "
            f"{comp*100:.1f}% (renda_comprovada=R$ {dados.get('renda_comprovada', 0):,.2f}). "
            f"Seu histórico de relacionamento com o Aurora Bank foi determinante "
            f"para esta decisão. Atenciosamente, Aurora Bank."
        )

    elif decisao == "APROVADO_COM_RESSALVA":
        motivo_str = "; ".join(motivos_legíveis) if motivos_legíveis else "critérios de ressalva"
        carta = (
            f"Prezado(a) {nome}, "
            f"seu pedido de crédito foi APROVADO com limite ajustado de R$ {limite:,.2f}. "
            f"O ajuste ocorreu por: {motivo_str}. "
            f"A parcela estimada é de R$ {parcela:,.2f}/mês, com comprometimento de renda "
            f"de {comp*100:.1f}% (renda_comprovada=R$ {dados.get('renda_comprovada', 0):,.2f}). "
            f"Para solicitar revisão futura, mantenha seu histórico em dia. "
            f"Atenciosamente, Aurora Bank."
        )

    elif decisao == "NEGADO":
        motivo_str = "; ".join(motivos_legíveis) if motivos_legíveis else "critérios da política de crédito"
        carta = (
            f"Prezado(a) {nome}, "
            f"após análise, seu pedido de crédito não pode ser aprovado neste momento. "
            f"Motivo: {motivo_str}. "
            f"Você pode contestar esta decisão pelos canais de atendimento do Aurora Bank "
            f"ou buscar regularização para uma nova análise futura. "
            f"Atenciosamente, Aurora Bank."
        )

    else:  # INCONCLUSIVO
        faltantes_str = (
            ", ".join(faltantes) if faltantes
            else "informações cadastrais pendentes"
        )
        carta = (
            f"Prezado(a) {nome}, "
            f"não foi possível concluir a análise do seu pedido de crédito automaticamente, "
            f"pois as seguintes informações estão pendentes: {faltantes_str}. "
            f"Seu pedido foi encaminhado para um analista humano, que entrará em contato "
            f"em até 2 dias úteis. "
            f"Atenciosamente, Aurora Bank."
        )

    return {
        "carta_texto": carta,
        "decisao_comunicada": decisao,
        "palavras": len(carta.split()),
        "numeros_citados": [
            f"limite_sugerido={limite}",
            f"parcela_simulada={parcela}",
            f"comprometimento_pos_credito={comp}",
        ],
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }


# ---------------------------------------------------------------------------
# Orquestrador principal
# ---------------------------------------------------------------------------

def executar_fluxo_credito(id_cliente: str) -> dict:
    """
    Executa o fluxo completo de decisão de crédito.

    Ordem:
      1. agente_carteira  → produtos elegíveis
      2. agente_cliente   → sumário de risco
      3. agente_decisor   → executa política (tool avaliar_politica)
      4. agente_justificativa → carta ao cliente
      5. registrar_decisao → trilha de auditoria

    Retorna o resultado consolidado.
    """
    print(f"\n{'='*60}")
    print(f"FLUXO DE CREDITO — cliente: {id_cliente}")
    print(f"{'='*60}")

    # ------------------------------------------------------------------
    # PASSO 1 — agente_carteira
    # ------------------------------------------------------------------
    print("\n[PASSO 1] agente_carteira...")
    saida_carteira = _simular_agente_carteira(id_cliente)

    if not saida_carteira.get("produtos_elegiveis"):
        print("  -> Nenhum produto elegível. NEGADO (parada antecipada).")
        carta = {
            "carta_texto": (
                f"Prezado(a) Cliente, não há produtos disponíveis para a "
                f"finalidade solicitada. Atenciosamente, Aurora Bank."
            ),
            "decisao_comunicada": "NEGADO",
        }
        rec = _unwrap(registrar_decisao({
            "id_cliente": id_cliente, "valor_solicitado": 0,
            "decisao_final": "NEGADO",
            "limite": 0.0,
            "justificativa_texto": carta["carta_texto"],
            "regras_acionadas": [],
            "dados_faltantes": [],
            "saida_agente_carteira": saida_carteira,
            "saida_agente_cliente": {},
            "saida_agente_decisor": {},
            "saida_agente_justificativa": carta,
        }))
        return {"decisao_final": "NEGADO", "motivo": "nenhum produto elegível", **rec}

    produto_selecionado = saida_carteira["produtos_elegiveis"][0]
    print(f"  -> Produto selecionado: {produto_selecionado['nome']}")

    # ------------------------------------------------------------------
    # PASSO 2 — agente_cliente
    # ------------------------------------------------------------------
    print("\n[PASSO 2] agente_cliente...")
    saida_cliente = _simular_agente_cliente(id_cliente)
    print(f"  -> Confiabilidade: {saida_cliente['confiabilidade']}")
    if saida_cliente.get("dados_faltantes"):
        print(f"  -> Dados faltantes: {saida_cliente['dados_faltantes']}")

    if saida_cliente["confiabilidade"] == "BAIXA":
        print("  -> Confiabilidade BAIXA. INCONCLUSIVO (parada antecipada).")
        carta = _simular_agente_justificativa(
            {"decisao": "INCONCLUSIVO", "dados_faltantes": saida_cliente["dados_faltantes"],
             "regras_acionadas": [], "dados_utilizados": {}, "limite_sugerido": 0,
             "parcela_simulada": 0, "comprometimento_pos_credito": 0},
            saida_cliente.get("nome"),
        )
        cliente_raw = _unwrap(buscar_cliente(id_cliente))
        rec = _unwrap(registrar_decisao({
            "id_cliente": id_cliente,
            "valor_solicitado": cliente_raw.get("valor_solicitado", 0),
            "decisao_final": "INCONCLUSIVO",
            "limite": 0.0,
            "justificativa_texto": carta["carta_texto"],
            "regras_acionadas": [{
                "codigo": "R-001",
                "descricao": "Dado obrigatório ausente — decisão INCONCLUSIVA.",
                "valor_acionador": f"Campos faltantes: {', '.join(saida_cliente['dados_faltantes'])}",
            }],
            "dados_faltantes": saida_cliente["dados_faltantes"],
            "saida_agente_carteira": saida_carteira,
            "saida_agente_cliente": saida_cliente,
            "saida_agente_decisor": {},
            "saida_agente_justificativa": carta,
        }))
        return {
            "id_cliente": id_cliente,
            "decisao_final": "INCONCLUSIVO",
            "dados_faltantes": saida_cliente["dados_faltantes"],
            "carta_ao_cliente": carta["carta_texto"],
            **rec,
        }

    # ------------------------------------------------------------------
    # PASSO 3 — agente_decisor (chama tool avaliar_politica)
    # ------------------------------------------------------------------
    print("\n[PASSO 3] agente_decisor (avaliar_politica)...")
    cliente_raw = _unwrap(buscar_cliente(id_cliente))
    saida_decisor = _unwrap(avaliar_politica(
        cliente_raw,
        produto_selecionado,
        float(cliente_raw.get("valor_solicitado", 0)),
    ))
    print(f"  -> Decisão: {saida_decisor['decisao']}")
    print(f"  -> Limite:  R$ {saida_decisor['limite_sugerido']:,.2f}")
    print(f"  -> Regras:  {[r['codigo'] for r in saida_decisor['regras_acionadas']]}")

    # ------------------------------------------------------------------
    # PASSO 4 — agente_justificativa
    # ------------------------------------------------------------------
    print("\n[PASSO 4] agente_justificativa...")
    saida_justificativa = _simular_agente_justificativa(
        saida_decisor, saida_cliente.get("nome")
    )
    print(f"  -> Carta ({saida_justificativa['palavras']} palavras): OK")

    # ------------------------------------------------------------------
    # PASSO 5 — registrar_decisao
    # ------------------------------------------------------------------
    print("\n[PASSO 5] registrar_decisao...")
    rec = _unwrap(registrar_decisao({
        "id_cliente": id_cliente,
        "valor_solicitado": cliente_raw.get("valor_solicitado", 0),
        "versao_politica": saida_decisor.get("versao_politica", "1.0.0"),
        "decisao_final": saida_decisor["decisao"],
        "limite": saida_decisor["limite_sugerido"],
        "justificativa_texto": saida_justificativa["carta_texto"],
        "regras_acionadas": saida_decisor["regras_acionadas"],
        "dados_faltantes": saida_decisor.get("dados_faltantes", []),
        "saida_agente_carteira": saida_carteira,
        "saida_agente_cliente": saida_cliente,
        "saida_agente_decisor": saida_decisor,
        "saida_agente_justificativa": saida_justificativa,
    }))
    print(f"  -> id_decisao: {rec['id_decisao']}")
    print(f"  -> hash: {rec['hash_do_payload'][:16]}...")

    resultado_final = {
        "id_cliente": id_cliente,
        "decisao_final": saida_decisor["decisao"],
        "limite": saida_decisor["limite_sugerido"],
        "parcela_simulada": saida_decisor.get("parcela_simulada", 0.0),
        "comprometimento_pos_credito": saida_decisor.get("comprometimento_pos_credito", 0.0),
        "carta_ao_cliente": saida_justificativa["carta_texto"],
        "regras_acionadas": saida_decisor["regras_acionadas"],
        "id_decisao": rec["id_decisao"],
        "timestamp": rec["timestamp"],
        "hash_do_payload": rec["hash_do_payload"],
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }

    print(f"\n{'='*60}")
    print(f"RESULTADO FINAL: {resultado_final['decisao_final']}")
    print(f"CARTA: {saida_justificativa['carta_texto']}")
    print(f"{'='*60}")

    return resultado_final


# ---------------------------------------------------------------------------
# Execução dos 12 clientes
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    CLIENTES_TESTE = [
        "C001", "C002", "C003", "C004", "C005", "C006",
        "C007", "C008", "C009", "C010", "C011", "C012",
    ]

    resultados = []
    for cid in CLIENTES_TESTE:
        r = executar_fluxo_credito(cid)
        resultados.append({
            "id": cid,
            "decisao": r.get("decisao_final"),
            "limite": r.get("limite", 0),
            "id_decisao": r.get("id_decisao"),
        })

    print("\n\n" + "=" * 60)
    print("RESUMO DOS 12 CLIENTES")
    print("=" * 60)
    for r in resultados:
        print(f"  {r['id']}  {r['decisao']:<25}  limite R$ {r['limite']:>10,.2f}  [{r['id_decisao']}]")
