"""
aurora_tools_standalone.py
===========================
Arquivo ÚNICO autocontido para upload no watsonx Orchestrate (SaaS via browser).

Contém:
  - Base de clientes sintéticos embutida (sem dependência de arquivo externo)
  - Base de produtos embutida
  - Política de crédito determinística embutida (R-001…R-014)
  - 4 tools decoradas com @tool prontas para importação

Como usar no Orchestrate (browser):
  Skills & Tools → Import → Python → selecione este arquivo

DADOS 100% FICTÍCIOS — desafio Aurora Bank / IBM Bobathon.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any

# ---------------------------------------------------------------------------
# Stub do @tool para execução local sem SDK
# ---------------------------------------------------------------------------
try:
    from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
    _SDK = True
except ImportError:
    _SDK = False
    def tool(*args, **kwargs):
        def decorator(fn):
            return fn
        return decorator if args and callable(args[0]) is False else (decorator(args[0]) if args else decorator)
    class ToolPermission:
        READ_ONLY = "read_only"
        READ_WRITE = "read_write"

# ---------------------------------------------------------------------------
# BASE DE CLIENTES — embutida
# ---------------------------------------------------------------------------
_CLIENTES_DB: dict[str, dict] = {
  "C001": {"id":"C001","caso_teste":"aprovacao_facil","nome":"Ana Paula Ferreira","cpf_mascarado":"***.234.567-**","idade":38,"uf":"SP","renda_mensal_declarada":12000.0,"renda_comprovada":11500.0,"tempo_relacionamento_meses":84,"saldo_medio_12m":8500.0,"divida_total_atual":5000.0,"parcelas_mensais_atuais":800.0,"score_interno_0_1000":820,"atrasos_ultimos_12m":{"quantidade":0,"dias_max":0},"restricao_externa":False,"produtos_contratados":["conta_corrente","cartao_credito","investimento_cdb"],"finalidade_pedido":"credito_pessoal","valor_solicitado":20000.0},
  "C002": {"id":"C002","caso_teste":"negativa_comprometimento_renda","nome":"Bruno Henrique Souza","cpf_mascarado":"***.456.789-**","idade":31,"uf":"RJ","renda_mensal_declarada":3500.0,"renda_comprovada":3200.0,"tempo_relacionamento_meses":36,"saldo_medio_12m":400.0,"divida_total_atual":18000.0,"parcelas_mensais_atuais":1950.0,"score_interno_0_1000":610,"atrasos_ultimos_12m":{"quantidade":1,"dias_max":12},"restricao_externa":False,"produtos_contratados":["conta_corrente"],"finalidade_pedido":"credito_pessoal","valor_solicitado":15000.0},
  "C003": {"id":"C003","caso_teste":"negativa_restricao_externa","nome":"Carla Mendes Lima","cpf_mascarado":"***.678.901-**","idade":44,"uf":"MG","renda_mensal_declarada":7000.0,"renda_comprovada":6500.0,"tempo_relacionamento_meses":60,"saldo_medio_12m":1200.0,"divida_total_atual":22000.0,"parcelas_mensais_atuais":1100.0,"score_interno_0_1000":430,"atrasos_ultimos_12m":{"quantidade":4,"dias_max":45},"restricao_externa":True,"produtos_contratados":["conta_corrente","cheque_especial"],"finalidade_pedido":"credito_pessoal","valor_solicitado":10000.0},
  "C004": {"id":"C004","caso_teste":"aprovacao_limite_reduzido","nome":"Diego Araujo Nascimento","cpf_mascarado":"***.890.123-**","idade":27,"uf":"BA","renda_mensal_declarada":5000.0,"renda_comprovada":4500.0,"tempo_relacionamento_meses":18,"saldo_medio_12m":1800.0,"divida_total_atual":3000.0,"parcelas_mensais_atuais":700.0,"score_interno_0_1000":680,"atrasos_ultimos_12m":{"quantidade":2,"dias_max":10},"restricao_externa":False,"produtos_contratados":["conta_corrente","cartao_credito"],"finalidade_pedido":"credito_pessoal","valor_solicitado":25000.0},
  "C005": {"id":"C005","caso_teste":"cliente_novo_historico_curto","nome":"Eduarda Cristina Pinto","cpf_mascarado":"***.012.345-**","idade":23,"uf":"PR","renda_mensal_declarada":2800.0,"renda_comprovada":2800.0,"tempo_relacionamento_meses":3,"saldo_medio_12m":350.0,"divida_total_atual":0.0,"parcelas_mensais_atuais":0.0,"score_interno_0_1000":550,"atrasos_ultimos_12m":{"quantidade":0,"dias_max":0},"restricao_externa":False,"produtos_contratados":["conta_corrente"],"finalidade_pedido":"cartao_credito","valor_solicitado":3000.0},
  "C006": {"id":"C006","caso_teste":"dado_faltante_inconclusivo","nome":"Fernando Jose Costa","cpf_mascarado":"***.234.567-**","idade":52,"uf":"RS","renda_mensal_declarada":9000.0,"renda_comprovada":None,"tempo_relacionamento_meses":120,"saldo_medio_12m":None,"divida_total_atual":None,"parcelas_mensais_atuais":None,"score_interno_0_1000":None,"atrasos_ultimos_12m":None,"restricao_externa":None,"produtos_contratados":["conta_corrente","investimento_lci"],"finalidade_pedido":"credito_pessoal","valor_solicitado":30000.0},
  "C007": {"id":"C007","caso_teste":"aprovacao_facil_pj","nome":"Gisele Rocha Barbosa - ME","cpf_mascarado":"N/A (CNPJ: 12.345.678/0001-**)","idade":41,"uf":"SC","renda_mensal_declarada":25000.0,"renda_comprovada":22000.0,"tempo_relacionamento_meses":48,"saldo_medio_12m":15000.0,"divida_total_atual":10000.0,"parcelas_mensais_atuais":1200.0,"score_interno_0_1000":790,"atrasos_ultimos_12m":{"quantidade":0,"dias_max":0},"restricao_externa":False,"produtos_contratados":["conta_pj","cartao_credito_pj","antecipacao_recebiveis"],"finalidade_pedido":"capital_de_giro_pj","valor_solicitado":50000.0},
  "C008": {"id":"C008","caso_teste":"negativa_score_baixo","nome":"Heitor Alves Teixeira","cpf_mascarado":"***.456.789-**","idade":35,"uf":"CE","renda_mensal_declarada":6000.0,"renda_comprovada":5500.0,"tempo_relacionamento_meses":24,"saldo_medio_12m":600.0,"divida_total_atual":8000.0,"parcelas_mensais_atuais":900.0,"score_interno_0_1000":320,"atrasos_ultimos_12m":{"quantidade":6,"dias_max":90},"restricao_externa":False,"produtos_contratados":["conta_corrente"],"finalidade_pedido":"credito_pessoal","valor_solicitado":12000.0},
  "C009": {"id":"C009","caso_teste":"aprovacao_consignado","nome":"Ivone Gomes Cavalcanti","cpf_mascarado":"***.678.901-**","idade":58,"uf":"PE","renda_mensal_declarada":4800.0,"renda_comprovada":4800.0,"tempo_relacionamento_meses":72,"saldo_medio_12m":3200.0,"divida_total_atual":2000.0,"parcelas_mensais_atuais":400.0,"score_interno_0_1000":720,"atrasos_ultimos_12m":{"quantidade":0,"dias_max":0},"restricao_externa":False,"produtos_contratados":["conta_corrente","previdencia_privada"],"finalidade_pedido":"consignado","valor_solicitado":18000.0},
  "C010": {"id":"C010","caso_teste":"negativa_idade_minima","nome":"Joao Pedro Martins","cpf_mascarado":"***.890.123-**","idade":17,"uf":"GO","renda_mensal_declarada":1200.0,"renda_comprovada":1200.0,"tempo_relacionamento_meses":2,"saldo_medio_12m":200.0,"divida_total_atual":0.0,"parcelas_mensais_atuais":0.0,"score_interno_0_1000":500,"atrasos_ultimos_12m":{"quantidade":0,"dias_max":0},"restricao_externa":False,"produtos_contratados":["conta_corrente"],"finalidade_pedido":"cartao_credito","valor_solicitado":1000.0},
  "C011": {"id":"C011","caso_teste":"aprovacao_ressalva_atrasos","nome":"Karen Silvia Drummond","cpf_mascarado":"***.012.345-**","idade":33,"uf":"DF","renda_mensal_declarada":8500.0,"renda_comprovada":8000.0,"tempo_relacionamento_meses":54,"saldo_medio_12m":4500.0,"divida_total_atual":7000.0,"parcelas_mensais_atuais":1000.0,"score_interno_0_1000":660,"atrasos_ultimos_12m":{"quantidade":2,"dias_max":20},"restricao_externa":False,"produtos_contratados":["conta_corrente","cartao_credito","seguro_vida"],"finalidade_pedido":"credito_pessoal","valor_solicitado":20000.0},
  "C012": {"id":"C012","caso_teste":"negativa_divida_alta","nome":"Leonardo Farias Vieira","cpf_mascarado":"***.234.567-**","idade":46,"uf":"AM","renda_mensal_declarada":6500.0,"renda_comprovada":6000.0,"tempo_relacionamento_meses":30,"saldo_medio_12m":500.0,"divida_total_atual":45000.0,"parcelas_mensais_atuais":2800.0,"score_interno_0_1000":540,"atrasos_ultimos_12m":{"quantidade":3,"dias_max":35},"restricao_externa":False,"produtos_contratados":["conta_corrente","cheque_especial"],"finalidade_pedido":"credito_pessoal","valor_solicitado":20000.0},
}

# ---------------------------------------------------------------------------
# BASE DE PRODUTOS — embutida
# ---------------------------------------------------------------------------
_PRODUTOS_DB: list[dict] = [
  {"id":"PROD001","nome":"Credito Pessoal Aurora","tipo":"credito_pessoal","publico_alvo":"pessoa_fisica","taxa_am":0.0299,"prazo_min_meses":6,"prazo_max_meses":60,"limite_min":1000.0,"limite_max":50000.0,"score_minimo":600,"comprometimento_renda_maximo":0.30,"tempo_relacionamento_minimo_meses":6,"restricoes":["Vedado a clientes com restricao externa ativa.","Vedado a menores de 18 anos.","Nao disponivel para CNPJ."]},
  {"id":"PROD002","nome":"Credito Consignado Aurora","tipo":"consignado","publico_alvo":"servidor_publico_ou_aposentado_inss","taxa_am":0.0179,"prazo_min_meses":12,"prazo_max_meses":96,"limite_min":500.0,"limite_max":100000.0,"score_minimo":500,"comprometimento_renda_maximo":0.35,"tempo_relacionamento_minimo_meses":0,"restricoes":["Vedado a clientes com restricao externa ativa.","Exige vinculo empregaticio publico ou beneficio INSS."]},
  {"id":"PROD003","nome":"Cartao de Credito Aurora Flex","tipo":"cartao_credito","publico_alvo":"pessoa_fisica","taxa_am":0.1499,"prazo_min_meses":1,"prazo_max_meses":1,"limite_min":300.0,"limite_max":20000.0,"score_minimo":550,"comprometimento_renda_maximo":0.20,"tempo_relacionamento_minimo_meses":3,"restricoes":["Vedado a clientes com restricao externa ativa.","Vedado a menores de 18 anos."]},
  {"id":"PROD004","nome":"Capital de Giro Aurora PJ","tipo":"capital_de_giro_pj","publico_alvo":"pessoa_juridica_mpe","taxa_am":0.0349,"prazo_min_meses":3,"prazo_max_meses":36,"limite_min":5000.0,"limite_max":200000.0,"score_minimo":600,"comprometimento_renda_maximo":0.25,"tempo_relacionamento_minimo_meses":12,"restricoes":["Vedado a CNPJ com restricao.","Exige CNPJ ativo ha no minimo 24 meses."]},
]
_PRODUTOS_BY_TIPO = {p["tipo"]: p for p in _PRODUTOS_DB}

# ---------------------------------------------------------------------------
# POLÍTICA DETERMINÍSTICA — embutida (R-001…R-014)
# ---------------------------------------------------------------------------
_VERSAO_POLITICA = "1.0.0"
_RENDA_MINIMA = 1500.0
_SCORE_MINIMO_ABSOLUTO = 400
_CAMPOS_OBRIGATORIOS = [
    "idade","renda_comprovada","parcelas_mensais_atuais","score_interno_0_1000",
    "restricao_externa","divida_total_atual","saldo_medio_12m",
    "valor_solicitado","atrasos_ultimos_12m","finalidade_pedido",
]

def _parcela_price(valor: float, taxa_am: float, prazo: int) -> float:
    if taxa_am == 0:
        return round(valor / prazo, 2)
    fator = (taxa_am * (1 + taxa_am) ** prazo) / ((1 + taxa_am) ** prazo - 1)
    return round(valor * fator, 2)

def _campos_faltantes(cliente: dict) -> list[str]:
    faltantes = []
    for campo in _CAMPOS_OBRIGATORIOS:
        v = cliente.get(campo)
        if v is None:
            faltantes.append(campo)
        if campo == "atrasos_ultimos_12m" and isinstance(v, dict):
            if v.get("quantidade") is None or v.get("dias_max") is None:
                if campo not in faltantes:
                    faltantes.append(campo)
    return faltantes

def _executar_politica(cliente: dict, produto: dict, valor_solicitado: float) -> dict:
    """Núcleo da política determinística. Retorna dict com resultado completo."""
    regras: list[dict] = []
    faltantes = _campos_faltantes(cliente)
    if valor_solicitado is None:
        faltantes.append("valor_solicitado")

    # R-001 — Dado faltante
    if faltantes:
        regras.append({"codigo":"R-001","descricao":"Dado obrigatorio ausente — decisao INCONCLUSIVA.","valor_acionador":f"Campos faltantes: {', '.join(faltantes)}"})
        return {"decisao":"INCONCLUSIVO","limite_sugerido":0.0,"produto_recomendado":produto["id"],"regras_acionadas":regras,"dados_utilizados":{},"dados_faltantes":faltantes,"confianca":0.0,"parcela_simulada":0.0,"comprometimento_pos_credito":0.0,"versao_politica":_VERSAO_POLITICA}

    idade = int(cliente["idade"])
    renda = float(cliente["renda_comprovada"])
    parcelas_atuais = float(cliente["parcelas_mensais_atuais"])
    score = int(cliente["score_interno_0_1000"])
    restricao = bool(cliente["restricao_externa"])
    saldo_medio = float(cliente["saldo_medio_12m"])
    atrasos = cliente["atrasos_ultimos_12m"]
    qtd_atrasos = int(atrasos["quantidade"])
    dias_max = int(atrasos["dias_max"])
    tempo_rel = int(cliente.get("tempo_relacionamento_meses", 0))
    taxa_am = float(produto["taxa_am"])
    prazo_max = int(produto["prazo_max_meses"])
    limite_min = float(produto["limite_min"])
    limite_max = float(produto["limite_max"])
    score_min_prod = int(produto["score_minimo"])
    comp_maximo = float(produto["comprometimento_renda_maximo"])

    dados_usados = {"idade":idade,"renda_comprovada":renda,"parcelas_mensais_atuais":parcelas_atuais,"score_interno_0_1000":score,"restricao_externa":restricao,"saldo_medio_12m":saldo_medio,"divida_total_atual":float(cliente["divida_total_atual"]),"valor_solicitado":float(valor_solicitado),"qtd_atrasos_12m":qtd_atrasos,"dias_max_atraso":dias_max,"tempo_relacionamento_meses":tempo_rel,"produto_id":produto["id"],"taxa_am":taxa_am,"prazo_max_meses":prazo_max,"comprometimento_maximo_produto":comp_maximo}

    def _negar(codigo, desc, acionador):
        regras.append({"codigo":codigo,"descricao":desc,"valor_acionador":acionador})
        return {"decisao":"NEGADO","limite_sugerido":0.0,"produto_recomendado":produto["id"],"regras_acionadas":regras,"dados_utilizados":dados_usados,"dados_faltantes":[],"confianca":0.0,"parcela_simulada":0.0,"comprometimento_pos_credito":0.0,"versao_politica":_VERSAO_POLITICA}

    if idade < 18:
        return _negar("R-002","Idade abaixo do minimo legal (18 anos).",f"idade={idade}")
    if restricao:
        return _negar("R-003","Restricao de credito ativa em bureau externo.","restricao_externa=true")
    if score < _SCORE_MINIMO_ABSOLUTO:
        return _negar("R-004",f"Score interno abaixo do minimo absoluto ({_SCORE_MINIMO_ABSOLUTO}).",f"score={score}")
    if score < score_min_prod:
        return _negar("R-005",f"Score interno abaixo do minimo do produto ({score_min_prod}).",f"score={score}, score_minimo_produto={score_min_prod}")
    if renda < _RENDA_MINIMA:
        return _negar("R-006",f"Renda comprovada abaixo do minimo (R$ {_RENDA_MINIMA:,.2f}).",f"renda_comprovada={renda:.2f}")

    # Cálculo de limite bruto
    limite_por_saldo = saldo_medio * 3.0
    limite_por_renda = renda * 4.0
    margem = max((comp_maximo * renda) - parcelas_atuais, 0.0)
    fator_price = _parcela_price(1.0, taxa_am, prazo_max)
    limite_pelo_comp = (margem / fator_price) if fator_price > 0 else 0.0
    limite_bruto = min(limite_por_saldo, limite_por_renda, limite_pelo_comp, limite_max)
    limite_bruto = max(limite_bruto, 0.0)

    valor_sim = min(float(valor_solicitado), limite_bruto) if limite_bruto > 0 else float(valor_solicitado)
    parcela_sim = _parcela_price(valor_sim, taxa_am, prazo_max)
    comp_pos = (parcelas_atuais + parcela_sim) / renda if renda > 0 else 1.0

    if comp_pos > comp_maximo or limite_bruto < limite_min:
        regras.append({"codigo":"R-007","descricao":f"Comprometimento pos-credito ({comp_pos*100:.1f}%) ultrapassa o limite ({comp_maximo*100:.0f}%) ou limite calculado abaixo do minimo do produto.","valor_acionador":f"parcelas_atuais={parcelas_atuais:.2f}, parcela_simulada={parcela_sim:.2f}, renda={renda:.2f}, comprometimento={comp_pos*100:.1f}%"})
        return {"decisao":"NEGADO","limite_sugerido":0.0,"produto_recomendado":produto["id"],"regras_acionadas":regras,"dados_utilizados":dados_usados,"dados_faltantes":[],"confianca":0.0,"parcela_simulada":round(parcela_sim,2),"comprometimento_pos_credito":round(comp_pos,4),"versao_politica":_VERSAO_POLITICA}

    # Soft rules
    limite_final = limite_bruto
    confianca = 0.70
    decisao = "APROVADO"

    if qtd_atrasos >= 2 and dias_max <= 30:
        regras.append({"codigo":"R-008","descricao":"2+ atrasos nos ultimos 12 meses (ate 30 dias). Limite reduzido em 25%.","valor_acionador":f"qtd_atrasos={qtd_atrasos}, dias_max={dias_max}"})
        limite_final *= 0.75; decisao = "APROVADO_COM_RESSALVA"
    if qtd_atrasos >= 1 and 30 < dias_max <= 60:
        regras.append({"codigo":"R-009","descricao":"Atraso entre 31 e 60 dias nos ultimos 12 meses. Limite reduzido em 40%.","valor_acionador":f"qtd_atrasos={qtd_atrasos}, dias_max={dias_max}"})
        limite_final *= 0.60; decisao = "APROVADO_COM_RESSALVA"
    if tempo_rel < 6:
        regras.append({"codigo":"R-010","descricao":"Relacionamento inferior a 6 meses. Limite reduzido em 30%.","valor_acionador":f"tempo_relacionamento_meses={tempo_rel}"})
        limite_final *= 0.70; decisao = "APROVADO_COM_RESSALVA"
    elif 6 <= tempo_rel < 12:
        regras.append({"codigo":"R-011","descricao":"Relacionamento entre 6 e 11 meses. Limite reduzido em 15%.","valor_acionador":f"tempo_relacionamento_meses={tempo_rel}"})
        limite_final *= 0.85; decisao = "APROVADO_COM_RESSALVA"
    if score_min_prod <= score < score_min_prod + 100:
        regras.append({"codigo":"R-012","descricao":f"Score na faixa de entrada do produto ({score_min_prod}-{score_min_prod+99}). Limite reduzido em 20%.","valor_acionador":f"score={score}, score_minimo_produto={score_min_prod}"})
        limite_final *= 0.80; decisao = "APROVADO_COM_RESSALVA"

    # Bonus
    if tempo_rel >= 60 and score >= 750:
        regras.append({"codigo":"R-013","descricao":"Cliente com 5+ anos de relacionamento e score >= 750. Confianca aumentada.","valor_acionador":f"tempo_relacionamento_meses={tempo_rel}, score={score}"})
        confianca += 0.10; limite_final = min(limite_final * 1.10, limite_max)
    if qtd_atrasos == 0 and saldo_medio >= renda * 0.5:
        regras.append({"codigo":"R-014","descricao":"Sem atrasos nos ultimos 12 meses e saldo medio >= 50% da renda. Confianca aumentada.","valor_acionador":f"qtd_atrasos=0, saldo_medio={saldo_medio:.2f}, renda={renda:.2f}"})
        confianca += 0.05

    limite_final = round(min(max(limite_final, limite_min), limite_max), 2)
    if limite_final < limite_min:
        regras.append({"codigo":"R-007","descricao":"Apos ressalvas, limite abaixo do minimo do produto.","valor_acionador":f"limite_apos_ressalvas={limite_final:.2f}, limite_min={limite_min:.2f}"})
        return {"decisao":"NEGADO","limite_sugerido":0.0,"produto_recomendado":produto["id"],"regras_acionadas":regras,"dados_utilizados":dados_usados,"dados_faltantes":[],"confianca":0.0,"parcela_simulada":round(parcela_sim,2),"comprometimento_pos_credito":round(comp_pos,4),"versao_politica":_VERSAO_POLITICA}

    return {"decisao":decisao,"limite_sugerido":limite_final,"produto_recomendado":produto["id"],"regras_acionadas":regras,"dados_utilizados":dados_usados,"dados_faltantes":[],"confianca":round(min(confianca,1.0),4),"parcela_simulada":round(parcela_sim,2),"comprometimento_pos_credito":round(comp_pos,4),"versao_politica":_VERSAO_POLITICA}

# ---------------------------------------------------------------------------
# TOOL 1 — buscar_cliente
# ---------------------------------------------------------------------------
@tool(
    name="buscar_cliente",
    description="Retorna os dados completos de um cliente Aurora Bank pelo id (ex: C001). DADOS FICTÍCIOS — desafio IBM Bobathon.",
)
def buscar_cliente(id_cliente: str) -> dict:
    """
    Busca cliente pelo ID na base sintética do Aurora Bank.

    Parameters
    ----------
    id_cliente : str
        ID do cliente. Valores válidos: C001 até C012.

    Returns
    -------
    dict com todos os campos do cliente, ou {'erro': '...'} se não encontrado.
    """
    cliente = _CLIENTES_DB.get(id_cliente.upper().strip())
    if cliente is None:
        return {"erro": f"Cliente '{id_cliente}' nao encontrado.", "id_cliente": id_cliente, "dados_faltantes": ["todos"]}
    return dict(cliente)

# ---------------------------------------------------------------------------
# TOOL 2 — listar_produtos
# ---------------------------------------------------------------------------
@tool(
    name="listar_produtos",
    description="Retorna os produtos de crédito do Aurora Bank. Aceita filtro opcional por tipo. DADOS FICTÍCIOS — desafio IBM Bobathon.",
)
def listar_produtos(tipo: str = "") -> dict:
    """
    Lista produtos de crédito do catálogo Aurora Bank.

    Parameters
    ----------
    tipo : str, opcional
        Filtro pelo tipo do produto. Valores: 'credito_pessoal', 'consignado',
        'cartao_credito', 'capital_de_giro_pj'. Vazio = retorna todos.

    Returns
    -------
    dict com lista 'produtos' e metadados.
    """
    produtos = _PRODUTOS_DB if not tipo else [p for p in _PRODUTOS_DB if p.get("tipo") == tipo]
    return {"produtos": produtos, "total": len(produtos), "fonte": "produtos_db v1.0.0", "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon."}

# ---------------------------------------------------------------------------
# TOOL 3 — avaliar_politica
# ---------------------------------------------------------------------------
@tool(
    name="avaliar_politica",
    description=(
        "Executa a política determinística de crédito Aurora Bank v1.0.0. "
        "Recebe id_cliente, id_produto e valor_solicitado. "
        "Retorna decisao (APROVADO/APROVADO_COM_RESSALVA/NEGADO/INCONCLUSIVO), "
        "limite_sugerido, parcela_simulada, comprometimento_pos_credito, "
        "regras_acionadas com código e valor acionador, dados_utilizados e dados_faltantes. "
        "A decisão é 100% determinística. O LLM NUNCA deve alterar este retorno. "
        "DADOS FICTÍCIOS — desafio IBM Bobathon."
    ),
)
def avaliar_politica(id_cliente: str, id_produto: str, valor_solicitado: float) -> dict:
    """
    Avalia pedido de crédito pela política determinística.

    Parameters
    ----------
    id_cliente      : str   — ID do cliente (ex: 'C001')
    id_produto      : str   — ID do produto (ex: 'PROD001')
    valor_solicitado: float — Valor pleiteado em reais

    Returns
    -------
    dict com decisao, limite_sugerido, regras_acionadas, dados_utilizados, dados_faltantes.
    """
    cliente = _CLIENTES_DB.get(id_cliente.upper().strip())
    if cliente is None:
        return {"decisao": "INCONCLUSIVO", "erro": f"Cliente '{id_cliente}' nao encontrado.", "dados_faltantes": ["cliente_nao_encontrado"], "limite_sugerido": 0.0, "regras_acionadas": [{"codigo": "R-001", "descricao": "Cliente nao encontrado na base.", "valor_acionador": f"id_cliente={id_cliente}"}], "versao_politica": _VERSAO_POLITICA}

    produto = next((p for p in _PRODUTOS_DB if p["id"] == id_produto), None)
    if produto is None:
        produto = _PRODUTOS_BY_TIPO.get(cliente.get("finalidade_pedido", "credito_pessoal"), _PRODUTOS_DB[0])

    cliente_copia = dict(cliente)
    cliente_copia["valor_solicitado"] = valor_solicitado
    return _executar_politica(cliente_copia, produto, valor_solicitado)

# ---------------------------------------------------------------------------
# TOOL 4 — registrar_decisao
# ---------------------------------------------------------------------------
@tool(
    name="registrar_decisao",
    description=(
        "Registra a decisão de crédito na trilha de auditoria. "
        "Retorna id_decisao único e hash SHA-256 do payload para verificação de integridade. "
        "DADOS FICTÍCIOS — desafio IBM Bobathon."
    ),
)
def registrar_decisao(
    id_cliente: str,
    decisao_final: str,
    limite: float,
    justificativa_texto: str,
    regras_acionadas: list,
    dados_faltantes: list,
    valor_solicitado: float = 0.0,
    versao_politica: str = "1.0.0",
) -> dict:
    """
    Grava registro de auditoria da decisão de crédito.

    Parameters
    ----------
    id_cliente          : str   — ID do cliente
    decisao_final       : str   — APROVADO | APROVADO_COM_RESSALVA | NEGADO | INCONCLUSIVO
    limite              : float — Limite aprovado (0 para NEGADO/INCONCLUSIVO)
    justificativa_texto : str   — Texto da carta ao cliente
    regras_acionadas    : list  — Lista de regras da política que foram acionadas
    dados_faltantes     : list  — Lista de campos ausentes (vazia se completo)
    valor_solicitado    : float — Valor pleiteado
    versao_politica     : str   — Versão da política usada

    Returns
    -------
    dict com id_decisao, timestamp e hash_do_payload.
    """
    id_decisao = f"DEC-{uuid.uuid4().hex[:12].upper()}"
    timestamp = datetime.now(timezone.utc).isoformat()

    registro = {
        "id_decisao": id_decisao,
        "timestamp": timestamp,
        "versao_politica": versao_politica,
        "id_cliente": id_cliente,
        "valor_solicitado": valor_solicitado,
        "decisao_final": decisao_final,
        "limite": limite,
        "justificativa_texto": justificativa_texto,
        "regras_acionadas": regras_acionadas,
        "dados_faltantes": dados_faltantes,
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }
    payload_str = str(sorted(registro.items()))
    hash_payload = hashlib.sha256(payload_str.encode("utf-8")).hexdigest()
    registro["hash_do_payload"] = hash_payload

    return {
        "id_decisao": id_decisao,
        "timestamp": timestamp,
        "hash_do_payload": hash_payload,
        "status": "gravado",
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }
