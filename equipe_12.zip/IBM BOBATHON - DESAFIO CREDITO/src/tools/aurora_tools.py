"""
aurora_tools.py
===============
Tools do watsonx Orchestrate para o fluxo de decisão de crédito — Aurora Bank.
Versão: 1.0.0
Status: FICTÍCIO — desafio IBM Bobathon.

CONVENÇÃO DE IMPORTAÇÃO NO ORCHESTRATE:
    orchestrate tools import -k python -f aurora_tools.py

Cada função decorada com @tool é registrada como uma skill individual.

NOTA SOBRE @tool:
    O decorador @tool é fornecido pelo SDK `ibm-watsonx-orchestrate`.
    Se você estiver rodando localmente sem o SDK instalado, o stub
    abaixo emula o comportamento para fins de teste.
    Instale o SDK real com: pip install ibm-watsonx-orchestrate
"""

from __future__ import annotations

import hashlib
import json
import pathlib
import uuid
from datetime import datetime, timezone
from typing import Any

# ---------------------------------------------------------------------------
# Stub do decorador @tool para execução local sem o SDK do Orchestrate
# ---------------------------------------------------------------------------
try:
    from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
    _SDK_DISPONIVEL = True
except ImportError:
    # Stub: em produção, instale o SDK real.
    # Referência: https://developer.ibm.com/components/watsonx-orchestrate/
    _SDK_DISPONIVEL = False

    def tool(*args, **kwargs):  # type: ignore[misc]
        """Stub de @tool para execução local sem o SDK do Orchestrate."""
        def decorator(fn):
            fn._is_tool = True
            fn._tool_name = kwargs.get("name", fn.__name__)
            fn._tool_description = kwargs.get("description", fn.__doc__ or "")
            return fn
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator

    class ToolPermission:  # type: ignore[misc]
        READ_ONLY = "read_only"
        READ_WRITE = "read_write"


# ---------------------------------------------------------------------------
# Caminhos dos dados sintéticos
# ---------------------------------------------------------------------------
_BASE_DIR = pathlib.Path(__file__).parent.parent
_CLIENTES_PATH = _BASE_DIR / "data" / "clientes.json"
_PRODUTOS_PATH = _BASE_DIR / "data" / "produtos.json"
_AUDIT_DIR = _BASE_DIR / "audit"
_AUDIT_DIR.mkdir(exist_ok=True)
_AUDIT_PATH = _AUDIT_DIR / "trilha_auditoria.jsonl"

# ---------------------------------------------------------------------------
# Cache em memória (evita I/O repetido nos testes)
# ---------------------------------------------------------------------------
_cache_clientes: dict[str, dict] | None = None
_cache_produtos: list[dict] | None = None


def _load_clientes() -> dict[str, dict]:
    global _cache_clientes
    if _cache_clientes is None:
        with open(_CLIENTES_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        _cache_clientes = {c["id"]: c for c in raw["clientes"]}
    return _cache_clientes


def _load_produtos() -> list[dict]:
    global _cache_produtos
    if _cache_produtos is None:
        with open(_PRODUTOS_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        _cache_produtos = raw["produtos"]
    return _cache_produtos


def _hash_payload(payload: dict) -> str:
    """SHA-256 do payload serializado — para integridade da trilha."""
    serialized = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


# ===========================================================================
# TOOL 1 — buscar_cliente
# ===========================================================================

@tool(
    name="buscar_cliente",
    description=(
        "Retorna os dados completos de um cliente do Aurora Bank pelo seu id "
        "(ex.: 'C001'). Se o cliente não for encontrado, retorna um objeto "
        "com 'erro' descrevendo o problema. "
        "DADOS FICTÍCIOS — desafio IBM Bobathon."
    ),
    permission=ToolPermission.READ_ONLY if _SDK_DISPONIVEL else "read_only",
)
def buscar_cliente(id_cliente: str) -> dict:
    """
    Busca um cliente pelo ID na base sintética.

    Parâmetros
    ----------
    id_cliente : str
        ID do cliente (ex.: "C001", "C006").

    Retorno
    -------
    dict com todos os campos do cliente, ou {"erro": "...", "id_cliente": "..."}
    se não encontrado.
    """
    clientes = _load_clientes()
    cliente = clientes.get(id_cliente.upper().strip())
    if cliente is None:
        return {
            "erro": f"Cliente '{id_cliente}' não encontrado na base sintética.",
            "id_cliente": id_cliente,
            "dados_faltantes": ["todos"],
        }
    return dict(cliente)  # cópia defensiva


# ===========================================================================
# TOOL 2 — listar_produtos
# ===========================================================================

@tool(
    name="listar_produtos",
    description=(
        "Retorna todos os produtos de crédito do catálogo Aurora Bank, "
        "incluindo taxas, prazos, limites, score mínimo e restrições. "
        "Também aceita filtro opcional por tipo de produto. "
        "DADOS FICTÍCIOS — desafio IBM Bobathon."
    ),
    permission=ToolPermission.READ_ONLY if _SDK_DISPONIVEL else "read_only",
)
def listar_produtos(tipo: str | None = None) -> dict:
    """
    Lista os produtos de crédito do Aurora Bank.

    Parâmetros
    ----------
    tipo : str, opcional
        Filtro pelo campo 'tipo' do produto. Valores válidos:
        'credito_pessoal', 'consignado', 'cartao_credito',
        'capital_de_giro_pj'. Se None, retorna todos.

    Retorno
    -------
    dict com 'produtos' (list) e metadados.
    """
    produtos = _load_produtos()
    if tipo:
        produtos = [p for p in produtos if p.get("tipo") == tipo]
    return {
        "produtos": produtos,
        "total": len(produtos),
        "fonte": "produtos.json v1.0.0",
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }


# ===========================================================================
# TOOL 3 — avaliar_politica
# ===========================================================================

@tool(
    name="avaliar_politica",
    description=(
        "Executa a política determinística de crédito do Aurora Bank v1.0.0. "
        "Recebe o dict do cliente, o dict do produto e o valor solicitado. "
        "Retorna decisão (APROVADO/APROVADO_COM_RESSALVA/NEGADO/INCONCLUSIVO), "
        "limite sugerido, parcela simulada, comprometimento de renda, "
        "regras acionadas com código e valor acionador, dados utilizados "
        "e dados faltantes. "
        "A decisão é 100% determinística — o mesmo input sempre produz "
        "o mesmo output. O LLM NUNCA deve alterar o retorno desta tool."
    ),
    permission=ToolPermission.READ_ONLY if _SDK_DISPONIVEL else "read_only",
)
def avaliar_politica(
    cliente: dict,
    produto: dict,
    valor_solicitado: float,
) -> dict:
    """
    Executa a política de crédito Aurora Bank.

    Parâmetros
    ----------
    cliente          : dict com os campos de clientes.json
    produto          : dict com os campos de produtos.json
    valor_solicitado : float — valor pleiteado pelo cliente

    Retorno
    -------
    dict com todos os campos de ResultadoPolitica (ver politica_credito.py).
    """
    # Importação local para evitar dependência circular na inicialização do SDK
    import sys
    import pathlib as _pl
    _policy_dir = str(_pl.Path(__file__).parent.parent / "policy")
    if _policy_dir not in sys.path:
        sys.path.insert(0, _policy_dir)

    from politica_credito import avaliar_politica as _avaliar  # type: ignore[import]

    # Sobrescreve valor_solicitado no cliente para garantir consistência
    cliente_copia = dict(cliente)
    cliente_copia["valor_solicitado"] = valor_solicitado

    resultado = _avaliar(cliente_copia, produto, valor_solicitado)
    return resultado.to_dict()


# ===========================================================================
# TOOL 4 — registrar_decisao
# ===========================================================================

@tool(
    name="registrar_decisao",
    description=(
        "Grava a decisão de crédito completa na trilha de auditoria (JSONL). "
        "Deve ser chamada pelo agente_decisor ou pelo orquestrador APÓS a "
        "decisão estar formada. Retorna o id_decisao gerado e o hash do "
        "payload para verificação de integridade. "
        "DADOS FICTÍCIOS — desafio IBM Bobathon."
    ),
    permission=ToolPermission.READ_WRITE if _SDK_DISPONIVEL else "read_write",
)
def registrar_decisao(payload: dict) -> dict:
    """
    Grava um registro de auditoria completo.

    Parâmetros
    ----------
    payload : dict com os campos obrigatórios:
        - id_cliente (str)
        - valor_solicitado (float)
        - decisao_final (str)
        - limite (float)
        - justificativa_texto (str)
        - regras_acionadas (list)
        - dados_faltantes (list)
        - saida_agente_carteira (dict)
        - saida_agente_cliente (dict)
        - saida_agente_decisor (dict)
        - saida_agente_justificativa (dict)

    Retorno
    -------
    dict com id_decisao, timestamp e hash_payload.
    """
    id_decisao = f"DEC-{uuid.uuid4().hex[:12].upper()}"
    timestamp = datetime.now(timezone.utc).isoformat()

    registro: dict[str, Any] = {
        "id_decisao": id_decisao,
        "timestamp": timestamp,
        "versao_politica": payload.get("versao_politica", "1.0.0"),
        "id_cliente": payload.get("id_cliente", "DESCONHECIDO"),
        "valor_solicitado": payload.get("valor_solicitado", 0.0),
        "agentes_acionados": [
            {
                "agente": "agente_carteira",
                "entrada_resumida": {"id_cliente": payload.get("id_cliente")},
                "saida_resumida": _resumir(payload.get("saida_agente_carteira", {})),
            },
            {
                "agente": "agente_cliente",
                "entrada_resumida": {"id_cliente": payload.get("id_cliente")},
                "saida_resumida": _resumir(payload.get("saida_agente_cliente", {})),
            },
            {
                "agente": "agente_decisor",
                "entrada_resumida": {
                    "id_cliente": payload.get("id_cliente"),
                    "produto": payload.get("saida_agente_decisor", {}).get("produto_avaliado"),
                    "valor_solicitado": payload.get("valor_solicitado"),
                },
                "saida_resumida": _resumir(payload.get("saida_agente_decisor", {})),
            },
            {
                "agente": "agente_justificativa",
                "entrada_resumida": {"decisao": payload.get("decisao_final")},
                "saida_resumida": _resumir(payload.get("saida_agente_justificativa", {})),
            },
        ],
        "decisao_final": payload.get("decisao_final", "INCONCLUSIVO"),
        "limite": payload.get("limite", 0.0),
        "justificativa_texto": payload.get("justificativa_texto", ""),
        "regras_acionadas": payload.get("regras_acionadas", []),
        "dados_faltantes": payload.get("dados_faltantes", []),
        "aviso": "DADOS FICTÍCIOS — desafio IBM Bobathon.",
    }

    hash_payload = _hash_payload(registro)
    registro["hash_do_payload"] = hash_payload

    # Grava em JSONL (append — cada linha é um registro independente)
    with open(_AUDIT_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(registro, ensure_ascii=False, default=str) + "\n")

    return {
        "id_decisao": id_decisao,
        "timestamp": timestamp,
        "hash_do_payload": hash_payload,
        "arquivo_auditoria": str(_AUDIT_PATH),
        "status": "gravado",
    }


def _resumir(obj: dict, max_keys: int = 6) -> dict:
    """Retorna as primeiras max_keys chaves de um dict — para o resumo da trilha."""
    if not isinstance(obj, dict):
        return {"valor": str(obj)[:120]}
    chaves = list(obj.keys())[:max_keys]
    return {k: obj[k] for k in chaves}


# ===========================================================================
# Teste local das tools (sem o SDK)
# ===========================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("TESTE LOCAL DAS TOOLS — AURORA BANK")
    print("SDK Orchestrate disponível:", _SDK_DISPONIVEL)
    print("=" * 60)

    # --- buscar_cliente ---
    print("\n[buscar_cliente] C001:")
    c = buscar_cliente("C001")
    print(f"  nome: {c['nome']}, score: {c['score_interno_0_1000']}")

    print("\n[buscar_cliente] C006 (dados faltantes):")
    c6 = buscar_cliente("C006")
    print(f"  renda_comprovada: {c6['renda_comprovada']}")

    print("\n[buscar_cliente] C999 (inexistente):")
    cx = buscar_cliente("C999")
    print(f"  {cx}")

    # --- listar_produtos ---
    print("\n[listar_produtos] todos:")
    p = listar_produtos()
    for prod in p["produtos"]:
        print(f"  {prod['id']} — {prod['nome']} — taxa {prod['taxa_am']*100:.2f}% am")

    print("\n[listar_produtos] filtro consignado:")
    pc = listar_produtos(tipo="consignado")
    print(f"  total: {pc['total']}")

    # --- avaliar_politica ---
    print("\n[avaliar_politica] C001 + PROD001:")
    cliente_c001 = buscar_cliente("C001")
    produto_p001 = listar_produtos(tipo="credito_pessoal")["produtos"][0]
    res = avaliar_politica(cliente_c001, produto_p001, 20000.0)
    print(f"  decisao: {res['decisao']}, limite: R$ {res['limite_sugerido']:,.2f}")
    print(f"  regras: {[r['codigo'] for r in res['regras_acionadas']]}")

    # --- registrar_decisao ---
    print("\n[registrar_decisao] C001:")
    jus_mock = {"carta_texto": "Prezado(a) Ana Paula, seu crédito foi aprovado.", "decisao_comunicada": "APROVADO"}
    rec = registrar_decisao({
        "id_cliente": "C001",
        "valor_solicitado": 20000.0,
        "decisao_final": res["decisao"],
        "limite": res["limite_sugerido"],
        "justificativa_texto": jus_mock["carta_texto"],
        "regras_acionadas": res["regras_acionadas"],
        "dados_faltantes": res["dados_faltantes"],
        "versao_politica": res["versao_politica"],
        "saida_agente_carteira": {"produtos_elegiveis": [produto_p001]},
        "saida_agente_cliente": {"confiabilidade": "ALTA", "score_interno": 820},
        "saida_agente_decisor": res,
        "saida_agente_justificativa": jus_mock,
    })
    print(f"  id_decisao: {rec['id_decisao']}")
    print(f"  hash: {rec['hash_do_payload'][:16]}...")
    print(f"  arquivo: {rec['arquivo_auditoria']}")

    print("\n" + "=" * 60)
    print("TODOS OS TESTES PASSARAM")
    print("=" * 60)
