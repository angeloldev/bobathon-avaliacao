# Diagrama de Fluxo — Aurora Bank Credit Decision
# Arquivo de referência para o README e apresentação.
# O diagrama abaixo é renderizável em qualquer editor Mermaid.

```mermaid
flowchart TD
    %% ── Entrada ──────────────────────────────────────────────────
    INICIO([" Pedido de Crédito\n{id_cliente, valor_solicitado} "])
    INICIO --> ORC

    %% ── Orquestrador ─────────────────────────────────────────────
    subgraph ORC["🎯 agente_orquestrador_credito"]
        direction TB

        %% PASSO 1
        P1["PASSO 1\nagente_carteira\n(listar_produtos + buscar_cliente)"]
        CHK1{Produtos\nelegíveis?}
        P1 --> CHK1

        %% PASSO 2
        P2["PASSO 2\nagente_cliente\n(buscar_cliente → sumário de risco)"]
        CHK2{Confiabilidade\n== BAIXA?}
        CHK1 -->|Sim| P2
        P2 --> CHK2

        %% PASSO 3
        P3["PASSO 3\nagente_decisor\n(tool: avaliar_politica)"]
        CHK3{Decisão\nda política}
        CHK2 -->|Não| P3
        P3 --> CHK3

        %% PASSO 4
        P4["PASSO 4\nagente_justificativa\n(redigir carta ao cliente)"]

        %% PASSO 5
        P5["PASSO 5\nregistrar_decisao\n(trilha JSONL + hash SHA-256)"]
    end

    %% ── Paradas antecipadas ──────────────────────────────────────
    CHK1 -->|Não| NEG_PROD["NEGADO\nnenhum produto\nelegível"]
    NEG_PROD --> P5

    CHK2 -->|Sim| INC_DADOS["INCONCLUSIVO\ndados insuficientes\n→ análise humana"]
    INC_DADOS --> P5

    %% ── Ramos de decisão ─────────────────────────────────────────
    CHK3 -->|APROVADO| APR["APROVADO\nlimite calculado\nconfiança alta"]
    CHK3 -->|APROVADO_COM_RESSALVA| RES["APROVADO\nCOM RESSALVA\nlimite reduzido"]
    CHK3 -->|NEGADO| NEG["NEGADO\nhard rule\nacionada"]
    CHK3 -->|INCONCLUSIVO\n(R-001)| INC2["INCONCLUSIVO\ndados faltantes\n→ análise humana"]

    APR  --> P4
    RES  --> P4
    NEG  --> P4
    INC2 --> P4

    P4 --> P5

    %% ── Saídas ────────────────────────────────────────────────────
    P5 --> SAIDA([" Resultado Final\n{decisao, limite, carta, id_decisao, hash} "])

    %% ── Estilos ───────────────────────────────────────────────────
    style INICIO fill:#dbeafe,stroke:#3b82f6,color:#1e3a5f
    style SAIDA  fill:#dcfce7,stroke:#16a34a,color:#14532d

    style APR   fill:#dcfce7,stroke:#16a34a,color:#14532d
    style RES   fill:#fef9c3,stroke:#ca8a04,color:#713f12
    style NEG   fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    style NEG_PROD fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    style INC_DADOS fill:#f3e8ff,stroke:#9333ea,color:#3b0764
    style INC2  fill:#f3e8ff,stroke:#9333ea,color:#3b0764

    style P1 fill:#f0f9ff,stroke:#0284c7
    style P2 fill:#f0f9ff,stroke:#0284c7
    style P3 fill:#f0f9ff,stroke:#0284c7
    style P4 fill:#f0f9ff,stroke:#0284c7
    style P5 fill:#f0f9ff,stroke:#0284c7
```
