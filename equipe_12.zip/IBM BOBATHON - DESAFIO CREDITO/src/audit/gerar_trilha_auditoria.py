"""
gerar_trilha_auditoria.py
=========================
Gera exemplos reais preenchidos da trilha de auditoria para 3 clientes:
  - C001: APROVADO
  - C003: NEGADO
  - C006: INCONCLUSIVO

Executa o fluxo completo de cada cliente, captura os registros gravados
em trilha_auditoria.jsonl e os exporta para trilha_exemplos.json
com formatação legível.

Uso:
    python src/audit/gerar_trilha_auditoria.py
"""

from __future__ import annotations

import json
import pathlib
import sys

# Garante que os módulos locais sejam encontrados
_ROOT = pathlib.Path(__file__).parent.parent
for _p in [str(_ROOT / "tools"), str(_ROOT / "policy")]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from orquestracao import executar_fluxo_credito  # type: ignore[import]
from aurora_tools import _AUDIT_PATH             # type: ignore[import]

_AUDIT_DIR = pathlib.Path(__file__).parent
_EXEMPLOS_PATH = _AUDIT_DIR / "trilha_exemplos.json"


def _ler_ultimo_registro_por_cliente(id_cliente: str) -> dict | None:
    """Lê o registro mais recente para um dado id_cliente do arquivo JSONL."""
    if not _AUDIT_PATH.exists():
        return None
    registros = []
    with open(_AUDIT_PATH, encoding="utf-8") as f:
        for linha in f:
            linha = linha.strip()
            if not linha:
                continue
            try:
                rec = json.loads(linha)
                if rec.get("id_cliente") == id_cliente:
                    registros.append(rec)
            except json.JSONDecodeError:
                continue
    return registros[-1] if registros else None


def main() -> None:
    clientes_exemplo = [
        ("C001", "APROVADO"),
        ("C003", "NEGADO"),
        ("C006", "INCONCLUSIVO"),
    ]

    print("=" * 60)
    print("GERANDO TRILHA DE AUDITORIA — 3 EXEMPLOS")
    print("=" * 60)

    for id_cliente, decisao_esperada in clientes_exemplo:
        print(f"\n-> Executando fluxo para {id_cliente} (esperado: {decisao_esperada})...")
        executar_fluxo_credito(id_cliente)

    # Lê os registros gravados
    exemplos = []
    for id_cliente, _ in clientes_exemplo:
        rec = _ler_ultimo_registro_por_cliente(id_cliente)
        if rec:
            exemplos.append(rec)
            print(f"   {id_cliente}: id_decisao={rec['id_decisao']}, decisao={rec['decisao_final']}")
        else:
            print(f"   {id_cliente}: NENHUM REGISTRO ENCONTRADO")

    # Salva como JSON formatado para leitura humana
    saida = {
        "_aviso": "DADOS 100% FICTÍCIOS — gerados para o desafio Aurora Bank / IBM Bobathon.",
        "_schema": "src/audit/trilha_schema.json",
        "_versao_politica": "1.0.0",
        "_descricao": (
            "Exemplos reais da trilha de auditoria para 3 casos: "
            "C001 (APROVADO), C003 (NEGADO), C006 (INCONCLUSIVO)."
        ),
        "registros": exemplos,
    }

    with open(_EXEMPLOS_PATH, "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n\nExemplos gravados em: {_EXEMPLOS_PATH}")
    print(f"Total de registros  : {len(exemplos)}")
    print("=" * 60)


if __name__ == "__main__":
    main()
