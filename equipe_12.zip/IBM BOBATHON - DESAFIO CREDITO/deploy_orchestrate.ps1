# deploy_orchestrate.ps1
# ======================
# Script de deploy completo para o watsonx Orchestrate (SaaS).
# Executa: configuracao do ambiente + import das tools + import dos 5 agentes.
#
# USO:
#   .\deploy_orchestrate.ps1
#
# O script vai pedir sua API Key de forma segura (sem exibir no terminal).
# Nunca salve sua API key em texto plano em arquivos.

$ErrorActionPreference = "Stop"
$env:PYTHONIOENCODING = "utf-8"

# ---------------------------------------------------------------------------
# Configuracao
# ---------------------------------------------------------------------------
$ORCHESTRATE_URL = "https://ap-southeast-1.dl.watson-orchestrate.ibm.com"
$ENV_NAME        = "aurora-bobathon"
$TOOLS_FILE      = "src\tools\aurora_tools_standalone.py"
$AGENTS = @(
    "src\agents\agente_carteira.yaml",
    "src\agents\agente_cliente.yaml",
    "src\agents\agente_decisor.yaml",
    "src\agents\agente_justificativa.yaml",
    "src\agents\agente_orquestrador_credito.yaml"
)

# Helper para invocar o CLI do Orchestrate via Python
function Invoke-Orchestrate {
    param([string[]]$Args)
    $result = python -c "
import sys
from ibm_watsonx_orchestrate.cli.main import app
from click.testing import CliRunner
runner = CliRunner(mix_stderr=False)
result = runner.invoke(app, sys.argv[1:], catch_exceptions=False)
print(result.output)
if result.exit_code != 0:
    sys.exit(result.exit_code)
" -- @Args 2>&1
    return $result
}

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  DEPLOY — Aurora Bank / IBM Bobathon / Grupo 12" -ForegroundColor Cyan
Write-Host "  Tenant: $ORCHESTRATE_URL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------------------
# PASSO 0 — Verificar pre-requisitos
# ---------------------------------------------------------------------------
Write-Host "[0/7] Verificando pre-requisitos..." -ForegroundColor Yellow

try {
    $version = python -c "import ibm_watsonx_orchestrate; print(ibm_watsonx_orchestrate.__version__)"
    Write-Host "      SDK ibm-watsonx-orchestrate: $version" -ForegroundColor Green
} catch {
    Write-Host "ERRO: SDK nao encontrado. Execute: pip install ibm-watsonx-orchestrate" -ForegroundColor Red
    exit 1
}

foreach ($f in @($TOOLS_FILE) + $AGENTS) {
    if (-not (Test-Path $f)) {
        Write-Host "ERRO: Arquivo nao encontrado: $f" -ForegroundColor Red
        exit 1
    }
}
Write-Host "      Todos os arquivos encontrados." -ForegroundColor Green

# ---------------------------------------------------------------------------
# PASSO 1 — Coletar API Key (de forma segura)
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/7] Autenticacao..." -ForegroundColor Yellow
Write-Host "      Para obter sua API Key:" -ForegroundColor Gray
Write-Host "      Acesse o Orchestrate > perfil (avatar) > API keys > Generate new key" -ForegroundColor Gray
Write-Host ""

$apiKeySecure = Read-Host "      Cole sua IBM Cloud API Key aqui" -AsSecureString
$apiKey = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($apiKeySecure)
)

if (-not $apiKey -or $apiKey.Length -lt 20) {
    Write-Host "ERRO: API Key invalida ou muito curta." -ForegroundColor Red
    exit 1
}
Write-Host "      API Key recebida (comprimento: $($apiKey.Length) chars)." -ForegroundColor Green

# ---------------------------------------------------------------------------
# PASSO 2 — Configurar ambiente
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/7] Configurando ambiente '$ENV_NAME'..." -ForegroundColor Yellow

$env:ORCHESTRATE_API_KEY = $apiKey

python -c "
import os, sys
from ibm_watsonx_orchestrate.cli.main import app
from click.testing import CliRunner

url = '$ORCHESTRATE_URL'
name = '$ENV_NAME'
apikey = os.environ['ORCHESTRATE_API_KEY']

runner = CliRunner(mix_stderr=False)

# Adicionar ambiente
result = runner.invoke(app, ['env', 'add', '--name', name, '--url', url], catch_exceptions=False)
print(result.output)

# Ativar ambiente
result = runner.invoke(app, ['env', 'activate', '--name', name], catch_exceptions=False)
print(result.output)
" 2>&1 | ForEach-Object { Write-Host "      $_" }

Write-Host "      Autenticando com API Key..." -ForegroundColor Yellow

# Login com API key via variavel de ambiente
python -c "
import os, sys
# Escreve o .env temporario para autenticacao
env_content = f'WATSONX_APIKEY={os.environ[chr(79)+chr(82)+chr(67)+chr(72)+chr(69)+chr(83)+chr(84)+chr(82)+chr(65)+chr(84)+chr(69)+chr(95)+chr(65)+chr(80)+chr(73)+chr(95)+chr(75)+chr(69)+chr(89)]}'
" 2>&1

# Usar variavel de ambiente diretamente para login
$env:WATSONX_APIKEY = $apiKey
$env:IBM_CLOUD_APIKEY = $apiKey

python -c "
import os, sys
from ibm_watsonx_orchestrate.cli.main import app
from click.testing import CliRunner

runner = CliRunner(mix_stderr=False)
result = runner.invoke(app, ['env', 'list'], catch_exceptions=False)
print(result.output)
" 2>&1 | ForEach-Object { Write-Host "      $_" }

Write-Host "      Ambiente configurado." -ForegroundColor Green

# ---------------------------------------------------------------------------
# PASSO 3 — Importar Tools
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/7] Importando tools ($TOOLS_FILE)..." -ForegroundColor Yellow

python -c "
import os, sys
os.environ['WATSONX_APIKEY'] = os.environ.get('ORCHESTRATE_API_KEY','')
from ibm_watsonx_orchestrate.cli.main import app
from click.testing import CliRunner

runner = CliRunner(mix_stderr=False)
result = runner.invoke(app, [
    'tools', 'import',
    '--kind', 'python',
    '--file', '$TOOLS_FILE'
], catch_exceptions=False)
print(result.output)
if result.exit_code != 0:
    sys.exit(result.exit_code)
" 2>&1 | ForEach-Object { Write-Host "      $_" }

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERRO ao importar tools. Verifique o output acima." -ForegroundColor Red
    exit 1
}
Write-Host "      Tools importadas." -ForegroundColor Green

# ---------------------------------------------------------------------------
# PASSO 4-8 — Importar agentes (ordem importa: colaboradores antes do orquestrador)
# ---------------------------------------------------------------------------
$step = 4
foreach ($agentFile in $AGENTS) {
    $agentName = (Split-Path $agentFile -Leaf) -replace "\.yaml$",""
    Write-Host ""
    Write-Host "[$step/7] Importando agente: $agentName..." -ForegroundColor Yellow

    python -c "
import os, sys
os.environ['WATSONX_APIKEY'] = os.environ.get('ORCHESTRATE_API_KEY','')
from ibm_watsonx_orchestrate.cli.main import app
from click.testing import CliRunner

runner = CliRunner(mix_stderr=False)
result = runner.invoke(app, [
    'agents', 'import',
    '--file', '$agentFile'
], catch_exceptions=False)
print(result.output)
if result.exit_code != 0:
    sys.exit(result.exit_code)
" 2>&1 | ForEach-Object { Write-Host "      $_" }

    if ($LASTEXITCODE -ne 0) {
        Write-Host "ERRO ao importar $agentName. Verifique o output acima." -ForegroundColor Red
        exit 1
    }
    Write-Host "      $agentName importado." -ForegroundColor Green
    $step++
}

# ---------------------------------------------------------------------------
# Resultado final
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  DEPLOY CONCLUIDO COM SUCESSO!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Tools importadas:" -ForegroundColor White
Write-Host "    - buscar_cliente" -ForegroundColor Gray
Write-Host "    - listar_produtos" -ForegroundColor Gray
Write-Host "    - avaliar_politica" -ForegroundColor Gray
Write-Host "    - registrar_decisao" -ForegroundColor Gray
Write-Host ""
Write-Host "  Agentes importados:" -ForegroundColor White
Write-Host "    - agente_carteira" -ForegroundColor Gray
Write-Host "    - agente_cliente" -ForegroundColor Gray
Write-Host "    - agente_decisor" -ForegroundColor Gray
Write-Host "    - agente_justificativa" -ForegroundColor Gray
Write-Host "    - agente_orquestrador_credito (orquestrador)" -ForegroundColor Gray
Write-Host ""
Write-Host "  Proximos passos:" -ForegroundColor White
Write-Host "    1. Acesse $ORCHESTRATE_URL" -ForegroundColor Gray
Write-Host "    2. Abra o chat do agente_orquestrador_credito" -ForegroundColor Gray
Write-Host "    3. Envie: {`"id_cliente`": `"C001`", `"valor_solicitado`": 20000}" -ForegroundColor Gray
Write-Host "    4. Tire prints para evidencias/" -ForegroundColor Gray
Write-Host ""

# Limpar a API key da memoria
$apiKey = $null
$env:ORCHESTRATE_API_KEY = $null
$env:WATSONX_APIKEY = $null
$env:IBM_CLOUD_APIKEY = $null
