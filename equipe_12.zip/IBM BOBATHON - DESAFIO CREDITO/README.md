# Aurora Bank — Decisão de Crédito Explicável
### Desafio IBM Bobathon · Grupo 12

> **Status:** FICTÍCIO — todos os dados, clientes, produtos e decisões são sintéticos,
> criados exclusivamente para fins de demonstração neste hackathon.

---

## 1. O Problema

O Aurora Bank opera um sistema legado de 22 anos que processa **4 milhões de decisões de crédito por mês** sem entregar nenhuma justificativa — nem ao cliente, nem ao regulador. A carta de decisão atual declara literalmente que a decisão *"não pode ser explicada nem contestada"*.

Isso gera três riscos simultâneos:

| Risco | Consequência |
|---|---|
| **Regulatório** | Ausência de auditabilidade viola exigências do Banco Central (Res. CMN 4.557 e correlatas) |
| **Reputacional** | Clientes negados sem motivo e aprovados sem pedir — experiência degradada |
| **Operacional** | Caixa-preta: impossível identificar viés, erro sistêmico ou fraude |

## 2. O Que a Solução Faz

Esta solução substitui a caixa-preta por um **fluxo de decisão explicável em 5 passos**, orquestrado pelo **IBM watsonx Orchestrate**, com:

1. **Dados verificados** — nenhum agente inventa informação; dados ausentes geram `INCONCLUSIVO`
2. **Política determinística** — a mesma entrada sempre produz a mesma saída (14 regras codificadas R-001…R-014)
3. **Justificativa em linguagem humana** — carta ao cliente citando os números exatos da decisão
4. **Trilha de auditoria imutável** — cada decisão gravada com SHA-256 para verificação de integridade
5. **Decisão em 4 estados** — `APROVADO`, `APROVADO_COM_RESSALVA`, `NEGADO`, `INCONCLUSIVO`

---

## 3. As 7 Etapas do Desafio — Como a Solução as Cobre

| Etapa | Requisito | Como está implementado |
|---|---|---|
| 1 | Receber pedido de crédito | Input `{id_cliente, valor_solicitado}` para o orquestrador |
| 2 | Agente Carteira consulta produtos | `agente_carteira` chama `listar_produtos()` + `buscar_cliente()` |
| 3 | Agente Cliente analisa perfil | `agente_cliente` chama `buscar_cliente()`, calcula indicadores |
| 4 | Orquestração entre agentes | `agente_orquestrador_credito` coordena os 4 colaboradores em sequência |
| 5 | Decisão com limite | `agente_decisor` chama `avaliar_politica()` — 100% determinística |
| 6 | Justificativa em linguagem clara | `agente_justificativa` redige carta ≤ 150 palavras citando números reais |
| 7 | Registro auditável | `registrar_decisao()` grava JSONL + hash SHA-256 em `trilha_auditoria.jsonl` |

---

## 4. Fluxo de Orquestração

```mermaid
flowchart TD
    INICIO([" Pedido de Crédito\n{id_cliente, valor_solicitado} "])
    INICIO --> ORC

    subgraph ORC["agente_orquestrador_credito (watsonx Orchestrate)"]
        direction TB
        P1["PASSO 1 — agente_carteira\nlistar_produtos + buscar_cliente"]
        CHK1{Produtos elegíveis?}
        P1 --> CHK1

        P2["PASSO 2 — agente_cliente\nbuscar_cliente → sumário de risco"]
        CHK2{Confiabilidade == BAIXA?}
        CHK1 -->|Sim| P2
        P2 --> CHK2

        P3["PASSO 3 — agente_decisor\ntool: avaliar_politica()"]
        CHK3{Decisão da política}
        CHK2 -->|Não| P3
        P3 --> CHK3

        P4["PASSO 4 — agente_justificativa\nredigir carta ao cliente"]
        P5["PASSO 5 — registrar_decisao\nJSONL + SHA-256"]
    end

    CHK1 -->|Não| NEG_PROD["NEGADO\nnenhum produto elegível"]
    NEG_PROD --> P5
    CHK2 -->|Sim| INC_DADOS["INCONCLUSIVO\ndados insuficientes → analista humano"]
    INC_DADOS --> P5

    CHK3 -->|APROVADO| APR["APROVADO"]
    CHK3 -->|APROVADO_COM_RESSALVA| RES["APROVADO COM RESSALVA\nlimite reduzido"]
    CHK3 -->|NEGADO| NEG["NEGADO"]
    CHK3 -->|INCONCLUSIVO R-001| INC2["INCONCLUSIVO\n→ analista humano"]

    APR --> P4
    RES --> P4
    NEG --> P4
    INC2 --> P4
    P4 --> P5

    P5 --> SAIDA([" Resultado Final\n{decisao, limite, carta, id_decisao, hash} "])

    style INICIO fill:#dbeafe,stroke:#3b82f6
    style SAIDA  fill:#dcfce7,stroke:#16a34a
    style APR    fill:#dcfce7,stroke:#16a34a
    style RES    fill:#fef9c3,stroke:#ca8a04
    style NEG    fill:#fee2e2,stroke:#dc2626
    style NEG_PROD fill:#fee2e2,stroke:#dc2626
    style INC_DADOS fill:#f3e8ff,stroke:#9333ea
    style INC2   fill:#f3e8ff,stroke:#9333ea
```

---

## 5. Arquitetura dos Agentes

### Agentes colaboradores (definidos em `src/agents/*.yaml`)

| Agente | Papel | Tools | Decide crédito? |
|---|---|---|---|
| `agente_carteira` | Especialista em produtos; retorna linhas elegíveis e condições | `listar_produtos`, `buscar_cliente` | **Não** |
| `agente_cliente` | Analisa perfil, histórico, indicadores; retorna sumário de risco | `buscar_cliente` | **Não** |
| `agente_decisor` | Executa a política determinística via tool | `avaliar_politica`, `registrar_decisao` | **Não** (tool decide) |
| `agente_justificativa` | Redige carta ao cliente ≤ 150 palavras | nenhuma | **Não** (só traduz) |
| `agente_orquestrador_credito` | Coordena os 4 acima; gerencia paradas antecipadas | `registrar_decisao` | **Não** (coordena) |

### Condições de parada antecipada

| Condição | Detectada em | Resultado |
|---|---|---|
| Nenhum produto elegível | Passo 1 | NEGADO sem chamar os demais |
| `confiabilidade == "BAIXA"` | Passo 2 | INCONCLUSIVO sem chamar decisor |
| Campo obrigatório `null` (R-001) | Passo 3 | INCONCLUSIVO (policy retorna antes de calcular) |

---

## 6. Política de Crédito — Tabela de Regras

> Implementada em [`src/policy/politica_credito.py`](src/policy/politica_credito.py).
> Especificação completa em [`src/policy/politica_credito.md`](src/policy/politica_credito.md).

### Hard Rules — eliminatórias (qualquer uma → NEGADO ou INCONCLUSIVO)

| Código | Critério | Limiar | Efeito |
|---|---|---|---|
| R-001 | Campo obrigatório ausente (`null`) | qualquer | **INCONCLUSIVO** |
| R-002 | Idade mínima | `< 18 anos` | NEGADO |
| R-003 | Restrição externa ativa | `true` | NEGADO |
| R-004 | Score mínimo absoluto | `< 400` | NEGADO |
| R-005 | Score mínimo do produto | `< score_minimo do produto` | NEGADO |
| R-006 | Renda comprovada mínima | `< R$ 1.500` | NEGADO |
| R-007 | Comprometimento de renda pós-crédito | `> teto do produto` | NEGADO |

### Soft Rules — ressalvas (reduzem limite, não eliminam)

| Código | Critério | Desconto no Limite |
|---|---|---|
| R-008 | ≥ 2 atrasos ≤ 30 dias | −25% |
| R-009 | ≥ 1 atraso entre 31–60 dias | −40% |
| R-010 | Relacionamento < 6 meses | −30% |
| R-011 | Relacionamento 6–11 meses | −15% |
| R-012 | Score na faixa de entrada do produto | −20% |

### Bônus de confiança

| Código | Critério | Efeito |
|---|---|---|
| R-013 | ≥ 60 meses de relacionamento e score ≥ 750 | +10% confiança; limite pode chegar ao máximo |
| R-014 | Zero atrasos e saldo médio ≥ 50% da renda | +5% confiança |

### Fórmula de limite sugerido

```
limite_por_saldo   = saldo_medio_12m × 3,0
limite_por_renda   = renda_comprovada × 4,0
limite_pelo_teto   = margem_parcela_disponível / fator_price(taxa_am, prazo_max)
limite_bruto       = min(limite_por_saldo, limite_por_renda, limite_pelo_teto, limite_max_produto)
limite_final       = limite_bruto × (produto das ressalvas ativas)
```

---

## 7. Onde Usamos o IBM Bob

O IBM Bob atuou como **par de engenharia** em todas as etapas do desafio:

### Geração da base sintética
- **Prompt:** *"Gere 12 clientes fictícios brasileiros cobrindo deliberadamente os casos: aprovação fácil, negativa por comprometimento, negativa por restrição, aprovação com limite reduzido, cliente novo, dado faltante INCONCLUSIVO."*
- Bob gerou [`src/data/clientes.json`](src/data/clientes.json) e [`src/data/produtos.json`](src/data/produtos.json) com todos os campos solicitados, valores consistentes entre si e os 12 casos de teste cobertos.

### Co-autoria da política de crédito
- **Prompt:** *"Implemente uma política determinística com hard rules R-001…R-007, soft rules R-008…R-012 e bônus R-013…R-014. Cada regra com código estável, cálculo de parcela Price, fórmula de limite explícita. Retornar objeto com decisao, limite_sugerido, regras_acionadas, dados_utilizados, dados_faltantes."*
- Bob escreveu [`src/policy/politica_credito.py`](src/policy/politica_credito.py) (395 linhas) com testes embutidos que validaram **12/12 casos** na primeira execução.

### Geração dos YAMLs dos agentes
- **Prompt:** *"Especifique 4 agentes no formato ADK do watsonx Orchestrate com spec_version, kind: native, instructions completas com regra anti-alucinação embutida e lista de tools."*
- Bob gerou os 5 YAMLs em [`src/agents/`](src/agents/), marcou explicitamente os campos `# [VERIFICAR]` onde o schema exato não pôde ser confirmado pela documentação disponível — cumprindo a própria regra anti-alucinação.

### Consulta à documentação do Orchestrate
- Bob consultou `list_ibm_doc_libraries` + `search_ibm_docs` antes de gerar os YAMLs, identificou que a documentação específica do Orchestrate ADK **não está indexada** nas bibliotecas disponíveis, e declarou isso explicitamente em vez de inventar campos — aplicando à própria resposta a mesma regra que os agentes devem seguir.

### Implementação das tools Python
- **Prompt:** *"Escreva as Python tools com @tool para buscar_cliente, listar_produtos, avaliar_politica, registrar_decisao — com stub local para execução sem SDK."*
- Bob escreveu [`src/tools/aurora_tools.py`](src/tools/aurora_tools.py) e [`src/tools/orquestracao.py`](src/tools/orquestracao.py), executou e validou os 12 fluxos completos.

### Trilha de auditoria
- **Prompt:** *"Defina trilha_schema.json e gere exemplos reais para C001 (aprovado), C003 (negado), C006 (inconclusivo). Valide os exemplos contra o schema."*
- Bob gerou o schema, o gerador e validou **3/3 registros conformes** com `jsonschema`.

### Revisão do README
- Bob estruturou este documento integralmente, incluindo tabelas, diagrama Mermaid, seções de limitações e próximos passos.

---

## 8. Onde Usamos o watsonx Orchestrate

### Agentes criados

| Arquivo YAML | Tipo | Colaboradores |
|---|---|---|
| [`agente_carteira.yaml`](src/agents/agente_carteira.yaml) | `kind: native` | nenhum |
| [`agente_cliente.yaml`](src/agents/agente_cliente.yaml) | `kind: native` | nenhum |
| [`agente_decisor.yaml`](src/agents/agente_decisor.yaml) | `kind: native` | nenhum |
| [`agente_justificativa.yaml`](src/agents/agente_justificativa.yaml) | `kind: native` | nenhum |
| [`agente_orquestrador_credito.yaml`](src/agents/agente_orquestrador_credito.yaml) | `kind: native` | 4 agentes acima |

### Tools importadas

Arquivo: [`src/tools/aurora_tools.py`](src/tools/aurora_tools.py)

```bash
# Importar as tools no Orchestrate
orchestrate tools import -k python -f src/tools/aurora_tools.py
```

| Tool | Permissão | Descrição |
|---|---|---|
| `buscar_cliente` | read_only | Retorna dados do cliente por ID |
| `listar_produtos` | read_only | Catálogo de produtos, com filtro opcional por tipo |
| `avaliar_politica` | read_only | Executa a política determinística; retorna decisão + regras |
| `registrar_decisao` | read_write | Grava registro na trilha JSONL com hash SHA-256 |

### Como reproduzir (comandos ADK)

```bash
# 1. Instalar o SDK
pip install ibm-watsonx-orchestrate

# 2. Autenticar
orchestrate env activate --profile <SEU_PROFILE>

# 3. Importar tools
orchestrate tools import -k python -f src/tools/aurora_tools.py

# 4. Importar agentes (na ordem — colaboradores antes do orquestrador)
orchestrate agents import -f src/agents/agente_carteira.yaml
orchestrate agents import -f src/agents/agente_cliente.yaml
orchestrate agents import -f src/agents/agente_decisor.yaml
orchestrate agents import -f src/agents/agente_justificativa.yaml
orchestrate agents import -f src/agents/agente_orquestrador_credito.yaml

# 5. Testar
orchestrate agents invoke agente_orquestrador_credito \
  --input '{"id_cliente": "C001", "valor_solicitado": 20000}'
```

> **Nota:** os campos marcados com `# [VERIFICAR]` nos YAMLs devem ser validados contra a versão do ADK instalada com `orchestrate agents validate -f <arquivo>.yaml`.

### O que está em `evidencias/`

Ver [`evidencias/README.md`](evidencias/README.md) para a checklist completa do que deve ser capturado como prova de uso.

---

## 9. Tratamento de Incerteza — Como a Solução se Recusa a Inventar

### Regra Anti-Alucinação (implementada em todas as camadas)

1. **Na política Python** ([`politica_credito.py`](src/policy/politica_credito.py)): se qualquer campo obrigatório for `null`, a função retorna imediatamente `INCONCLUSIVO` com `dados_faltantes` preenchido. Nenhum cálculo é feito com dados ausentes.

2. **No `agente_cliente`** (YAML): instructions explicitam que *"PROIBIDO inferir, estimar ou preencher campos faltantes"*. Campos `null` → `confiabilidade: BAIXA` → fluxo para antes do decisor.

3. **No `agente_decisor`** (YAML): instructions proíbem emitir decisão sem chamar `avaliar_politica`. Se a tool falhar → `INCONCLUSIVO` automático.

4. **No `agente_justificativa`** (YAML): *"Você SOMENTE usa números que existam no objeto de decisão recebido."* — template INCONCLUSIVO não cita limite nem aprovação.

5. **No orquestrador**: parada antecipada em Passo 2 se confiabilidade `BAIXA` — o decisor e o justificador de aprovação nunca são chamados.

### O que acontece num caso INCONCLUSIVO (cliente C006)

```
PASSO 1: agente_carteira → produto elegível encontrado (PROD001)
PASSO 2: agente_cliente  → confiabilidade=BAIXA
         dados_faltantes: [renda_comprovada, score_interno_0_1000,
                           restricao_externa, parcelas_mensais_atuais,
                           saldo_medio_12m, divida_total_atual, atrasos_ultimos_12m]
→ PARADA ANTECIPADA
PASSO 3: agente_decisor  → NÃO CHAMADO
PASSO 4: agente_justificativa → carta INCONCLUSIVO:
         "...as seguintes informações estão pendentes: renda_comprovada,
          score_interno_0_1000, [...]  Seu pedido foi encaminhado para
          um analista humano..."
PASSO 5: registrar_decisao → gravado com R-001, dados_faltantes preenchidos
```

---

## 10. Limitações Honestas e Próximos Passos

### Limitações desta versão

| Limitação | Descrição |
|---|---|
| Dados sintéticos | A base de 12 clientes e 4 produtos é fictícia; não há integração com sistemas reais |
| LLM local simulado | O `agente_justificativa` usa templates determinísticos no teste local; em produção, o Granite do Orchestrate geraria texto mais natural |
| Schema ADK não verificado em produção | Campos `# [VERIFICAR]` nos YAMLs precisam ser validados contra a versão instalada do ADK antes do deploy |
| Trilha JSONL local | O arquivo `trilha_auditoria.jsonl` é gravado em disco local; produção exige storage persistente (S3, Db2, etc.) |
| Política estática | As 14 regras e parâmetros estão em código; produção exigiria um repositório de políticas com controle de versão e rollback |

### Próximos Passos

1. **Integração real**: conectar `buscar_cliente` ao CRM do banco e `listar_produtos` ao catálogo real
2. **Score externo**: adicionar chamada ao bureau (Serasa, SPC) na tool `buscar_cliente`
3. **Repositório de políticas**: externalizar R-001…R-014 para arquivo YAML/DB com versionamento
4. **Monitoramento**: integrar trilha com watsonx.governance para dashboards de viés e drift
5. **Contestação**: endpoint REST que recebe `id_decisao` + motivo de contestação e abre fluxo de revisão humana
6. **Testes de regressão**: pipeline CI que valida os 12 casos a cada alteração da política

---

## 11. Equipe — Grupo 12

| Nome |
|---|
| Elisia Christine |
| Marcos Teodoro |
| Marcelo Carlos |
| Philipe Matos |
| Valdecy Cruz |

---

## 12. Estrutura de Pastas

```
[GRUPO_12]/
├── README.md                          ← este arquivo
├── evidencias/
│   └── README.md                      ← checklist de evidências do Orchestrate
└── src/
    ├── data/
    │   ├── clientes.json              ← 12 clientes sintéticos (Etapa 1)
    │   └── produtos.json              ← 4 linhas de crédito (Etapa 1)
    ├── policy/
    │   ├── politica_credito.md        ← especificação das 14 regras (Etapa 2)
    │   └── politica_credito.py        ← implementação + testes 12/12 (Etapa 2)
    ├── agents/
    │   ├── agente_carteira.yaml       ← ADK watsonx Orchestrate (Etapa 3)
    │   ├── agente_cliente.yaml        ← ADK watsonx Orchestrate (Etapa 3)
    │   ├── agente_decisor.yaml        ← ADK watsonx Orchestrate (Etapa 3)
    │   ├── agente_justificativa.yaml  ← ADK watsonx Orchestrate (Etapa 3)
    │   └── agente_orquestrador_credito.yaml  ← orquestrador (Etapas 3+4)
    ├── tools/
    │   ├── aurora_tools.py            ← 4 @tool functions (Etapa 4)
    │   ├── orquestracao.py            ← fluxo local 5 passos (Etapa 4)
    │   └── fluxo_orquestracao.md      ← diagrama Mermaid (Etapa 4)
    └── audit/
        ├── trilha_schema.json         ← JSON Schema Draft-07 (Etapa 5)
        ├── gerar_trilha_auditoria.py  ← gerador de exemplos (Etapa 5)
        ├── trilha_exemplos.json       ← 3 registros reais validados (Etapa 5)
        └── trilha_auditoria.jsonl     ← trilha acumulada (gerada em runtime)
```
