# Aurora Bank — Sistema Multi-Agente de Concessão de Cartão de Crédito

> **Equipe 09** | Hackathon IBM watsonx Orchestrate
Ana Leite
Joseph Katiamba
Kleidson Rodrigues
Letícia Miranda
Rodrigo Lima
---

## O que a solução faz

O sistema toma **decisões automatizadas e auditáveis de concessão de cartão de crédito** para o Aurora Bank, baseadas em análise de risco multidimensional. A partir de um único dado de entrada — o CPF do cliente — o sistema orquestra cinco agentes especializados que colaboram para produzir:

- ✅ **Aprovação** com o produto e limite mais adequados ao perfil;
- ⚠️ **Aprovação com limite reduzido** quando o risco é moderado;
- ❌ **Negação fundamentada** com orientações humanizadas ao cliente.

### Fluxo de decisão

```
CPF do cliente
      │
      ▼
┌─────────────────────────────────────────────────────────┐
│                  OrquestradorCredito                     │
│                                                         │
│  1. AgenteBaseClientes ──── Identificação + Score       │
│  2. AgenteGestaoLimite ──── Cálculo do limite           │
│  3. AgentePortfolioProdutos ── Produto elegível         │
│  4. AgenteDecisaoCredito ── Decisão + Justificativa     │
│  5. AgenteAuditoria ─────── Registro append-only        │
└─────────────────────────────────────────────────────────┘
      │
      ▼
RespostaFinal (decisão · limite · produto · justificativa · ID de rastreamento)
```

---

## Como funciona — os cinco agentes

| Agente | Arquivo de prompt | Responsabilidade |
|---|---|---|
| `AgentePortfolioProdutos` | [`agent_portfolio_produtos.md`](agent_portfolio_produtos.md) | Catálogo de 5 cartões, elegibilidade por risco e renda |
| `AgenteGestaoLimite` | [`agent_gestao_limite.md`](agent_gestao_limite.md) | Cálculo de limite com 4 faixas de renda + bônus por vínculo |
| `AgenteBaseClientes` | [`agent_base_clientes.md`](agent_base_clientes.md) | Base de 44 clientes, histórico, score de capacidade 0–100 |
| `AgenteDecisaoCredito` | [`agent_decisao_credito.md`](agent_decisao_credito.md) | Regras de decisão combinadas + justificativa ao cliente |
| `AgenteAuditoria` | [`agent_auditoria.md`](agent_auditoria.md) | Log imutável de todo o caminho até a decisão |
| `OrquestradorCredito` | [`agent_orquestrador.md`](agent_orquestrador.md) | Coordena todos os agentes na ordem correta |

### Modelo de dados do cliente (campos utilizados)

```
CPF · Nome · Data de nascimento · Score Serasa · Renda mensal
Restrição de crédito · Comprometimento de renda · Vínculo empregatício
Possui conta corrente · Produtos contratados · Possui cartão atual
```

### Regras de negócio principais

**Score de capacidade (0–100):**
- 50% → Score Serasa normalizado (Serasa/1000 × 100)
- 25% → Comprometimento de renda (100 − comprometimento%)
- 15% → Histórico de solicitações (neutro 70; +10/aprovação; −15/negação)
- 10% → Conta corrente Aurora Bank (Sim=100, Não=50)
- Score 0 automático se houver restrição de crédito ativa

**Faixas de renda × multiplicadores de limite:**
| Faixa | Multiplicador |
|---|---|
| Até R$ 3.000 | 1,5× |
| R$ 3.001–R$ 10.000 | 2,5× |
| R$ 10.001–R$ 25.000 | 3,5× |
| Acima de R$ 25.000 | 4,5× |

**Bônus por vínculo empregatício:** CLT/Servidor Público +15% · Aposentado +10% · PJ +5% · Autônomo −5%

**Decisão final:**
| Score | Decisão |
|---|---|
| < 20 | NEGADO automático |
| 20–39 | APROVADO com limite reduzido em 50% |
| 40–59 | APROVADO com limite reduzido em 20% |
| ≥ 60 | APROVADO integral |

---

## Onde o IBM Bob e o IBM watsonx Orchestrate foram usados

### IBM Bob

O **IBM Bob** foi o assistente de desenvolvimento central do projeto. Ele foi utilizado para:

1. **Análise da base de conhecimento** — leitura e interpretação do PDF `aurora_bank_clientes.pdf` com os dados de 44 clientes, extraindo estrutura, campos e padrões;
2. **Design da arquitetura multi-agente** — co-criação do diagrama de fluxo e definição de responsabilidades de cada agente;
3. **Implementação de todo o código Python** — geração do arquivo `aurora_bank_sistema.py` (~1.900 linhas) com dataclasses, tipagem estática, logging estruturado, exceções customizadas e regras de negócio;
4. **Enriquecimento da base de dados** — adição dos novos campos `vinculo_empregaticio`, `data_nascimento` e `possui_conta_corrente` para todos os 44 clientes;
5. **Geração dos arquivos de documentação** — todos os arquivos `.md` desta estrutura de projeto foram gerados pelo Bob;
6. **Validação e execução** — Bob executou o sistema, verificou os 3 cenários e confirmou que os resultados estavam corretos.

### IBM watsonx Orchestrate

O **IBM watsonx Orchestrate** é o motor de orquestração que viabiliza o padrão multi-agente em produção. Cada arquivo `.md` nesta pasta define a skill de um agente para ser registrado no Orchestrate:

- Cada agente é uma **skill independente** com tool description, parâmetros de entrada/saída tipados e instrução de comportamento;
- O `OrquestradorCredito` é o **agente orquestrador** que chama os demais na sequência correta, passando contexto entre eles;
- O `AgenteAuditoria` é injetado **transversalmente** em cada etapa para garantir rastreabilidade completa;
- Os arquivos `.md` seguem o formato de **agent skill definition** esperado pelo Orchestrate, com seções de `role`, `tools`, `instructions` e `output_schema`.

---

## Como executar

### Pré-requisitos
- Python 3.10 ou superior
- Sem dependências externas além da biblioteca padrão

```bash
# Clonar / navegar até a pasta src
cd equipe_09/src

# Executar o sistema completo com os 3 cenários
python3 aurora_bank_sistema.py

# Gerar o PDF da base de clientes (requer reportlab)
python3 aurora_bank_gerador_pdf.py
```

### Saída esperada
O sistema exibe no console para cada cenário:
1. Dados resumidos da solicitação + confirmação de identidade do cliente
2. Decisão final formatada como carta ao cliente
3. Resultado de cada agente (score, produto, limite)
4. Relatório de auditoria completo com todas as 5 etapas

---

## Evidências

| Arquivo | Conteúdo |
|---|---|
| [`evidencias/execucao_3_cenarios.log`](evidencias/execucao_3_cenarios.log) | Saída completa da execução dos 3 cenários |
| [`evidencias/aurora_bank_clientes.pdf`](evidencias/aurora_bank_clientes.pdf) | Base de conhecimento de 44 clientes |
| [`evidencias/cenario_01_aprovado.md`](evidencias/cenario_01_aprovado.md) | Resultado detalhado — Cenário 1 (APROVADO) |
| [`evidencias/cenario_02_aprovado_reduzido.md`](evidencias/cenario_02_aprovado_reduzido.md) | Resultado detalhado — Cenário 2 (APROVADO COM LIMITE REDUZIDO) |
| [`evidencias/cenario_03_negado.md`](evidencias/cenario_03_negado.md) | Resultado detalhado — Cenário 3 (NEGADO) |

---

## Quem é a Equipe 09

| Membro | Papel |
|---|---|
| *(adicionar nome)* | *(adicionar papel)* |
| *(adicionar nome)* | *(adicionar papel)* |
| *(adicionar nome)* | *(adicionar papel)* |

---

> Aurora Bank Multi-Agent Credit System — desenvolvido com IBM Bob + IBM watsonx Orchestrate
