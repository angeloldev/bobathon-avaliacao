# Evidência — Cenário 2: APROVADO COM LIMITE REDUZIDO (Risco Médio)

## Dados da Solicitação

| Campo | Valor |
|---|---|
| ID da Solicitação | `75765a67-4d6c-4062-8272-eb25be4eb54f` |
| Data/Hora | 10/09/2026 15:18:54 |
| CPF | 614.971.615-50 |

## Dados do Cliente (confirmação de identidade)

| Campo | Valor |
|---|---|
| Nome | Marcos Costa Vieira |
| Data de Nascimento | 30/01/1978 |
| Vínculo Empregatício | Autônomo |
| Conta Corrente Aurora Bank | Não |
| Renda Mensal | R$ 5.891,42 |
| Score Serasa | 481 |
| Comprometimento de Renda | 55,0% |
| Restrição de Crédito | Não |

---

## Resultado de Cada Agente

### AgenteBaseClientes — Identificação ✅
- Status: OK | Duração: 0,0 ms
- Cliente localizado com sucesso

### AgenteBaseClientes — Capacidade ✅
- Status: OK | Duração: 0,0 ms
- Score Serasa: 481/1.000 → componente normalizado: 48,1
- Comprometimento de renda: 55,0% → componente: 45,0
- Histórico: neutro → componente: 70,0
- Conta corrente: Não → componente: 50,0
- **Score de capacidade final: 50,8/100 → risco: MÉDIO**

> **Cálculo detalhado:**
> - Serasa: 48,1 × 0,50 = 24,05
> - Comprometimento: 45,0 × 0,25 = 11,25
> - Histórico: 70,0 × 0,15 = 10,50
> - Conta corrente: 50,0 × 0,10 = 5,00
> - **Total: 50,80**

### AgenteGestaoLimite ✅
- Status: OK | Duração: 0,0 ms
- Faixa de renda: Intermediária (R$ 3.001–R$ 10.000) | Multiplicador: 2,5×
- Limite base: R$ 5.891,42 × 2,5 = R$ 14.728,55
- Ajuste vínculo Autônomo (−5%): −R$ 736,43 → R$ 13.992,12
- Ajuste externo: R$ 0,00 (sem conta corrente + comprometimento < 60%)
- **Limite calculado: R$ 13.992,12**

### AgentePortfolioProdutos ✅
- Status: OK | Duração: 0,0 ms
- Produtos elegíveis para perfil **médio** e renda R$ 5.891,42:
  - Aurora Essencial (R$ 500 – R$ 2.000)
  - **Aurora Clássico** (R$ 1.000 – R$ 6.000) ← recomendado
- Produto recomendado: **Aurora Clássico** (maior limite máximo disponível)

### AgenteDecisaoCredito ✅
- Status: OK | Duração: 0,0 ms
- Score 40–59 (risco médio) → redução de **20%** sobre o limite calculado
- Limite após redução: R$ 13.992,12 × 0,80 = R$ 11.193,70
- Cap máximo do produto Aurora Clássico: **R$ 6.000,00**
- Limite aprovado = min(R$ 11.193,70, R$ 6.000,00) = **R$ 6.000,00**
- **Decisão: APROVADO COM LIMITE REDUZIDO**

---

## Mensagem ao Cliente

```
Prezado(a) Marcos Costa Vieira,

Temos boas notícias! Sua solicitação de cartão de crédito foi APROVADA!

Para garantir a melhor experiência e proteger o seu bolso, aprovamos
um limite inicial adequado ao seu momento financeiro atual
(perfil de risco médio).

  Produto: Aurora Clássico (Mastercard)
  Limite aprovado: R$ 6.000,00
  Anuidade mensal: R$ 15,00

Benefícios incluídos:
  • Parcelamento em até 12x
  • Seguro de viagem básico
  • Cashback 1%

Como aumentar seu limite no futuro:
  • Use o cartão com responsabilidade e pague sempre em dia;
  • Após 6 meses, solicite uma revisão de limite pelo app;
  • Quanto mais você usa os serviços Aurora Bank, mais benefícios recebe!

Bem-vindo(a) à família Aurora Bank!
Equipe Aurora Bank
```
