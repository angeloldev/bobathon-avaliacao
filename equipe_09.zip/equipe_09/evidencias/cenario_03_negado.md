# Evidência — Cenário 3: NEGADO (Restrição de Crédito Ativa)

## Dados da Solicitação

| Campo | Valor |
|---|---|
| ID da Solicitação | `a06ca0ff-c312-4171-b536-fc20079fee29` |
| Data/Hora | 10/09/2026 15:18:54 |
| CPF | 973.175.891-79 |

## Dados do Cliente (confirmação de identidade)

| Campo | Valor |
|---|---|
| Nome | Juliana Costa Marques |
| Data de Nascimento | 31/08/1994 |
| Vínculo Empregatício | Autônomo |
| Conta Corrente Aurora Bank | Não |
| Renda Mensal | R$ 10.965,36 |
| Score Serasa | 275 |
| Comprometimento de Renda | 31,1% |
| Restrição de Crédito | ⚠️ **SIM** |

---

## Resultado de Cada Agente

### AgenteBaseClientes — Identificação ✅
- Status: OK | Duração: 0,0 ms
- Cliente localizado com sucesso
- **ALERTA: Restrição de crédito ativa detectada**

### AgenteBaseClientes — Capacidade ✅
- Status: OK | Duração: 0,1 ms
- Restrição de crédito ativa → **score zerado automaticamente**
- **Score de capacidade: 0,0/100 → risco: ALTO**
- Observação registrada: `"ALERTA: Cliente possui restrição de crédito ativa no Serasa."`

### AgenteGestaoLimite ✅
- Status: OK | Duração: 0,0 ms
- O cálculo é realizado normalmente (para fins de auditoria)
- Faixa: Superior (R$ 10.001–R$ 25.000) | Multiplicador: 3,5×
- Limite base: R$ 38.378,76
- Ajuste Autônomo (−5%): −R$ 1.918,94
- **Limite calculado: R$ 36.459,82**
- *(Este valor não é utilizado pois a decisão será NEGADO)*

### AgentePortfolioProdutos ✅
- Status: OK | Duração: 0,0 ms
- Perfil de risco: alto → produtos aceitos: **Aurora Essencial**
- **Produto elegível: Aurora Essencial**

### AgenteDecisaoCredito ✅
- Status: OK | Duração: 0,0 ms
- Regra aplicada: **Negação automática por restrição de crédito ativa**
- Score de capacidade: 0,0 (mas irrelevante — restrição tem prioridade)
- **Decisão: NEGADO**
- Limite aprovado: **R$ 0,00**

---

## Mensagem ao Cliente

```
Prezado(a) Juliana Costa Marques,

Após análise da sua solicitação de cartão de crédito, informamos que,
no momento, não foi possível aprovar o seu pedido.

Identificamos que existe uma pendência no seu cadastro junto aos órgãos
de proteção ao crédito. Enquanto essa situação não for regularizada,
não conseguimos liberar novos produtos de crédito.

O que você pode fazer:
  • Entre em contato com o Serasa ou SPC para verificar e quitar
    eventuais pendências;
  • Após a regularização, aguarde a atualização dos cadastros (pode
    levar até 5 dias úteis) e solicite novamente;
  • Nossa equipe está à disposição para orientar você nesse processo.

Contamos com a sua compreensão e esperamos poder atendê-lo(a) em breve.
Equipe Aurora Bank
```

---

## Por que todos os agentes foram executados mesmo com negação?

O orquestrador executa **todos os agentes em todas as solicitações**, mesmo quando a negação é previsível desde a etapa 2. Isso é intencional:

1. **Auditoria completa:** o `AgenteAuditoria` registra o caminho integral, incluindo os valores calculados pelos demais agentes;
2. **Transparência regulatória:** em caso de contestação, é possível demonstrar que o cálculo de limite e a consulta ao portfólio foram realizados;
3. **Consistência:** simplifica o fluxo — o `AgenteDecisaoCredito` é sempre o único a emitir a decisão final.
