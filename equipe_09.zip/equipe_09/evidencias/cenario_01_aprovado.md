# Evidência — Cenário 1: APROVADO (Baixo Risco)

## Dados da Solicitação

| Campo | Valor |
|---|---|
| ID da Solicitação | `77c07c4c-75dc-458d-a285-c76867f03955` |
| Data/Hora | 10/09/2026 15:18:54 |
| CPF | 806.095.346-02 |

## Dados do Cliente (confirmação de identidade)

| Campo | Valor |
|---|---|
| Nome | Rodrigo Ramos Fernandes |
| Data de Nascimento | 14/01/1977 |
| Vínculo Empregatício | Servidor Público |
| Conta Corrente Aurora Bank | Sim |
| Renda Mensal | R$ 22.766,25 |
| Score Serasa | 965 |
| Comprometimento de Renda | 16,2% |
| Restrição de Crédito | Não |

---

## Resultado de Cada Agente

### AgenteBaseClientes — Identificação ✅
- Status: OK | Duração: 0,1 ms
- Cliente localizado com sucesso

### AgenteBaseClientes — Capacidade ✅
- Status: OK | Duração: 0,0 ms
- Score Serasa: 965/1.000 → componente normalizado: 96,5
- Comprometimento de renda: 16,2% → componente: 83,8
- Histórico: neutro → componente: 70,0
- Conta corrente: Sim → componente: 100,0
- **Score de capacidade final: 89,7/100 → risco: BAIXO**

### AgenteGestaoLimite ✅
- Status: OK | Duração: 0,0 ms
- Faixa de renda: Superior (R$ 10.001–R$ 25.000) | Multiplicador: 3,5×
- Limite base: R$ 22.766,25 × 3,5 = R$ 79.681,88
- Ajuste vínculo Servidor Público (+15%): +R$ 11.952,28 → R$ 91.634,16
- Ajuste externo (conta corrente +10%): +R$ 2.276,62
- **Limite calculado: R$ 93.910,78**

### AgentePortfolioProdutos ✅
- Status: OK | Duração: 0,1 ms
- Produtos elegíveis: Aurora Clássico, Aurora Gold, **Aurora Platinum**
- **Produto recomendado: Aurora Platinum** (limite encaixa em R$ 10.000–R$ 40.000)

### AgenteDecisaoCredito ✅
- Status: OK | Duração: 0,0 ms
- Score ≥ 60 → aprovação integral (fator 1,0×)
- Limite aprovado = R$ 93.910,78 → cap máximo do produto = **R$ 40.000,00**
- **Decisão: APROVADO**

---

## Mensagem ao Cliente

```
Prezado(a) Rodrigo Ramos Fernandes,

Temos uma ótima notícia para você! 🎉

Após analisar o seu perfil financeiro, temos o prazer de informar que
a sua solicitação de cartão de crédito foi APROVADA!

  Produto: Aurora Platinum (Visa)
  Limite aprovado: R$ 40.000,00
  Anuidade mensal: R$ 79,00

Benefícios incluídos:
  • Programa de pontos 3x
  • Acesso a salas VIP globais
  • Seguro viagem premium
  • Concierge 24h
  • Cashback 2%

Em breve você receberá seu cartão em até 10 dias úteis.
Acesse nosso app para acompanhar o status da entrega.

Bem-vindo(a) à família Aurora Bank!
Equipe Aurora Bank
```
