"""
aurora_bank.py
Gera um PDF com a base de conhecimento fictícia de clientes do Aurora Bank.
Dependência: reportlab (instalada automaticamente se ausente)
"""

import sys
import subprocess
import random
from datetime import date, timedelta

# ──────────────────────────────────────────────
# Instalação automática do reportlab se necessário
# ──────────────────────────────────────────────
try:
    import reportlab  # noqa: F401
except ImportError:
    print("Biblioteca 'reportlab' não encontrada. Instalando automaticamente...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "reportlab"])
    print("Instalação concluída.")

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, HRFlowable, PageBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# ──────────────────────────────────────────────
# Constantes
# ──────────────────────────────────────────────
NOME_ARQUIVO = "aurora_bank_clientes.pdf"
TITULO_BANCO  = "Aurora Bank — Base de Conhecimento de Clientes"

# Tipos de vínculo empregatício disponíveis
VINCULOS = ["CLT", "PJ", "Autônomo", "Servidor Público", "Aposentado"]

# Listas de nomes e sobrenomes brasileiros realistas
PRIMEIROS_NOMES = [
    "Ana", "Carlos", "Fernanda", "João", "Mariana", "Pedro", "Juliana",
    "Lucas", "Patrícia", "Rafael", "Beatriz", "Rodrigo", "Camila", "Felipe",
    "Larissa", "Gustavo", "Aline", "Thiago", "Vanessa", "Bruno", "Letícia",
    "Eduardo", "Natália", "Marcos", "Renata", "Diego", "Priscila", "André",
    "Simone", "Leandro", "Tânia", "Vitor", "Cristina", "Fábio", "Mônica",
    "Alexandre", "Daniela", "Henrique", "Sônia", "Wellington",
]

SOBRENOMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves",
    "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho",
    "Almeida", "Lopes", "Soares", "Fernandes", "Vieira", "Barbosa",
    "Rocha", "Dias", "Nascimento", "Andrade", "Moreira", "Nunes", "Marques",
    "Machado", "Mendes", "Freitas", "Cardoso", "Ramos", "Gonçalves", "Cruz",
    "Teixeira", "Araújo", "Correia", "Pinto", "Azevedo", "Batista",
]


# ──────────────────────────────────────────────
# Geração de CPF válido
# ──────────────────────────────────────────────
def gerar_cpf() -> str:
    """Gera um CPF com dígitos verificadores válidos e retorna formatado."""
    def calcular_digito(digitos: list, pesos: list) -> int:
        soma = sum(d * p for d, p in zip(digitos, pesos))
        resto = soma % 11
        return 0 if resto < 2 else 11 - resto

    base = [random.randint(0, 9) for _ in range(9)]
    d1 = calcular_digito(base, list(range(10, 1, -1)))
    d2 = calcular_digito(base + [d1], list(range(11, 1, -1)))
    todos = base + [d1, d2]
    cpf_str = "".join(map(str, todos))
    return f"{cpf_str[:3]}.{cpf_str[3:6]}.{cpf_str[6:9]}-{cpf_str[9:]}"


# ──────────────────────────────────────────────
# Geração de um cliente fictício
# ──────────────────────────────────────────────
def _data_nascimento_para_vinculo(vinculo: str) -> str:
    """
    Gera uma data de nascimento coerente com o tipo de vínculo empregatício.

    Faixas etárias adotadas:
      - Aposentado:       60–80 anos  (nascidos entre 1944 e 1964)
      - Servidor Público: 28–58 anos  (concurso pressupõe ao menos maioridade + preparo)
      - CLT:              22–55 anos  (mercado formal amplo)
      - PJ:               25–52 anos  (perfil empreendedor/consultor)
      - Autônomo:         20–55 anos  (inclui jovens recém-iniciados)
    """
    hoje = date.today()
    faixas = {
        "Aposentado":        (60, 80),
        "Servidor Público":  (28, 58),
        "CLT":               (22, 55),
        "PJ":                (25, 52),
        "Autônomo":          (20, 55),
    }
    idade_min, idade_max = faixas[vinculo]
    # Sorteia a idade em anos e depois um deslocamento em dias dentro do ano
    idade_anos = random.randint(idade_min, idade_max)
    dia_no_ano = random.randint(0, 364)
    nascimento = hoje.replace(year=hoje.year - idade_anos) - timedelta(days=dia_no_ano)
    return nascimento.strftime("%d/%m/%Y")


def _vinculo_para_perfil(restricao: bool, score: int, renda: float) -> str:
    """
    Escolhe o tipo de vínculo empregatício de forma coerente com o perfil
    financeiro do cliente.

    Lógica de coerência:
      - Servidor Público: score tipicamente alto (≥ 600), renda estável
      - Aposentado:       renda moderada-fixa, score variado
      - CLT:              perfil mais comum, faixa ampla de score/renda
      - PJ:               renda alta ou média, score médio-alto
      - Autônomo:         score mais variável, pode ter restrição
    """
    # Clientes com restrição tendem a ser autônomos ou PJ (menos proteção formal)
    if restricao:
        return random.choices(
            ["Autônomo", "PJ", "CLT"],
            weights=[55, 25, 20],
        )[0]

    # Score muito alto (≥ 750) + renda alta → servidor público ou PJ premium
    if score >= 750 and renda >= 10_000:
        return random.choices(
            ["Servidor Público", "PJ", "CLT"],
            weights=[40, 35, 25],
        )[0]

    # Renda baixa (< 3.000) → autônomo, aposentado ou CLT básico
    if renda < 3_000:
        return random.choices(
            ["Autônomo", "Aposentado", "CLT"],
            weights=[45, 30, 25],
        )[0]

    # Renda alta (≥ 20.000) → PJ ou servidor público
    if renda >= 20_000:
        return random.choices(
            ["PJ", "Servidor Público", "CLT"],
            weights=[40, 35, 25],
        )[0]

    # Perfil médio → distribuição mais uniforme com peso no CLT
    return random.choices(
        ["CLT", "Autônomo", "PJ", "Servidor Público", "Aposentado"],
        weights=[40, 20, 18, 14, 8],
    )[0]


def gerar_cliente(numero: int) -> dict:
    """
    Gera um dicionário com os dados fictícios de um cliente.
    Regras:
      - Clientes com restrição de crédito não têm empréstimos nem cartão.
      - Comprometimento de renda total ≤ 80 %.
      - Vínculo empregatício, data de nascimento e conta corrente são
        gerados de forma coerente com o perfil financeiro.
    """
    # Nome
    primeiro = random.choice(PRIMEIROS_NOMES)
    meio     = random.choice(SOBRENOMES)
    ultimo   = random.choice(SOBRENOMES)
    nome = f"{primeiro} {meio} {ultimo}"

    cpf = gerar_cpf()

    # Restrição de crédito — ~20 % de chance
    restricao = random.random() < 0.20

    # Score Serasa: clientes com restrição tendem a ter score mais baixo
    if restricao:
        score = random.randint(0, 400)
    else:
        score = random.randint(300, 1000)

    # Renda mensal bruta entre R$ 1.500 e R$ 30.000
    renda = round(random.uniform(1500, 30000), 2)

    # ── Vínculo empregatício (coerente com perfil) ──
    vinculo = _vinculo_para_perfil(restricao, score, renda)

    # ── Data de nascimento (coerente com vínculo) ──
    data_nascimento = _data_nascimento_para_vinculo(vinculo)

    # ── Conta corrente Aurora Bank ──
    # Clientes com score alto, sem restrição e com cartão têm maior probabilidade;
    # clientes com restrição ou score muito baixo têm probabilidade menor.
    if restricao or score < 300:
        prob_conta = 0.20
    elif score >= 700:
        prob_conta = 0.80
    else:
        prob_conta = 0.55
    possui_conta_corrente = random.random() < prob_conta

    # Limite máximo de comprometimento: 80 %
    limite_comprometimento = renda * 0.80
    comprometido_acum = 0.0

    def valor_aleatorio(minimo: float, maximo: float) -> float:
        """Retorna valor aleatório arredondado a 2 casas decimais."""
        return round(random.uniform(minimo, maximo), 2)

    def alocar(minimo: float, maximo: float) -> float:
        """
        Tenta alocar um valor dentro do limite de comprometimento.
        Retorna 0.0 se não houver margem disponível.
        """
        nonlocal comprometido_acum
        disponivel = limite_comprometimento - comprometido_acum
        if disponivel <= 0:
            return 0.0
        valor = valor_aleatorio(minimo, min(maximo, disponivel))
        comprometido_acum += valor
        return valor

    # ── Produtos ──
    # Seguro de vida (~60 % de chance de contratar)
    seguro_vida = alocar(30, 300) if random.random() < 0.60 else 0.0

    # Seguro residencial (~40 % de chance)
    seguro_residencial = alocar(50, 400) if random.random() < 0.40 else 0.0

    # Empréstimos e financiamento — bloqueados para clientes com restrição
    if not restricao:
        emprestimo_pessoal    = alocar(200, 2000) if random.random() < 0.45 else 0.0
        emprestimo_consignado = alocar(200, 3000) if random.random() < 0.35 else 0.0
        financiamento_veiculo = alocar(500, 4000) if random.random() < 0.30 else 0.0
    else:
        emprestimo_pessoal    = 0.0
        emprestimo_consignado = 0.0
        financiamento_veiculo = 0.0

    # Investimentos
    cdb              = alocar(100, 5000) if random.random() < 0.50 else 0.0
    tesouro_direto   = alocar(100, 3000) if random.random() < 0.40 else 0.0
    previdencia      = alocar(100, 2000) if random.random() < 0.45 else 0.0

    # Total comprometido e percentual
    total_comprometido = (
        seguro_vida + seguro_residencial +
        emprestimo_pessoal + emprestimo_consignado + financiamento_veiculo +
        cdb + tesouro_direto + previdencia
    )
    percentual = round((total_comprometido / renda) * 100, 2)

    # Cartão de crédito — bloqueado para clientes com restrição
    if not restricao:
        tem_cartao = random.random() < 0.65
        bandeira   = random.choice(["Visa", "Mastercard"]) if tem_cartao else "Nenhum"
    else:
        tem_cartao = False
        bandeira   = "Nenhum"

    return {
        "numero":                numero,
        "nome":                  nome,
        "cpf":                   cpf,
        "restricao":             "Sim" if restricao else "Não",
        "score_serasa":          score,
        "renda_mensal":          renda,
        # novos campos
        "vinculo_empregaticio":  vinculo,
        "data_nascimento":       data_nascimento,
        "possui_conta_corrente": "Sim" if possui_conta_corrente else "Não",
        # produtos
        "seguro_vida":           seguro_vida,
        "seguro_residencial":    seguro_residencial,
        "emprestimo_pessoal":    emprestimo_pessoal,
        "emprestimo_consignado": emprestimo_consignado,
        "financiamento_veiculo": financiamento_veiculo,
        "cdb":                   cdb,
        "tesouro_direto":        tesouro_direto,
        "previdencia":           previdencia,
        "percentual_renda":      percentual,
        "tem_cartao":            "Sim" if tem_cartao else "Não",
        "bandeira_cartao":       bandeira,
    }


# ──────────────────────────────────────────────
# Formatação monetária
# ──────────────────────────────────────────────
def formatar_moeda(valor: float) -> str:
    """Formata um float no padrão brasileiro R$ 0.000,00."""
    if valor == 0.0:
        return "Não contratado"
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


# ──────────────────────────────────────────────
# Construção do PDF
# ──────────────────────────────────────────────
def construir_pdf(clientes: list) -> None:
    """Recebe a lista de clientes e gera o PDF com ReportLab."""

    # ── Configuração do documento ──
    doc = SimpleDocTemplate(
        NOME_ARQUIVO,
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=3 * cm,      # espaço para o cabeçalho
        bottomMargin=2.5 * cm, # espaço para o rodapé
    )

    # ── Estilos ──
    estilos = getSampleStyleSheet()

    estilo_titulo_secao = ParagraphStyle(
        "TituloSecao",
        parent=estilos["Heading2"],
        fontSize=13,
        textColor=colors.HexColor("#1A3A5C"),
        spaceBefore=6,
        spaceAfter=4,
    )

    estilo_label = ParagraphStyle(
        "Label",
        parent=estilos["Normal"],
        fontSize=9,
        textColor=colors.HexColor("#555555"),
        leading=14,
    )

    estilo_valor = ParagraphStyle(
        "Valor",
        parent=estilos["Normal"],
        fontSize=10,
        textColor=colors.black,
        leading=14,
    )

    estilo_subtitulo = ParagraphStyle(
        "Subtitulo",
        parent=estilos["Normal"],
        fontSize=10,
        textColor=colors.HexColor("#1A3A5C"),
        fontName="Helvetica-Bold",
        spaceBefore=6,
        spaceAfter=2,
    )

    # ── Funções de cabeçalho e rodapé ──
    def cabecalho_rodape(canvas, doc):
        canvas.saveState()
        largura, altura = A4

        # Cabeçalho
        canvas.setFillColor(colors.HexColor("#1A3A5C"))
        canvas.rect(0, altura - 2 * cm, largura, 2 * cm, fill=True, stroke=False)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica-Bold", 13)
        canvas.drawCentredString(largura / 2, altura - 1.3 * cm, TITULO_BANCO)

        # Rodapé
        canvas.setFillColor(colors.HexColor("#EEEEEE"))
        canvas.rect(0, 0, largura, 1.5 * cm, fill=True, stroke=False)
        canvas.setFillColor(colors.HexColor("#555555"))
        canvas.setFont("Helvetica", 8)
        canvas.drawCentredString(
            largura / 2, 0.5 * cm,
            f"Documento confidencial — Uso interno Aurora Bank  |  Página {doc.page}"
        )
        canvas.restoreState()

    # ── Montagem do conteúdo ──
    conteudo = []

    def linha(label: str, valor: str) -> Paragraph:
        """Retorna um parágrafo no formato  Label: Valor."""
        return Paragraph(f"<b>{label}:</b> {valor}", estilo_valor)

    for idx, c in enumerate(clientes):
        # Título da seção do cliente
        conteudo.append(
            Paragraph(f"Cliente #{c['numero']}  —  {c['nome']}", estilo_titulo_secao)
        )
        conteudo.append(
            HRFlowable(width="100%", thickness=1, color=colors.HexColor("#1A3A5C"), spaceAfter=6)
        )

        # Dados pessoais
        conteudo.append(Paragraph("▸ Dados Pessoais", estilo_subtitulo))
        conteudo.append(linha("CPF",                      c["cpf"]))
        conteudo.append(linha("Data de nascimento",       c["data_nascimento"]))
        conteudo.append(linha("Vínculo empregatício",     c["vinculo_empregaticio"]))
        conteudo.append(linha("Restrição de crédito",     c["restricao"]))
        conteudo.append(linha("Score Serasa",             str(c["score_serasa"])))
        conteudo.append(linha("Renda mensal bruta",       formatar_moeda(c["renda_mensal"])))
        conteudo.append(linha("Conta corrente Aurora Bank", c["possui_conta_corrente"]))
        conteudo.append(Spacer(1, 0.3 * cm))

        # Produtos contratados
        conteudo.append(Paragraph("▸ Produtos Contratados", estilo_subtitulo))
        conteudo.append(linha("Seguro de vida (mensal)",              formatar_moeda(c["seguro_vida"])))
        conteudo.append(linha("Seguro residencial (mensal)",          formatar_moeda(c["seguro_residencial"])))
        conteudo.append(linha("Empréstimo pessoal (parcela mensal)",  formatar_moeda(c["emprestimo_pessoal"])))
        conteudo.append(linha("Empréstimo consignado (parcela)",      formatar_moeda(c["emprestimo_consignado"])))
        conteudo.append(linha("Financiamento de veículo (parcela)",   formatar_moeda(c["financiamento_veiculo"])))
        conteudo.append(linha("Investimento em CDB (mensal)",         formatar_moeda(c["cdb"])))
        conteudo.append(linha("Investimento Tesouro Direto (mensal)", formatar_moeda(c["tesouro_direto"])))
        conteudo.append(linha("Previdência privada (mensal)",         formatar_moeda(c["previdencia"])))
        conteudo.append(Spacer(1, 0.3 * cm))

        # Resumo financeiro
        conteudo.append(Paragraph("▸ Resumo Financeiro", estilo_subtitulo))
        conteudo.append(linha("Comprometimento total da renda", f"{c['percentual_renda']} %"))
        conteudo.append(Spacer(1, 0.3 * cm))

        # Cartão de crédito
        conteudo.append(Paragraph("▸ Cartão de Crédito Aurora Bank", estilo_subtitulo))
        conteudo.append(linha("Possui cartão",  c["tem_cartao"]))
        conteudo.append(linha("Bandeira",       c["bandeira_cartao"]))

        # Separador entre clientes (exceto o último)
        if idx < len(clientes) - 1:
            conteudo.append(Spacer(1, 0.5 * cm))
            conteudo.append(
                HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#CCCCCC"), spaceAfter=4)
            )
            conteudo.append(Spacer(1, 0.3 * cm))

    # ── Geração do arquivo ──
    doc.build(conteudo, onFirstPage=cabecalho_rodape, onLaterPages=cabecalho_rodape)
    print(f"\n✔ PDF gerado com sucesso: {NOME_ARQUIVO}")
    print(f"  Total de clientes gerados: {len(clientes)}")


# ──────────────────────────────────────────────
# Ponto de entrada
# ──────────────────────────────────────────────
if __name__ == "__main__":
    random.seed()  # semente aleatória para resultados distintos a cada execução

    qtd_clientes = random.randint(30, 50)
    print(f"Gerando base de conhecimento com {qtd_clientes} clientes fictícios...")

    clientes = [gerar_cliente(i + 1) for i in range(qtd_clientes)]

    print("Construindo o PDF...")
    construir_pdf(clientes)
