"""
Aurora Bank — Sistema Multi-Agente de Concessão de Cartão de Crédito
=====================================================================
Sistema orquestrado de decisão de crédito baseado em risco.
Todo o código, comentários, logs e saídas estão em português brasileiro.

Execução:
    python aurora_bank_sistema.py
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Configuração de Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("aurora_bank")


# ---------------------------------------------------------------------------
# Enumerações
# ---------------------------------------------------------------------------

class PerfilRisco(str, Enum):
    BAIXO = "baixo"
    MEDIO = "medio"
    ALTO = "alto"


class VinculoEmpregaticio(str, Enum):
    CLT = "CLT"
    PJ = "PJ"
    AUTONOMO = "Autônomo"
    SERVIDOR_PUBLICO = "Servidor Público"
    APOSENTADO = "Aposentado"


class DecisaoCredito(str, Enum):
    APROVADO = "APROVADO"
    APROVADO_LIMITE_REDUZIDO = "APROVADO COM LIMITE REDUZIDO"
    NEGADO = "NEGADO"


# ---------------------------------------------------------------------------
# Exceções customizadas
# ---------------------------------------------------------------------------

class ErroAuroraBank(Exception):
    """Exceção base do sistema Aurora Bank."""


class ClienteNaoEncontrado(ErroAuroraBank):
    """CPF não localizado na base de clientes."""


class DadosInvalidos(ErroAuroraBank):
    """Dados de entrada inválidos ou incompletos."""


class ErroAgente(ErroAuroraBank):
    """Erro interno durante execução de um agente."""


# ---------------------------------------------------------------------------
# Modelos de Dados
# ---------------------------------------------------------------------------

@dataclass
class ProdutoCartao:
    """Representa um produto de cartão de crédito do Aurora Bank."""
    nome: str
    limite_minimo: float
    limite_maximo: float
    perfis_risco_aceitos: list[PerfilRisco]
    anuidade_mensal: float
    beneficios: list[str]
    renda_minima: float
    bandeira: str
    descricao: str


@dataclass
class DadosCliente:
    """Dados completos do cliente extraídos da base de conhecimento."""
    cpf: str
    nome: str
    data_nascimento: date
    score_serasa: int
    renda_mensal: float
    restricao_credito: bool
    comprometimento_renda: float          # percentual já comprometido (0–100)
    vinculo_empregaticio: VinculoEmpregaticio
    possui_conta_corrente: bool
    # Produtos contratados
    seguro_vida: float = 0.0
    seguro_residencial: float = 0.0
    emprestimo_pessoal: float = 0.0
    emprestimo_consignado: float = 0.0
    financiamento_veiculo: float = 0.0
    investimento_cdb: float = 0.0
    investimento_tesouro: float = 0.0
    previdencia_privada: float = 0.0
    # Cartão atual
    possui_cartao: bool = False
    bandeira_atual: str = "Nenhum"


@dataclass
class SolicitacaoCredito:
    """Objeto de entrada do sistema — gerado a partir do CPF informado."""
    cpf: str
    id_solicitacao: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp_solicitacao: datetime = field(default_factory=datetime.now)


@dataclass
class ResultadoPortfolio:
    """Saída do AgentePortfolioProdutos."""
    produtos_elegiveis: list[ProdutoCartao]
    produto_recomendado: Optional[ProdutoCartao]
    justificativa: str


@dataclass
class ResultadoLimite:
    """Saída do AgenteGestaoLimite."""
    limite_calculado: float
    limite_ajustado: float
    faixa_renda: str
    multiplicador_aplicado: float
    ajuste_aplicado: float
    memoria_calculo: list[str]


@dataclass
class ResultadoBaseClientes:
    """Saída do AgenteBaseClientes."""
    score_capacidade: float          # 0–100
    indicador_risco: PerfilRisco
    total_solicitacoes_anteriores: int
    observacoes: list[str]


@dataclass
class EtapaAuditoria:
    """Registro imutável de uma etapa do fluxo."""
    id_solicitacao: str
    agente: str
    timestamp_inicio: datetime
    timestamp_fim: datetime
    duracao_ms: float
    entradas: dict[str, Any]
    saidas: dict[str, Any]
    status: str                      # "ok" | "erro"
    mensagem: str = ""


@dataclass
class RespostaFinal:
    """Objeto de resposta consolidado retornado ao chamador."""
    id_solicitacao: str
    cpf: str
    nome_cliente: str
    decisao: DecisaoCredito
    justificativa_cliente: str
    produto_sugerido: Optional[str]
    limite_aprovado: float
    score_cliente: float
    indicador_risco: PerfilRisco
    timestamp: datetime = field(default_factory=datetime.now)

# ===========================================================================
# BASE DE CONHECIMENTO DE CLIENTES
# (Dados extraídos do documento aurora_bank_clientes.pdf + novos campos)
# ===========================================================================

BASE_CLIENTES: dict[str, DadosCliente] = {}   # preenchida em _carregar_base()


def _carregar_base() -> None:
    """Carrega a base de clientes em memória com todos os dados do PDF
    acrescidos dos novos campos: vínculo empregatício, data de nascimento
    e indicador de conta corrente."""
    clientes = [
        DadosCliente(
            cpf="709.255.516-78", nome="Bruno Nunes Cardoso",
            data_nascimento=date(1990, 4, 15),
            score_serasa=302, renda_mensal=20_205.75, restricao_credito=False,
            comprometimento_renda=2.61,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            financiamento_veiculo=527.93,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="932.277.232-80", nome="Mariana Costa Silva",
            data_nascimento=date(1985, 9, 22),
            score_serasa=663, renda_mensal=8_807.20, restricao_credito=False,
            comprometimento_renda=62.54,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_residencial=93.99, emprestimo_consignado=1_885.22,
            investimento_cdb=3_416.44, previdencia_privada=112.37,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="614.971.615-50", nome="Marcos Costa Vieira",
            data_nascimento=date(1978, 1, 30),
            score_serasa=481, renda_mensal=5_891.42, restricao_credito=False,
            comprometimento_renda=55.04,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=193.69, emprestimo_consignado=330.69,
            investimento_cdb=2_577.64, investimento_tesouro=140.59,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="447.401.424-30", nome="Leandro Batista Soares",
            data_nascimento=date(1982, 6, 11),
            score_serasa=577, renda_mensal=12_342.11, restricao_credito=False,
            comprometimento_renda=17.95,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_residencial=321.93, emprestimo_consignado=528.01,
            previdencia_privada=1_365.08,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="417.704.258-70", nome="Vanessa Mendes Mendes",
            data_nascimento=date(1993, 3, 7),
            score_serasa=733, renda_mensal=23_259.44, restricao_credito=False,
            comprometimento_renda=12.40,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_residencial=158.12, emprestimo_pessoal=432.09,
            emprestimo_consignado=2_293.57,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="173.106.130-74", nome="Aline Santos Rocha",
            data_nascimento=date(1996, 11, 5),
            score_serasa=423, renda_mensal=6_106.01, restricao_credito=False,
            comprometimento_renda=74.09,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=227.56, investimento_cdb=4_296.35,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="328.907.891-44", nome="Gustavo Oliveira Batista",
            data_nascimento=date(1988, 7, 19),
            score_serasa=823, renda_mensal=24_550.48, restricao_credito=False,
            comprometimento_renda=21.16,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_residencial=275.12, investimento_cdb=4_411.70,
            previdencia_privada=509.12,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="441.361.378-34", nome="Bruno Cruz Soares",
            data_nascimento=date(1975, 12, 2),
            score_serasa=427, renda_mensal=8_779.00, restricao_credito=False,
            comprometimento_renda=74.62,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=280.92, seguro_residencial=186.38,
            emprestimo_pessoal=1_652.38, emprestimo_consignado=1_299.53,
            investimento_tesouro=1_351.18, previdencia_privada=1_780.83,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="701.477.536-78", nome="André Rocha Cruz",
            data_nascimento=date(1980, 8, 14),
            score_serasa=618, renda_mensal=29_125.58, restricao_credito=False,
            comprometimento_renda=12.92,
            vinculo_empregaticio=VinculoEmpregaticio.SERVIDOR_PUBLICO,
            possui_conta_corrente=True,
            seguro_residencial=393.54, emprestimo_consignado=2_745.28,
            previdencia_privada=625.57,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="143.401.295-69", nome="Rodrigo Vieira Pinto",
            data_nascimento=date(1971, 5, 25),
            score_serasa=347, renda_mensal=27_794.09, restricao_credito=False,
            comprometimento_renda=4.22,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_vida=105.03, emprestimo_pessoal=1_068.59,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="589.358.962-92", nome="Mariana Silva Moreira",
            data_nascimento=date(1991, 2, 18),
            score_serasa=796, renda_mensal=6_943.29, restricao_credito=False,
            comprometimento_renda=71.25,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=102.54, seguro_residencial=256.69,
            emprestimo_pessoal=432.12, emprestimo_consignado=2_712.30,
            investimento_cdb=627.09, previdencia_privada=816.45,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="745.036.431-00", nome="Marcos Correia Souza",
            data_nascimento=date(2000, 10, 9),
            score_serasa=532, renda_mensal=2_391.53, restricao_credito=False,
            comprometimento_renda=43.64,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_residencial=287.03, investimento_tesouro=756.71,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="575.164.316-05", nome="Renata Ramos Gomes",
            data_nascimento=date(1987, 4, 3),
            score_serasa=823, renda_mensal=11_140.54, restricao_credito=False,
            comprometimento_renda=31.88,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=182.97, emprestimo_pessoal=1_303.75,
            emprestimo_consignado=2_065.09,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="949.497.999-08", nome="João Santos Almeida",
            data_nascimento=date(1979, 6, 20),
            score_serasa=884, renda_mensal=23_072.20, restricao_credito=False,
            comprometimento_renda=25.01,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            investimento_cdb=4_395.00, investimento_tesouro=1_375.37,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="973.175.891-79", nome="Juliana Costa Marques",
            data_nascimento=date(1994, 8, 31),
            score_serasa=275, renda_mensal=10_965.36, restricao_credito=True,
            comprometimento_renda=31.11,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            investimento_cdb=705.70, investimento_tesouro=2_706.04,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="559.374.537-43", nome="Wellington Rocha Marques",
            data_nascimento=date(1983, 3, 17),
            score_serasa=491, renda_mensal=26_234.13, restricao_credito=False,
            comprometimento_renda=11.03,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=197.19, seguro_residencial=143.46,
            investimento_cdb=2_553.00,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="511.413.640-26", nome="Rodrigo Vieira Soares",
            data_nascimento=date(1992, 9, 8),
            score_serasa=844, renda_mensal=19_429.15, restricao_credito=False,
            comprometimento_renda=13.53,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            emprestimo_pessoal=1_258.94, investimento_tesouro=1_369.53,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="806.095.346-02", nome="Rodrigo Ramos Fernandes",
            data_nascimento=date(1977, 1, 14),
            score_serasa=965, renda_mensal=22_766.25, restricao_credito=False,
            comprometimento_renda=16.18,
            vinculo_empregaticio=VinculoEmpregaticio.SERVIDOR_PUBLICO,
            possui_conta_corrente=True,
            financiamento_veiculo=2_393.24, investimento_tesouro=1_291.28,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="263.115.272-78", nome="Wellington Gomes Costa",
            data_nascimento=date(1986, 5, 23),
            score_serasa=856, renda_mensal=24_068.30, restricao_credito=False,
            comprometimento_renda=20.27,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_residencial=328.30, financiamento_veiculo=2_722.11,
            investimento_tesouro=197.19, previdencia_privada=1_630.18,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="110.597.407-37", nome="Priscila Dias Cruz",
            data_nascimento=date(1997, 7, 4),
            score_serasa=131, renda_mensal=9_815.71, restricao_credito=True,
            comprometimento_renda=45.29,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=127.60, seguro_residencial=228.66,
            investimento_cdb=2_408.93, investimento_tesouro=1_680.01,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="598.324.657-70", nome="Lucas Gomes Lima",
            data_nascimento=date(1989, 11, 16),
            score_serasa=851, renda_mensal=17_623.30, restricao_credito=False,
            comprometimento_renda=21.70,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=250.61, emprestimo_consignado=373.69,
            financiamento_veiculo=2_287.63, previdencia_privada=912.77,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="173.023.372-41", nome="Marcos Almeida Almeida",
            data_nascimento=date(1984, 2, 27),
            score_serasa=522, renda_mensal=18_424.74, restricao_credito=False,
            comprometimento_renda=21.73,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_vida=255.06, emprestimo_pessoal=372.71,
            emprestimo_consignado=1_996.01, investimento_cdb=1_379.32,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="035.927.945-74", nome="Cristina Costa Dias",
            data_nascimento=date(1995, 6, 12),
            score_serasa=441, renda_mensal=5_182.92, restricao_credito=False,
            comprometimento_renda=76.89,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=34.10, seguro_residencial=199.43,
            emprestimo_pessoal=1_955.09, investimento_cdb=1_545.37,
            investimento_tesouro=250.95,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="628.377.837-22", nome="Rafael Nunes Marques",
            data_nascimento=date(1981, 10, 28),
            score_serasa=389, renda_mensal=25_341.17, restricao_credito=False,
            comprometimento_renda=17.67,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            emprestimo_pessoal=488.12, financiamento_veiculo=2_288.27,
            investimento_cdb=1_026.21, investimento_tesouro=674.80,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="576.907.945-21", nome="Wellington Ramos Correia",
            data_nascimento=date(1976, 4, 9),
            score_serasa=427, renda_mensal=23_711.28, restricao_credito=False,
            comprometimento_renda=26.41,
            vinculo_empregaticio=VinculoEmpregaticio.APOSENTADO,
            possui_conta_corrente=True,
            financiamento_veiculo=2_528.48, investimento_cdb=2_447.18,
            investimento_tesouro=806.87, previdencia_privada=479.83,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
        DadosCliente(
            cpf="338.323.217-48", nome="Pedro Nunes Marques",
            data_nascimento=date(1973, 8, 5),
            score_serasa=981, renda_mensal=18_263.48, restricao_credito=False,
            comprometimento_renda=43.94,
            vinculo_empregaticio=VinculoEmpregaticio.SERVIDOR_PUBLICO,
            possui_conta_corrente=True,
            emprestimo_pessoal=1_852.50, emprestimo_consignado=406.78,
            financiamento_veiculo=3_628.18, investimento_cdb=2_137.97,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="968.143.469-23", nome="Eduardo Ribeiro Ferreira",
            data_nascimento=date(1990, 12, 1),
            score_serasa=492, renda_mensal=28_315.43, restricao_credito=False,
            comprometimento_renda=14.43,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_vida=260.26, seguro_residencial=66.36,
            investimento_cdb=3_623.28, previdencia_privada=137.24,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="902.779.395-69", nome="Henrique Correia Cardoso",
            data_nascimento=date(1968, 3, 22),
            score_serasa=358, renda_mensal=25_290.97, restricao_credito=True,
            comprometimento_renda=0.0,
            vinculo_empregaticio=VinculoEmpregaticio.APOSENTADO,
            possui_conta_corrente=False,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="538.083.492-20", nome="Aline Ferreira Marques",
            data_nascimento=date(1999, 1, 17),
            score_serasa=126, renda_mensal=2_801.29, restricao_credito=True,
            comprometimento_renda=15.33,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            previdencia_privada=429.56,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="283.679.245-09", nome="Beatriz Vieira Lima",
            data_nascimento=date(1986, 9, 10),
            score_serasa=901, renda_mensal=9_519.76, restricao_credito=False,
            comprometimento_renda=33.45,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=94.37, emprestimo_pessoal=862.07,
            emprestimo_consignado=2_227.77,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="844.717.035-79", nome="Tânia Dias Rocha",
            data_nascimento=date(1980, 11, 28),
            score_serasa=970, renda_mensal=8_471.01, restricao_credito=False,
            comprometimento_renda=5.52,
            vinculo_empregaticio=VinculoEmpregaticio.SERVIDOR_PUBLICO,
            possui_conta_corrente=True,
            seguro_residencial=164.52, previdencia_privada=303.36,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="151.553.044-23", nome="André Azevedo Machado",
            data_nascimento=date(1977, 7, 6),
            score_serasa=410, renda_mensal=14_254.26, restricao_credito=False,
            comprometimento_renda=28.40,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=34.86, investimento_tesouro=2_652.99,
            previdencia_privada=1_359.66,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="140.596.185-60", nome="Cristina Correia Rocha",
            data_nascimento=date(1983, 4, 15),
            score_serasa=934, renda_mensal=22_197.53, restricao_credito=False,
            comprometimento_renda=24.51,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            investimento_cdb=4_151.78, investimento_tesouro=899.50,
            previdencia_privada=389.55,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="752.477.733-73", nome="Pedro Machado Lopes",
            data_nascimento=date(1969, 12, 19),
            score_serasa=716, renda_mensal=2_957.68, restricao_credito=False,
            comprometimento_renda=60.52,
            vinculo_empregaticio=VinculoEmpregaticio.APOSENTADO,
            possui_conta_corrente=True,
            seguro_vida=98.36, financiamento_veiculo=514.48,
            investimento_tesouro=385.73, previdencia_privada=791.49,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="018.376.761-60", nome="Mônica Azevedo Nascimento",
            data_nascimento=date(1991, 3, 7),
            score_serasa=828, renda_mensal=28_753.24, restricao_credito=False,
            comprometimento_renda=10.57,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_vida=176.02, financiamento_veiculo=2_862.52,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="542.538.791-10", nome="Letícia Teixeira Martins",
            data_nascimento=date(1994, 6, 30),
            score_serasa=536, renda_mensal=29_801.37, restricao_credito=False,
            comprometimento_renda=16.97,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=85.52, seguro_residencial=61.60,
            emprestimo_pessoal=909.19, emprestimo_consignado=2_765.91,
            investimento_cdb=347.24, previdencia_privada=887.75,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="430.195.301-99", nome="Vitor Teixeira Marques",
            data_nascimento=date(1985, 8, 24),
            score_serasa=613, renda_mensal=11_122.60, restricao_credito=False,
            comprometimento_renda=73.55,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            emprestimo_pessoal=1_767.24, emprestimo_consignado=1_984.84,
            financiamento_veiculo=2_974.45, investimento_cdb=1_017.99,
            previdencia_privada=436.51,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="220.400.330-17", nome="André Soares Batista",
            data_nascimento=date(1972, 2, 13),
            score_serasa=326, renda_mensal=16_057.10, restricao_credito=False,
            comprometimento_renda=36.04,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=281.33, seguro_residencial=359.85,
            emprestimo_pessoal=584.50, emprestimo_consignado=2_050.28,
            investimento_cdb=511.15, previdencia_privada=1_999.99,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="587.524.058-00", nome="Pedro Correia Teixeira",
            data_nascimento=date(2001, 5, 18),
            score_serasa=928, renda_mensal=1_542.71, restricao_credito=False,
            comprometimento_renda=73.25,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_residencial=331.11, emprestimo_consignado=798.95,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="239.499.283-24", nome="André Carvalho Machado",
            data_nascimento=date(1998, 10, 4),
            score_serasa=257, renda_mensal=1_975.60, restricao_credito=True,
            comprometimento_renda=10.18,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=201.16,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="562.521.042-05", nome="Beatriz Rodrigues Batista",
            data_nascimento=date(1988, 1, 21),
            score_serasa=783, renda_mensal=24_603.97, restricao_credito=False,
            comprometimento_renda=38.32,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            emprestimo_pessoal=1_105.97, financiamento_veiculo=2_610.52,
            investimento_cdb=4_951.02, previdencia_privada=760.28,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="450.541.400-00", nome="Larissa Rodrigues Rodrigues",
            data_nascimento=date(1993, 7, 9),
            score_serasa=687, renda_mensal=21_540.27, restricao_credito=False,
            comprometimento_renda=28.74,
            vinculo_empregaticio=VinculoEmpregaticio.PJ,
            possui_conta_corrente=True,
            seguro_vida=286.22, emprestimo_pessoal=1_965.77,
            investimento_cdb=3_737.59, previdencia_privada=201.17,
            possui_cartao=True, bandeira_atual="Visa",
        ),
        DadosCliente(
            cpf="567.281.856-07", nome="Felipe Vieira Vieira",
            data_nascimento=date(2000, 3, 15),
            score_serasa=593, renda_mensal=2_979.81, restricao_credito=False,
            comprometimento_renda=75.57,
            vinculo_empregaticio=VinculoEmpregaticio.AUTONOMO,
            possui_conta_corrente=False,
            seguro_vida=122.47, seguro_residencial=101.54,
            emprestimo_consignado=1_030.46, investimento_cdb=997.41,
            possui_cartao=False, bandeira_atual="Nenhum",
        ),
        DadosCliente(
            cpf="810.033.266-50", nome="Henrique Andrade Azevedo",
            data_nascimento=date(1976, 9, 28),
            score_serasa=756, renda_mensal=28_895.74, restricao_credito=False,
            comprometimento_renda=20.07,
            vinculo_empregaticio=VinculoEmpregaticio.CLT,
            possui_conta_corrente=True,
            seguro_vida=293.55, seguro_residencial=268.05,
            investimento_cdb=3_056.35, investimento_tesouro=1_215.14,
            previdencia_privada=967.41,
            possui_cartao=True, bandeira_atual="Mastercard",
        ),
    ]
    for c in clientes:
        BASE_CLIENTES[c.cpf] = c


_carregar_base()


# ===========================================================================
# AGENTE 1 — PORTFÓLIO DE PRODUTOS
# ===========================================================================

class AgentePortfolioProdutos:
    """
    Gerencia o catálogo de produtos de cartão de crédito do Aurora Bank.

    Responsabilidades:
    - Manter o catálogo atualizado de produtos disponíveis.
    - Consultar produtos elegíveis dado perfil de risco e faixa de renda.
    - Recomendar o produto mais adequado para um limite calculado.
    """

    CATALOGO: list[ProdutoCartao] = [
        ProdutoCartao(
            nome="Aurora Essencial",
            limite_minimo=500.0,
            limite_maximo=2_000.0,
            perfis_risco_aceitos=[PerfilRisco.ALTO, PerfilRisco.MEDIO],
            anuidade_mensal=0.0,
            beneficios=["Sem anuidade", "Controle via app", "Cashback 0,5%"],
            renda_minima=1_500.0,
            bandeira="Mastercard",
            descricao="Cartão de entrada sem anuidade, ideal para quem está "
                      "construindo seu histórico de crédito.",
        ),
        ProdutoCartao(
            nome="Aurora Clássico",
            limite_minimo=1_000.0,
            limite_maximo=6_000.0,
            perfis_risco_aceitos=[PerfilRisco.MEDIO, PerfilRisco.BAIXO],
            anuidade_mensal=15.0,
            beneficios=["Parcelamento em até 12x", "Seguro de viagem básico",
                        "Cashback 1%"],
            renda_minima=3_000.0,
            bandeira="Mastercard",
            descricao="Cartão clássico para uso cotidiano com benefícios "
                      "essenciais e limite intermediário.",
        ),
        ProdutoCartao(
            nome="Aurora Gold",
            limite_minimo=5_000.0,
            limite_maximo=15_000.0,
            perfis_risco_aceitos=[PerfilRisco.MEDIO, PerfilRisco.BAIXO],
            anuidade_mensal=35.0,
            beneficios=["Programa de pontos 2x", "Seguro de viagem completo",
                        "Acesso a salas VIP nacionais", "Cashback 1,5%"],
            renda_minima=8_000.0,
            bandeira="Visa",
            descricao="Cartão para clientes com perfil médio que buscam "
                      "benefícios de viagem e acúmulo de pontos.",
        ),
        ProdutoCartao(
            nome="Aurora Platinum",
            limite_minimo=10_000.0,
            limite_maximo=40_000.0,
            perfis_risco_aceitos=[PerfilRisco.BAIXO],
            anuidade_mensal=79.0,
            beneficios=["Programa de pontos 3x", "Acesso a salas VIP globais",
                        "Seguro viagem premium", "Concierge 24h",
                        "Cashback 2%"],
            renda_minima=15_000.0,
            bandeira="Visa",
            descricao="Cartão premium para clientes com excelente perfil de "
                      "crédito e alta renda, com benefícios exclusivos.",
        ),
        ProdutoCartao(
            nome="Aurora Infinite",
            limite_minimo=30_000.0,
            limite_maximo=100_000.0,
            perfis_risco_aceitos=[PerfilRisco.BAIXO],
            anuidade_mensal=149.0,
            beneficios=["Pontos ilimitados 5x", "Acesso global a salas VIP",
                        "Seguro viagem global", "Concierge dedicado",
                        "Cashback 3%", "Benefícios em parceiros exclusivos"],
            renda_minima=25_000.0,
            bandeira="Mastercard",
            descricao="O cartão mais exclusivo do Aurora Bank, com os "
                      "melhores benefícios e limites elevados.",
        ),
    ]

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.portfolio")

    def consultar_elegiveis(
        self,
        perfil_risco: PerfilRisco,
        renda_mensal: float,
    ) -> list[ProdutoCartao]:
        """
        Retorna os produtos elegíveis para um dado perfil de risco e renda.

        Args:
            perfil_risco: Perfil de risco avaliado para o cliente.
            renda_mensal: Renda mensal bruta do cliente em R$.

        Returns:
            Lista de produtos que atendem ao perfil e à renda informados.
        """
        elegiveis = [
            p for p in self.CATALOGO
            if perfil_risco in p.perfis_risco_aceitos
            and renda_mensal >= p.renda_minima
        ]
        self._log.info(
            "Produtos elegíveis para perfil '%s' e renda R$ %.2f: %s",
            perfil_risco.value,
            renda_mensal,
            [p.nome for p in elegiveis],
        )
        return elegiveis

    def produto_para_limite(
        self,
        limite_sugerido: float,
        produtos_elegiveis: list[ProdutoCartao],
    ) -> Optional[ProdutoCartao]:
        """
        Retorna o produto mais adequado dado o limite de crédito sugerido.
        Seleciona o produto cujo intervalo [limite_minimo, limite_maximo]
        contém o limite sugerido; em caso de múltiplos, retorna o de maior
        limite máximo (produto mais premium disponível).

        Args:
            limite_sugerido: Limite calculado pelo AgenteGestaoLimite.
            produtos_elegiveis: Lista já filtrada por risco/renda.

        Returns:
            O produto recomendado ou None se nenhum se adequar.
        """
        compatíveis = [
            p for p in produtos_elegiveis
            if p.limite_minimo <= limite_sugerido <= p.limite_maximo
        ]
        if not compatíveis:
            # Fallback: produto com maior limite_maximo que acomode o limite
            compatíveis = [
                p for p in produtos_elegiveis
                if limite_sugerido <= p.limite_maximo
            ]
        if not compatíveis:
            # Último recurso: produto mais acessível da lista elegível
            compatíveis = sorted(produtos_elegiveis, key=lambda p: p.limite_minimo)

        if not compatíveis:
            self._log.warning("Nenhum produto compatível encontrado para limite R$ %.2f", limite_sugerido)
            return None

        recomendado = max(compatíveis, key=lambda p: p.limite_maximo)
        self._log.info("Produto recomendado: %s", recomendado.nome)
        return recomendado

    def executar(
        self,
        perfil_risco: PerfilRisco,
        renda_mensal: float,
        limite_sugerido: float,
    ) -> ResultadoPortfolio:
        """
        Ponto de entrada principal do agente.

        Args:
            perfil_risco: Perfil de risco do cliente.
            renda_mensal: Renda mensal bruta em R$.
            limite_sugerido: Limite calculado pelo AgenteGestaoLimite.

        Returns:
            ResultadoPortfolio com produtos elegíveis e recomendação.
        """
        elegiveis = self.consultar_elegiveis(perfil_risco, renda_mensal)
        recomendado = self.produto_para_limite(limite_sugerido, elegiveis) if elegiveis else None

        if not elegiveis:
            justificativa = (
                "Nenhum produto do catálogo Aurora Bank atende ao perfil de "
                "risco e renda informados."
            )
        elif recomendado:
            justificativa = (
                f"Produto '{recomendado.nome}' recomendado para o perfil "
                f"{perfil_risco.value} com limite de R$ {limite_sugerido:,.2f}."
            )
        else:
            justificativa = "Produtos elegíveis encontrados, mas nenhum acomoda o limite calculado."

        return ResultadoPortfolio(
            produtos_elegiveis=elegiveis,
            produto_recomendado=recomendado,
            justificativa=justificativa,
        )


# ===========================================================================
# AGENTE 2 — GESTÃO DE LIMITE
# ===========================================================================

class AgenteGestaoLimite:
    """
    Calcula o limite de crédito sugerido com base na renda e no vínculo
    empregatício do cliente, aplicando regras de negócio configuráveis.

    Faixas de renda e multiplicadores padrão:
    - Até R$ 3.000   → multiplicador 1,5× (faixa básica)
    - R$ 3.001–10.000 → multiplicador 2,5× (faixa intermediária)
    - R$ 10.001–25.000 → multiplicador 3,5× (faixa superior)
    - Acima de R$ 25.000 → multiplicador 4,5× (faixa premium)

    Bônus por vínculo empregatício (sobre o limite base):
    - Servidor Público / CLT: +15%
    - PJ: +5%
    - Aposentado: +10%
    - Autônomo: −5% (maior instabilidade de renda)
    """

    # Faixas: (limite_superior, multiplicador, nome_faixa)
    FAIXAS_RENDA: list[tuple[float, float, str]] = [
        (3_000.0,    1.5, "Básica (até R$ 3.000)"),
        (10_000.0,   2.5, "Intermediária (R$ 3.001–R$ 10.000)"),
        (25_000.0,   3.5, "Superior (R$ 10.001–R$ 25.000)"),
        (float("inf"), 4.5, "Premium (acima de R$ 25.000)"),
    ]

    BONUS_VINCULO: dict[VinculoEmpregaticio, float] = {
        VinculoEmpregaticio.SERVIDOR_PUBLICO: 0.15,
        VinculoEmpregaticio.CLT:              0.15,
        VinculoEmpregaticio.APOSENTADO:       0.10,
        VinculoEmpregaticio.PJ:               0.05,
        VinculoEmpregaticio.AUTONOMO:        -0.05,
    }

    # Teto absoluto de limite (controle de risco global)
    LIMITE_ABSOLUTO_MAXIMO: float = 100_000.0

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.limite")

    def calcular(
        self,
        renda_mensal: float,
        vinculo: VinculoEmpregaticio,
        ajuste_externo: float = 0.0,
    ) -> ResultadoLimite:
        """
        Calcula o limite de crédito com memória de cálculo detalhada.

        Args:
            renda_mensal: Renda mensal bruta em R$.
            vinculo: Tipo de vínculo empregatício.
            ajuste_externo: Valor em R$ a ser somado/subtraído ao limite base
                            (proveniente do AgenteBaseClientes).

        Returns:
            ResultadoLimite com limite calculado, ajustado e memória de cálculo.
        """
        memoria: list[str] = []

        # 1. Determinar faixa de renda e multiplicador
        multiplicador = 1.5
        faixa_nome = self.FAIXAS_RENDA[0][2]
        for teto, mult, nome in self.FAIXAS_RENDA:
            if renda_mensal <= teto:
                multiplicador = mult
                faixa_nome = nome
                break
        memoria.append(
            f"Renda mensal: R$ {renda_mensal:,.2f} → faixa '{faixa_nome}' "
            f"(multiplicador {multiplicador}×)"
        )

        # 2. Calcular limite base
        limite_base = renda_mensal * multiplicador
        memoria.append(
            f"Limite base: R$ {renda_mensal:,.2f} × {multiplicador} = "
            f"R$ {limite_base:,.2f}"
        )

        # 3. Aplicar bônus/penalidade por vínculo empregatício
        bonus = self.BONUS_VINCULO.get(vinculo, 0.0)
        ajuste_vinculo = limite_base * bonus
        limite_apos_vinculo = limite_base + ajuste_vinculo
        sinal = "+" if bonus >= 0 else ""
        memoria.append(
            f"Ajuste por vínculo ({vinculo.value}): {sinal}{bonus*100:.0f}% → "
            f"{sinal}R$ {ajuste_vinculo:,.2f} → subtotal R$ {limite_apos_vinculo:,.2f}"
        )

        # 4. Aplicar ajuste externo (histórico de crédito)
        limite_calculado = limite_apos_vinculo + ajuste_externo
        sinal_ext = "+" if ajuste_externo >= 0 else ""
        memoria.append(
            f"Ajuste externo (histórico): {sinal_ext}R$ {ajuste_externo:,.2f} → "
            f"total R$ {limite_calculado:,.2f}"
        )

        # 5. Aplicar teto absoluto
        limite_ajustado = min(limite_calculado, self.LIMITE_ABSOLUTO_MAXIMO)
        limite_ajustado = max(limite_ajustado, 0.0)
        if limite_ajustado != limite_calculado:
            memoria.append(
                f"Teto absoluto aplicado: R$ {limite_calculado:,.2f} → "
                f"R$ {limite_ajustado:,.2f}"
            )
        else:
            memoria.append(f"Limite final: R$ {limite_ajustado:,.2f}")

        self._log.info(
            "Limite calculado para renda R$ %.2f (%s): R$ %.2f → R$ %.2f (ajustado)",
            renda_mensal, vinculo.value, limite_calculado, limite_ajustado,
        )
        return ResultadoLimite(
            limite_calculado=round(limite_calculado, 2),
            limite_ajustado=round(limite_ajustado, 2),
            faixa_renda=faixa_nome,
            multiplicador_aplicado=multiplicador,
            ajuste_aplicado=round(ajuste_externo, 2),
            memoria_calculo=memoria,
        )


# ===========================================================================
# AGENTE 3 — BASE DE CLIENTES
# ===========================================================================

@dataclass
class RegistroSolicitacao:
    """Registro de uma solicitação armazenada no histórico do cliente."""
    id_solicitacao: str
    timestamp: datetime
    dados_entrada: dict[str, Any]
    decisao: Optional[str] = None      # preenchido após encerramento do fluxo
    limite_aprovado: Optional[float] = None


class AgenteBaseClientes:
    """
    Gerencia a base de clientes, mantendo histórico de solicitações e
    avaliando a capacidade de pagamento com base em dados cadastrais.

    Escala de score de capacidade (0–100):
    - 0–19:  risco altíssimo (negação automática recomendada)
    - 20–39: alto risco
    - 40–59: risco médio
    - 60–79: risco baixo moderado
    - 80–100: baixo risco
    """

    # Pesos e parâmetros de cálculo do score interno
    _PESO_SCORE_SERASA:    float = 0.50   # 50% do score vem do Serasa (0–1000)
    _PESO_COMPROMETIMENTO: float = 0.25   # 25% vem do comprometimento de renda
    _PESO_HISTORICO:       float = 0.15   # 15% vem do histórico de solicitações
    _PESO_CONTA_CORRENTE:  float = 0.10   # 10% vem da existência de conta corrente

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.base_clientes")
        # Histórico de solicitações por CPF (append-only via método dedicado)
        self._historico: dict[str, list[RegistroSolicitacao]] = {}

    def buscar_cliente(self, cpf: str) -> DadosCliente:
        """
        Busca os dados do cliente pelo CPF na base de conhecimento.

        Args:
            cpf: CPF do cliente no formato XXX.XXX.XXX-XX.

        Returns:
            DadosCliente com todos os dados cadastrais.

        Raises:
            ClienteNaoEncontrado: Se o CPF não estiver na base.
        """
        cliente = BASE_CLIENTES.get(cpf)
        if not cliente:
            raise ClienteNaoEncontrado(
                f"CPF {cpf} não localizado na base de clientes Aurora Bank."
            )
        self._log.info("Cliente localizado: %s (CPF: %s)", cliente.nome, cpf)
        return cliente

    def registrar_solicitacao(
        self,
        id_solicitacao: str,
        cpf: str,
        dados_entrada: dict[str, Any],
    ) -> None:
        """
        Registra uma nova solicitação no histórico (append-only).

        Args:
            id_solicitacao: Identificador único da solicitação.
            cpf: CPF do cliente.
            dados_entrada: Dados da solicitação recebida.
        """
        registro = RegistroSolicitacao(
            id_solicitacao=id_solicitacao,
            timestamp=datetime.now(),
            dados_entrada=dados_entrada,
        )
        if cpf not in self._historico:
            self._historico[cpf] = []
        self._historico[cpf].append(registro)
        self._log.info("Solicitação %s registrada para CPF %s", id_solicitacao, cpf)

    def atualizar_resultado(
        self,
        cpf: str,
        id_solicitacao: str,
        decisao: str,
        limite_aprovado: float,
    ) -> None:
        """
        Atualiza o resultado de uma solicitação já registrada.

        Args:
            cpf: CPF do cliente.
            id_solicitacao: ID da solicitação a ser atualizada.
            decisao: Decisão final (APROVADO, NEGADO, etc.).
            limite_aprovado: Limite de crédito aprovado.
        """
        for reg in self._historico.get(cpf, []):
            if reg.id_solicitacao == id_solicitacao:
                reg.decisao = decisao
                reg.limite_aprovado = limite_aprovado
                return
        self._log.warning(
            "Solicitação %s não encontrada no histórico do CPF %s", id_solicitacao, cpf
        )

    def avaliar_capacidade(self, cliente: DadosCliente, cpf: str) -> ResultadoBaseClientes:
        """
        Avalia a capacidade de pagamento do cliente gerando um score (0–100)
        e um indicador de risco (baixo, médio, alto).

        Lógica de cálculo:
        1. Score Serasa normalizado (0–1000 → 0–100) × peso 50%
        2. Score de comprometimento: 100 − comprometimento% (penaliza alto comprometimento) × peso 25%
        3. Score de histórico: baseado em aprovações anteriores × peso 15%
        4. Score de conta corrente: 100 se tem conta, 50 se não tem × peso 10%

        Args:
            cliente: Dados completos do cliente.
            cpf: CPF para consultar histórico de solicitações.

        Returns:
            ResultadoBaseClientes com score, indicador de risco e observações.
        """
        observacoes: list[str] = []

        # ── Regra de negação automática imediata ──────────────────────────
        # Clientes com restrição de crédito ativa recebem score 0
        if cliente.restricao_credito:
            observacoes.append("ALERTA: Cliente possui restrição de crédito ativa no Serasa.")
            self._log.warning("CPF %s possui restrição de crédito — score zerado.", cpf)
            return ResultadoBaseClientes(
                score_capacidade=0.0,
                indicador_risco=PerfilRisco.ALTO,
                total_solicitacoes_anteriores=len(self._historico.get(cpf, [])),
                observacoes=observacoes,
            )

        # 1. Componente Serasa (0–100)
        score_serasa_norm = (cliente.score_serasa / 1000.0) * 100.0
        observacoes.append(
            f"Score Serasa: {cliente.score_serasa}/1.000 → "
            f"componente normalizado: {score_serasa_norm:.1f}"
        )

        # 2. Componente comprometimento (100 − comprometimento%; mínimo 0)
        score_comprometimento = max(0.0, 100.0 - cliente.comprometimento_renda)
        observacoes.append(
            f"Comprometimento de renda: {cliente.comprometimento_renda:.1f}% → "
            f"componente: {score_comprometimento:.1f}"
        )

        # 3. Componente histórico de solicitações
        historico = self._historico.get(cpf, [])
        total_anteriores = len(historico)
        # Conta aprovações passadas (bônus) e eventuais negações repetidas (penalidade)
        aprovacoes = sum(
            1 for r in historico
            if r.decisao and "APROVADO" in r.decisao
        )
        negacoes = sum(
            1 for r in historico
            if r.decisao and r.decisao == "NEGADO"
        )
        # Score de histórico: começa em 70 (neutro), +10 por aprovação, −15 por negação
        score_historico = min(100.0, max(0.0, 70.0 + aprovacoes * 10 - negacoes * 15))
        observacoes.append(
            f"Histórico: {total_anteriores} solicitação(ões) anterior(es) "
            f"({aprovacoes} aprovadas, {negacoes} negadas) → componente: {score_historico:.1f}"
        )

        # 4. Componente conta corrente
        score_conta = 100.0 if cliente.possui_conta_corrente else 50.0
        observacoes.append(
            f"Conta corrente Aurora Bank: {'Sim' if cliente.possui_conta_corrente else 'Não'} → "
            f"componente: {score_conta:.1f}"
        )

        # Cálculo final ponderado
        score_final = (
            score_serasa_norm    * self._PESO_SCORE_SERASA
            + score_comprometimento * self._PESO_COMPROMETIMENTO
            + score_historico    * self._PESO_HISTORICO
            + score_conta        * self._PESO_CONTA_CORRENTE
        )
        score_final = round(min(100.0, max(0.0, score_final)), 2)

        # Determinar indicador de risco
        if score_final >= 60:
            indicador = PerfilRisco.BAIXO
        elif score_final >= 35:
            indicador = PerfilRisco.MEDIO
        else:
            indicador = PerfilRisco.ALTO

        observacoes.append(
            f"Score de capacidade final: {score_final:.1f}/100 → "
            f"indicador de risco: {indicador.value}"
        )
        self._log.info(
            "Avaliação de capacidade para %s: score=%.1f, risco=%s",
            cpf, score_final, indicador.value,
        )
        return ResultadoBaseClientes(
            score_capacidade=score_final,
            indicador_risco=indicador,
            total_solicitacoes_anteriores=total_anteriores,
            observacoes=observacoes,
        )


# ===========================================================================
# AGENTE 4 — DECISÃO DE CRÉDITO
# ===========================================================================

class AgenteDecisaoCredito:
    """
    Agente central de decisão: combina os resultados dos demais agentes e
    produz a decisão final, justificativa para o cliente e possíveis
    orientações de melhoria.

    Regras de negócio:
    - Score < 20: negação automática (risco inaceitável)
    - Restrição de crédito: negação automática
    - Nenhum produto elegível: negação automática
    - Score entre 20–39 (alto risco): aprovado com limite reduzido em 50%
    - Score entre 40–59 (médio risco): aprovado com limite reduzido em 20%
    - Score ≥ 60 (baixo risco): aprovado com limite calculado integral
    - Limite final não pode ser inferior ao mínimo do produto recomendado
    """

    _SCORE_NEGACAO_AUTOMATICA: float = 20.0
    _SCORE_LIMITE_REDUZIDO_ALTO: float = 40.0    # abaixo → redução 50%
    _SCORE_LIMITE_REDUZIDO_MEDIO: float = 60.0   # abaixo → redução 20%

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.decisao")

    def decidir(
        self,
        cliente: DadosCliente,
        resultado_portfolio: ResultadoPortfolio,
        resultado_limite: ResultadoLimite,
        resultado_base: ResultadoBaseClientes,
    ) -> tuple[DecisaoCredito, str, float]:
        """
        Aplica as regras de decisão e gera a justificativa ao cliente.

        Args:
            cliente: Dados completos do cliente.
            resultado_portfolio: Saída do AgentePortfolioProdutos.
            resultado_limite: Saída do AgenteGestaoLimite.
            resultado_base: Saída do AgenteBaseClientes.

        Returns:
            Tupla (DecisaoCredito, justificativa_texto, limite_aprovado).
        """
        score = resultado_base.score_capacidade
        risco = resultado_base.indicador_risco
        produto = resultado_portfolio.produto_recomendado
        limite_sugerido = resultado_limite.limite_ajustado

        # ── NEGAÇÃO AUTOMÁTICA — restrição de crédito ──────────────────────
        if cliente.restricao_credito:
            msg = self._justificativa_negacao_restricao(cliente.nome)
            self._log.info("Decisão: NEGADO — restrição de crédito ativa.")
            return DecisaoCredito.NEGADO, msg, 0.0

        # ── NEGAÇÃO AUTOMÁTICA — score crítico ────────────────────────────
        if score < self._SCORE_NEGACAO_AUTOMATICA:
            msg = self._justificativa_negacao_score(cliente.nome, score)
            self._log.info("Decisão: NEGADO — score %.1f abaixo do mínimo.", score)
            return DecisaoCredito.NEGADO, msg, 0.0

        # ── NEGAÇÃO AUTOMÁTICA — nenhum produto elegível ───────────────────
        if not resultado_portfolio.produtos_elegiveis:
            msg = self._justificativa_negacao_produto(cliente.nome)
            self._log.info("Decisão: NEGADO — nenhum produto elegível para o perfil.")
            return DecisaoCredito.NEGADO, msg, 0.0

        # ── NEGAÇÃO — não há produto recomendado após ajuste de limite ─────
        if produto is None:
            msg = self._justificativa_negacao_produto(cliente.nome)
            self._log.info("Decisão: NEGADO — nenhum produto acomoda o limite calculado.")
            return DecisaoCredito.NEGADO, msg, 0.0

        # ── Calcular fator de redução com base no score ────────────────────
        if score < self._SCORE_LIMITE_REDUZIDO_ALTO:
            # Alto risco: reduz o limite em 50%
            fator = 0.50
            tipo_decisao = DecisaoCredito.APROVADO_LIMITE_REDUZIDO
            motivo_reducao = "perfil de alto risco"
        elif score < self._SCORE_LIMITE_REDUZIDO_MEDIO:
            # Risco médio: reduz o limite em 20%
            fator = 0.80
            tipo_decisao = DecisaoCredito.APROVADO_LIMITE_REDUZIDO
            motivo_reducao = "perfil de risco médio"
        else:
            # Baixo risco: aprovação integral
            fator = 1.00
            tipo_decisao = DecisaoCredito.APROVADO
            motivo_reducao = ""

        limite_aprovado = round(limite_sugerido * fator, 2)

        # Garante que o limite aprovado não seja inferior ao mínimo do produto
        if limite_aprovado < produto.limite_minimo:
            # Se nem o limite mínimo do produto é atingido após redução, nega
            msg = self._justificativa_negacao_limite_baixo(
                cliente.nome, produto.nome, produto.limite_minimo
            )
            self._log.info(
                "Decisão: NEGADO — limite aprovado R$ %.2f abaixo do mínimo do produto "
                "R$ %.2f.", limite_aprovado, produto.limite_minimo,
            )
            return DecisaoCredito.NEGADO, msg, 0.0

        # Garante que o limite não exceda o máximo do produto
        limite_aprovado = min(limite_aprovado, produto.limite_maximo)

        # ── Gerar justificativa final ──────────────────────────────────────
        if tipo_decisao == DecisaoCredito.APROVADO:
            msg = self._justificativa_aprovado(
                cliente.nome, produto, limite_aprovado, score
            )
        else:
            msg = self._justificativa_aprovado_reduzido(
                cliente.nome, produto, limite_aprovado, limite_sugerido,
                motivo_reducao, score
            )

        self._log.info(
            "Decisão: %s — limite R$ %.2f — produto '%s'",
            tipo_decisao.value, limite_aprovado, produto.nome,
        )
        return tipo_decisao, msg, limite_aprovado

    # ── Métodos de composição de justificativa ─────────────────────────────

    @staticmethod
    def _justificativa_negacao_restricao(nome: str) -> str:
        return (
            f"Prezado(a) {nome},\n\n"
            "Após análise da sua solicitação de cartão de crédito, informamos que, "
            "no momento, não foi possível aprovar o seu pedido.\n\n"
            "Identificamos que existe uma pendência no seu cadastro junto aos órgãos "
            "de proteção ao crédito. Enquanto essa situação não for regularizada, "
            "não conseguimos liberar novos produtos de crédito.\n\n"
            "O que você pode fazer:\n"
            "  • Entre em contato com o Serasa ou SPC para verificar e quitar eventuais "
            "pendências;\n"
            "  • Após a regularização, aguarde a atualização dos cadastros (pode levar "
            "até 5 dias úteis) e solicite novamente;\n"
            "  • Nossa equipe está à disposição para orientar você nesse processo.\n\n"
            "Contamos com a sua compreensão e esperamos poder atendê-lo(a) em breve.\n"
            "Equipe Aurora Bank"
        )

    @staticmethod
    def _justificativa_negacao_score(nome: str, score: float) -> str:
        return (
            f"Prezado(a) {nome},\n\n"
            "Após análise da sua solicitação de cartão de crédito, informamos que, "
            "no momento, não foi possível aprovar o seu pedido.\n\n"
            "Com base nas informações disponíveis em nossos sistemas, identificamos "
            "que o seu perfil de crédito atual requer atenção antes de avançarmos "
            "com a concessão de um cartão.\n\n"
            "O que você pode fazer para melhorar seu perfil:\n"
            "  • Mantenha suas contas em dia e evite atrasos nos pagamentos;\n"
            "  • Reduza o número de consultas ao seu CPF em curtos períodos;\n"
            "  • Utilize nosso app para acompanhar seu score e receber dicas "
            "personalizadas;\n"
            "  • Considere abrir uma conta corrente Aurora Bank para fortalecer "
            "seu relacionamento conosco.\n\n"
            "Você poderá solicitar novamente após 90 dias.\n"
            "Equipe Aurora Bank"
        )

    @staticmethod
    def _justificativa_negacao_produto(nome: str) -> str:
        return (
            f"Prezado(a) {nome},\n\n"
            "Após análise da sua solicitação de cartão de crédito, informamos que, "
            "no momento, não temos um produto de cartão que se encaixe perfeitamente "
            "no seu perfil financeiro atual.\n\n"
            "Isso não é uma negativa definitiva! Significa apenas que precisamos de "
            "um pouco mais de tempo para que você fortaleça seu histórico conosco.\n\n"
            "Sugestões:\n"
            "  • Considere investir regularmente com a Aurora Bank para aumentar "
            "seu relacionamento;\n"
            "  • Mantenha suas finanças organizadas e reduza compromissos de renda;\n"
            "  • Retorne em 6 meses para uma nova análise.\n\n"
            "Equipe Aurora Bank"
        )

    @staticmethod
    def _justificativa_negacao_limite_baixo(
        nome: str, produto: str, limite_minimo: float
    ) -> str:
        return (
            f"Prezado(a) {nome},\n\n"
            "Analisamos com atenção a sua solicitação de cartão de crédito, mas não "
            "conseguimos oferecer um limite que atenda aos requisitos mínimos do "
            f"produto '{produto}' (mínimo de R$ {limite_minimo:,.2f}).\n\n"
            "Para receber uma oferta personalizada no futuro:\n"
            "  • Aumente seu relacionamento financeiro com o Aurora Bank;\n"
            "  • Reduza o comprometimento atual da sua renda;\n"
            "  • Aguarde a melhora gradual do seu perfil de crédito.\n\n"
            "Equipe Aurora Bank"
        )

    @staticmethod
    def _justificativa_aprovado(
        nome: str, produto: ProdutoCartao, limite: float, score: float
    ) -> str:
        beneficios_fmt = "\n".join(f"  • {b}" for b in produto.beneficios)
        return (
            f"Prezado(a) {nome},\n\n"
            "Temos uma ótima notícia para você! 🎉\n\n"
            "Após analisar o seu perfil financeiro, temos o prazer de informar que "
            "a sua solicitação de cartão de crédito foi APROVADA!\n\n"
            f"  Produto: {produto.nome} ({produto.bandeira})\n"
            f"  Limite aprovado: R$ {limite:,.2f}\n"
            f"  Anuidade mensal: R$ {produto.anuidade_mensal:,.2f}\n\n"
            "Benefícios incluídos:\n"
            f"{beneficios_fmt}\n\n"
            "Em breve você receberá seu cartão em até 10 dias úteis. "
            "Acesse nosso app para acompanhar o status da entrega.\n\n"
            "Bem-vindo(a) à família Aurora Bank!\n"
            "Equipe Aurora Bank"
        )

    @staticmethod
    def _justificativa_aprovado_reduzido(
        nome: str, produto: ProdutoCartao, limite: float,
        limite_original: float, motivo: str, score: float
    ) -> str:
        beneficios_fmt = "\n".join(f"  • {b}" for b in produto.beneficios)
        return (
            f"Prezado(a) {nome},\n\n"
            "Temos boas notícias! Sua solicitação de cartão de crédito foi APROVADA!\n\n"
            "Para garantir a melhor experiência e proteger o seu bolso, aprovamos "
            f"um limite inicial adequado ao seu momento financeiro atual ({motivo}).\n\n"
            f"  Produto: {produto.nome} ({produto.bandeira})\n"
            f"  Limite aprovado: R$ {limite:,.2f}\n"
            f"  Anuidade mensal: R$ {produto.anuidade_mensal:,.2f}\n\n"
            "Benefícios incluídos:\n"
            f"{beneficios_fmt}\n\n"
            "Como aumentar seu limite no futuro:\n"
            "  • Use o cartão com responsabilidade e pague sempre em dia;\n"
            "  • Após 6 meses, solicite uma revisão de limite pelo app;\n"
            "  • Quanto mais você usa os serviços Aurora Bank, mais benefícios recebe!\n\n"
            "Bem-vindo(a) à família Aurora Bank!\n"
            "Equipe Aurora Bank"
        )


# ===========================================================================
# AGENTE 5 — AUDITORIA
# ===========================================================================

class AgenteAuditoria:
    """
    Registra de forma estruturada (append-only) cada etapa do fluxo de
    decisão e gera relatórios auditáveis completos.

    O log de auditoria é imutável: entradas só são adicionadas, nunca
    modificadas ou removidas após o registro.
    """

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.auditoria")
        # Estrutura: {id_solicitacao: [EtapaAuditoria, ...]}
        self._registros: dict[str, list[EtapaAuditoria]] = {}
        # Índice CPF → lista de IDs de solicitação para consulta rápida
        self._indice_cpf: dict[str, list[str]] = {}

    def iniciar_solicitacao(self, id_solicitacao: str, cpf: str) -> None:
        """Prepara o log para uma nova solicitação."""
        self._registros[id_solicitacao] = []
        if cpf not in self._indice_cpf:
            self._indice_cpf[cpf] = []
        self._indice_cpf[cpf].append(id_solicitacao)
        self._log.info("Auditoria iniciada para solicitação %s (CPF: %s)", id_solicitacao, cpf)

    def registrar_etapa(
        self,
        id_solicitacao: str,
        agente: str,
        inicio: datetime,
        fim: datetime,
        entradas: dict[str, Any],
        saidas: dict[str, Any],
        status: str = "ok",
        mensagem: str = "",
    ) -> None:
        """
        Registra uma etapa de forma imutável (append-only).

        Args:
            id_solicitacao: ID da solicitação em andamento.
            agente: Nome do agente que executou a etapa.
            inicio: Timestamp de início da execução.
            fim: Timestamp de fim da execução.
            entradas: Dados de entrada recebidos pelo agente.
            saidas: Dados de saída produzidos pelo agente.
            status: "ok" ou "erro".
            mensagem: Mensagem adicional (usada em casos de erro).
        """
        duracao_ms = (fim - inicio).total_seconds() * 1000
        etapa = EtapaAuditoria(
            id_solicitacao=id_solicitacao,
            agente=agente,
            timestamp_inicio=inicio,
            timestamp_fim=fim,
            duracao_ms=round(duracao_ms, 3),
            entradas=entradas,
            saidas=saidas,
            status=status,
            mensagem=mensagem,
        )
        if id_solicitacao not in self._registros:
            self._registros[id_solicitacao] = []
        self._registros[id_solicitacao].append(etapa)
        self._log.debug(
            "Etapa registrada — agente: %s | status: %s | duração: %.1f ms",
            agente, status, duracao_ms,
        )

    def gerar_relatorio(self, id_solicitacao: str) -> str:
        """
        Gera o relatório de auditoria completo em texto estruturado.

        Args:
            id_solicitacao: ID da solicitação.

        Returns:
            Texto formatado com todas as etapas do fluxo.
        """
        etapas = self._registros.get(id_solicitacao, [])
        if not etapas:
            return f"Nenhum registro encontrado para a solicitação {id_solicitacao}."

        linhas: list[str] = [
            "=" * 80,
            " RELATÓRIO DE AUDITORIA — AURORA BANK ".center(80, "="),
            "=" * 80,
            f"  ID Solicitação : {id_solicitacao}",
            f"  Total de etapas: {len(etapas)}",
            f"  Período        : {etapas[0].timestamp_inicio:%d/%m/%Y %H:%M:%S} → "
            f"{etapas[-1].timestamp_fim:%d/%m/%Y %H:%M:%S}",
            "=" * 80,
        ]

        for i, etapa in enumerate(etapas, 1):
            linhas.append(f"\n  ETAPA {i}: {etapa.agente}")
            linhas.append(f"  {'─' * 60}")
            linhas.append(f"  Início   : {etapa.timestamp_inicio:%d/%m/%Y %H:%M:%S.%f}")
            linhas.append(f"  Fim      : {etapa.timestamp_fim:%d/%m/%Y %H:%M:%S.%f}")
            linhas.append(f"  Duração  : {etapa.duracao_ms:.1f} ms")
            linhas.append(f"  Status   : {etapa.status.upper()}")
            if etapa.mensagem:
                linhas.append(f"  Mensagem : {etapa.mensagem}")
            linhas.append(f"  Entradas :")
            for k, v in etapa.entradas.items():
                linhas.append(f"    {k}: {v}")
            linhas.append(f"  Saídas   :")
            for k, v in etapa.saidas.items():
                linhas.append(f"    {k}: {v}")

        linhas.append("\n" + "=" * 80)
        return "\n".join(linhas)

    def consultar_por_cpf(self, cpf: str) -> list[str]:
        """Retorna os IDs de solicitações associados a um CPF."""
        return self._indice_cpf.get(cpf, [])

    def exportar_json(self, id_solicitacao: str) -> str:
        """Exporta o relatório de auditoria em formato JSON."""
        etapas = self._registros.get(id_solicitacao, [])
        dados = [
            {
                "agente": e.agente,
                "timestamp_inicio": e.timestamp_inicio.isoformat(),
                "timestamp_fim": e.timestamp_fim.isoformat(),
                "duracao_ms": e.duracao_ms,
                "status": e.status,
                "mensagem": e.mensagem,
                "entradas": e.entradas,
                "saidas": e.saidas,
            }
            for e in etapas
        ]
        return json.dumps(
            {"id_solicitacao": id_solicitacao, "etapas": dados},
            ensure_ascii=False, indent=2, default=str
        )


# ===========================================================================
# ORQUESTRADOR
# ===========================================================================

class OrquestradorCredito:
    """
    Orquestra o fluxo completo de análise de crédito, coordenando todos os
    agentes na sequência correta e injetando auditoria em cada etapa.

    Fluxo de execução:
    1. Verificar identidade e buscar dados do cliente (AgenteBaseClientes)
    2. Avaliar capacidade de pagamento (AgenteBaseClientes)
    3. Calcular limite de crédito sugerido (AgenteGestaoLimite)
    4. Consultar portfólio de produtos elegíveis (AgentePortfolioProdutos)
    5. Decidir concessão e gerar justificativa (AgenteDecisaoCredito)
    6. Registrar resultado e fechar auditoria
    """

    def __init__(self) -> None:
        self._log = logging.getLogger("aurora_bank.orquestrador")
        self.agente_base = AgenteBaseClientes()
        self.agente_limite = AgenteGestaoLimite()
        self.agente_portfolio = AgentePortfolioProdutos()
        self.agente_decisao = AgenteDecisaoCredito()
        self.agente_auditoria = AgenteAuditoria()

    def processar(self, solicitacao: SolicitacaoCredito) -> RespostaFinal:
        """
        Processa uma solicitação de cartão de crédito do início ao fim.

        Args:
            solicitacao: Objeto com o CPF e ID único da solicitação.

        Returns:
            RespostaFinal com decisão, justificativa e dados de rastreamento.

        Raises:
            ClienteNaoEncontrado: Se o CPF não existir na base.
            ErroAgente: Se algum agente falhar de forma não recuperável.
        """
        sid = solicitacao.id_solicitacao
        cpf = solicitacao.cpf

        self._log.info("═" * 60)
        self._log.info("NOVA SOLICITAÇÃO — ID: %s | CPF: %s", sid, cpf)
        self._log.info("═" * 60)

        # Inicializar auditoria para esta solicitação
        self.agente_auditoria.iniciar_solicitacao(sid, cpf)

        # ── ETAPA 1: Identificação e busca de dados do cliente ─────────────
        t0 = datetime.now()
        try:
            cliente = self.agente_base.buscar_cliente(cpf)
            self.agente_base.registrar_solicitacao(
                id_solicitacao=sid,
                cpf=cpf,
                dados_entrada={
                    "cpf": cpf,
                    "timestamp": solicitacao.timestamp_solicitacao.isoformat(),
                },
            )
        except ClienteNaoEncontrado as exc:
            t1 = datetime.now()
            self.agente_auditoria.registrar_etapa(
                id_solicitacao=sid, agente="AgenteBaseClientes",
                inicio=t0, fim=t1,
                entradas={"cpf": cpf},
                saidas={"erro": str(exc)},
                status="erro", mensagem=str(exc),
            )
            raise

        t1 = datetime.now()
        self.agente_auditoria.registrar_etapa(
            id_solicitacao=sid, agente="AgenteBaseClientes — Identificação",
            inicio=t0, fim=t1,
            entradas={"cpf": cpf},
            saidas={
                "nome": cliente.nome,
                "data_nascimento": cliente.data_nascimento.strftime("%d/%m/%Y"),
                "score_serasa": cliente.score_serasa,
                "renda_mensal": f"R$ {cliente.renda_mensal:,.2f}",
                "vinculo": cliente.vinculo_empregaticio.value,
                "restricao_credito": cliente.restricao_credito,
                "comprometimento_renda": f"{cliente.comprometimento_renda}%",
                "possui_conta_corrente": cliente.possui_conta_corrente,
            },
        )

        # Exibir dados resumidos da solicitação
        self._exibir_resumo_solicitacao(solicitacao, cliente)

        # ── ETAPA 2: Avaliação de capacidade de pagamento ──────────────────
        t0 = datetime.now()
        resultado_base = self.agente_base.avaliar_capacidade(cliente, cpf)
        t1 = datetime.now()
        self.agente_auditoria.registrar_etapa(
            id_solicitacao=sid, agente="AgenteBaseClientes — Capacidade",
            inicio=t0, fim=t1,
            entradas={
                "score_serasa": cliente.score_serasa,
                "comprometimento_renda": f"{cliente.comprometimento_renda}%",
                "restricao_credito": cliente.restricao_credito,
                "possui_conta_corrente": cliente.possui_conta_corrente,
            },
            saidas={
                "score_capacidade": resultado_base.score_capacidade,
                "indicador_risco": resultado_base.indicador_risco.value,
                "observacoes": resultado_base.observacoes,
            },
        )

        # ── ETAPA 3: Cálculo do limite de crédito ─────────────────────────
        t0 = datetime.now()
        # Ajuste externo: bônus se conta corrente, penalidade se comprometimento alto
        ajuste = 0.0
        if cliente.possui_conta_corrente:
            ajuste += cliente.renda_mensal * 0.10   # +10% da renda como bônus
        if cliente.comprometimento_renda > 60:
            ajuste -= cliente.renda_mensal * 0.30   # −30% se muito comprometido
        resultado_limite = self.agente_limite.calcular(
            renda_mensal=cliente.renda_mensal,
            vinculo=cliente.vinculo_empregaticio,
            ajuste_externo=ajuste,
        )
        t1 = datetime.now()
        self.agente_auditoria.registrar_etapa(
            id_solicitacao=sid, agente="AgenteGestaoLimite",
            inicio=t0, fim=t1,
            entradas={
                "renda_mensal": f"R$ {cliente.renda_mensal:,.2f}",
                "vinculo": cliente.vinculo_empregaticio.value,
                "ajuste_externo": f"R$ {ajuste:,.2f}",
            },
            saidas={
                "limite_calculado": f"R$ {resultado_limite.limite_calculado:,.2f}",
                "limite_ajustado": f"R$ {resultado_limite.limite_ajustado:,.2f}",
                "faixa_renda": resultado_limite.faixa_renda,
                "multiplicador": resultado_limite.multiplicador_aplicado,
                "memoria_calculo": resultado_limite.memoria_calculo,
            },
        )

        # ── ETAPA 4: Consulta ao portfólio de produtos ────────────────────
        t0 = datetime.now()
        resultado_portfolio = self.agente_portfolio.executar(
            perfil_risco=resultado_base.indicador_risco,
            renda_mensal=cliente.renda_mensal,
            limite_sugerido=resultado_limite.limite_ajustado,
        )
        t1 = datetime.now()
        self.agente_auditoria.registrar_etapa(
            id_solicitacao=sid, agente="AgentePortfolioProdutos",
            inicio=t0, fim=t1,
            entradas={
                "perfil_risco": resultado_base.indicador_risco.value,
                "renda_mensal": f"R$ {cliente.renda_mensal:,.2f}",
                "limite_sugerido": f"R$ {resultado_limite.limite_ajustado:,.2f}",
            },
            saidas={
                "produtos_elegiveis": [p.nome for p in resultado_portfolio.produtos_elegiveis],
                "produto_recomendado": resultado_portfolio.produto_recomendado.nome
                    if resultado_portfolio.produto_recomendado else "Nenhum",
                "justificativa": resultado_portfolio.justificativa,
            },
        )

        # ── ETAPA 5: Decisão final de crédito ─────────────────────────────
        t0 = datetime.now()
        decisao, justificativa, limite_aprovado = self.agente_decisao.decidir(
            cliente=cliente,
            resultado_portfolio=resultado_portfolio,
            resultado_limite=resultado_limite,
            resultado_base=resultado_base,
        )
        t1 = datetime.now()
        self.agente_auditoria.registrar_etapa(
            id_solicitacao=sid, agente="AgenteDecisaoCredito",
            inicio=t0, fim=t1,
            entradas={
                "score_capacidade": resultado_base.score_capacidade,
                "indicador_risco": resultado_base.indicador_risco.value,
                "limite_sugerido": f"R$ {resultado_limite.limite_ajustado:,.2f}",
                "produto_recomendado": resultado_portfolio.produto_recomendado.nome
                    if resultado_portfolio.produto_recomendado else "Nenhum",
                "restricao_credito": cliente.restricao_credito,
            },
            saidas={
                "decisao": decisao.value,
                "limite_aprovado": f"R$ {limite_aprovado:,.2f}",
                "justificativa": justificativa[:200] + "..." if len(justificativa) > 200 else justificativa,
            },
        )

        # ── ETAPA 6: Registrar resultado final na base de clientes ─────────
        self.agente_base.atualizar_resultado(
            cpf=cpf,
            id_solicitacao=sid,
            decisao=decisao.value,
            limite_aprovado=limite_aprovado,
        )

        # Montar resposta final
        nome_produto = (
            resultado_portfolio.produto_recomendado.nome
            if resultado_portfolio.produto_recomendado and limite_aprovado > 0
            else None
        )
        resposta = RespostaFinal(
            id_solicitacao=sid,
            cpf=cpf,
            nome_cliente=cliente.nome,
            decisao=decisao,
            justificativa_cliente=justificativa,
            produto_sugerido=nome_produto,
            limite_aprovado=limite_aprovado,
            score_cliente=resultado_base.score_capacidade,
            indicador_risco=resultado_base.indicador_risco,
        )
        return resposta

    # ── Apresentação formatada ─────────────────────────────────────────────

    @staticmethod
    def _exibir_resumo_solicitacao(
        sol: SolicitacaoCredito, cliente: DadosCliente
    ) -> None:
        """Exibe no console os dados resumidos da solicitação recebida."""
        print("\n" + "─" * 70)
        print("  📋  SOLICITAÇÃO RECEBIDA".center(70))
        print("─" * 70)
        print(f"  ID da Solicitação : {sol.id_solicitacao}")
        print(f"  Data/Hora         : {sol.timestamp_solicitacao:%d/%m/%Y %H:%M:%S}")
        print(f"  CPF               : {sol.cpf}")
        print()
        print("  DADOS DO CLIENTE (confirmação de identidade)")
        print(f"  Nome              : {cliente.nome}")
        print(f"  Data de Nascimento: {cliente.data_nascimento:%d/%m/%Y}")
        print(f"  Vínculo Empreg.   : {cliente.vinculo_empregaticio.value}")
        print(f"  Conta Corrente    : {'Sim' if cliente.possui_conta_corrente else 'Não'}")
        print(f"  Renda Mensal      : R$ {cliente.renda_mensal:,.2f}")
        print(f"  Score Serasa      : {cliente.score_serasa}")
        print(f"  Comprometimento   : {cliente.comprometimento_renda:.1f}%")
        print(f"  Restrição Crédito : {'⚠️  SIM' if cliente.restricao_credito else 'Não'}")
        print("─" * 70)


def exibir_resposta_final(resposta: RespostaFinal) -> None:
    """Exibe a resposta final formatada como seria apresentada ao cliente."""
    simbolo = "✅" if resposta.decisao == DecisaoCredito.APROVADO else \
              "⚠️ " if resposta.decisao == DecisaoCredito.APROVADO_LIMITE_REDUZIDO else "❌"
    print("\n" + "═" * 70)
    print(f"  {simbolo}  DECISÃO FINAL — {resposta.decisao.value}".center(70))
    print("═" * 70)
    print(f"  Solicitação : {resposta.id_solicitacao}")
    print(f"  Cliente     : {resposta.nome_cliente}")
    print(f"  Score       : {resposta.score_cliente:.1f}/100 "
          f"(risco {resposta.indicador_risco.value})")
    if resposta.produto_sugerido:
        print(f"  Produto     : {resposta.produto_sugerido}")
        print(f"  Limite      : R$ {resposta.limite_aprovado:,.2f}")
    print()
    print("  MENSAGEM PARA O CLIENTE:")
    print("  " + "─" * 66)
    for linha in resposta.justificativa_cliente.splitlines():
        print(f"  {linha}")
    print("═" * 70)


# ===========================================================================
# PONTO DE ENTRADA — EXEMPLOS DE EXECUÇÃO (3 CENÁRIOS)
# ===========================================================================

if __name__ == "__main__":

    print("\n" + "█" * 70)
    print("  AURORA BANK — SISTEMA MULTI-AGENTE DE CONCESSÃO DE CRÉDITO  ".center(70, "█"))
    print("█" * 70)

    # Instancia o orquestrador (compartilhado entre os cenários)
    orquestrador = OrquestradorCredito()

    # =========================================================================
    # CENÁRIO 1 — APROVADO (score alto, renda alta, sem restrição)
    # Cliente: Rodrigo Ramos Fernandes | Score Serasa: 965 | Renda: R$ 22.766,25
    # Vínculo: Servidor Público | Comprometimento: 16,18% | Conta corrente: Sim
    # Expectativa: APROVADO com produto premium
    # =========================================================================
    print("\n\n" + "▓" * 70)
    print("  CENÁRIO 1 — CLIENTE APROVADO (baixo risco)  ".center(70, "▓"))
    print("▓" * 70)

    sol1 = SolicitacaoCredito(cpf="806.095.346-02")
    resposta1 = orquestrador.processar(sol1)
    exibir_resposta_final(resposta1)

    print("\n  📊  RESULTADO DE CADA AGENTE (Cenário 1):")
    print(f"  [AgenteBaseClientes]    Score: {resposta1.score_cliente:.1f}/100 | "
          f"Risco: {resposta1.indicador_risco.value}")
    print(f"  [AgentePortfolio]       Produto sugerido: {resposta1.produto_sugerido}")
    print(f"  [AgenteDecisaoCredito]  Decisão: {resposta1.decisao.value} | "
          f"Limite: R$ {resposta1.limite_aprovado:,.2f}")

    print("\n  📄  RELATÓRIO DE AUDITORIA (Cenário 1):")
    print(orquestrador.agente_auditoria.gerar_relatorio(resposta1.id_solicitacao))

    # =========================================================================
    # CENÁRIO 2 — APROVADO COM LIMITE REDUZIDO (risco médio)
    # Cliente: Marcos Costa Vieira | Score Serasa: 481 | Renda: R$ 5.891,42
    # Vínculo: Autônomo | Comprometimento: 55,04% | Conta corrente: Não
    # Score esperado: ~45 (risco médio → faixa 40–59)
    # → Serasa 48.1 × 0.50 = 24.05
    # → Comprometimento (100-55.04) × 0.25 = 11.24
    # → Histórico neutro 70 × 0.15 = 10.50
    # → Sem conta corrente 50 × 0.10 = 5.00 → total ≈ 50.79
    # Expectativa: APROVADO COM LIMITE REDUZIDO (redução de 20%)
    # =========================================================================
    print("\n\n" + "▓" * 70)
    print("  CENÁRIO 2 — APROVADO COM LIMITE REDUZIDO (risco médio)  ".center(70, "▓"))
    print("▓" * 70)

    sol2 = SolicitacaoCredito(cpf="614.971.615-50")
    resposta2 = orquestrador.processar(sol2)
    exibir_resposta_final(resposta2)

    print("\n  📊  RESULTADO DE CADA AGENTE (Cenário 2):")
    print(f"  [AgenteBaseClientes]    Score: {resposta2.score_cliente:.1f}/100 | "
          f"Risco: {resposta2.indicador_risco.value}")
    print(f"  [AgentePortfolio]       Produto sugerido: {resposta2.produto_sugerido}")
    print(f"  [AgenteDecisaoCredito]  Decisão: {resposta2.decisao.value} | "
          f"Limite: R$ {resposta2.limite_aprovado:,.2f}")

    print("\n  📄  RELATÓRIO DE AUDITORIA (Cenário 2):")
    print(orquestrador.agente_auditoria.gerar_relatorio(resposta2.id_solicitacao))

    # =========================================================================
    # CENÁRIO 3 — NEGADO (restrição de crédito ativa)
    # Cliente: Juliana Costa Marques | Score Serasa: 275 | Restrição: SIM
    # Vínculo: Autônomo | Comprometimento: 31,11% | Conta corrente: Não
    # Expectativa: NEGADO automaticamente por restrição de crédito
    # =========================================================================
    print("\n\n" + "▓" * 70)
    print("  CENÁRIO 3 — NEGADO (restrição de crédito ativa)  ".center(70, "▓"))
    print("▓" * 70)

    sol3 = SolicitacaoCredito(cpf="973.175.891-79")
    resposta3 = orquestrador.processar(sol3)
    exibir_resposta_final(resposta3)

    print("\n  📊  RESULTADO DE CADA AGENTE (Cenário 3):")
    print(f"  [AgenteBaseClientes]    Score: {resposta3.score_cliente:.1f}/100 | "
          f"Risco: {resposta3.indicador_risco.value}")
    print(f"  [AgentePortfolio]       Produto sugerido: {resposta3.produto_sugerido}")
    print(f"  [AgenteDecisaoCredito]  Decisão: {resposta3.decisao.value} | "
          f"Limite: R$ {resposta3.limite_aprovado:,.2f}")

    print("\n  📄  RELATÓRIO DE AUDITORIA (Cenário 3):")
    print(orquestrador.agente_auditoria.gerar_relatorio(resposta3.id_solicitacao))

    # ── Demonstração extra: consulta de auditoria por CPF ─────────────────
    print("\n\n" + "─" * 70)
    print("  🔍  CONSULTA DE AUDITORIA POR CPF".center(70))
    print("─" * 70)
    cpf_demo = "806.095.346-02"
    ids = orquestrador.agente_auditoria.consultar_por_cpf(cpf_demo)
    print(f"  CPF {cpf_demo} → solicitações registradas: {ids}")

    print("\n\n" + "█" * 70)
    print("  FIM DA DEMONSTRAÇÃO DO SISTEMA AURORA BANK  ".center(70, "█"))
    print("█" * 70 + "\n")
