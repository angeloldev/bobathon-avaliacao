"""
gerar_dados.py
Gerador da base sintética de clientes fictícios do Aurora Master.
Produz 200 clientes (100 antigos + 100 novos) com variação intencional
para demonstrar a distorção de limite e a correção pela esteira.
Execute este script uma vez para gerar o arquivo dados/clientes.json.
"""

import json
import random
import os

random.seed(42)  # Reprodutibilidade nos dados gerados

# ── Listas de nomes fictícios para composição dos clientes ──────────────────
NOMES = [
    "Ana Silva", "Bruno Oliveira", "Carla Santos", "Diego Ferreira",
    "Elisa Costa", "Fábio Almeida", "Gabriela Lima", "Henrique Souza",
    "Isabela Pereira", "João Rodrigues", "Karina Martins", "Leonardo Gomes",
    "Mariana Araújo", "Nicolas Barbosa", "Olivia Carvalho", "Pedro Ribeiro",
    "Queila Nascimento", "Rafael Melo", "Sabrina Dias", "Thiago Nunes",
    "Ursula Teixeira", "Vinícius Monteiro", "Wanda Freitas", "Xavier Cardoso",
    "Yasmin Correia", "Zé Paulo Cunha", "Alice Rocha", "Bernardo Pires",
    "Cecília Moraes", "Danilo Ramos", "Eduarda Lopes", "Flávio Sousa",
    "Gisele Nogueira", "Hugo Mendes", "Irene Castro", "Julio Rezende",
    "Kelly Pinheiro", "Lucas Faria", "Mônica Borges", "Nathan Azevedo",
    "Olga Tavares", "Paulo Vasconcelos", "Quézia Paiva", "Renato Guimarães",
    "Sandra Macedo", "Túlio Andrade", "Uriel Braga", "Vanessa Campos",
    "Wendell Duarte", "Ximena Figueiredo",
]


def gerar_cpf_ficticio():
    """Gera CPF fictício no formato XXX.XXX.XXX-XX (apenas para exibição)."""
    nums = [random.randint(0, 9) for _ in range(11)]
    return f"{''.join(map(str, nums[:3]))}.{''.join(map(str, nums[3:6]))}.{''.join(map(str, nums[6:9]))}-{''.join(map(str, nums[9:]))}"


def gerar_cliente_antigo(idx):
    """
    Cria um cliente antigo com relacionamento entre 24 e 180 meses.
    Clientes antigos com bom histórico deveriam ter limites maiores —
    exatamente o cenário que a esteira precisa corrigir.
    """
    nome = random.choice(NOMES) + f" #{idx:03d}"
    tempo_rel = random.randint(24, 180)  # 2 a 15 anos de banco
    renda = round(random.uniform(2500, 18000), 2)

    # Historico mais variado: maioria pontual, alguns irregulares
    historico_pesos = ["pontual"] * 65 + ["irregular"] * 25 + ["inadimplente"] * 10
    historico = random.choice(historico_pesos)

    # Score mais alto para antigos com bom historico
    if historico == "pontual":
        score = random.randint(620, 950)
    elif historico == "irregular":
        score = random.randint(380, 650)
    else:
        score = random.randint(150, 400)

    # Produtos contratados: antigos têm mais produtos
    todos_produtos = ["conta_corrente", "cartao_credito", "credito_pessoal",
                      "consignado", "credito_imobiliario", "seguro_vida"]
    qtd_produtos = random.randint(2, 5)
    produtos = random.sample(todos_produtos, qtd_produtos)

    # Comprometimento de renda estimado
    comprometimento = round(random.uniform(0.10, 0.55), 2)

    return {
        "id": f"CLI-{idx:04d}",
        "nome": nome,
        "cpf": gerar_cpf_ficticio(),
        "tipo_cliente": "antigo",
        "renda_mensal": renda,
        "tempo_relacionamento_meses": tempo_rel,
        "historico_pagamentos": historico,
        "produtos_contratados": produtos,
        "score_interno": score,
        "comprometimento_renda": comprometimento,
        # Limite que o banco ESTAVA concedendo (distorção proposital)
        "limite_atual_banco": 5000.0,
    }


def gerar_cliente_novo(idx):
    """
    Cria um cliente novo com 0 a 6 meses de relacionamento.
    Estes estavam recebendo R$ 30.000 automaticamente — o que a
    esteira irá corrigir avaliando capacidade real de pagamento.
    """
    nome = random.choice(NOMES) + f" #{idx:03d}"
    tempo_rel = random.randint(0, 6)
    renda = round(random.uniform(1500, 25000), 2)

    historico_pesos = ["pontual"] * 50 + ["irregular"] * 30 + ["inadimplente"] * 20
    historico = random.choice(historico_pesos)

    if historico == "pontual":
        score = random.randint(500, 900)
    elif historico == "irregular":
        score = random.randint(300, 550)
    else:
        score = random.randint(100, 320)

    # Novos têm menos produtos
    todos_produtos = ["conta_corrente", "cartao_credito", "credito_pessoal"]
    qtd_produtos = random.randint(1, 3)
    produtos = random.sample(todos_produtos, qtd_produtos)

    comprometimento = round(random.uniform(0.05, 0.70), 2)

    return {
        "id": f"CLI-{idx:04d}",
        "nome": nome,
        "cpf": gerar_cpf_ficticio(),
        "tipo_cliente": "novo",
        "renda_mensal": renda,
        "tempo_relacionamento_meses": tempo_rel,
        "historico_pagamentos": historico,
        "produtos_contratados": produtos,
        "score_interno": score,
        "comprometimento_renda": comprometimento,
        # Limite que o banco ESTAVA concedendo (distorção proposital)
        "limite_atual_banco": 30000.0,
    }


def gerar_base_completa():
    """Gera a base completa: 100 antigos + 100 novos."""
    clientes = []

    print("Gerando 100 clientes antigos...")
    for i in range(1, 101):
        clientes.append(gerar_cliente_antigo(i))

    print("Gerando 100 clientes novos...")
    for i in range(101, 201):
        clientes.append(gerar_cliente_novo(i))

    return clientes


if __name__ == "__main__":
    base = gerar_base_completa()

    caminho = os.path.join(os.path.dirname(__file__), "dados", "clientes.json")
    os.makedirs(os.path.dirname(caminho), exist_ok=True)

    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(base, f, ensure_ascii=False, indent=2)

    total_antigos = sum(1 for c in base if c["tipo_cliente"] == "antigo")
    total_novos = sum(1 for c in base if c["tipo_cliente"] == "novo")
    media_score_antigos = sum(c["score_interno"] for c in base if c["tipo_cliente"] == "antigo") / total_antigos
    media_score_novos = sum(c["score_interno"] for c in base if c["tipo_cliente"] == "novo") / total_novos

    print(f"\n[OK] Base gerada com sucesso: {caminho}")
    print(f"   Total de clientes : {len(base)}")
    print(f"   Clientes antigos  : {total_antigos} | Score medio: {media_score_antigos:.1f}")
    print(f"   Clientes novos    : {total_novos}  | Score medio: {media_score_novos:.1f}")
    print(f"\n[!] Distorcao identificada:")
    print(f"   Clientes antigos recebiam R$ 5.000 fixos - independente do score.")
    print(f"   Clientes novos   recebiam R$ 30.000 fixos - independente do risco.")
