"""
app.py — Servidor Flask da Esteira de Crédito Aurora Master
Serve a interface HTML e expõe a API REST que conecta
o front-end com a esteira de análise de crédito.
"""

import json
import os
import sys

# Garante importações relativas corretas ao rodar de dentro da pasta aurora_master
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, render_template, request, jsonify
from esteira import processar_pedido
from agentes import registro as agente_registro

app = Flask(__name__)

# ── Carregamento da base de clientes sintéticos ───────────────────────────────
CAMINHO_BASE = os.path.join(os.path.dirname(__file__), "dados", "clientes.json")

def carregar_base_clientes():
    """Lê a base de 200 clientes fictícios do arquivo JSON."""
    if not os.path.exists(CAMINHO_BASE):
        return []
    with open(CAMINHO_BASE, "r", encoding="utf-8") as f:
        return json.load(f)


# ── Rotas da interface ────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve a interface principal do sistema Aurora Master."""
    return render_template("index.html")


# ── Rotas da API ──────────────────────────────────────────────────────────────

@app.route("/api/analise", methods=["POST"])
def analisar_credito():
    """
    Recebe os dados do cliente via formulário HTML (JSON) e
    executa a esteira completa de 7 etapas.
    Retorna o resultado completo da análise.
    """
    dados = request.get_json(force=True)
    if not dados:
        return jsonify({"sucesso": False, "erros": ["Nenhum dado recebido"]}), 400

    resultado = processar_pedido(dados)
    return jsonify(resultado)


@app.route("/api/historico", methods=["GET"])
def listar_historico():
    """
    Retorna a lista de todas as análises realizadas na sessão,
    com o resumo executivo de cada uma.
    """
    historico = agente_registro.listar_historico()
    return jsonify({
        "sucesso": True,
        "total": len(historico),
        "historico": historico,
    })


@app.route("/api/historico/<protocolo_id>", methods=["GET"])
def detalhar_analise(protocolo_id):
    """
    Retorna o rastro completo de uma análise específica
    identificada pelo protocolo ID.
    """
    rastro = agente_registro.carregar_analise(protocolo_id)
    if not rastro:
        return jsonify({"sucesso": False, "erro": "Protocolo não encontrado"}), 404
    return jsonify({"sucesso": True, "rastro": rastro})


@app.route("/api/cliente", methods=["GET"])
def buscar_cliente():
    """
    Busca um cliente na base por nome (parcial) e/ou CPF.
    Parâmetros de query: ?nome=... e/ou ?cpf=...
    Retorna os dados completos do cliente se encontrado,
    ou sucesso=False com mensagem se não encontrado.
    """
    clientes = carregar_base_clientes()
    nome_busca = (request.args.get("nome") or "").strip().lower()
    cpf_busca  = (request.args.get("cpf")  or "").strip().replace(".", "").replace("-", "")

    if not nome_busca and not cpf_busca:
        return jsonify({"sucesso": False, "erro": "Informe ao menos nome ou CPF para busca."}), 400

    encontrados = []
    for c in clientes:
        nome_c = c.get("nome", "").lower()
        cpf_c  = c.get("cpf", "").replace(".", "").replace("-", "")

        match_nome = nome_busca and nome_busca in nome_c
        match_cpf  = cpf_busca  and cpf_busca == cpf_c

        # Prioridade: CPF é identificador único — se bater, retorna direto
        if match_cpf:
            return jsonify({"sucesso": True, "cliente": c})

        if match_nome:
            encontrados.append(c)

    if len(encontrados) == 1:
        return jsonify({"sucesso": True, "cliente": encontrados[0]})

    if len(encontrados) > 1:
        return jsonify({
            "sucesso": False,
            "multiplos": True,
            "erro": f"Encontrados {len(encontrados)} clientes com esse nome. Informe o CPF para identificar corretamente.",
            "sugestoes": [{"id": c["id"], "nome": c["nome"], "cpf": c["cpf"]} for c in encontrados],
        })

    return jsonify({
        "sucesso": False,
        "cliente_nao_encontrado": True,
        "erro": "Cliente não encontrado na base. Para solicitar crédito, é necessário abrir uma conta no Banco Aurora.",
    })


@app.route("/api/base-clientes", methods=["GET"])
def listar_base_clientes():
    """
    Retorna a base de clientes sintéticos para análise em lote
    e para o painel de métricas comparativas.
    """
    clientes = carregar_base_clientes()
    tipo = request.args.get("tipo")  # Filtro opcional: ?tipo=novo ou ?tipo=antigo
    if tipo:
        clientes = [c for c in clientes if c.get("tipo_cliente") == tipo]
    return jsonify({
        "sucesso": True,
        "total": len(clientes),
        "clientes": clientes,
    })


@app.route("/api/analise-lote", methods=["POST"])
def analise_em_lote():
    """
    Processa múltiplos clientes da base sintética em sequência.
    Aceita uma lista de IDs ou um limite de quantidade para processar.
    Retorna resultados agregados para o painel de métricas.
    """
    dados_req = request.get_json(force=True) or {}
    quantidade = int(dados_req.get("quantidade", 20))
    tipo_filtro = dados_req.get("tipo_cliente")  # 'novo', 'antigo' ou None (todos)

    clientes = carregar_base_clientes()

    if tipo_filtro:
        clientes = [c for c in clientes if c["tipo_cliente"] == tipo_filtro]

    clientes_processar = clientes[:min(quantidade, 50)]  # Limita a 50 por vez

    resultados = []
    erros = []

    for cliente in clientes_processar:
        try:
            resultado = processar_pedido(cliente)
            rf = resultado["resultado_final"]
            etapas = resultado.get("etapas", {})
            agente_cliente = etapas.get("etapa_3_agente_cliente", {})

            resultados.append({
                "id": cliente["id"],
                "nome": cliente["nome"],
                "cpf": cliente.get("cpf", ""),
                "tipo_cliente": cliente["tipo_cliente"],
                "score_interno": cliente["score_interno"],
                "renda_mensal": cliente.get("renda_mensal", 0),
                "comprometimento_renda": cliente.get("comprometimento_renda", 0),
                "tempo_relacionamento_meses": cliente.get("tempo_relacionamento_meses", 0),
                "historico_pagamentos": cliente.get("historico_pagamentos", ""),
                "produtos_contratados": cliente.get("produtos_contratados", []),
                "limite_anterior": cliente.get("limite_atual_banco", 0),
                "limite_novo": rf["limite_total_aprovado"],
                "status": rf["status_aprovacao"],
                "score_composto": rf["score_composto"],
                "classificacao_risco": rf["classificacao_score"]["faixa"],
                "regra_antidistorcao": rf["antidistorcao"]["distorcao_corrigida"],
                "descricao_antidistorcao": rf["antidistorcao"].get("descricao", ""),
                # Fatores em linguagem humana para o modal
                "fatores_positivos": agente_cliente.get("fatores_positivos_consolidados", []),
                "fatores_negativos": agente_cliente.get("fatores_negativos_consolidados", []),
                "razoes_reprovacao": etapas.get("etapa_5_decisao", {}).get("razoes_reprovacao", []),
                "razoes_ressalvas": etapas.get("etapa_5_decisao", {}).get("razoes_ressalvas", []),
                "justificativa": rf.get("justificativa", ""),
            })
        except Exception as e:
            erros.append({"id": cliente.get("id"), "erro": str(e)})

    # Calcula métricas comparativas
    metricas = calcular_metricas_lote(resultados)

    return jsonify({
        "sucesso": True,
        "total_processados": len(resultados),
        "total_erros": len(erros),
        "resultados": resultados,
        "metricas": metricas,
        "erros": erros,
    })


@app.route("/api/metricas", methods=["GET"])
def obter_metricas():
    """
    Retorna métricas comparativas entre clientes novos e antigos,
    demonstrando a distorção original e a correção pela esteira.
    Usa os dados da base sintética pré-calculados.
    """
    clientes = carregar_base_clientes()

    if not clientes:
        return jsonify({"sucesso": False, "erro": "Base de clientes não encontrada"}), 404

    antigos = [c for c in clientes if c["tipo_cliente"] == "antigo"]
    novos = [c for c in clientes if c["tipo_cliente"] == "novo"]

    metricas = {
        "distorcao_original": {
            "descricao": "Limites que o banco ESTAVA aplicando (antes da esteira)",
            "media_limite_antigos": sum(c["limite_atual_banco"] for c in antigos) / len(antigos),
            "media_limite_novos": sum(c["limite_atual_banco"] for c in novos) / len(novos),
            "media_score_antigos": round(sum(c["score_interno"] for c in antigos) / len(antigos), 1),
            "media_score_novos": round(sum(c["score_interno"] for c in novos) / len(novos), 1),
        },
        "base_resumo": {
            "total_clientes": len(clientes),
            "total_antigos": len(antigos),
            "total_novos": len(novos),
            "distribuicao_historico_antigos": {
                "pontual": sum(1 for c in antigos if c["historico_pagamentos"] == "pontual"),
                "irregular": sum(1 for c in antigos if c["historico_pagamentos"] == "irregular"),
                "inadimplente": sum(1 for c in antigos if c["historico_pagamentos"] == "inadimplente"),
            },
            "distribuicao_historico_novos": {
                "pontual": sum(1 for c in novos if c["historico_pagamentos"] == "pontual"),
                "irregular": sum(1 for c in novos if c["historico_pagamentos"] == "irregular"),
                "inadimplente": sum(1 for c in novos if c["historico_pagamentos"] == "inadimplente"),
            },
        },
    }

    return jsonify({"sucesso": True, "metricas": metricas})


def calcular_metricas_lote(resultados):
    """Calcula métricas agregadas de um processamento em lote."""
    if not resultados:
        return {}

    antigos = [r for r in resultados if r["tipo_cliente"] == "antigo"]
    novos = [r for r in resultados if r["tipo_cliente"] == "novo"]

    def media_ou_zero(lista, campo):
        vals = [item[campo] for item in lista if item.get(campo)]
        return round(sum(vals) / len(vals), 2) if vals else 0

    def contagem_status(lista):
        return {
            "aprovado": sum(1 for r in lista if r["status"] == "aprovado"),
            "aprovado_com_ressalvas": sum(1 for r in lista if r["status"] == "aprovado_com_ressalvas"),
            "reprovado": sum(1 for r in lista if r["status"] == "reprovado"),
        }

    return {
        "antigos": {
            "total": len(antigos),
            "media_limite_anterior": media_ou_zero(antigos, "limite_anterior"),
            "media_limite_novo": media_ou_zero(antigos, "limite_novo"),
            "media_score_composto": media_ou_zero(antigos, "score_composto"),
            "status_distribuicao": contagem_status(antigos),
            "correcoes_antidistorcao": sum(1 for r in antigos if r.get("regra_antidistorcao")),
        },
        "novos": {
            "total": len(novos),
            "media_limite_anterior": media_ou_zero(novos, "limite_anterior"),
            "media_limite_novo": media_ou_zero(novos, "limite_novo"),
            "media_score_composto": media_ou_zero(novos, "score_composto"),
            "status_distribuicao": contagem_status(novos),
        },
        "totais": {
            "processados": len(resultados),
            "aprovados": sum(1 for r in resultados if r["status"] == "aprovado"),
            "com_ressalvas": sum(1 for r in resultados if r["status"] == "aprovado_com_ressalvas"),
            "reprovados": sum(1 for r in resultados if r["status"] == "reprovado"),
        },
    }


if __name__ == "__main__":
    print("=" * 55)
    print("  🏦 Aurora Master — Esteira de Crédito")
    print("=" * 55)
    print(f"  Servidor iniciado em: http://127.0.0.1:5000")
    print(f"  Pressione CTRL+C para encerrar")
    print("=" * 55)
    app.run(debug=True, host="127.0.0.1", port=5000)
