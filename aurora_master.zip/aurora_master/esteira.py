"""
esteira.py — Pipeline principal da Esteira Aurora Master
Integra todos os agentes em sequência e expõe a função `processar_pedido()`
como ponto de entrada único para qualquer análise de crédito.
As 7 etapas são executadas em ordem com o orquestrador gerenciando o fluxo.
"""

import sys
import os

# Garante que os módulos locais sejam encontrados corretamente
sys.path.insert(0, os.path.dirname(__file__))

from agentes import orquestrador, decisao, justificativa, registro
from datetime import datetime


def validar_dados_entrada(dados):
    """
    Etapa 1 — Validação dos dados de entrada recebidos do formulário.
    Verifica campos obrigatórios, tipos e valores aceitáveis.
    Retorna (dados_validados, lista_de_erros).
    """
    erros = []

    # Campos obrigatórios
    campos_obrigatorios = [
        "nome", "cpf", "tipo_cliente", "renda_mensal",
        "tempo_relacionamento_meses", "historico_pagamentos",
        "score_interno",
    ]
    for campo in campos_obrigatorios:
        if campo not in dados or dados[campo] is None or str(dados[campo]).strip() == "":
            erros.append(f"Campo obrigatório ausente: {campo}")

    if erros:
        return None, erros

    # Validações de domínio
    if dados["tipo_cliente"] not in ("novo", "antigo"):
        erros.append("tipo_cliente deve ser 'novo' ou 'antigo'")

    if dados["historico_pagamentos"] not in ("pontual", "irregular", "inadimplente"):
        erros.append("historico_pagamentos deve ser 'pontual', 'irregular' ou 'inadimplente'")

    try:
        renda = float(dados["renda_mensal"])
        if renda <= 0:
            erros.append("renda_mensal deve ser um valor positivo")
        dados["renda_mensal"] = round(renda, 2)
    except (ValueError, TypeError):
        erros.append("renda_mensal deve ser um número válido")

    try:
        tempo = int(dados["tempo_relacionamento_meses"])
        if tempo < 0:
            erros.append("tempo_relacionamento_meses não pode ser negativo")
        dados["tempo_relacionamento_meses"] = tempo
    except (ValueError, TypeError):
        erros.append("tempo_relacionamento_meses deve ser um número inteiro")

    try:
        score = int(dados["score_interno"])
        if not (0 <= score <= 1000):
            erros.append("score_interno deve estar entre 0 e 1000")
        dados["score_interno"] = score
    except (ValueError, TypeError):
        erros.append("score_interno deve ser um número inteiro entre 0 e 1000")

    # Normaliza comprometimento de renda (campo opcional, default 0.30)
    try:
        comp = float(dados.get("comprometimento_renda", 0.30))
        dados["comprometimento_renda"] = max(0.0, min(1.0, comp))
    except (ValueError, TypeError):
        dados["comprometimento_renda"] = 0.30

    # Normaliza produtos contratados (campo opcional)
    if "produtos_contratados" not in dados or not dados["produtos_contratados"]:
        dados["produtos_contratados"] = ["conta_corrente"]  # Todo cliente tem conta
    elif isinstance(dados["produtos_contratados"], str):
        # Se veio como string separada por vírgula (do formulário HTML)
        dados["produtos_contratados"] = [p.strip() for p in dados["produtos_contratados"].split(",") if p.strip()]

    # Garante ID do cliente
    if "id" not in dados or not dados.get("id"):
        dados["id"] = f"CLI-{datetime.now().strftime('%Y%m%d%H%M%S')}"

    return dados, erros


def processar_pedido(dados_entrada):
    """
    Ponto de entrada único da esteira de crédito Aurora Master.
    Executa as 7 etapas em sequência e retorna o resultado completo.

    Parâmetros:
        dados_entrada (dict): dados do cliente vindos do formulário

    Retorna:
        dict com:
            - sucesso (bool)
            - protocolo_id (str)
            - etapas (dict com resultados de cada agente)
            - resultado_final (dict com decisão e justificativa)
            - erros (list) se sucesso=False
    """
    inicio_total = datetime.now()

    # ── Etapa 1: Recebimento e validação ─────────────────────────────────────
    dados_validados, erros = validar_dados_entrada(dados_entrada)
    if erros:
        return {
            "sucesso": False,
            "etapa_falhou": 1,
            "erros": erros,
            "mensagem": "Dados de entrada inválidos. Verifique os campos e tente novamente.",
        }

    # ── Etapas 2, 3 e 4: Carteira + Cliente + Orquestrador ───────────────────
    # O orquestrador aciona internamente os agentes Carteira e Cliente
    resultado_orquestrador = orquestrador.executar(dados_validados)

    # ── Etapa 5: Decisão ──────────────────────────────────────────────────────
    resultado_decisao = decisao.executar(dados_validados, resultado_orquestrador)

    # ── Etapa 6: Justificativa ────────────────────────────────────────────────
    resultado_justificativa = justificativa.executar(
        dados_validados, resultado_decisao, resultado_orquestrador
    )

    # ── Etapa 7: Registro e Auditoria ────────────────────────────────────────
    resultado_registro = registro.executar(
        dados_validados, resultado_orquestrador, resultado_decisao, resultado_justificativa
    )

    fim_total = datetime.now()
    tempo_total_ms = round((fim_total - inicio_total).total_seconds() * 1000, 2)

    # ── Monta resposta consolidada ────────────────────────────────────────────
    return {
        "sucesso": True,
        "protocolo_id": resultado_registro["protocolo_id"],
        "tempo_total_processamento_ms": tempo_total_ms,
        "etapas": {
            "etapa_1_recebimento": {
                "descricao": "Dados recebidos e validados com sucesso",
                "dados_cliente": {k: v for k, v in dados_validados.items() if k not in ("cpf",)},
                "status": "concluido",
            },
            "etapa_2_agente_carteira": resultado_orquestrador["resultado_agente_carteira"],
            "etapa_3_agente_cliente": resultado_orquestrador["resultado_agente_cliente"],
            "etapa_4_orquestrador": {
                "descricao": "Orquestração concluída",
                "limite_final_orquestrado": resultado_orquestrador["limite_final_orquestrado"],
                "regra_antidistorcao_aplicada": resultado_orquestrador["regra_antidistorcao_aplicada"],
                "log_orquestracao": resultado_orquestrador["log_orquestracao"],
                "conflito_detectado": resultado_orquestrador["consolidacao"]["conflito_detectado"],
            },
            "etapa_5_decisao": resultado_decisao,
            "etapa_6_justificativa": resultado_justificativa,
            "etapa_7_registro": resultado_registro,
        },
        "resultado_final": {
            "status_aprovacao": resultado_decisao["status_aprovacao"],
            "status_label": resultado_decisao["status_label"],
            "limite_total_aprovado": resultado_decisao["limite_total_aprovado"],
            "limites_por_linha": resultado_decisao["limites_por_linha"],
            "score_composto": resultado_decisao["score_composto_utilizado"],
            "classificacao_score": resultado_decisao["classificacao_score"],
            "justificativa": resultado_justificativa["justificativa_completa"],
            "justificativa_blocos": resultado_justificativa["blocos"],
            "antidistorcao": resultado_decisao["antidistorcao"],
        },
        "rastro_auditoria": resultado_registro["rastro_completo"],
    }
