# Aurora Master — Esteira de Análise de Crédito
## Instruções de Execução Local

---

### Sobre o Projeto

O Aurora Master é uma esteira de análise de crédito baseada em múltiplos agentes de IA,
desenvolvida para corrigir uma distorção identificada na política de crédito do banco fictício:
clientes novos recebiam **R$ 30.000 automaticamente**, enquanto clientes antigos com bom
relacionamento recebiam apenas **R$ 5.000**.

**Contexto:** Projeto educacional de bootcamp — todos os dados são completamente fictícios.

---

### Pré-requisitos

- Python 3.9 ou superior
- pip (gerenciador de pacotes Python)

Verifique sua versão:
```
python --version
pip --version
```

---

### 1. Instalação das Dependências

Dentro da pasta `aurora_master`, instale o Flask:

```bash
pip install flask
```

Ou crie um ambiente virtual (recomendado):

```bash
# Cria o ambiente virtual
python -m venv venv

# Ativa no Windows (PowerShell)
.\venv\Scripts\Activate.ps1

# Ativa no Linux/macOS
source venv/bin/activate

# Instala dependências
pip install flask
```

---

### 2. Gerar a Base de Dados Sintética

Execute o script gerador para criar os 200 clientes fictícios:

```bash
cd aurora_master
python gerar_dados.py
```

Isso criará o arquivo `dados/clientes.json` com 100 clientes antigos e 100 clientes novos.

---

### 3. Iniciar o Servidor

```bash
cd aurora_master
python app.py
```

Você verá no terminal:

```
═══════════════════════════════════════════════════════
  🏦 Aurora Master — Esteira de Crédito
═══════════════════════════════════════════════════════
  Servidor iniciado em: http://127.0.0.1:5000
  Pressione CTRL+C para encerrar
═══════════════════════════════════════════════════════
```

---

### 4. Acessar a Interface

Abra o navegador e acesse:

```
http://127.0.0.1:5000
```

---

### Estrutura do Projeto

```
aurora_master/
│
├── app.py                   # Servidor Flask e rotas da API
├── esteira.py               # Pipeline principal (integra os 7 agentes)
├── gerar_dados.py           # Gerador da base sintética de clientes
│
├── agentes/
│   ├── __init__.py
│   ├── agente_carteira.py   # Etapa 2: análise de produtos elegíveis
│   ├── agente_cliente.py    # Etapa 3: score composto por 3 dimensões
│   ├── orquestrador.py      # Etapa 4: coordenação e resolução de conflitos
│   ├── decisao.py           # Etapa 5: aprovação e limite final
│   ├── justificativa.py     # Etapa 6: texto explicativo ao cliente
│   └── registro.py          # Etapa 7: auditoria e rastro completo
│
├── dados/
│   └── clientes.json        # Base de 200 clientes fictícios (gerado)
│
├── historico/               # Análises realizadas (JSONs por protocolo)
│
├── templates/
│   └── index.html           # Interface principal
│
└── static/
    ├── css/style.css        # Estilos visuais (paleta azul e branco)
    └── js/
        ├── app.js           # Lógica da interface
        └── metricas.js      # Gráficos Chart.js
```

---

### Funcionalidades da Interface

| Aba | Descrição |
|-----|-----------|
| **Nova Análise** | Formulário para análise individual com progressão visual das 7 etapas |
| **Análise em Lote** | Processa até 50 clientes da base sintética de uma vez |
| **Painel de Métricas** | Gráficos comparando distorção antes/depois da esteira |
| **Histórico** | Lista todas as análises realizadas com rastro auditável |

---

### Rotas da API

| Método | Rota | Descrição |
|--------|------|-----------|
| `POST` | `/api/analise` | Executa a esteira para um cliente |
| `GET`  | `/api/historico` | Lista análises realizadas |
| `GET`  | `/api/historico/<id>` | Detalha uma análise pelo protocolo |
| `GET`  | `/api/base-clientes` | Retorna a base sintética |
| `POST` | `/api/analise-lote` | Processa múltiplos clientes |
| `GET`  | `/api/metricas` | Métricas comparativas da base |

---

### A Distorção e a Correção

**Problema identificado:**
- Base analisada: 100 clientes antigos + 100 clientes novos (recorte de 4 milhões)
- Clientes novos: limite fixo de R$ 30.000 independente de risco
- Clientes antigos: limite fixo de R$ 5.000 independente de relacionamento

**Como a esteira corrige:**
1. **Agente Cliente** avalia 3 dimensões com pesos diferentes para antigos vs novos
2. **Orquestrador** aplica regra anti-distorção: clientes antigos com score ≥ 600 e ≥ 24 meses recebem bônus de 25%
3. **Decisão** usa score composto real, não regras fixas por tipo
4. **Métricas** demonstram o antes e o depois visualmente

---

### Observações

- Todos os CPFs, nomes e dados são **completamente fictícios**
- O projeto **não usa APIs externas** — toda lógica é local
- Os arquivos de auditoria ficam em `historico/` como JSONs por protocolo
- Compatível com Python 3.9+ no Windows, Linux e macOS
