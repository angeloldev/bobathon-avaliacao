"""
agentes/justificativa.py — Etapa 6 da Esteira Aurora Master
Agente Justificativa: gera texto explicativo em linguagem simples,
acessível ao cliente final, explicando a decisão de crédito
sem jargão técnico. Diferencia a linguagem para clientes novos e antigos.
"""

from datetime import datetime


def gerar_saudacao(dados_cliente, resultado_decisao):
    """Gera a saudação personalizada conforme o tipo de cliente."""
    nome_curto = dados_cliente["nome"].split()[0]
    tipo = dados_cliente["tipo_cliente"]
    tempo = dados_cliente.get("tempo_relacionamento_meses", 0)

    if tipo == "antigo":
        if tempo >= 120:
            anos = tempo // 12
            return (
                f"Olá, {nome_curto}! Você é um dos nossos clientes mais especiais — "
                f"são {anos} anos de parceria com o Aurora Master. Agradecemos muito a sua fidelidade."
            )
        elif tempo >= 24:
            anos = tempo // 12
            return (
                f"Olá, {nome_curto}! Que bom ter você aqui! Com {anos} anos de relacionamento conosco, "
                f"você faz parte da família Aurora Master."
            )
        else:
            return (
                f"Olá, {nome_curto}! Você já tem um histórico com o Aurora Master e "
                f"agradecemos a sua confiança no nosso banco."
            )
    else:
        return (
            f"Olá, {nome_curto}! Seja muito bem-vindo ao Aurora Master! "
            f"Estamos felizes em ter você como nosso novo cliente."
        )


def gerar_paragrafo_decisao(resultado_decisao, dados_cliente):
    """Gera o parágrafo principal explicando a decisão."""
    status = resultado_decisao["status_aprovacao"]
    limite = resultado_decisao["limite_total_aprovado"]
    nome_curto = dados_cliente["nome"].split()[0]

    if status == "aprovado":
        return (
            f"Temos uma ótima notícia para você, {nome_curto}! "
            f"Sua solicitação de crédito foi **aprovada** com um limite total de "
            f"**R$ {limite:,.2f}**. Esse valor está disponível nas linhas de crédito "
            f"descritas abaixo e pode ser utilizado de acordo com a sua necessidade."
        )
    elif status == "aprovado_com_ressalvas":
        return (
            f"{nome_curto}, sua solicitação de crédito foi **aprovada com um limite inicial**. "
            f"Você tem à disposição **R$ {limite:,.2f}** para começar. "
            f"Esse valor poderá ser revisto e ampliado conforme seu relacionamento com o banco evolua."
        )
    else:
        return (
            f"{nome_curto}, após uma análise cuidadosa do seu perfil, "
            f"precisamos informar que, neste momento, não foi possível aprovar sua solicitação de crédito. "
            f"Sabemos que essa não é a resposta que você esperava, e por isso vamos explicar tudo com clareza."
        )


def gerar_paragrafo_positivos(fatores_positivos, tipo_cliente, tempo_relacionamento):
    """Gera o parágrafo dos pontos que pesaram positivamente."""
    if not fatores_positivos:
        return ""

    intro = "O que pesou a seu favor:\n"
    if tipo_cliente == "antigo" and tempo_relacionamento >= 24:
        intro = "O que pesou muito a seu favor (inclusive o seu tempo conosco):\n"

    itens = ""
    for fator in fatores_positivos[:5]:  # Limita a 5 itens para não sobrecarregar
        # Traduz termos técnicos para linguagem do cliente
        fator_legivel = (fator
            .replace("score interno", "sua nota de crédito interna")
            .replace("comprometimento", "quanto da sua renda já está comprometida")
            .replace("renda disponível", "valor que sobra da sua renda mensalmente")
            .replace("historico de pagamentos pontual", "você sempre pagou suas contas em dia")
            .replace("pontual", "em dia")
        )
        itens += f"• {fator_legivel.capitalize()}\n"

    return intro + itens


def gerar_paragrafo_negativos(fatores_negativos, status):
    """Gera o parágrafo dos pontos que pesaram negativamente."""
    if not fatores_negativos:
        return ""

    if status == "reprovado":
        intro = "O que nos impediu de aprovar desta vez:\n"
    else:
        intro = "Pontos de atenção identificados:\n"

    itens = ""
    for fator in fatores_negativos[:4]:
        fator_legivel = (fator
            .replace("comprometimento de renda", "valor comprometido da sua renda")
            .replace("score composto", "sua pontuação de crédito")
            .replace("abaixo do mínimo exigido", "ainda não atingiu o patamar necessário")
            .replace("histórico de inadimplência", "dívidas em aberto no seu histórico")
            .replace("limite máximo permitido", "teto que conseguimos trabalhar com segurança")
        )
        itens += f"• {fator_legivel.capitalize()}\n"

    return intro + itens


def gerar_paragrafo_melhorias(status, tipo_cliente, fatores_negativos, score):
    """Gera sugestões de melhoria adaptadas ao perfil do cliente."""
    if status == "aprovado" and score >= 750:
        return (
            "Continue assim! Com seu excelente histórico, em breve você poderá "
            "solicitar um aumento de limite diretamente pelo aplicativo Aurora."
        )

    sugestoes = []

    if "inadimplência" in " ".join(fatores_negativos).lower() or "dívidas" in " ".join(fatores_negativos).lower():
        sugestoes.append(
            "regularize eventuais pendências financeiras — isso é o que mais "
            "impacta positivamente sua pontuação de crédito"
        )

    if "comprometimento" in " ".join(fatores_negativos).lower():
        sugestoes.append(
            "reduza o comprometimento da sua renda quitando dívidas existentes antes "
            "de assumir novos compromissos"
        )

    if score < 500:
        sugestoes.append(
            "mantenha seus pagamentos sempre em dia — cada mês de pontualidade "
            "eleva sua pontuação significativamente"
        )

    if tipo_cliente == "novo":
        sugestoes.append(
            "continue usando os produtos do Aurora Master regularmente — "
            "o tempo de relacionamento conta muito na próxima análise"
        )

    if tipo_cliente == "antigo" and status == "reprovado":
        sugestoes.append(
            "por ser um cliente de relacionamento, nossa equipe pode agendar "
            "uma conversa personalizada para encontrar a melhor solução para você"
        )

    if not sugestoes:
        sugestoes.append("continue mantendo seus compromissos em dia e retorne em 90 dias para nova análise")

    texto = "O que você pode fazer para melhorar:\n"
    for s in sugestoes[:3]:
        texto += f"• {s.capitalize()}\n"

    return texto


def gerar_paragrafo_linhas(limites_por_linha):
    """Detalha as linhas de crédito aprovadas em linguagem simples."""
    if not limites_por_linha:
        return ""

    texto = "Seu crédito aprovado está distribuído assim:\n"
    for produto_id, info in limites_por_linha.items():
        nome = info["nome"]
        limite = info["limite_aprovado"]
        texto += f"• **{nome}**: R$ {limite:,.2f}\n"
    return texto


def gerar_nota_antidistorcao(resultado_decisao, tipo_cliente, tempo_relacionamento):
    """Nota especial quando a regra anti-distorção foi aplicada."""
    if (resultado_decisao.get("antidistorcao", {}).get("distorcao_corrigida") and
            tipo_cliente == "antigo"):
        return (
            f"*Nota: com base no seu histórico de {tempo_relacionamento} meses conosco, "
            f"aplicamos um bônus de fidelidade que ampliou seu limite. "
            f"Clientes antigos com bom histórico merecem reconhecimento — e o Aurora Master honra isso.*"
        )
    return ""


def executar(dados_cliente, resultado_decisao, resultado_orquestrador):
    """
    Ponto de entrada do Agente Justificativa.
    Gera o texto de justificativa completo em linguagem acessível.
    """
    inicio = datetime.now()

    status = resultado_decisao["status_aprovacao"]
    tipo_cliente = dados_cliente["tipo_cliente"]
    tempo_rel = dados_cliente.get("tempo_relacionamento_meses", 0)
    score = resultado_decisao["score_composto_utilizado"]

    fatores_positivos = resultado_orquestrador["resultado_agente_cliente"]["fatores_positivos_consolidados"]
    fatores_negativos = resultado_orquestrador["resultado_agente_cliente"]["fatores_negativos_consolidados"]
    limites_por_linha = resultado_decisao.get("limites_por_linha", {})

    # Constrói a justificativa em blocos
    saudacao = gerar_saudacao(dados_cliente, resultado_decisao)
    paragrafo_decisao = gerar_paragrafo_decisao(resultado_decisao, dados_cliente)
    paragrafo_positivos = gerar_paragrafo_positivos(fatores_positivos, tipo_cliente, tempo_rel)
    paragrafo_negativos = gerar_paragrafo_negativos(fatores_negativos, status)
    paragrafo_linhas = gerar_paragrafo_linhas(limites_por_linha)
    paragrafo_melhorias = gerar_paragrafo_melhorias(status, tipo_cliente, fatores_negativos, score)
    nota_antidistorcao = gerar_nota_antidistorcao(resultado_decisao, tipo_cliente, tempo_rel)

    # Encerramento
    if status == "reprovado":
        encerramento = (
            "Estamos à disposição para tirar dúvidas pelo aplicativo Aurora, "
            "WhatsApp ou nas nossas agências. Você pode solicitar uma nova análise "
            "em 90 dias, ou a qualquer momento se sua situação financeira mudar."
        )
    else:
        encerramento = (
            "Para ativar seu crédito, acesse o aplicativo Aurora Master ou "
            "visite uma de nossas agências. Qualquer dúvida, estamos aqui para você. "
            "Obrigado por confiar no Aurora Master!"
        )

    # Texto completo da justificativa
    blocos = [saudacao, paragrafo_decisao]
    if paragrafo_linhas:
        blocos.append(paragrafo_linhas)
    if paragrafo_positivos:
        blocos.append(paragrafo_positivos)
    if paragrafo_negativos:
        blocos.append(paragrafo_negativos)
    if paragrafo_melhorias:
        blocos.append(paragrafo_melhorias)
    if nota_antidistorcao:
        blocos.append(nota_antidistorcao)
    blocos.append(encerramento)

    texto_completo = "\n\n".join(blocos)

    fim = datetime.now()

    return {
        "agente": "Agente Justificativa",
        "etapa": 6,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "justificativa_completa": texto_completo,
        "blocos": {
            "saudacao": saudacao,
            "decisao": paragrafo_decisao,
            "linhas_aprovadas": paragrafo_linhas,
            "pontos_positivos": paragrafo_positivos,
            "pontos_negativos": paragrafo_negativos,
            "sugestoes_melhoria": paragrafo_melhorias,
            "nota_antidistorcao": nota_antidistorcao,
            "encerramento": encerramento,
        },
        "status": "sucesso",
    }
