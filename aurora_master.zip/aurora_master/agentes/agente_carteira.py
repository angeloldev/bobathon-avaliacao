"""
agentes/agente_carteira.py — Etapa 2 da Esteira Aurora Master
Agente Carteira: analisa os produtos disponíveis no banco e mapeia
quais linhas de crédito são elegíveis para o perfil recebido,
retornando os limites máximos possíveis por produto.
"""

from datetime import datetime


# ── Definição dos produtos do Aurora Master ──────────────────────────────────
PRODUTOS_BANCO = {
    "credito_pessoal": {
        "nome": "Crédito Pessoal Aurora",
        "limite_minimo": 500,
        "limite_maximo": 50000,
        "score_minimo": 400,
        "renda_minima": 1200,
        "descricao": "Crédito pessoal para qualquer finalidade, sem necessidade de garantia.",
    },
    "limite_conta_corrente": {
        "nome": "Limite Conta Corrente",
        "limite_minimo": 200,
        "limite_maximo": 15000,
        "score_minimo": 350,
        "renda_minima": 800,
        "descricao": "Cheque especial vinculado à conta corrente Aurora.",
    },
    "cartao_credito": {
        "nome": "Cartão Aurora Visa",
        "limite_minimo": 300,
        "limite_maximo": 40000,
        "score_minimo": 450,
        "renda_minima": 1000,
        "descricao": "Cartão de crédito com programa de pontos Aurora Rewards.",
    },
    "consignado": {
        "nome": "Crédito Consignado Aurora",
        "limite_minimo": 1000,
        "limite_maximo": 80000,
        "score_minimo": 300,
        "renda_minima": 1500,
        "descricao": "Crédito com desconto em folha, taxas reduzidas.",
    },
    "credito_imobiliario": {
        "nome": "Crédito Imobiliário Aurora",
        "limite_minimo": 50000,
        "limite_maximo": 800000,
        "score_minimo": 650,
        "renda_minima": 5000,
        "descricao": "Financiamento imobiliário com as melhores taxas do mercado.",
    },
}


def calcular_limite_por_produto(produto_id, dados_cliente):
    """
    Calcula o limite máximo elegível para um produto específico,
    considerando renda, score e tempo de relacionamento do cliente.
    Retorna None se o cliente não for elegível para o produto.
    """
    produto = PRODUTOS_BANCO[produto_id]
    score = dados_cliente["score_interno"]
    renda = dados_cliente["renda_mensal"]
    tempo_rel = dados_cliente["tempo_relacionamento_meses"]

    # Verifica critérios mínimos de elegibilidade
    if score < produto["score_minimo"]:
        return None
    if renda < produto["renda_minima"]:
        return None

    # Imobiliário exige pelo menos 3 meses de relacionamento
    if produto_id == "credito_imobiliario" and tempo_rel < 3:
        return None

    # Consignado exige pelo menos 1 mês de relacionamento
    if produto_id == "consignado" and tempo_rel < 1:
        return None

    # Fórmula de limite: múltiplo da renda ajustado pelo score
    fator_score = score / 1000  # 0.0 a 1.0
    fator_renda_base = {
        "credito_pessoal": 5,
        "limite_conta_corrente": 2,
        "cartao_credito": 4,
        "consignado": 12,
        "credito_imobiliario": 80,
    }.get(produto_id, 3)

    limite_calculado = renda * fator_renda_base * fator_score

    # Bônus de relacionamento: clientes antigos recebem até 30% a mais
    if tempo_rel >= 24:
        bônus_fidelidade = min(0.30, (tempo_rel / 180) * 0.30)
        limite_calculado *= (1 + bônus_fidelidade)

    # Aplica o teto e o piso do produto
    limite_final = max(produto["limite_minimo"],
                       min(produto["limite_maximo"], round(limite_calculado, 2)))

    return limite_final


def executar(dados_cliente):
    """
    Ponto de entrada do Agente Carteira.
    Recebe os dados do cliente e retorna o mapeamento
    de produtos elegíveis com seus limites calculados.
    """
    inicio = datetime.now()

    produtos_elegiveis = {}
    produtos_nao_elegiveis = {}

    for produto_id in PRODUTOS_BANCO:
        limite = calcular_limite_por_produto(produto_id, dados_cliente)
        if limite is not None:
            produtos_elegiveis[produto_id] = {
                "nome": PRODUTOS_BANCO[produto_id]["nome"],
                "limite_maximo_elegivel": limite,
                "descricao": PRODUTOS_BANCO[produto_id]["descricao"],
            }
        else:
            motivo = []
            p = PRODUTOS_BANCO[produto_id]
            if dados_cliente["score_interno"] < p["score_minimo"]:
                motivo.append(f"score {dados_cliente['score_interno']} abaixo do mínimo {p['score_minimo']}")
            if dados_cliente["renda_mensal"] < p["renda_minima"]:
                motivo.append(f"renda R${dados_cliente['renda_mensal']:,.2f} abaixo do mínimo R${p['renda_minima']:,.2f}")
            if produto_id == "credito_imobiliario" and dados_cliente["tempo_relacionamento_meses"] < 3:
                motivo.append("tempo de relacionamento inferior a 3 meses")
            if produto_id == "consignado" and dados_cliente["tempo_relacionamento_meses"] < 1:
                motivo.append("tempo de relacionamento inferior a 1 mês")
            produtos_nao_elegiveis[produto_id] = {
                "nome": p["nome"],
                "motivo_inelegibilidade": "; ".join(motivo) if motivo else "critérios não atendidos",
            }

    limite_total_potencial = sum(
        v["limite_maximo_elegivel"] for v in produtos_elegiveis.values()
    )

    fim = datetime.now()

    return {
        "agente": "Agente Carteira",
        "etapa": 2,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "produtos_elegiveis": produtos_elegiveis,
        "produtos_nao_elegiveis": produtos_nao_elegiveis,
        "total_produtos_elegiveis": len(produtos_elegiveis),
        "limite_total_potencial": round(limite_total_potencial, 2),
        "status": "sucesso",
    }
