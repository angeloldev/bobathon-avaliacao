"""
agentes/agente_cliente.py — Etapa 3 da Esteira Aurora Master
Agente Cliente: analisa o perfil do cliente em três dimensões —
histórico, comportamento e capacidade de pagamento — e gera
um score composto interno (0 a 1000) com peso diferenciado
para clientes antigos, valorizando fidelidade e relacionamento.
"""

from datetime import datetime


# ── Pesos do score composto por dimensão ────────────────────────────────────
PESOS_NOVO = {
    "historico": 0.30,
    "comportamento": 0.30,
    "capacidade": 0.40,
}

# Clientes antigos têm maior peso no histórico e comportamento (fidelidade)
PESOS_ANTIGO = {
    "historico": 0.40,
    "comportamento": 0.35,
    "capacidade": 0.25,
}

# Pontuação base por histórico de pagamento
PONTUACAO_HISTORICO = {
    "pontual": 900,
    "irregular": 500,
    "inadimplente": 150,
}


def avaliar_historico(dados_cliente):
    """
    Dimensão 1 — Histórico:
    Avalia tempo de conta, pontualidade e ocorrências negativas.
    Retorna pontuação de 0 a 1000 e fatores identificados.
    """
    pontos = PONTUACAO_HISTORICO.get(dados_cliente["historico_pagamentos"], 400)
    fatores_positivos = []
    fatores_negativos = []
    penalidades = 0
    bonificacoes = 0

    tempo = dados_cliente["tempo_relacionamento_meses"]

    # Bônus de longevidade: quanto mais antigo, melhor o histórico
    if tempo >= 120:
        bonificacoes += 80
        fatores_positivos.append(f"relacionamento de longa data ({tempo} meses — mais de 10 anos)")
    elif tempo >= 60:
        bonificacoes += 50
        fatores_positivos.append(f"relacionamento consolidado ({tempo} meses — mais de 5 anos)")
    elif tempo >= 24:
        bonificacoes += 25
        fatores_positivos.append(f"relacionamento estabelecido ({tempo} meses — mais de 2 anos)")
    elif tempo >= 6:
        bonificacoes += 10
        fatores_positivos.append(f"início de relacionamento ({tempo} meses)")
    else:
        fatores_negativos.append("cliente muito recente — histórico insuficiente para análise completa")

    # Análise do histórico de pagamento
    if dados_cliente["historico_pagamentos"] == "pontual":
        bonificacoes += 50
        fatores_positivos.append("histórico de pagamentos pontual")
    elif dados_cliente["historico_pagamentos"] == "irregular":
        penalidades += 100
        fatores_negativos.append("histórico com pagamentos irregulares")
    else:
        penalidades += 250
        fatores_negativos.append("registros de inadimplência")

    # Diversidade de produtos como indicador de engajamento
    qtd_produtos = len(dados_cliente.get("produtos_contratados", []))
    if qtd_produtos >= 4:
        bonificacoes += 40
        fatores_positivos.append(f"alta utilização de produtos ({qtd_produtos} produtos contratados)")
    elif qtd_produtos >= 2:
        bonificacoes += 15
        fatores_positivos.append(f"utilização moderada de produtos ({qtd_produtos} produtos)")

    pontuacao_final = max(0, min(1000, pontos + bonificacoes - penalidades))

    return {
        "dimensao": "historico",
        "pontuacao": round(pontuacao_final),
        "fatores_positivos": fatores_positivos,
        "fatores_negativos": fatores_negativos,
        "detalhes": {
            "pontuacao_base_historico": pontos,
            "bonificacoes": bonificacoes,
            "penalidades": penalidades,
            "tempo_relacionamento_meses": tempo,
            "historico_pagamentos": dados_cliente["historico_pagamentos"],
            "quantidade_produtos": qtd_produtos,
        },
    }


def avaliar_comportamento(dados_cliente):
    """
    Dimensão 2 — Comportamento:
    Avalia padrão de uso dos produtos, frequência e engajamento.
    Retorna pontuação de 0 a 1000 e fatores identificados.
    """
    fatores_positivos = []
    fatores_negativos = []
    pontos = 500  # Base neutra

    produtos = dados_cliente.get("produtos_contratados", [])
    tempo = dados_cliente["tempo_relacionamento_meses"]
    score_interno = dados_cliente["score_interno"]
    comprometimento = dados_cliente.get("comprometimento_renda", 0.30)

    # Score interno como proxy de comportamento histórico
    pontos = score_interno * 0.8  # Normaliza para base comportamental

    # Variedade de produtos indica engajamento
    if "cartao_credito" in produtos and "conta_corrente" in produtos:
        pontos += 60
        fatores_positivos.append("utiliza conta corrente e cartão — perfil de relacionamento ativo")

    if "consignado" in produtos:
        pontos += 40
        fatores_positivos.append("possui crédito consignado — indicativo de estabilidade de renda")

    if "credito_imobiliario" in produtos:
        pontos += 50
        fatores_positivos.append("possui financiamento imobiliário — comprometimento de longo prazo")

    # Comprometimento de renda
    if comprometimento > 0.60:
        pontos -= 120
        fatores_negativos.append(f"comprometimento elevado da renda ({comprometimento:.0%})")
    elif comprometimento > 0.40:
        pontos -= 50
        fatores_negativos.append(f"comprometimento moderado da renda ({comprometimento:.0%})")
    elif comprometimento <= 0.20:
        pontos += 30
        fatores_positivos.append(f"baixo comprometimento da renda ({comprometimento:.0%}) — boa folga financeira")

    # Clientes antigos com uso contínuo demonstram comportamento confiável
    if tempo >= 36 and len(produtos) >= 3:
        pontos += 70
        fatores_positivos.append("uso contínuo e diversificado por mais de 3 anos")

    pontuacao_final = max(0, min(1000, round(pontos)))

    return {
        "dimensao": "comportamento",
        "pontuacao": pontuacao_final,
        "fatores_positivos": fatores_positivos,
        "fatores_negativos": fatores_negativos,
        "detalhes": {
            "score_interno_base": score_interno,
            "comprometimento_renda": comprometimento,
            "produtos_analisados": produtos,
        },
    }


def avaliar_capacidade_pagamento(dados_cliente):
    """
    Dimensão 3 — Capacidade de Pagamento:
    Avalia renda disponível, comprometimento atual e score para
    estimar a capacidade de honrar novos compromissos.
    Retorna pontuação de 0 a 1000 e fatores identificados.
    """
    fatores_positivos = []
    fatores_negativos = []

    renda = dados_cliente["renda_mensal"]
    comprometimento = dados_cliente.get("comprometimento_renda", 0.30)
    score = dados_cliente["score_interno"]

    # Renda disponível após comprometimentos existentes
    renda_disponivel = renda * (1 - comprometimento)

    # Pontuação baseada na renda disponível
    if renda_disponivel >= 8000:
        pontos_renda = 900
        fatores_positivos.append(f"renda disponível elevada (R${renda_disponivel:,.2f}/mês)")
    elif renda_disponivel >= 4000:
        pontos_renda = 750
        fatores_positivos.append(f"renda disponível confortável (R${renda_disponivel:,.2f}/mês)")
    elif renda_disponivel >= 2000:
        pontos_renda = 580
        fatores_positivos.append(f"renda disponível adequada (R${renda_disponivel:,.2f}/mês)")
    elif renda_disponivel >= 800:
        pontos_renda = 400
        fatores_negativos.append(f"renda disponível limitada (R${renda_disponivel:,.2f}/mês)")
    else:
        pontos_renda = 200
        fatores_negativos.append(f"renda disponível insuficiente (R${renda_disponivel:,.2f}/mês)")

    # Score como indicador de capacidade histórica
    pontos_score = score

    # Pontuação composta: 60% renda disponível, 40% score
    pontuacao_final = round((pontos_renda * 0.60) + (pontos_score * 0.40))
    pontuacao_final = max(0, min(1000, pontuacao_final))

    # Faixa de crédito sugerida com base na capacidade
    parcela_maxima_segura = renda_disponivel * 0.30  # 30% da renda disponível
    limite_sugerido = parcela_maxima_segura * 12  # Capacidade anual

    return {
        "dimensao": "capacidade_pagamento",
        "pontuacao": pontuacao_final,
        "fatores_positivos": fatores_positivos,
        "fatores_negativos": fatores_negativos,
        "detalhes": {
            "renda_mensal": renda,
            "comprometimento_atual": comprometimento,
            "renda_disponivel": round(renda_disponivel, 2),
            "parcela_maxima_segura": round(parcela_maxima_segura, 2),
            "limite_sugerido_capacidade": round(limite_sugerido, 2),
            "score_interno": score,
        },
    }


def calcular_score_composto(historico, comportamento, capacidade, tipo_cliente):
    """
    Combina as três dimensões com pesos ajustados por tipo de cliente.
    Clientes antigos têm valorização extra pela fidelidade (bônus de relacionamento).
    """
    pesos = PESOS_ANTIGO if tipo_cliente == "antigo" else PESOS_NOVO

    score_ponderado = (
        historico["pontuacao"] * pesos["historico"] +
        comportamento["pontuacao"] * pesos["comportamento"] +
        capacidade["pontuacao"] * pesos["capacidade"]
    )

    # Bônus de fidelidade exclusivo para clientes antigos
    bonus_fidelidade = 0
    if tipo_cliente == "antigo":
        bonus_fidelidade = min(80, historico["detalhes"]["tempo_relacionamento_meses"] * 0.5)

    score_final = min(1000, round(score_ponderado + bonus_fidelidade))

    return {
        "score_composto": score_final,
        "pesos_aplicados": pesos,
        "bonus_fidelidade": round(bonus_fidelidade),
        "componentes": {
            "historico": round(historico["pontuacao"] * pesos["historico"]),
            "comportamento": round(comportamento["pontuacao"] * pesos["comportamento"]),
            "capacidade": round(capacidade["pontuacao"] * pesos["capacidade"]),
        },
        "classificacao": classificar_score(score_final),
    }


def classificar_score(score):
    """Classifica o score composto em faixas de risco."""
    if score >= 800:
        return {"faixa": "Excelente", "risco": "Muito Baixo", "cor": "#22c55e"}
    elif score >= 650:
        return {"faixa": "Bom", "risco": "Baixo", "cor": "#84cc16"}
    elif score >= 500:
        return {"faixa": "Regular", "risco": "Médio", "cor": "#f59e0b"}
    elif score >= 350:
        return {"faixa": "Ruim", "risco": "Alto", "cor": "#f97316"}
    else:
        return {"faixa": "Crítico", "risco": "Muito Alto", "cor": "#ef4444"}


def executar(dados_cliente):
    """
    Ponto de entrada do Agente Cliente.
    Executa as três dimensões de análise e gera o score composto.
    """
    inicio = datetime.now()

    # Avaliação das três dimensões
    analise_historico = avaliar_historico(dados_cliente)
    analise_comportamento = avaliar_comportamento(dados_cliente)
    analise_capacidade = avaliar_capacidade_pagamento(dados_cliente)

    # Score composto com pesos por tipo de cliente
    score_composto = calcular_score_composto(
        analise_historico,
        analise_comportamento,
        analise_capacidade,
        dados_cliente["tipo_cliente"],
    )

    # Consolida todos os fatores positivos e negativos
    todos_positivos = (
        analise_historico["fatores_positivos"] +
        analise_comportamento["fatores_positivos"] +
        analise_capacidade["fatores_positivos"]
    )
    todos_negativos = (
        analise_historico["fatores_negativos"] +
        analise_comportamento["fatores_negativos"] +
        analise_capacidade["fatores_negativos"]
    )

    fim = datetime.now()

    return {
        "agente": "Agente Cliente",
        "etapa": 3,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "analise_historico": analise_historico,
        "analise_comportamento": analise_comportamento,
        "analise_capacidade": analise_capacidade,
        "score_composto": score_composto,
        "fatores_positivos_consolidados": todos_positivos,
        "fatores_negativos_consolidados": todos_negativos,
        "limite_sugerido_por_capacidade": analise_capacidade["detalhes"]["limite_sugerido_capacidade"],
        "status": "sucesso",
    }
