"""
agentes/registro.py — Etapa 7 da Esteira Aurora Master
Agente Registro e Auditoria: grava o rastro completo da decisão,
gera ID de protocolo único, persiste em arquivo JSON e
fornece dados para o painel de métricas.
"""

import json
import os
import uuid
from datetime import datetime


# Diretório de histórico de decisões
HISTORICO_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "historico")


def gerar_id_protocolo():
    """
    Gera um ID de protocolo único no formato:
    AM-YYYYMMDD-HHMMSS-XXXX (AM = Aurora Master)
    """
    agora = datetime.now()
    sufixo = str(uuid.uuid4()).upper()[:6]
    return f"AM-{agora.strftime('%Y%m%d')}-{agora.strftime('%H%M%S')}-{sufixo}"


def montar_rastro_completo(dados_cliente, resultado_orquestrador, resultado_decisao, resultado_justificativa):
    """
    Monta o rastro auditável completo com todas as etapas da esteira.
    Este é o registro imutável que permite rastrear qualquer decisão.
    """
    agora = datetime.now()
    protocolo_id = gerar_id_protocolo()

    # Resumo executivo da decisão
    resumo = {
        "protocolo_id": protocolo_id,
        "timestamp_decisao": agora.isoformat(),
        "data_formatada": agora.strftime("%d/%m/%Y às %H:%M:%S"),
        "cliente": {
            "id": dados_cliente.get("id", "N/A"),
            "nome": dados_cliente["nome"],
            "cpf_mascarado": mascarar_cpf(dados_cliente.get("cpf", "000.000.000-00")),
            "tipo_cliente": dados_cliente["tipo_cliente"],
        },
        "decisao_final": {
            "status": resultado_decisao["status_aprovacao"],
            "status_label": resultado_decisao["status_label"],
            "limite_total_aprovado": resultado_decisao["limite_total_aprovado"],
            "score_composto": resultado_decisao["score_composto_utilizado"],
            "classificacao_risco": resultado_decisao["classificacao_score"]["faixa"],
        },
    }

    # Rastro por etapa
    etapas = {
        "etapa_1_recebimento": {
            "descricao": "Recebimento e validação dos dados do cliente",
            "dados_entrada": sanitizar_dados_entrada(dados_cliente),
            "timestamp": agora.isoformat(),
            "status": "concluido",
        },
        "etapa_2_agente_carteira": resultado_orquestrador["resultado_agente_carteira"],
        "etapa_3_agente_cliente": resultado_orquestrador["resultado_agente_cliente"],
        "etapa_4_orquestrador": {
            "descricao": resultado_orquestrador["agente"],
            "timestamp_inicio": resultado_orquestrador["timestamp_inicio"],
            "timestamp_fim": resultado_orquestrador["timestamp_fim"],
            "duracao_ms": resultado_orquestrador["duracao_ms"],
            "limite_final_orquestrado": resultado_orquestrador["limite_final_orquestrado"],
            "conflito_detectado": resultado_orquestrador["consolidacao"]["conflito_detectado"],
            "regra_antidistorcao_aplicada": resultado_orquestrador["regra_antidistorcao_aplicada"],
            "log_orquestracao": resultado_orquestrador["log_orquestracao"],
            "status": "concluido",
        },
        "etapa_5_decisao": resultado_decisao,
        "etapa_6_justificativa": resultado_justificativa,
        "etapa_7_registro": {
            "descricao": "Registro auditável gerado",
            "protocolo_id": protocolo_id,
            "timestamp": agora.isoformat(),
            "status": "concluido",
        },
    }

    # Métricas de tempo por etapa
    metricas_tempo = calcular_metricas_tempo(resultado_orquestrador, resultado_decisao, resultado_justificativa)

    return {
        "versao_esteira": "1.0.0",
        "banco": "Aurora Master",
        "resumo": resumo,
        "etapas": etapas,
        "metricas_tempo": metricas_tempo,
    }


def mascarar_cpf(cpf):
    """Mascara o CPF para exibição no rastro: XXX.***.***-XX"""
    partes = cpf.replace("-", "").replace(".", "")
    if len(partes) == 11:
        return f"{partes[:3]}.***.***.{partes[-2:]}"
    return "***.***.***-**"


def sanitizar_dados_entrada(dados_cliente):
    """Remove dados sensíveis do rastro público, mantendo o que é auditável."""
    return {
        "id": dados_cliente.get("id", "N/A"),
        "tipo_cliente": dados_cliente["tipo_cliente"],
        "renda_mensal": dados_cliente["renda_mensal"],
        "tempo_relacionamento_meses": dados_cliente.get("tempo_relacionamento_meses", 0),
        "historico_pagamentos": dados_cliente["historico_pagamentos"],
        "produtos_contratados": dados_cliente.get("produtos_contratados", []),
        "score_interno_declarado": dados_cliente.get("score_interno", 0),
        "comprometimento_renda": dados_cliente.get("comprometimento_renda", 0),
        # CPF e nome não são incluídos no rastro técnico por LGPD
        "cpf_presente": bool(dados_cliente.get("cpf")),
    }


def calcular_metricas_tempo(resultado_orquestrador, resultado_decisao, resultado_justificativa):
    """Calcula métricas de desempenho de cada etapa da esteira."""
    return {
        "agente_carteira_ms": resultado_orquestrador["resultado_agente_carteira"].get("duracao_ms", 0),
        "agente_cliente_ms": resultado_orquestrador["resultado_agente_cliente"].get("duracao_ms", 0),
        "orquestrador_ms": resultado_orquestrador.get("duracao_ms", 0),
        "decisao_ms": resultado_decisao.get("duracao_ms", 0),
        "justificativa_ms": resultado_justificativa.get("duracao_ms", 0),
        "total_estimado_ms": (
            resultado_orquestrador["resultado_agente_carteira"].get("duracao_ms", 0) +
            resultado_orquestrador["resultado_agente_cliente"].get("duracao_ms", 0) +
            resultado_decisao.get("duracao_ms", 0) +
            resultado_justificativa.get("duracao_ms", 0)
        ),
    }


def persistir_historico(rastro_completo):
    """
    Persiste o rastro completo em arquivo JSON no diretório histórico.
    Cada análise gera um arquivo único identificado pelo protocolo.
    """
    os.makedirs(HISTORICO_DIR, exist_ok=True)
    protocolo_id = rastro_completo["resumo"]["protocolo_id"]
    caminho = os.path.join(HISTORICO_DIR, f"{protocolo_id}.json")

    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(rastro_completo, f, ensure_ascii=False, indent=2)

    return caminho


def listar_historico():
    """
    Retorna a lista de todas as análises já realizadas,
    com o resumo executivo de cada uma (sem o rastro completo).
    """
    os.makedirs(HISTORICO_DIR, exist_ok=True)
    historico = []

    for arquivo in sorted(os.listdir(HISTORICO_DIR), reverse=True):
        if arquivo.endswith(".json"):
            caminho = os.path.join(HISTORICO_DIR, arquivo)
            try:
                with open(caminho, "r", encoding="utf-8") as f:
                    dados = json.load(f)
                historico.append(dados.get("resumo", {}))
            except Exception:
                continue

    return historico


def carregar_analise(protocolo_id):
    """Carrega o rastro completo de uma análise pelo protocolo ID."""
    caminho = os.path.join(HISTORICO_DIR, f"{protocolo_id}.json")
    if not os.path.exists(caminho):
        return None
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def executar(dados_cliente, resultado_orquestrador, resultado_decisao, resultado_justificativa):
    """
    Ponto de entrada do Agente Registro.
    Monta o rastro completo, persiste e retorna os metadados do registro.
    """
    inicio = datetime.now()

    rastro = montar_rastro_completo(
        dados_cliente,
        resultado_orquestrador,
        resultado_decisao,
        resultado_justificativa,
    )

    # Persiste no histórico local
    caminho_arquivo = persistir_historico(rastro)

    fim = datetime.now()

    return {
        "agente": "Agente Registro",
        "etapa": 7,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "protocolo_id": rastro["resumo"]["protocolo_id"],
        "arquivo_gerado": os.path.basename(caminho_arquivo),
        "rastro_completo": rastro,
        "status": "sucesso",
    }
