"""
agentes/orquestrador.py — Etapa 4 da Esteira Aurora Master
Orquestrador: coordena a sequência de execução dos agentes,
consolida as saídas, resolve conflitos entre recomendações
e registra cada passo com timestamp para rastreabilidade.
"""

from datetime import datetime
from agentes import agente_carteira, agente_cliente


def resolver_conflito_limite(resultado_carteira, resultado_cliente):
    """
    Resolve conflitos entre o limite sugerido pela carteira (capacidade
    de produto) e o limite sugerido pelo agente cliente (capacidade de pagamento).
    A regra de ouro: o limite final nunca deve exceder a capacidade de pagamento.
    Retorna o limite consolidado e o motivo da resolução.
    """
    limite_carteira = resultado_carteira["limite_total_potencial"]
    limite_capacidade = resultado_cliente["limite_sugerido_por_capacidade"]
    score = resultado_cliente["score_composto"]["score_composto"]

    # Fator de confiança: quanto maior o score, mais próximo do teto da carteira
    fator_confianca = score / 1000  # 0.0 a 1.0

    # Limite conservador: ponderação entre capacidade e oferta de produto
    # O peso da capacidade é maior para proteger o cliente e o banco
    limite_ponderado = (limite_capacidade * 0.65) + (limite_carteira * 0.35 * fator_confianca)

    conflito = False
    motivo_resolucao = ""

    if limite_carteira > limite_capacidade * 1.5:
        # Carteira sugere muito mais do que o cliente consegue pagar → conflito
        conflito = True
        motivo_resolucao = (
            f"Conflito detectado: carteira sugeria R${limite_carteira:,.2f}, "
            f"mas capacidade de pagamento indica R${limite_capacidade:,.2f}. "
            f"Aplicado fator de confiança {fator_confianca:.2f} (score {score})."
        )
    elif limite_capacidade > limite_carteira:
        # Capacidade é maior que a oferta → usa o teto da carteira
        limite_ponderado = limite_carteira
        motivo_resolucao = "Capacidade de pagamento supera a oferta de produto; aplicado teto da carteira."
    else:
        motivo_resolucao = "Limites compatíveis; ponderação normal aplicada."

    return {
        "conflito_detectado": conflito,
        "limite_consolidado": round(max(0, limite_ponderado), 2),
        "limite_sugerido_carteira": round(limite_carteira, 2),
        "limite_sugerido_capacidade": round(limite_capacidade, 2),
        "fator_confianca": round(fator_confianca, 3),
        "motivo_resolucao": motivo_resolucao,
    }


def registrar_passo(log_orquestracao, descricao, dados=None):
    """Registra cada passo da orquestração com timestamp preciso."""
    entrada = {
        "timestamp": datetime.now().isoformat(),
        "descricao": descricao,
    }
    if dados:
        entrada["dados"] = dados
    log_orquestracao.append(entrada)
    return log_orquestracao


def executar(dados_cliente):
    """
    Ponto de entrada do Orquestrador.
    Coordena o Agente Carteira (Etapa 2) e o Agente Cliente (Etapa 3),
    consolida os resultados e resolve conflitos.
    """
    inicio = datetime.now()
    log_orquestracao = []

    # ── Passo 1: Validação inicial dos dados de entrada ──────────────────────
    registrar_passo(log_orquestracao, "Orquestrador iniciado — validando dados de entrada", {
        "cliente_id": dados_cliente.get("id", "N/A"),
        "tipo_cliente": dados_cliente.get("tipo_cliente"),
        "campos_recebidos": list(dados_cliente.keys()),
    })

    # ── Passo 2: Acionar Agente Carteira ─────────────────────────────────────
    registrar_passo(log_orquestracao, "Acionando Agente Carteira para mapeamento de produtos elegíveis")
    resultado_carteira = agente_carteira.executar(dados_cliente)
    registrar_passo(log_orquestracao, "Agente Carteira concluído", {
        "produtos_elegiveis": resultado_carteira["total_produtos_elegiveis"],
        "limite_total_potencial": resultado_carteira["limite_total_potencial"],
    })

    # ── Passo 3: Acionar Agente Cliente ──────────────────────────────────────
    registrar_passo(log_orquestracao, "Acionando Agente Cliente para análise de perfil")
    resultado_cliente = agente_cliente.executar(dados_cliente)
    registrar_passo(log_orquestracao, "Agente Cliente concluído", {
        "score_composto": resultado_cliente["score_composto"]["score_composto"],
        "classificacao": resultado_cliente["score_composto"]["classificacao"]["faixa"],
        "limite_sugerido_capacidade": resultado_cliente["limite_sugerido_por_capacidade"],
    })

    # ── Passo 4: Consolidar e resolver conflitos ──────────────────────────────
    registrar_passo(log_orquestracao, "Consolidando saídas e resolvendo possíveis conflitos")
    consolidacao = resolver_conflito_limite(resultado_carteira, resultado_cliente)
    registrar_passo(log_orquestracao, "Consolidação concluída", {
        "conflito_detectado": consolidacao["conflito_detectado"],
        "limite_consolidado": consolidacao["limite_consolidado"],
        "motivo": consolidacao["motivo_resolucao"],
    })

    # ── Passo 5: Aplicar regra anti-distorção ────────────────────────────────
    # Garante que clientes antigos com bom score recebam limite justo
    limite_ajustado = consolidacao["limite_consolidado"]
    regra_antidistorcao_aplicada = False
    descricao_ajuste = ""

    tipo = dados_cliente["tipo_cliente"]
    score_composto = resultado_cliente["score_composto"]["score_composto"]
    tempo_rel = dados_cliente["tempo_relacionamento_meses"]

    if tipo == "antigo" and score_composto >= 600 and tempo_rel >= 24:
        # Regra: cliente antigo com bom score não pode receber menos que
        # um cliente novo de mesmo score — aplica bônus de relacionamento
        limite_minimo_garantido = min(consolidacao["limite_consolidado"] * 1.25,
                                      resultado_carteira["limite_total_potencial"])
        if limite_minimo_garantido > limite_ajustado:
            limite_ajustado = round(limite_minimo_garantido, 2)
            regra_antidistorcao_aplicada = True
            descricao_ajuste = (
                f"Regra anti-distorção aplicada: cliente antigo com score {score_composto} "
                f"e {tempo_rel} meses de relacionamento recebeu bônus de 25% no limite."
            )
            registrar_passo(log_orquestracao, "⚖️ Regra anti-distorção aplicada", {
                "limite_antes": consolidacao["limite_consolidado"],
                "limite_depois": limite_ajustado,
                "motivo": descricao_ajuste,
            })

    # ── Passo 6: Empacota resultado consolidado ───────────────────────────────
    registrar_passo(log_orquestracao, "Orquestração concluída — enviando para módulo de Decisão")

    fim = datetime.now()

    return {
        "agente": "Orquestrador",
        "etapa": 4,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "resultado_agente_carteira": resultado_carteira,
        "resultado_agente_cliente": resultado_cliente,
        "consolidacao": consolidacao,
        "limite_final_orquestrado": limite_ajustado,
        "regra_antidistorcao_aplicada": regra_antidistorcao_aplicada,
        "descricao_ajuste_antidistorcao": descricao_ajuste,
        "log_orquestracao": log_orquestracao,
        "status": "sucesso",
    }
