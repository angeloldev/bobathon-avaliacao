"""
agentes/decisao.py — Etapa 5 da Esteira Aurora Master
Agente Decisão: com base nas saídas consolidadas do orquestrador,
decide se o crédito é aprovado, aprovado com ressalvas ou reprovado,
e define o limite final por linha de crédito.
Implementa regras explícitas anti-distorção.
"""

from datetime import datetime


# ── Limiares de decisão ──────────────────────────────────────────────────────
SCORE_MINIMO_APROVACAO = 350        # Abaixo disso → reprovado
SCORE_RESSALVAS = 500               # Entre 350 e 500 → aprovado com ressalvas
COMPROMETIMENTO_MAX_APROVACAO = 0.75  # Acima de 75% → reprovado por risco

# Distribuição do limite total por linha de crédito (pesos)
DISTRIBUICAO_LIMITE = {
    "limite_conta_corrente": 0.15,
    "cartao_credito": 0.35,
    "credito_pessoal": 0.30,
    "consignado": 0.20,
}


def determinar_status_aprovacao(score_composto, comprometimento, dados_cliente):
    """
    Define o status de aprovação com base no score composto,
    comprometimento de renda e tipo de cliente.
    Retorna: 'aprovado', 'aprovado_com_ressalvas' ou 'reprovado'.
    """
    razoes_reprovacao = []
    razoes_ressalvas = []

    # Verificação de score mínimo
    if score_composto < SCORE_MINIMO_APROVACAO:
        razoes_reprovacao.append(
            f"score composto {score_composto} abaixo do mínimo exigido ({SCORE_MINIMO_APROVACAO})"
        )

    # Verificação de comprometimento
    if comprometimento > COMPROMETIMENTO_MAX_APROVACAO:
        razoes_reprovacao.append(
            f"comprometimento de renda {comprometimento:.0%} excede o limite máximo permitido (75%)"
        )

    # Inadimplência bloqueia aprovação automática
    if dados_cliente.get("historico_pagamentos") == "inadimplente":
        if score_composto < 450:
            razoes_reprovacao.append("histórico de inadimplência com score insuficiente para mitigação")

    if razoes_reprovacao:
        return "reprovado", razoes_reprovacao, razoes_ressalvas

    # Verificação de ressalvas
    if score_composto < SCORE_RESSALVAS:
        razoes_ressalvas.append(f"score composto {score_composto} na faixa de atenção (350–500)")
    if comprometimento > 0.50:
        razoes_ressalvas.append(f"comprometimento elevado ({comprometimento:.0%}) — monitoramento recomendado")
    if dados_cliente.get("historico_pagamentos") == "irregular":
        razoes_ressalvas.append("histórico de pagamentos irregular — acompanhamento necessário")
    if dados_cliente.get("tipo_cliente") == "novo" and dados_cliente.get("tempo_relacionamento_meses", 0) < 3:
        razoes_ressalvas.append("relacionamento muito recente — limite inicial reduzido por precaução")

    if razoes_ressalvas:
        return "aprovado_com_ressalvas", [], razoes_ressalvas

    return "aprovado", [], []


def calcular_limites_por_linha(limite_total, resultado_carteira, status):
    """
    Distribui o limite total aprovado entre as linhas de crédito elegíveis,
    respeitando os tetos por produto calculados pelo Agente Carteira.
    """
    produtos_elegiveis = resultado_carteira.get("produtos_elegiveis", {})

    # Fator de redução para aprovado com ressalvas
    fator_reducao = 0.70 if status == "aprovado_com_ressalvas" else 1.0
    limite_efetivo = limite_total * fator_reducao

    limites_por_linha = {}
    for produto_id, info_produto in produtos_elegiveis.items():
        peso = DISTRIBUICAO_LIMITE.get(produto_id, 0.0)
        if peso == 0:
            continue
        limite_calculado = limite_efetivo * peso
        # Respeita o teto do produto calculado pelo Agente Carteira
        limite_linha = min(limite_calculado, info_produto["limite_maximo_elegivel"])
        if limite_linha >= 200:  # Mínimo operacional
            limites_por_linha[produto_id] = {
                "nome": info_produto["nome"],
                "limite_aprovado": round(limite_linha, 2),
                "limite_maximo_disponivel": info_produto["limite_maximo_elegivel"],
            }

    return limites_por_linha


def executar(dados_cliente, resultado_orquestrador):
    """
    Ponto de entrada do Agente Decisão.
    Recebe o resultado consolidado do orquestrador e emite a decisão final.
    """
    inicio = datetime.now()

    score_composto = resultado_orquestrador["resultado_agente_cliente"]["score_composto"]["score_composto"]
    comprometimento = dados_cliente.get("comprometimento_renda", 0.30)
    limite_orquestrado = resultado_orquestrador["limite_final_orquestrado"]
    resultado_carteira = resultado_orquestrador["resultado_agente_carteira"]
    classificacao_score = resultado_orquestrador["resultado_agente_cliente"]["score_composto"]["classificacao"]

    # Determina o status de aprovação
    status, razoes_reprovacao, razoes_ressalvas = determinar_status_aprovacao(
        score_composto, comprometimento, dados_cliente
    )

    # Define o limite final
    if status == "reprovado":
        limite_final = 0.0
        limites_por_linha = {}
    else:
        limite_final = limite_orquestrado
        limites_por_linha = calcular_limites_por_linha(limite_final, resultado_carteira, status)
        # Ajusta limite_final pela soma real das linhas aprovadas
        if limites_por_linha:
            limite_final = round(sum(v["limite_aprovado"] for v in limites_por_linha.values()), 2)

    # ── Verificação anti-distorção explícita ─────────────────────────────────
    # Garante que cliente antigo bom não receba menos que cliente novo de mesmo score
    antidistorcao_info = {
        "verificacao_realizada": True,
        "distorcao_corrigida": resultado_orquestrador.get("regra_antidistorcao_aplicada", False),
        "descricao": resultado_orquestrador.get("descricao_ajuste_antidistorcao", ""),
    }

    fim = datetime.now()

    return {
        "agente": "Agente Decisão",
        "etapa": 5,
        "timestamp_inicio": inicio.isoformat(),
        "timestamp_fim": fim.isoformat(),
        "duracao_ms": round((fim - inicio).total_seconds() * 1000, 2),
        "status_aprovacao": status,
        "status_label": {
            "aprovado": "Aprovado",
            "aprovado_com_ressalvas": "Aprovado com Ressalvas",
            "reprovado": "Reprovado",
        }.get(status, status),
        "limite_total_aprovado": limite_final,
        "limites_por_linha": limites_por_linha,
        "score_composto_utilizado": score_composto,
        "classificacao_score": classificacao_score,
        "razoes_reprovacao": razoes_reprovacao,
        "razoes_ressalvas": razoes_ressalvas,
        "antidistorcao": antidistorcao_info,
        "status": "sucesso",
    }
