/**
 * app.js — Lógica principal da interface Aurora Master
 * Controla o formulário, o indicador de progresso da esteira,
 * a exibição de resultados, o lote, o histórico e o modal de detalhes.
 */

// ── Estado global da aplicação ───────────────────────────────────────────────
let ultimoResultado = null;   // Último resultado de análise individual
let dadosLoteAtual  = null;   // Resultado do último processamento em lote
// Mapa de resultados completos do lote, indexado pelo id do cliente
let mapaResultadosLote = {};

// ── Utilitários ──────────────────────────────────────────────────────────────

function setLoading(visivel, texto = "Processando análise...", sub = "Aguarde enquanto a esteira processa os dados") {
  const overlay = document.getElementById("overlay-loading");
  const txtEl   = document.getElementById("loading-text");
  const subEl   = document.getElementById("loading-sub");
  if (txtEl) txtEl.textContent = texto;
  if (subEl) subEl.textContent = sub;
  overlay.classList.toggle("hidden", !visivel);
}

function formatarReais(valor) {
  return `R$ ${Number(valor).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatarVariacao(antes, depois) {
  const diff = depois - antes;
  const pct  = antes > 0 ? ((diff / antes) * 100).toFixed(1) : "∞";
  const sinal = diff >= 0 ? "+" : "";
  const cls   = diff > 0 ? "variacao-positiva" : diff < 0 ? "variacao-negativa" : "variacao-neutra";
  return `<span class="${cls}">${sinal}${formatarReais(diff)} (${sinal}${pct}%)</span>`;
}

function sanitizarTexto(txt) {
  return String(txt)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function markdownSimples(txt) {
  return sanitizarTexto(txt)
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\n/g, "<br/>");
}

// ── Navegação por abas ───────────────────────────────────────────────────────

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const tabId = btn.dataset.tab;
    document.querySelectorAll(".nav-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".tab-content").forEach((sec) => {
      sec.classList.remove("active");
      sec.classList.add("hidden");
    });
    const secao = document.getElementById(`tab-${tabId}`);
    if (secao) {
      secao.classList.remove("hidden");
      secao.classList.add("active");
    }
    if (tabId === "painel-metricas") inicializarMetricas();
    else if (tabId === "historico")  carregarHistorico();
  });
});

// ── Pipeline de progresso (com logs humanizados) ──────────────────────────────

/**
 * Mensagens legíveis para cada estado de cada etapa.
 * Estrutura: { ativo: "...", concluido: "..." }
 */
const LOG_ETAPAS = {
  1: {
    ativo:    "Verificando campos obrigatórios e formatos...",
    concluido: "Dados validados com sucesso.",
  },
  2: {
    ativo:    "Consultando produtos elegíveis para o perfil...",
    concluido: null, // preenchido dinamicamente após resposta
  },
  3: {
    ativo:    "Calculando score de crédito em 3 dimensões...",
    concluido: null,
  },
  4: {
    ativo:    "Consolidando limites e verificando consistências...",
    concluido: null,
  },
  5: {
    ativo:    "Avaliando critérios de aprovação e limites finais...",
    concluido: null,
  },
  6: {
    ativo:    "Redigindo justificativa em linguagem simples...",
    concluido: "Justificativa gerada.",
  },
  7: {
    ativo:    "Gravando rastro auditável da decisão...",
    concluido: null,
  },
};

function setLogPasso(numero, texto) {
  const el = document.getElementById(`log-${numero}`);
  if (el) el.textContent = texto || "";
}

function atualizarPasso(numero, estado, logTexto) {
  const el = document.getElementById(`step-${numero}`);
  if (!el) return;
  el.classList.remove("ativo", "concluido", "erro");
  const statusEl = el.querySelector(".step-status");

  switch (estado) {
    case "ativo":
      el.classList.add("ativo");
      if (statusEl) statusEl.textContent = "⚙️";
      setLogPasso(numero, logTexto ?? LOG_ETAPAS[numero]?.ativo ?? "");
      break;
    case "concluido":
      el.classList.add("concluido");
      if (statusEl) statusEl.textContent = "✅";
      setLogPasso(numero, logTexto ?? LOG_ETAPAS[numero]?.concluido ?? "Concluído.");
      break;
    case "erro":
      el.classList.add("erro");
      if (statusEl) statusEl.textContent = "❌";
      setLogPasso(numero, logTexto ?? "Erro nesta etapa.");
      break;
    default:
      if (statusEl) statusEl.textContent = "⏳";
      setLogPasso(numero, "");
  }
}

function resetarPipeline() {
  for (let i = 1; i <= 7; i++) atualizarPasso(i, "aguardando");
}

/**
 * Anima a esteira durante o processamento e, ao receber a resposta,
 * preenche os logs com dados reais do resultado.
 */
async function animarEsteira(promessaAPI) {
  resetarPipeline();

  const passos = [
    { n: 1, ms: 200 },
    { n: 2, ms: 350 },
    { n: 3, ms: 500 },
    { n: 4, ms: 350 },
    { n: 5, ms: 250 },
    { n: 6, ms: 200 },
    { n: 7, ms: 150 },
  ];

  const labelsPorPasso = [
    "Validando dados do cliente...",
    "Agente Carteira analisando produtos...",
    "Agente Cliente calculando score composto...",
    "Orquestrador consolidando limites...",
    "Tomando decisão de crédito...",
    "Gerando justificativa ao cliente...",
    "Registrando auditoria...",
  ];

  let resolvido = false;
  let resultadoFinal = null;

  const animar = async () => {
    for (let i = 0; i < passos.length; i++) {
      const passo = passos[i];
      if (resolvido && i >= passos.length - 1) break;
      atualizarPasso(passo.n, "ativo");
      setLoading(true, labelsPorPasso[i]);
      await new Promise((r) => setTimeout(r, passo.ms));
      if (!resolvido) atualizarPasso(passo.n, "concluido");
    }
  };

  [resultadoFinal] = await Promise.all([
    promessaAPI.then((r) => { resolvido = true; return r; }),
    animar(),
  ]);

  // Preenche logs com dados reais do resultado
  if (resultadoFinal?.sucesso) {
    preencherLogsComResultado(resultadoFinal);
  } else {
    for (let i = 1; i <= 7; i++) atualizarPasso(i, "concluido");
  }

  setLoading(false);

  // Log técnico completo no console (para depuração)
  console.group("🔍 Aurora Master — Resultado técnico completo");
  console.log(resultadoFinal);
  console.groupEnd();

  return resultadoFinal;
}

/**
 * Após a resposta da API, preenche os logs de cada etapa
 * com informações reais extraídas do resultado — em linguagem humana.
 */
function preencherLogsComResultado(resultado) {
  const etapas = resultado.etapas || {};
  const rf     = resultado.resultado_final || {};

  // Etapa 1
  atualizarPasso(1, "concluido", "Dados do cliente recebidos e validados.");

  // Etapa 2 — Agente Carteira
  const carteira = etapas.etapa_2_agente_carteira || {};
  const nProd = carteira.total_produtos_elegiveis ?? "—";
  const limPot = carteira.limite_total_potencial != null
    ? formatarReais(carteira.limite_total_potencial)
    : "—";
  atualizarPasso(2, "concluido", `${nProd} produto(s) elegível(is) · Teto potencial: ${limPot}`);

  // Etapa 3 — Agente Cliente
  const cli = etapas.etapa_3_agente_cliente || {};
  const score = cli.score_composto?.score_composto ?? rf.score_composto ?? "—";
  const classif = cli.score_composto?.classificacao?.faixa ?? rf.classificacao_score?.faixa ?? "";
  atualizarPasso(3, "concluido", `Score composto: ${score} · Classificação: ${classif}`);

  // Etapa 4 — Orquestrador
  const orq = etapas.etapa_4_orquestrador || {};
  const antiDistMsg = orq.regra_antidistorcao_aplicada
    ? "⚖️ Bônus de fidelidade aplicado!"
    : "Sem conflitos detectados.";
  const conflito = orq.conflito_detectado ? "Conflito resolvido. " : "";
  atualizarPasso(4, "concluido", `${conflito}${antiDistMsg}`);

  // Etapa 5 — Decisão
  const labelStatus = { aprovado: "Aprovado ✅", aprovado_com_ressalvas: "Aprovado com ressalvas ⚠️", reprovado: "Reprovado ❌" };
  const statusLabel = labelStatus[rf.status_aprovacao] ?? rf.status_label ?? "—";
  const limFinal = rf.limite_total_aprovado != null ? ` · Limite: ${formatarReais(rf.limite_total_aprovado)}` : "";
  atualizarPasso(5, "concluido", `${statusLabel}${limFinal}`);

  // Etapa 6 — Justificativa
  atualizarPasso(6, "concluido", "Justificativa ao cliente gerada com sucesso.");

  // Etapa 7 — Registro
  const protocolo = resultado.protocolo_id ?? "—";
  atualizarPasso(7, "concluido", `Protocolo registrado: ${protocolo}`);
}

// ── Formulário de nova análise ────────────────────────────────────────────────

function coletarDadosFormulario() {
  const get = (id) => document.getElementById(id)?.value?.trim() || "";
  const produtos = Array.from(
    document.querySelectorAll('input[name="produtos"]:checked')
  ).map((cb) => cb.value);

  return {
    nome:                       get("nome"),
    cpf:                        get("cpf"),
    tipo_cliente:               get("tipo_cliente"),
    renda_mensal:               parseFloat(get("renda_mensal")) || 0,
    tempo_relacionamento_meses: parseInt(get("tempo_relacionamento_meses")) || 0,
    historico_pagamentos:       get("historico_pagamentos"),
    score_interno:              parseInt(get("score_interno")) || 0,
    comprometimento_renda:      parseFloat(get("comprometimento_renda")) || 0.30,
    produtos_contratados:       produtos.length ? produtos : ["conta_corrente"],
  };
}

function exibirResultado(resultado) {
  const rf = resultado.resultado_final;
  const cardResultado = document.getElementById("card-resultado");
  if (cardResultado) cardResultado.classList.remove("hidden");

  // Banner de status
  const banner = document.getElementById("resultado-status-banner");
  banner.className = "status-banner";
  if (rf.status_aprovacao === "aprovado") {
    banner.classList.add("aprovado");
    document.getElementById("resultado-icon").textContent = "✅";
  } else if (rf.status_aprovacao === "aprovado_com_ressalvas") {
    banner.classList.add("ressalvas");
    document.getElementById("resultado-icon").textContent = "⚠️";
  } else {
    banner.classList.add("reprovado");
    document.getElementById("resultado-icon").textContent = "❌";
  }

  document.getElementById("resultado-status-label").textContent = rf.status_label;
  document.getElementById("resultado-protocolo").textContent = `Protocolo: ${resultado.protocolo_id}`;

  document.getElementById("resultado-limite").textContent = formatarReais(rf.limite_total_aprovado);
  document.getElementById("resultado-score").textContent  = rf.score_composto;
  document.getElementById("resultado-classificacao").textContent =
    `${rf.classificacao_score.faixa} — Risco ${rf.classificacao_score.risco}`;

  const antiEl = document.getElementById("resultado-antidistorcao");
  if (rf.antidistorcao?.distorcao_corrigida) {
    antiEl.textContent = "✅ Bônus de fidelidade aplicado";
    antiEl.style.color = "var(--verde)";
  } else {
    antiEl.textContent = "Não aplicada";
    antiEl.style.color = "var(--cinza-mudo)";
  }

  // Linhas de crédito aprovadas
  const linhasContainer = document.getElementById("resultado-linhas-container");
  const linhasDiv       = document.getElementById("resultado-linhas");
  const linhas = rf.limites_por_linha || {};

  if (Object.keys(linhas).length > 0) {
    linhasContainer.classList.remove("hidden");
    linhasDiv.innerHTML = Object.entries(linhas)
      .map(([, info]) => `
        <div class="linha-item">
          <span class="linha-nome">${info.nome}</span>
          <span class="linha-valor">${formatarReais(info.limite_aprovado)}</span>
        </div>`)
      .join("");
  } else {
    linhasContainer.classList.add("hidden");
  }

  // Justificativa
  const justDiv = document.getElementById("resultado-justificativa");
  if (justDiv) {
    justDiv.innerHTML = markdownSimples(rf.justificativa || "Sem justificativa disponível.");
  }

  ultimoResultado = resultado;
  atualizarAbaPainel("resumo");

  setTimeout(() => cardResultado.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
}

// ── Abas do painel de auditoria ───────────────────────────────────────────────

document.querySelectorAll(".audit-tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".audit-tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    atualizarAbaPainel(btn.dataset.audittab);
  });
});

function atualizarAbaPainel(aba) {
  const el = document.getElementById("auditoria-json");
  if (!el || !ultimoResultado) return;

  const etapas = ultimoResultado.etapas;
  let dados;

  switch (aba) {
    case "resumo":
      dados = ultimoResultado.rastro_auditoria?.resumo || {};
      break;
    case "carteira":
      dados = etapas?.etapa_2_agente_carteira || {};
      break;
    case "cliente":
      dados = etapas?.etapa_3_agente_cliente || {};
      break;
    case "orquestrador":
      dados = {
        limite_final_orquestrado: etapas?.etapa_4_orquestrador?.limite_final_orquestrado,
        conflito_detectado:       etapas?.etapa_4_orquestrador?.conflito_detectado,
        regra_antidistorcao:      etapas?.etapa_4_orquestrador?.regra_antidistorcao_aplicada,
        log:                      etapas?.etapa_4_orquestrador?.log_orquestracao,
      };
      break;
    case "completo":
      dados = ultimoResultado.rastro_auditoria || {};
      break;
    default:
      dados = ultimoResultado;
  }

  el.textContent = JSON.stringify(dados, null, 2);
}

// ── Submit do formulário ──────────────────────────────────────────────────────

document.getElementById("form-analise")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const dados = coletarDadosFormulario();

  const promessa = fetch("/api/analise", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados),
  }).then((r) => r.json());

  const resultado = await animarEsteira(promessa);

  if (resultado.sucesso) {
    exibirResultado(resultado);
  } else {
    alert("Erro ao processar:\n" + (resultado.erros?.join("\n") || resultado.mensagem || JSON.stringify(resultado)));
    resetarPipeline();
  }
});

// ── Botão: Carregar Exemplo ───────────────────────────────────────────────────

document.getElementById("btn-carregar-exemplo")?.addEventListener("click", async () => {
  try {
    const resp  = await fetch("/api/base-clientes");
    const dados = await resp.json();
    if (dados.clientes && dados.clientes.length > 0) {
      const cliente = dados.clientes[Math.floor(Math.random() * dados.clientes.length)];
      preencherFormulario(cliente);
    }
  } catch (e) {
    console.error("Erro ao carregar exemplo:", e);
    preencherFormulario({
      nome: "Carlos Eduardo Mendes",
      cpf: "123.456.789-01",
      tipo_cliente: "antigo",
      tempo_relacionamento_meses: 72,
      renda_mensal: 7500,
      historico_pagamentos: "pontual",
      score_interno: 780,
      comprometimento_renda: 0.25,
      produtos_contratados: ["conta_corrente", "cartao_credito", "credito_pessoal"],
    });
  }
});

function preencherFormulario(c) {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  set("nome", c.nome);
  set("cpf",  c.cpf || "");
  set("tipo_cliente", c.tipo_cliente);
  set("tempo_relacionamento_meses", c.tempo_relacionamento_meses);
  set("renda_mensal", c.renda_mensal);
  set("historico_pagamentos", c.historico_pagamentos);
  set("score_interno", c.score_interno);

  const comp = c.comprometimento_renda || 0.30;
  const opcoesComp = [0.10, 0.25, 0.40, 0.55, 0.70];
  const maisProximo = opcoesComp.reduce((a, b) => Math.abs(b - comp) < Math.abs(a - comp) ? b : a);
  set("comprometimento_renda", maisProximo);

  document.querySelectorAll('input[name="produtos"]').forEach((cb) => {
    cb.checked = (c.produtos_contratados || []).includes(cb.value);
  });
}

// ── Análise em lote ───────────────────────────────────────────────────────────

document.getElementById("btn-processar-lote")?.addEventListener("click", async () => {
  const quantidade = parseInt(document.getElementById("lote-quantidade")?.value) || 20;
  const tipo       = document.getElementById("lote-tipo")?.value || "";

  setLoading(true, "Processando lote de clientes...", `Analisando ${quantidade} clientes da base sintética`);

  try {
    const resp  = await fetch("/api/analise-lote", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quantidade, tipo_cliente: tipo || undefined }),
    });
    const dados = await resp.json();
    setLoading(false);

    if (dados.sucesso) {
      dadosLoteAtual = dados;
      // Constrói mapa id → resultado completo para uso no modal
      mapaResultadosLote = {};
      (dados.resultados || []).forEach((r) => {
        mapaResultadosLote[r.id] = r;
      });
      exibirResultadoLote(dados);

      if (dados.metricas) {
        renderizarGraficoStatus(dados.metricas);
        renderizarGraficoLimitesPosLote(dados.metricas);
      }
    } else {
      alert("Erro no processamento em lote.");
    }
  } catch (e) {
    setLoading(false);
    console.error("Erro no lote:", e);
    alert("Falha na comunicação com o servidor.");
  }
});

function exibirResultadoLote(dados) {
  const container = document.getElementById("lote-resultado");
  if (container) container.classList.remove("hidden");

  // Cards de métricas
  const metContainer = document.getElementById("lote-metricas-cards");
  if (metContainer && dados.metricas) {
    const m = dados.metricas;
    const cards = [
      { num: dados.total_processados,                           lbl: "Clientes processados", cls: "" },
      { num: m.totais.aprovados,                                lbl: "Aprovados",             cls: "verde" },
      { num: m.totais.com_ressalvas,                            lbl: "Com ressalvas",         cls: "amarelo" },
      { num: m.totais.reprovados,                               lbl: "Reprovados",            cls: "vermelho" },
      { num: formatarReais(m.antigos?.media_limite_novo || 0),  lbl: "Limite médio antigos (novo)", cls: "" },
      { num: formatarReais(m.novos?.media_limite_novo   || 0),  lbl: "Limite médio novos (novo)",   cls: "" },
    ];
    metContainer.innerHTML = cards
      .map((c) => `<div class="metric-card ${c.cls}"><span class="num">${c.num}</span><span class="lbl">${c.lbl}</span></div>`)
      .join("");
  }

  // Tabela de resultados
  const tbody = document.getElementById("lote-tabela-body");
  if (!tbody) return;

  tbody.innerHTML = dados.resultados.map((r) => {
    const statusCls = {
      aprovado:               "badge-aprovado",
      aprovado_com_ressalvas: "badge-ressalvas",
      reprovado:              "badge-reprovado",
    }[r.status] || "";

    const tipoCls = r.tipo_cliente === "antigo" ? "badge-antigo" : "badge-novo";

    return `
      <tr data-cliente-id="${sanitizarTexto(r.id)}" onclick="abrirModalDetalhe('${sanitizarTexto(r.id)}')">
        <td><code>${sanitizarTexto(r.id)}</code></td>
        <td>${sanitizarTexto(r.nome)}</td>
        <td><span class="badge ${tipoCls}">${r.tipo_cliente}</span></td>
        <td>${r.score_interno} → <strong>${r.score_composto}</strong></td>
        <td>${formatarReais(r.limite_anterior)}</td>
        <td><strong>${formatarReais(r.limite_novo)}</strong></td>
        <td>${formatarVariacao(r.limite_anterior, r.limite_novo)}</td>
        <td><span class="badge ${statusCls}">${r.status.replace(/_/g, " ")}</span></td>
        <td><span class="badge ${r.regra_antidistorcao ? 'badge-sim' : 'badge-nao'}">${r.regra_antidistorcao ? "✅ Sim" : "Não"}</span></td>
        <td><button class="btn-detalhe" onclick="event.stopPropagation(); abrirModalDetalhe('${sanitizarTexto(r.id)}')">Ver detalhes</button></td>
      </tr>`;
  }).join("");
}

function renderizarGraficoLimitesPosLote(metricas) {
  const ctx = document.getElementById("grafico-limites");
  if (!ctx || !window.chartLimites) return;
  const antigoNovo = metricas.antigos?.media_limite_novo || 0;
  const novoNovo   = metricas.novos?.media_limite_novo   || 0;
  if (chartLimites && chartLimites.data.datasets.length < 3) {
    chartLimites.data.datasets.push({
      label: "Após Lote (dados reais da sessão)",
      data:  [Math.round(antigoNovo), Math.round(novoNovo)],
      backgroundColor: ["rgba(22, 163, 74, 0.75)", "rgba(22, 163, 74, 0.45)"],
      borderColor: ["#16A34A", "#16A34A"],
      borderWidth: 1.5,
      borderRadius: 4,
    });
    chartLimites.update();
  }
}

// ── Modal de detalhes do cliente (lote) ──────────────────────────────────────

function abrirModalDetalhe(clienteId) {
  const dados = mapaResultadosLote[clienteId];
  if (!dados) return;

  // Destaca linha ativa
  document.querySelectorAll(".tabela-clicavel tbody tr").forEach((tr) => tr.classList.remove("linha-ativa"));
  const trAtiva = document.querySelector(`tr[data-cliente-id="${clienteId}"]`);
  if (trAtiva) trAtiva.classList.add("linha-ativa");

  // Status icon e banner
  const iconMap   = { aprovado: "✅", aprovado_com_ressalvas: "⚠️", reprovado: "❌" };
  const classeMap = { aprovado: "aprovado", aprovado_com_ressalvas: "ressalvas", reprovado: "reprovado" };
  const statusLabel = dados.status === "aprovado" ? "Aprovado"
    : dados.status === "aprovado_com_ressalvas"   ? "Aprovado com Ressalvas"
    : "Reprovado";

  document.getElementById("modal-status-icon").textContent  = iconMap[dados.status] || "❓";
  document.getElementById("modal-titulo").textContent       = sanitizarTexto(dados.nome);
  document.getElementById("modal-protocolo").textContent    = `ID: ${dados.id}`;
  document.getElementById("modal-status-label").textContent = statusLabel;
  document.getElementById("modal-limite-label").textContent =
    dados.limite_novo > 0 ? formatarReais(dados.limite_novo) : "—";

  const banner = document.getElementById("modal-status-banner");
  banner.className = `modal-status-banner ${classeMap[dados.status] || "reprovado"}`;

  // Dados cadastrais
  const dadosGrid = document.getElementById("modal-dados-cliente");
  const histMap = { pontual: "Pontual ✅", irregular: "Irregular ⚠️", inadimplente: "Inadimplente ❌" };
  const itens = [
    { lbl: "Tipo de cliente", val: dados.tipo_cliente === "antigo" ? "Antigo 🏦" : "Novo 🌱" },
    { lbl: "Score interno",   val: dados.score_interno },
    { lbl: "Score composto",  val: dados.score_composto },
    { lbl: "Histórico",       val: histMap[dados.historico_pagamentos] || dados.historico_pagamentos || "—" },
    { lbl: "Renda mensal",    val: dados.renda_mensal != null ? formatarReais(dados.renda_mensal) : "—" },
    { lbl: "Comprometimento", val: dados.comprometimento_renda != null
        ? `${(dados.comprometimento_renda * 100).toFixed(0)}%` : "—" },
    { lbl: "Relacionamento",  val: dados.tempo_relacionamento_meses != null
        ? `${dados.tempo_relacionamento_meses} meses` : "—" },
    { lbl: "Limite anterior", val: formatarReais(dados.limite_anterior) },
  ];
  dadosGrid.innerHTML = itens.map((i) =>
    `<div class="modal-dado-item">
       <span class="modal-dado-label">${i.lbl}</span>
       <span class="modal-dado-valor">${i.val}</span>
     </div>`
  ).join("");

  // Score grid
  const scoreGrid = document.getElementById("modal-score-grid");
  const classfRisco = dados.classificacao_risco || dados.classificacao_score || "—";
  scoreGrid.innerHTML = `
    <div class="modal-score-item">
      <span class="mscore-lbl">Score composto</span>
      <span class="mscore-val">${dados.score_composto}</span>
    </div>
    <div class="modal-score-item">
      <span class="mscore-lbl">Classificação</span>
      <span class="mscore-val" style="font-size:14px">${classfRisco}</span>
    </div>
    <div class="modal-score-item">
      <span class="mscore-lbl">Limite aprovado</span>
      <span class="mscore-val" style="font-size:14px">${formatarReais(dados.limite_novo)}</span>
    </div>
    <div class="modal-score-item">
      <span class="mscore-lbl">Variação</span>
      <span class="mscore-val" style="font-size:14px">${formatarVariacao(dados.limite_anterior, dados.limite_novo)}</span>
    </div>`;

  // Fatores positivos e negativos
  const positivos = dados.fatores_positivos || [];
  const negativos = dados.fatores_negativos || dados.razoes_reprovacao || dados.razoes_ressalvas || [];

  const ulPos = document.getElementById("modal-fatores-positivos");
  const ulNeg = document.getElementById("modal-fatores-negativos");

  document.getElementById("modal-fatores-titulo").style.display    = positivos.length ? "" : "none";
  document.getElementById("modal-negativos-titulo").style.display  = negativos.length ? "" : "none";

  ulPos.innerHTML = positivos.length
    ? positivos.map((f) => `<li>✔ ${sanitizarTexto(f)}</li>`).join("")
    : "";
  ulNeg.innerHTML = negativos.length
    ? negativos.map((f) => `<li>✖ ${sanitizarTexto(f)}</li>`).join("")
    : "";

  // Anti-distorção
  const antiDiv  = document.getElementById("modal-antidistorcao");
  const antiDesc = document.getElementById("modal-antidistorcao-desc");
  if (dados.regra_antidistorcao) {
    antiDiv.classList.remove("hidden");
    antiDesc.textContent = dados.descricao_antidistorcao ||
      "Cliente antigo com bom score recebeu bônus de fidelidade de 25% no limite.";
  } else {
    antiDiv.classList.add("hidden");
  }

  // Justificativa
  const justEl = document.getElementById("modal-justificativa");
  if (justEl) {
    justEl.innerHTML = markdownSimples(dados.justificativa || "Justificativa não disponível.");
  }

  // Exibe o modal
  document.getElementById("modal-detalhe-cliente").classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function fecharModal() {
  document.getElementById("modal-detalhe-cliente").classList.add("hidden");
  document.body.style.overflow = "";
  // Remove destaque da linha
  document.querySelectorAll(".tabela-clicavel tbody tr").forEach((tr) => tr.classList.remove("linha-ativa"));
}

// Fechar modal pelo botão ✕
document.getElementById("btn-fechar-modal")?.addEventListener("click", fecharModal);

// Fechar clicando fora do box
document.getElementById("modal-detalhe-cliente")?.addEventListener("click", (e) => {
  if (e.target === e.currentTarget) fecharModal();
});

// Fechar com Esc
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") fecharModal();
});

// ── Histórico de decisões ─────────────────────────────────────────────────────

async function carregarHistorico() {
  const container = document.getElementById("historico-lista");
  if (!container) return;
  try {
    const resp  = await fetch("/api/historico");
    const dados = await resp.json();

    if (!dados.historico || dados.historico.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhuma análise realizada ainda.</p>';
      return;
    }

    container.innerHTML = dados.historico.map((item) => {
      const dec = item.decisao_final || {};
      const cli = item.cliente       || {};
      const statusCls = {
        aprovado:               "badge-aprovado",
        aprovado_com_ressalvas: "badge-ressalvas",
        reprovado:              "badge-reprovado",
      }[dec.status] || "";

      return `
        <div class="historico-item" onclick="verDetalhesAnalise('${item.protocolo_id}')">
          <div>
            <div class="historico-protocolo">${item.protocolo_id}</div>
            <div class="historico-data">${item.data_formatada || ""}</div>
          </div>
          <div class="historico-nome">${sanitizarTexto(cli.nome || "—")}</div>
          <span class="badge ${cli.tipo_cliente === 'antigo' ? 'badge-antigo' : 'badge-novo'}">${cli.tipo_cliente || "—"}</span>
          <span class="badge ${statusCls}">${dec.status_label || "—"}</span>
          <div class="historico-limite">${formatarReais(dec.limite_total_aprovado || 0)}</div>
        </div>`;
    }).join("");
  } catch (e) {
    container.innerHTML = '<p class="empty-state">Erro ao carregar histórico.</p>';
  }
}

async function verDetalhesAnalise(protocoloId) {
  try {
    const resp  = await fetch(`/api/historico/${protocoloId}`);
    const dados = await resp.json();
    if (dados.sucesso) {
      const dec = dados.rastro.resumo.decisao_final;
      alert(
        `Protocolo: ${protocoloId}\n\n` +
        `Decisão: ${dec.status_label}\n` +
        `Limite:  ${formatarReais(dec.limite_total_aprovado)}\n` +
        `Score:   ${dec.score_composto}\n\n` +
        `Rastro completo salvo em:\nhistorico/${protocoloId}.json`
      );
    }
  } catch (e) {
    console.error("Erro ao carregar análise:", e);
  }
}

document.getElementById("btn-refresh-historico")?.addEventListener("click", carregarHistorico);

// ── Máscara de CPF ────────────────────────────────────────────────────────────

document.getElementById("cpf")?.addEventListener("input", (e) => {
  let v = e.target.value.replace(/\D/g, "");
  if (v.length > 11) v = v.slice(0, 11);
  v = v.replace(/(\d{3})(\d)/, "$1.$2")
       .replace(/(\d{3})\.(\d{3})(\d)/, "$1.$2.$3")
       .replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, "$1.$2.$3-$4");
  e.target.value = v;
});

// ── Validação de consistência: tipo + tempo ───────────────────────────────────

document.getElementById("tipo_cliente")?.addEventListener("change", (e) => {
  const campoTempo = document.getElementById("tempo_relacionamento_meses");
  if (!campoTempo) return;
  if (e.target.value === "novo") {
    campoTempo.max = 6;
    if (parseInt(campoTempo.value) > 6) campoTempo.value = 3;
  } else {
    campoTempo.max = 360;
    if (!campoTempo.value || parseInt(campoTempo.value) < 6) campoTempo.value = 24;
  }
});
