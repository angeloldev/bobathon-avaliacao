/**
 * metricas.js — Gráficos Chart.js para o Painel de Métricas Aurora Master
 * Exibe a distorção identificada e o impacto da correção pela esteira.
 */

// Referências aos elementos canvas dos gráficos
let chartLimites = null;
let chartScores = null;
let chartHistorico = null;
let chartStatus = null;

/**
 * Inicializa os gráficos do painel de métricas.
 * Busca os dados da API e renderiza cada visualização.
 */
async function inicializarMetricas() {
  try {
    const resp = await fetch("/api/metricas");
    const dados = await resp.json();

    if (!dados.sucesso) {
      console.error("Erro ao carregar métricas:", dados.erro);
      return;
    }

    const m = dados.metricas;

    renderizarGraficoLimites(m.distorcao_original);
    renderizarGraficoScores(m.distorcao_original);
    renderizarGraficoHistorico(m.base_resumo);
    renderizarIndicadores(m);
  } catch (e) {
    console.error("Falha ao carregar métricas:", e);
  }
}

/**
 * Gráfico 1 — Comparação de limites médios antes e depois da esteira.
 * Demonstra a distorção e como a esteira a corrigiria.
 */
function renderizarGraficoLimites(distorcao) {
  const ctx = document.getElementById("grafico-limites");
  if (!ctx) return;

  if (chartLimites) chartLimites.destroy();

  // Estimativa pós-esteira: antigos sobem, novos são ajustados com base em perfil
  const limiteAntigosPos = distorcao.media_score_antigos * 20; // heurística demonstrativa
  const limiteNovosPos   = distorcao.media_score_novos   * 16;

  chartLimites = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Clientes Antigos", "Clientes Novos"],
      datasets: [
        {
          label: "Antes da Esteira (banco antigo)",
          data: [
            distorcao.media_limite_antigos,
            distorcao.media_limite_novos,
          ],
          backgroundColor: ["rgba(220, 38, 38, 0.75)", "rgba(220, 38, 38, 0.75)"],
          borderColor:     ["#DC2626", "#DC2626"],
          borderWidth: 1.5,
          borderRadius: 4,
        },
        {
          label: "Após a Esteira Aurora Master",
          data: [
            Math.round(limiteAntigosPos),
            Math.round(limiteNovosPos),
          ],
          backgroundColor: ["rgba(0, 61, 165, 0.75)", "rgba(74, 144, 217, 0.75)"],
          borderColor:     ["#003DA5", "#4A90D9"],
          borderWidth: 1.5,
          borderRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom", labels: { font: { size: 12 } } },
        tooltip: {
          callbacks: {
            label: (ctx) => ` R$ ${ctx.raw.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
          },
        },
      },
      scales: {
        y: {
          ticks: {
            callback: (v) => `R$ ${v.toLocaleString("pt-BR")}`,
            font: { size: 11 },
          },
          grid: { color: "#E0E6EF" },
        },
        x: { grid: { display: false } },
      },
    },
  });
}

/**
 * Gráfico 2 — Distribuição de score médio por tipo de cliente.
 */
function renderizarGraficoScores(distorcao) {
  const ctx = document.getElementById("grafico-scores");
  if (!ctx) return;

  if (chartScores) chartScores.destroy();

  chartScores = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Clientes Antigos", "Clientes Novos"],
      datasets: [{
        label: "Score Médio Interno",
        data: [distorcao.media_score_antigos, distorcao.media_score_novos],
        backgroundColor: ["rgba(0, 61, 165, 0.80)", "rgba(124, 58, 237, 0.80)"],
        borderColor:     ["#003DA5", "#7C3AED"],
        borderWidth: 1.5,
        borderRadius: 4,
      }],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: { label: (ctx) => ` Score: ${ctx.raw}` },
        },
      },
      scales: {
        y: {
          min: 0, max: 1000,
          ticks: { font: { size: 11 } },
          grid: { color: "#E0E6EF" },
        },
        x: { grid: { display: false } },
      },
    },
  });
}

/**
 * Gráfico 3 — Distribuição de histórico de pagamentos na base.
 */
function renderizarGraficoHistorico(baseResumo) {
  const ctx = document.getElementById("grafico-historico");
  if (!ctx) return;

  if (chartHistorico) chartHistorico.destroy();

  const ha = baseResumo.distribuicao_historico_antigos;
  const hn = baseResumo.distribuicao_historico_novos;

  chartHistorico = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Pontual", "Irregular", "Inadimplente"],
      datasets: [
        {
          label: "Clientes Antigos",
          data: [ha.pontual, ha.irregular, ha.inadimplente],
          backgroundColor: "rgba(0, 61, 165, 0.75)",
          borderColor: "#003DA5",
          borderWidth: 1.5,
          borderRadius: 4,
        },
        {
          label: "Clientes Novos",
          data: [hn.pontual, hn.irregular, hn.inadimplente],
          backgroundColor: "rgba(74, 144, 217, 0.75)",
          borderColor: "#4A90D9",
          borderWidth: 1.5,
          borderRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom", labels: { font: { size: 12 } } },
      },
      scales: {
        y: {
          ticks: { font: { size: 11 }, stepSize: 5 },
          grid: { color: "#E0E6EF" },
        },
        x: { grid: { display: false } },
      },
    },
  });
}

/**
 * Gráfico 4 — Status de aprovação da sessão atual (atualizado após lote).
 */
function renderizarGraficoStatus(metricas) {
  const ctx = document.getElementById("grafico-status");
  const hint = document.getElementById("hint-status");
  if (!ctx) return;

  if (chartStatus) chartStatus.destroy();
  if (hint) hint.classList.add("hidden");

  const tot = metricas.totais;

  chartStatus = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Aprovado", "Aprovado c/ Ressalvas", "Reprovado"],
      datasets: [{
        data: [tot.aprovados, tot.com_ressalvas, tot.reprovados],
        backgroundColor: [
          "rgba(22, 163, 74, 0.85)",
          "rgba(180, 83, 9, 0.85)",
          "rgba(220, 38, 38, 0.85)",
        ],
        borderColor: ["#16A34A", "#B45309", "#DC2626"],
        borderWidth: 2,
      }],
    },
    options: {
      responsive: true,
      cutout: "60%",
      plugins: {
        legend: { position: "bottom", labels: { font: { size: 12 } } },
        tooltip: {
          callbacks: {
            label: (ctx) => ` ${ctx.label}: ${ctx.raw} clientes`,
          },
        },
      },
    },
  });
}

/**
 * Renderiza os cards de indicadores gerais da base sintética.
 */
function renderizarIndicadores(metricas) {
  const container = document.getElementById("metricas-indicadores");
  if (!container) return;

  const dist = metricas.distorcao_original;
  const base = metricas.base_resumo;

  const cards = [
    {
      num: base.total_clientes,
      lbl: "Total de clientes na base",
      classe: "",
    },
    {
      num: `R$ ${dist.media_limite_antigos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
      lbl: "Limite médio antigos (ANTES)",
      classe: "vermelho",
    },
    {
      num: `R$ ${dist.media_limite_novos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
      lbl: "Limite médio novos (ANTES)",
      classe: "verde",
    },
    {
      num: dist.media_score_antigos,
      lbl: "Score médio clientes antigos",
      classe: "",
    },
    {
      num: dist.media_score_novos,
      lbl: "Score médio clientes novos",
      classe: "",
    },
    {
      num: `${(((dist.media_limite_novos / dist.media_limite_antigos) - 1) * 100).toFixed(0)}%`,
      lbl: "Distorção: novos vs antigos",
      classe: "vermelho",
    },
  ];

  container.innerHTML = cards.map((c) => `
    <div class="metric-card ${c.classe}">
      <span class="num">${c.num}</span>
      <span class="lbl">${c.lbl}</span>
    </div>
  `).join("");
}
