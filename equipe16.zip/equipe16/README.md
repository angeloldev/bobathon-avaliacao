# Aurora Bank — Sistema de Concessão de Crédito Explicável

## 1. Nome da solução e problema que resolve

**Aurora Bank Credit XAI** é um sistema de concessão de crédito explicável construído para substituir o sistema legado do Aurora Bank — com 22 anos de existência — que tomava mais de **4 milhões de decisões mensais** de forma opaca, sem registrar o raciocínio utilizado.

Os três problemas críticos que esta solução resolve:

1. **Decisões incompreensíveis**: clientes recebiam limites sem explicação (ex.: R$ 30.000 concedidos sem solicitação; 12 anos de relacionamento recusados sem justificativa).
2. **Ausência de auditabilidade**: mais de 4 milhões de decisões mensais sem justificativa auditável, expondo o banco a risco regulatório severo.
3. **200 casos ativos sem documentação**: exposição direta a questionamentos de clientes e órgãos reguladores.

A solução implementa um pipeline multi-agente orquestrado pelo **IBM watsonx Orchestrate (Bob)**, onde cada decisão é tomada de forma estruturada, justificada em linguagem acessível ao cliente e registrada com rastro auditável completo.

---

## 2. Como a solução funciona

### Pipeline de 7 Etapas

```mermaid
flowchart TD
    A([Pedido do Cliente\nJSON de entrada]) --> B

    B["**Etapa 1 — Validação**\nVerifica campos obrigatórios\ne tipos de dados"]

    B --> C & D

    C["**Etapa 2 — Agente Carteira**\nConsulta produtos disponíveis\ne teto de limite por faixa de renda"]

    D["**Etapa 3 — Agente Cliente**\nCalcula score composto\nVerifica critérios eliminatórios\nComponentes: credit score (40%),\nrenda (30%), relacionamento (20%),\nprodutos (10%)"]

    C --> E
    D --> E

    E["**Etapa 4 — Orquestração (Bob)**\nConsolida outputs dos agentes\nResolve conflitos\nPrepara dados para decisão"]

    E --> F

    F["**Etapa 5 — Decisão Clara**\nAPROVADO ou RECUSADO\nLimite sugerido calculado\n{ decisao, limite_sugerido, moeda }"]

    F --> G

    G["**Etapa 6 — Justificativa ao Cliente**\nLinguagem acessível, sem jargão\nTexto empático e direto"]

    G --> H

    H["**Etapa 7 — Registro Auditável**\nJSON imutável salvo em src/logs/\nContém: timestamp, inputs, outputs\nde cada agente, score, decisão,\njustificativas técnica e ao cliente"]

    H --> I([Resultado Final\nDecisão + Log de Auditoria])
```

### Tabela de Decisão

| Score Composto Final | Decisão  | Multiplicador de Limite |
|----------------------|----------|------------------------|
| < 30                 | RECUSADO | —                      |
| 30 a 49              | APROVADO | renda × 0,5            |
| 50 a 69              | APROVADO | renda × 1,0            |
| 70 a 84              | APROVADO | renda × 2,0            |
| ≥ 85                 | APROVADO | renda × 3,5            |

> Limite máximo absoluto: R$ 500.000,00. Arredondado para múltiplos de R$ 100.

---

## 3. Uso do IBM watsonx Orchestrate (Bob)

O **IBM watsonx Orchestrate (Bob)** é o motor de orquestração central desta solução. Ele atua na **Etapa 4** do pipeline, mas sua presença permeia todo o fluxo:

### Agentes registrados no Orchestrate

| Agente / Ferramenta        | Arquivo                     | Função registrada              | Responsabilidade                                                     |
|----------------------------|-----------------------------|-------------------------------|----------------------------------------------------------------------|
| **Agente Carteira**        | `src/agente_carteira.py`    | `executar_agente_carteira()`  | Consulta produtos elegíveis e teto de limite por faixa de renda      |
| **Agente Cliente**         | `src/agente_cliente.py`     | `executar_agente_cliente()`   | Calcula score composto, detecta critérios eliminatórios e penalizações |
| **Pipeline de Crédito**    | `src/orchestrate_pipeline.py` | `executar_pipeline()`       | Orquestra as 7 etapas, consolida outputs e aciona o registro         |

### Como o Orchestrate foi configurado

1. **Criação dos agentes**: cada arquivo `agente_*.py` expõe uma função principal que é importada e registrada como *tool* no IBM watsonx Orchestrate através do Builder de Automações.

2. **Fluxo de orquestração**: o Bob é configurado para invocar sequencialmente:
   - `executar_agente_carteira()` com a renda do cliente
   - `executar_agente_cliente()` com todos os dados cadastrais
   - `etapa4_consolidar()` para resolver conflitos entre os dois outputs
   - `etapa5_decidir()` para emitir a decisão final
   - `etapa6_justificar()` para gerar a justificativa ao cliente
   - `registrar_decisao()` para persistir o log auditável

3. **Papel central do Bob**: o Orchestrate garante que nenhuma decisão seja emitida sem que **ambos os agentes** tenham retornado resultados válidos. Em caso de conflito (ex.: Agente Carteira indisponível), o Bob aplica regras de fallback documentadas em `etapa4_consolidar()`.

4. **Rastreabilidade**: cada execução gera um arquivo `auditoria_YYYYMMDD_HHMMSS_<id_cliente>.json` em `src/logs/`, com hash SHA-256 de consistência.

> **Evidências de uso**: consulte a pasta `evidencias/` para prints do Builder do Orchestrate, configuração dos agentes e exemplos de execução.

---

## 4. Modelo errado vs. modelo correto

| Critério                            | Modelo Errado (`modelo_errado.py`)           | Modelo Correto (`modelo_correto.py`)                           |
|-------------------------------------|----------------------------------------------|----------------------------------------------------------------|
| **Critérios utilizados**            | Nenhum — limite 100% aleatório               | Credit score, renda, tempo de relacionamento, qtd. de produtos |
| **Correlação com renda**            | r ≈ 0,00 (próxima de zero)                   | r > 0,60 (positiva e estatisticamente significativa)           |
| **Critérios eliminatórios**         | Não existem                                  | Inadimplência > 6 meses, score < 300, renda < R$2k, idade     |
| **Penalizações**                    | Não existem                                  | -15 pontos para inadimplência recente (≤ 6 meses)             |
| **Explicabilidade**                 | Nenhuma                                      | Justificativa textual em linguagem simples para cada decisão   |
| **Auditabilidade**                  | Não existe                                   | JSON estruturado com todos os componentes e hash de integridade|
| **Limite máximo**                   | R$ 50.000,00 (uniforme)                      | Até R$ 500.000,00 (renda × 3,5 para score ≥ 85)               |
| **Risco regulatório**               | Alto — sem justificativa                     | Baixo — cada decisão tem rastro completo                       |
| **Referência ao Aurora Bank legado**| Simula o sistema opaco de 22 anos            | Substitui com transparência e explicabilidade                  |

---

## 5. Como executar

### Pré-requisitos

- Python 3.10 ou superior
- pip atualizado

### Instalação de dependências

```bash
cd aurora-bank-credit
pip install -r requirements.txt
```

### Passo 1 — Gerar a base de clientes

```bash
python src/gerar_base.py
```

Saída esperada: `src/dados/clientes.csv` com 5.000 registros e resumo estatístico no console.

### Passo 2 — Gerar o modelo errado (referência)

```bash
python src/modelo_errado.py
```

Saída esperada: `src/dados/limites_modelo_errado.csv` e correlação de Pearson ≈ 0 no console.

### Passo 3 — Gerar o modelo correto

```bash
python src/modelo_correto.py
```

Saída esperada: `src/dados/limites_modelo_correto.csv` e correlação de Pearson > 0,6 no console.

### Passo 4 — Executar o pipeline multi-agente (localmente)

```bash
cd src
python orchestrate_pipeline.py
```

Saída esperada: decisões para 4 clientes de teste, justificativas e arquivos JSON em `src/logs/`.

### Passo 5 — Testar componentes individualmente

```bash
# Agente Carteira
cd src && python agente_carteira.py

# Agente Cliente
cd src && python agente_cliente.py

# Registro auditável
cd src && python registro_auditavel.py
```

### Verificação dos outputs

| Script                  | Arquivo gerado                            | Verificação                              |
|-------------------------|-------------------------------------------|------------------------------------------|
| `gerar_base.py`         | `src/dados/clientes.csv`                  | 5.000 linhas, encoding UTF-8             |
| `modelo_errado.py`      | `src/dados/limites_modelo_errado.csv`     | Correlação Pearson ≈ 0 no console        |
| `modelo_correto.py`     | `src/dados/limites_modelo_correto.csv`    | Correlação Pearson > 0,6 no console      |
| `orchestrate_pipeline.py` | `src/logs/auditoria_*.json`             | 1 arquivo JSON por decisão processada    |

---

## 6. Equipe

| Nome | Papel |
|------|-------|
| *(preencher)* | Arquitetura de solução e IBM watsonx Orchestrate |
| *(preencher)* | Modelagem de crédito e regras de negócio |
| *(preencher)* | Engenharia de dados e geração da base |
| *(preencher)* | Documentação e evidências |

---

## 7. Evidências

A pasta `evidencias/` deve conter:

| Arquivo / Item               | Descrição                                                                 |
|------------------------------|---------------------------------------------------------------------------|
| `orchestrate_builder.png`    | Print do IBM watsonx Orchestrate Builder com os agentes configurados      |
| `orchestrate_execucao.png`   | Print de uma execução completa do pipeline no Orchestrate                 |
| `log_auditoria_exemplo.json` | Exemplo de arquivo de auditoria gerado pelo Etapa 7                       |
| `correlacao_modelos.png`     | Gráfico comparando a correlação renda × limite nos dois modelos           |
| `video_demo.mp4` (opcional)  | Vídeo demonstrando o pipeline em execução no IBM watsonx Orchestrate      |

### Como validar o uso do Orchestrate

1. Abra o IBM watsonx Orchestrate e acesse o **Builder de Automações**.
2. Localize a automação **"Aurora Bank — Concessão de Crédito"**.
3. Verifique os três agentes configurados: *Agente Carteira*, *Agente Cliente* e *Pipeline de Crédito*.
4. Execute uma automação de teste com o payload de exemplo disponível em `evidencias/payload_teste.json`.
5. Confirme que o arquivo `src/logs/auditoria_*.json` foi gerado ao final da execução.
