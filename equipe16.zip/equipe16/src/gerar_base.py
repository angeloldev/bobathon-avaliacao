"""
gerar_base.py
=============
Geração da base de dados sintética de clientes para o Aurora Bank Credit System.

Gera 5.000 registros com dados demográficos e financeiros realistas,
utilizando Faker (locale pt_BR), numpy e scipy para distribuições estatísticas.

Saída: src/dados/clientes.csv
"""

import os
import random
import numpy as np
import pandas as pd
from datetime import date, timedelta
from faker import Faker
from faker.providers import person

# ── Configuração de seed para reprodutibilidade ──────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

fake = Faker("pt_BR")
Faker.seed(SEED)

# ── Constantes ───────────────────────────────────────────────────────────────
TOTAL_REGISTROS = 5_000
DATA_MIN_NASCIMENTO = date(1926, 9, 10)
DATA_MAX_NASCIMENTO = date(2026, 2, 1)
DATA_MIN_CONTA = date(1970, 3, 1)
DATA_MAX_CONTA = date(2026, 9, 9)
RENDA_MIN = 2_000.00
RENDA_MAX = 250_000.00
SAIDA = os.path.join(os.path.dirname(__file__), "dados", "clientes.csv")

# ── Listas de nomes brasileiros ──────────────────────────────────────────────
NOMES_MASCULINOS = [
    "Miguel", "Arthur", "Heitor", "Bernardo", "Davi", "Lorenzo", "Theo",
    "Pedro", "Gabriel", "Enzo", "Matheus", "Lucas", "João", "Rafael",
    "Felipe", "Guilherme", "André", "Bruno", "Carlos", "Diego", "Eduardo",
    "Fábio", "Gustavo", "Henrique", "Igor", "Júlio", "Leandro", "Marcelo",
    "Nelson", "Otávio", "Paulo", "Ricardo", "Sérgio", "Thiago", "Vinícius",
]

NOMES_FEMININOS = [
    "Alice", "Sophia", "Valentina", "Isabella", "Manuela", "Laura",
    "Helena", "Lívia", "Júlia", "Lara", "Luiza", "Maria", "Ana",
    "Beatriz", "Clara", "Daniela", "Elisa", "Fernanda", "Gabriela",
    "Isabela", "Joana", "Karina", "Letícia", "Mariana", "Natália",
    "Olivia", "Patricia", "Renata", "Sabrina", "Tatiana", "Viviane",
]

SOBRENOMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira",
    "Alves", "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins",
    "Carvalho", "Almeida", "Lopes", "Soares", "Fernandes", "Vieira",
    "Barbosa", "Rocha", "Dias", "Nascimento", "Andrade", "Moreira",
    "Nunes", "Marques", "Machado", "Mendes", "Freitas", "Cardoso",
    "Ramos", "Gonçalves", "Teixeira", "Cruz", "Araújo", "Monteiro",
]


def gerar_data_aleatoria(data_min: date, data_max: date) -> date:
    """
    Gera uma data aleatória entre data_min e data_max (inclusive).

    Parâmetros:
        data_min (date): Data mínima do intervalo.
        data_max (date): Data máxima do intervalo.

    Retorno:
        date: Data aleatória no intervalo fornecido.
    """
    delta = (data_max - data_min).days
    dias_aleatorios = random.randint(0, delta)
    return data_min + timedelta(days=dias_aleatorios)


def gerar_renda_log_normal() -> float:
    """
    Gera renda mensal com distribuição log-normal concentrada entre R$ 2.500 e R$ 25.000.

    Utiliza log-normal com mu e sigma calibrados para que a mediana fique em ~R$ 5.500
    e a maioria dos valores esteja entre R$ 2.500 e R$ 25.000.
    Valores são truncados entre RENDA_MIN e RENDA_MAX.

    Retorno:
        float: Renda mensal com duas casas decimais.
    """
    mu = np.log(5_500)       # mediana ~ R$ 5.500
    sigma = 0.75             # dispersão moderada
    renda = np.random.lognormal(mean=mu, sigma=sigma)
    renda = float(np.clip(renda, RENDA_MIN, RENDA_MAX))
    return round(renda, 2)


def gerar_registro(id_cliente: int) -> dict:
    """
    Gera um único registro de cliente com todos os campos obrigatórios.

    Parâmetros:
        id_cliente (int): Identificador sequencial do cliente (1 a 5000).

    Retorno:
        dict: Dicionário com todos os campos do cliente.

    Lógica:
        - Sexo sorteado com probabilidade igual entre Masculino e Feminino.
        - Nome coerente com o sexo gerado.
        - Data de abertura de conta garantida >= 18 anos após nascimento.
        - tempo_inadimplencia_meses preenchido apenas para inadimplentes.
    """
    # Sexo
    sexo = random.choice(["Masculino", "Feminino"])

    # Nome coerente com sexo
    if sexo == "Masculino":
        primeiro_nome = random.choice(NOMES_MASCULINOS)
    else:
        primeiro_nome = random.choice(NOMES_FEMININOS)
    sobrenome = random.choice(SOBRENOMES)
    nome = f"{primeiro_nome} {sobrenome}"

    # Data de nascimento
    data_nascimento = gerar_data_aleatoria(DATA_MIN_NASCIMENTO, DATA_MAX_NASCIMENTO)

    # Data de abertura de conta: posterior ao nascimento em pelo menos 18 anos
    # Evita ValueError ao adicionar 18 anos em 29/fev de ano não bissexto
    try:
        data_min_conta_cliente = data_nascimento.replace(
            year=data_nascimento.year + 18
        )
    except ValueError:
        # 29/fev → usar 28/fev
        data_min_conta_cliente = data_nascimento.replace(
            year=data_nascimento.year + 18, day=28
        )
    # Garantir que a data mínima da conta do cliente respeita o limite global
    data_min_conta_efetiva = max(data_min_conta_cliente, DATA_MIN_CONTA)

    if data_min_conta_efetiva > DATA_MAX_CONTA:
        # Cliente muito jovem; forçar abertura no máximo permitido
        data_abertura_conta = DATA_MAX_CONTA
    else:
        data_abertura_conta = gerar_data_aleatoria(data_min_conta_efetiva, DATA_MAX_CONTA)

    # Renda mensal (log-normal)
    renda_mensal = gerar_renda_log_normal()

    # Quantidade de produtos
    quantidade_produtos = random.randint(1, 15)

    # Credit score
    credit_score = random.randint(1, 1000)

    # Inadimplência (30% de chance de ser inadimplente)
    inadimplente = random.choices(["Sim", "Não"], weights=[30, 70])[0]

    # Tempo de inadimplência (apenas para inadimplentes)
    if inadimplente == "Sim":
        tempo_inadimplencia_meses = random.randint(1, 120)
    else:
        tempo_inadimplencia_meses = ""

    return {
        "id_cliente": id_cliente,
        "nome": nome,
        "sexo": sexo,
        "data_nascimento": data_nascimento.strftime("%d/%m/%Y"),
        "data_abertura_conta": data_abertura_conta.strftime("%d/%m/%Y"),
        "renda_mensal": renda_mensal,
        "quantidade_produtos": quantidade_produtos,
        "credit_score": credit_score,
        "inadimplente": inadimplente,
        "tempo_inadimplencia_meses": tempo_inadimplencia_meses,
    }


def gerar_base() -> pd.DataFrame:
    """
    Gera a base completa de 5.000 clientes sintéticos.

    Retorno:
        pd.DataFrame: DataFrame com todos os registros gerados.

    Lógica:
        Itera de 1 a 5000, gerando cada registro individualmente via gerar_registro().
        Ao final, salva em CSV UTF-8 com separador vírgula.
    """
    registros = [gerar_registro(i) for i in range(1, TOTAL_REGISTROS + 1)]
    df = pd.DataFrame(registros)
    return df


def imprimir_resumo(df: pd.DataFrame) -> None:
    """
    Imprime no console um resumo estatístico da base gerada.

    Parâmetros:
        df (pd.DataFrame): DataFrame com os dados gerados.

    Saída no console:
        - Total de registros
        - Distribuição de sexo
        - Percentis de renda (25, 50, 75, 90)
        - Percentual de inadimplentes
        - Média de credit score
    """
    print("\n" + "=" * 60)
    print("     RESUMO ESTATÍSTICO — BASE DE CLIENTES AURORA BANK")
    print("=" * 60)
    print(f"  Total de registros    : {len(df):,}")
    print()

    dist_sexo = df["sexo"].value_counts()
    print("  Distribuição por sexo:")
    for sexo, qtd in dist_sexo.items():
        print(f"    {sexo:<12}: {qtd:,} ({qtd / len(df) * 100:.1f}%)")
    print()

    percentis = df["renda_mensal"].quantile([0.25, 0.50, 0.75, 0.90])
    print("  Faixa de renda mensal (R$):")
    print(f"    Percentil 25  : R$ {percentis[0.25]:>10,.2f}")
    print(f"    Percentil 50  : R$ {percentis[0.50]:>10,.2f}")
    print(f"    Percentil 75  : R$ {percentis[0.75]:>10,.2f}")
    print(f"    Percentil 90  : R$ {percentis[0.90]:>10,.2f}")
    print()

    pct_inadimplente = (df["inadimplente"] == "Sim").mean() * 100
    print(f"  Percentual de inadimplentes : {pct_inadimplente:.1f}%")

    media_score = df["credit_score"].mean()
    print(f"  Média do credit score       : {media_score:.1f}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    os.makedirs(os.path.dirname(SAIDA), exist_ok=True)

    print("Gerando base de clientes...")
    df = gerar_base()

    df.to_csv(SAIDA, index=False, encoding="utf-8", sep=",")
    print(f"Arquivo salvo em: {SAIDA}")

    imprimir_resumo(df)
