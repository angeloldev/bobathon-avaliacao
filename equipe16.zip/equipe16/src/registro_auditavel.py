"""
registro_auditavel.py
=====================
Módulo de Registro Auditável — Etapa 7 do pipeline multi-agente Aurora Bank.

Responsabilidade:
    Persistir um log completo e imutável da decisão de crédito, contendo:
        - Timestamp da decisão
        - Dados de entrada do cliente
        - Outputs de cada agente (Carteira e Cliente)
        - Score composto com detalhamento dos componentes
        - Decisão final e limite sugerido
        - Justificativa ao cliente (linguagem acessível)
        - Justificativa técnica para o regulador

    O arquivo JSON gerado é considerado auditável e não deve ser modificado
    após a gravação.

Integração com IBM watsonx Orchestrate (Bob):
    Este módulo é chamado automaticamente ao final de cada pipeline pelo
    orchestrate_pipeline.py.

Formato de saída:
    src/logs/auditoria_YYYYMMDD_HHMMSS_<id_cliente>.json
"""

import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# ── Caminho base para os logs ─────────────────────────────────────────────────
BASE_DIR = os.path.dirname(__file__)
LOGS_DIR = os.path.join(BASE_DIR, "logs")


def gerar_justificativa_tecnica(resultado_pipeline: dict) -> str:
    """
    Gera justificativa técnica detalhada destinada ao regulador e auditores.

    Ao contrário da justificativa ao cliente, esta versão usa terminologia
    técnica completa e cita todos os valores numéricos relevantes.

    Parâmetros:
        resultado_pipeline (dict): Resultado completo do pipeline, incluindo
                                   outputs dos agentes e decisão final.

    Retorno:
        str: Texto técnico completo para fins regulatórios.
    """
    decisao = resultado_pipeline.get("decisao", "N/A")
    score = resultado_pipeline.get("score_composto", 0.0)
    limite = resultado_pipeline.get("limite_sugerido", 0.0)
    criterio = resultado_pipeline.get("criterio_eliminatorio") or "Nenhum"
    det = resultado_pipeline.get("detalhamento_score", {})

    linhas = [
        f"DECISÃO: {decisao}",
        f"Score composto final: {score:.4f} / 100",
        f"Limite sugerido: R$ {limite:,.2f}",
        f"Critério eliminatório aplicado: {criterio}",
        "",
        "DETALHAMENTO DO SCORE COMPOSTO:",
        f"  - Componente credit_score  (peso 40%): {det.get('comp_credit_score', 'N/A')}",
        f"  - Componente renda         (peso 30%): {det.get('comp_renda', 'N/A')}",
        f"  - Componente relacionamento(peso 20%): {det.get('comp_relacionamento', 'N/A')}",
        f"  - Componente produtos      (peso 10%): {det.get('comp_produtos', 'N/A')}",
        f"  - Penalização inadimplência          : -{det.get('penalizacao_inadimplencia', 0)}",
        f"  - Score bruto (antes da penalização) : {det.get('score_bruto', 'N/A')}",
        "",
        "AGENTE CARTEIRA:",
        f"  - Teto de limite global: R$ {resultado_pipeline.get('teto_limite_global', 0):,.2f}",
        f"  - Produtos elegíveis   : {resultado_pipeline.get('total_produtos_elegiveis', 0)}",
        "",
        "REGRA DE DECISÃO APLICADA:",
    ]

    if criterio != "Nenhum":
        linhas.append(f"  Critério eliminatório '{criterio}' resultou em recusa imediata.")
    elif score < 30:
        linhas.append("  Score < 30: recusado por insuficiência de perfil.")
    elif score < 50:
        linhas.append(f"  Score {score:.2f} (faixa 30–49): limite = renda × 0,5.")
    elif score < 70:
        linhas.append(f"  Score {score:.2f} (faixa 50–69): limite = renda × 1,0.")
    elif score < 85:
        linhas.append(f"  Score {score:.2f} (faixa 70–84): limite = renda × 2,0.")
    else:
        linhas.append(f"  Score {score:.2f} (≥ 85): limite = renda × 3,5.")

    return "\n".join(linhas)


def registrar_decisao(
    dados_entrada: dict,
    resultado_agente_carteira: dict,
    resultado_agente_cliente: dict,
    resultado_pipeline: dict,
) -> str:
    """
    Persiste o registro auditável completo de uma decisão de crédito.

    Gera um arquivo JSON imutável contendo todos os dados do processo decisório,
    incluindo inputs, outputs de agentes, score, decisão, justificativas e
    metadados de rastreabilidade.

    Parâmetros:
        dados_entrada (dict): Dados originais do cliente (input do pipeline).
        resultado_agente_carteira (dict): Output do Agente Carteira (Etapa 2).
        resultado_agente_cliente (dict): Output do Agente Cliente (Etapa 3).
        resultado_pipeline (dict): Resultado consolidado do pipeline
                                   (Etapas 4, 5 e 6).

    Retorno:
        str: Caminho absoluto do arquivo JSON gerado.

    Formato do arquivo:
        src/logs/auditoria_YYYYMMDD_HHMMSS_<id_cliente>.json

    Estrutura do JSON:
        {
            "metadados": { versao, sistema, timestamp_utc, id_auditoria },
            "entrada": { ...dados do cliente... },
            "agente_carteira": { ...output... },
            "agente_cliente": { ...output... },
            "score_composto": float,
            "detalhamento_score": dict,
            "decisao": "APROVADO" | "RECUSADO",
            "limite_sugerido": float,
            "criterio_eliminatorio": str | null,
            "justificativa_cliente": str,
            "justificativa_tecnica_regulador": str,
            "hash_consistencia": str  (SHA-256 dos dados principais)
        }
    """
    import hashlib

    timestamp = datetime.now(tz=timezone.utc)
    ts_str = timestamp.strftime("%Y%m%d_%H%M%S")
    id_cliente = dados_entrada.get("id_cliente", "sem_id")

    # ── Gerar justificativa técnica regulatória ───────────────────────────────
    justificativa_tecnica = gerar_justificativa_tecnica(resultado_pipeline)

    # ── Montar o documento de auditoria ──────────────────────────────────────
    documento = {
        "metadados": {
            "versao_sistema": "1.0.0",
            "sistema": "Aurora Bank — Sistema de Concessão de Crédito Explicável",
            "pipeline": "IBM watsonx Orchestrate (Bob) — 7 etapas",
            "timestamp_utc": timestamp.isoformat(),
            "id_auditoria": f"AUD-{ts_str}-{id_cliente}",
        },
        "entrada": dados_entrada,
        "agente_carteira_saida": resultado_agente_carteira,
        "agente_cliente_saida": resultado_agente_cliente,
        "score_composto": resultado_pipeline.get("score_composto", 0.0),
        "detalhamento_score": resultado_pipeline.get("detalhamento_score", {}),
        "decisao": resultado_pipeline.get("decisao", "RECUSADO"),
        "limite_sugerido": resultado_pipeline.get("limite_sugerido", 0.0),
        "moeda": "BRL",
        "criterio_eliminatorio": resultado_pipeline.get("criterio_eliminatorio") or None,
        "justificativa_cliente": resultado_pipeline.get("justificativa_cliente", ""),
        "justificativa_tecnica_regulador": justificativa_tecnica,
    }

    # ── Hash de consistência (SHA-256) ────────────────────────────────────────
    conteudo_hash = json.dumps({
        "id_cliente": id_cliente,
        "timestamp_utc": documento["metadados"]["timestamp_utc"],
        "score_composto": documento["score_composto"],
        "decisao": documento["decisao"],
        "limite_sugerido": documento["limite_sugerido"],
    }, sort_keys=True)
    documento["hash_consistencia"] = hashlib.sha256(
        conteudo_hash.encode("utf-8")
    ).hexdigest()

    # ── Persistir o arquivo ───────────────────────────────────────────────────
    os.makedirs(LOGS_DIR, exist_ok=True)
    nome_arquivo = f"auditoria_{ts_str}_{id_cliente}.json"
    caminho_arquivo = os.path.join(LOGS_DIR, nome_arquivo)

    with open(caminho_arquivo, "w", encoding="utf-8") as f:
        json.dump(documento, f, ensure_ascii=False, indent=2)

    logger.info(
        "Registro auditável salvo: %s | Decisão: %s | Limite: R$ %.2f",
        caminho_arquivo,
        documento["decisao"],
        documento["limite_sugerido"],
    )

    return caminho_arquivo


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    # Exemplo de uso direto
    dados_entrada_exemplo = {
        "id_cliente": 1001,
        "nome": "Fernanda Costa",
        "data_nascimento": "12/08/1987",
        "data_abertura_conta": "03/03/2010",
        "renda_mensal": 9_000.00,
        "quantidade_produtos": 6,
        "credit_score": 680,
        "inadimplente": "Não",
        "valor_solicitado": 15_000.00,
    }

    resultado_carteira_exemplo = {
        "status": "ok",
        "renda_mensal": 9_000.00,
        "teto_limite_global": 40_000.00,
        "produtos_elegiveis": [
            {"codigo": "CARTAO_GOLD", "nome": "Cartão Gold Aurora", "teto_limite": 30_000.00},
        ],
        "total_produtos": 1,
    }

    resultado_cliente_exemplo = {
        "status": "ok",
        "nome": "Fernanda Costa",
        "idade": 37,
        "anos_relacionamento": 14.5,
        "score_composto": 67.3,
        "detalhamento_score": {
            "comp_credit_score": 27.2,
            "comp_renda": 21.4,
            "comp_relacionamento": 9.67,
            "comp_produtos": 4.0,
            "penalizacao_inadimplencia": 0.0,
            "score_bruto": 62.27,
            "score_final": 67.3,
        },
        "criterio_eliminatorio": None,
        "inadimplente": "Não",
        "nivel_risco": "BAIXO",
    }

    resultado_pipeline_exemplo = {
        "score_composto": 67.3,
        "detalhamento_score": resultado_cliente_exemplo["detalhamento_score"],
        "decisao": "APROVADO",
        "limite_sugerido": 9_000.00,
        "criterio_eliminatorio": None,
        "teto_limite_global": 40_000.00,
        "total_produtos_elegiveis": 1,
        "justificativa_cliente": (
            "Levamos em consideração seu bom histórico de pagamentos, seu tempo de "
            "relacionamento com o banco (14 anos) e sua renda mensal, que demonstram "
            "sua capacidade de pagamento e comprometimento financeiro. "
            "Por isso, aprovamos um limite de crédito de R$ 9.000,00 para o seu cartão."
        ),
    }

    caminho = registrar_decisao(
        dados_entrada_exemplo,
        resultado_carteira_exemplo,
        resultado_cliente_exemplo,
        resultado_pipeline_exemplo,
    )
    print(f"\nRegistro auditável gerado em: {caminho}")
