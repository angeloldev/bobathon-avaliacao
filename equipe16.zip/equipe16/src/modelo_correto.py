"""
modelo_correto.py
=================
Modelo de concessão de crédito baseado em regras de negócio explícitas e
documentadas, utilizando todos os dados cadastrais disponíveis.

Estrutura do modelo:
    Etapa A — Critérios eliminatórios (recusa imediata)
    Etapa B — Cálculo do score composto (0–100)
    Etapa C — Penalizações sobre o score composto
    Etapa D — Decisão e cálculo do limite sugerido
    Etapa E — Geração da justificativa textual em linguagem simples

Entrada : src/dados/clientes.csv
Saída   : src/dados/limites_modelo_correto.csv
"""

import json
import math
import os
from datetime import date, datetime

import numpy as np
import pandas as pd
from scipy.stats import pearsonr

# ── Caminhos ─────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(__file__)
ENTRADA = os.path.join(BASE_DIR, "dados", "clientes.csv")
SAIDA = os.path.join(BASE_DIR, "dados", "limites_modelo_correto.csv")

# ── Constantes do modelo ──────────────────────────────────────────────────────
DATA_REFERENCIA = date.today()          # data usada para calcular idade e tempo de conta
LIMITE_MAXIMO_ABSOLUTO = 500_000.00     # teto absoluto do limite
ARREDONDAMENTO = 100                    # múltiplos de R$ 100


# ═══════════════════════════════════════════════════════════════════════════════
#  FUNÇÕES AUXILIARES
# ═══════════════════════════════════════════════════════════════════════════════

def calcular_idade(data_nascimento_str: str, referencia: date = DATA_REFERENCIA) -> int:
    """
    Calcula a idade em anos completos a partir de uma string de data no formato DD/MM/AAAA.

    Parâmetros:
        data_nascimento_str (str): Data de nascimento no formato 'DD/MM/AAAA'.
        referencia (date): Data de referência para o cálculo. Padrão: hoje.

    Retorno:
        int: Idade em anos completos.
    """
    nascimento = datetime.strptime(data_nascimento_str, "%d/%m/%Y").date()
    anos = referencia.year - nascimento.year
    # Ajuste: ainda não fez aniversário no ano de referência
    if (referencia.month, referencia.day) < (nascimento.month, nascimento.day):
        anos -= 1
    return anos


def calcular_anos_relacionamento(data_abertura_str: str, referencia: date = DATA_REFERENCIA) -> float:
    """
    Calcula o tempo de relacionamento em anos (com decimais) desde a abertura da conta.

    Parâmetros:
        data_abertura_str (str): Data de abertura no formato 'DD/MM/AAAA'.
        referencia (date): Data de referência. Padrão: hoje.

    Retorno:
        float: Anos desde a abertura da conta.
    """
    abertura = datetime.strptime(data_abertura_str, "%d/%m/%Y").date()
    delta_dias = (referencia - abertura).days
    return max(delta_dias / 365.25, 0.0)


def arredondar_multiplo(valor: float, multiplo: int) -> float:
    """
    Arredonda um valor para o múltiplo mais próximo.

    Parâmetros:
        valor (float): Valor a arredondar.
        multiplo (int): Múltiplo de referência (ex.: 100).

    Retorno:
        float: Valor arredondado para o múltiplo informado.
    """
    return round(round(valor / multiplo) * multiplo, 2)


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA A — CRITÉRIOS ELIMINATÓRIOS
# ═══════════════════════════════════════════════════════════════════════════════

def verificar_criterios_eliminatorios(row: pd.Series) -> str | None:
    """
    Verifica se o cliente é recusado imediatamente por critérios eliminatórios.

    Regras (qualquer uma resulta em recusa imediata com limite R$ 0,00):
        1. inadimplente = Sim AND tempo_inadimplencia_meses > 6
        2. credit_score < 300
        3. renda_mensal < R$ 2.000,00
        4. Idade < 18 anos ou > 90 anos (calculada em DATA_REFERENCIA)

    Parâmetros:
        row (pd.Series): Linha do DataFrame com os dados do cliente.

    Retorno:
        str | None: Descrição do critério eliminatório aplicado, ou None se
                    o cliente passou por todos os critérios.
    """
    # Regra 1: inadimplência prolongada (> 6 meses)
    if row["inadimplente"] == "Sim":
        tempo = row["tempo_inadimplencia_meses"]
        if pd.notna(tempo) and tempo != "" and int(tempo) > 6:
            return "inadimplencia_prolongada"

    # Regra 2: credit score mínimo
    if int(row["credit_score"]) < 300:
        return "credit_score_insuficiente"

    # Regra 3: renda mínima
    if float(row["renda_mensal"]) < 2_000.00:
        return "renda_abaixo_do_minimo"

    # Regra 4: idade fora do intervalo permitido
    idade = calcular_idade(str(row["data_nascimento"]))
    if idade < 18:
        return "idade_menor_que_18"
    if idade > 90:
        return "idade_maior_que_90"

    return None   # passou em todos os critérios


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPAS B e C — SCORE COMPOSTO
# ═══════════════════════════════════════════════════════════════════════════════

def calcular_score_composto(row: pd.Series) -> tuple[float, dict]:
    """
    Calcula o score composto de 0 a 100 e retorna o detalhamento dos componentes.

    Etapa B — Componentes e pesos:
        - Credit score normalizado  (peso 40%): (credit_score / 1000) * 40
        - Renda normalizada log-scale (peso 30%): escala logarítmica entre R$2k e R$250k
        - Tempo de relacionamento   (peso 20%): anos / 30 * 20 (máx 20 pontos)
        - Quantidade de produtos    (peso 10%): (qtd_produtos / 15) * 10

    Etapa C — Penalizações:
        - inadimplente = Sim AND tempo_inadimplencia_meses <= 6: -15 pontos

    Parâmetros:
        row (pd.Series): Linha do DataFrame com os dados do cliente.

    Retorno:
        tuple[float, dict]:
            - score_composto (float): Score final após penalizações, mínimo 0.
            - detalhamento (dict): Valores individuais de cada componente.
    """
    credit_score = int(row["credit_score"])
    renda = float(row["renda_mensal"])
    anos_relacionamento = calcular_anos_relacionamento(str(row["data_abertura_conta"]))
    qtd_produtos = int(row["quantidade_produtos"])

    # ── Componente 1: Credit score normalizado (peso 40%) ───────────────────
    comp_credit = (credit_score / 1000) * 40

    # ── Componente 2: Renda normalizada em log-scale (peso 30%) ─────────────
    log_renda = math.log(renda)
    log_min = math.log(2_000)
    log_max = math.log(250_000)
    comp_renda = ((log_renda - log_min) / (log_max - log_min)) * 30

    # ── Componente 3: Tempo de relacionamento (peso 20%) ─────────────────────
    comp_relacionamento = min(anos_relacionamento / 30, 1.0) * 20

    # ── Componente 4: Quantidade de produtos (peso 10%) ───────────────────────
    comp_produtos = (qtd_produtos / 15) * 10

    score_bruto = comp_credit + comp_renda + comp_relacionamento + comp_produtos

    # ── Etapa C: Penalização por inadimplência recente (<= 6 meses) ──────────
    penalizacao = 0.0
    if row["inadimplente"] == "Sim":
        tempo = row["tempo_inadimplencia_meses"]
        if pd.notna(tempo) and tempo != "" and int(tempo) <= 6:
            penalizacao = 15.0

    score_final = max(score_bruto - penalizacao, 0.0)

    detalhamento = {
        "comp_credit_score": round(comp_credit, 4),
        "comp_renda": round(comp_renda, 4),
        "comp_relacionamento": round(comp_relacionamento, 4),
        "comp_produtos": round(comp_produtos, 4),
        "penalizacao_inadimplencia": penalizacao,
        "score_bruto": round(score_bruto, 4),
        "score_final": round(score_final, 4),
    }

    return round(score_final, 4), detalhamento


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA D — DECISÃO E LIMITE
# ═══════════════════════════════════════════════════════════════════════════════

def calcular_decisao_e_limite(score_composto: float, renda_mensal: float) -> tuple[str, float]:
    """
    Determina a decisão (APROVADO / RECUSADO) e o limite sugerido com base no score.

    Tabela de decisão:
        Score < 30       → RECUSADO  | limite = R$ 0,00
        Score 30–49      → APROVADO  | limite = renda * 0,5
        Score 50–69      → APROVADO  | limite = renda * 1,0
        Score 70–84      → APROVADO  | limite = renda * 2,0
        Score >= 85      → APROVADO  | limite = renda * 3,5

    Limite máximo absoluto: R$ 500.000,00. Arredondado para múltiplos de R$ 100.

    Parâmetros:
        score_composto (float): Score composto final após penalizações.
        renda_mensal (float): Renda mensal do cliente em R$.

    Retorno:
        tuple[str, float]: ('APROVADO' | 'RECUSADO', limite_sugerido)
    """
    if score_composto < 30:
        return "RECUSADO", 0.00

    if score_composto < 50:
        multiplicador = 0.5
    elif score_composto < 70:
        multiplicador = 1.0
    elif score_composto < 85:
        multiplicador = 2.0
    else:
        multiplicador = 3.5

    limite_bruto = renda_mensal * multiplicador
    limite = min(limite_bruto, LIMITE_MAXIMO_ABSOLUTO)
    limite = arredondar_multiplo(limite, ARREDONDAMENTO)

    return "APROVADO", limite


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA E — JUSTIFICATIVA TEXTUAL
# ═══════════════════════════════════════════════════════════════════════════════

JUSTIFICATIVAS_ELIMINATORIO = {
    "inadimplencia_prolongada": (
        "Identificamos uma pendência financeira em seu histórico recente. "
        "Para solicitar crédito, é necessário regularizar essa situação. "
        "Após a regularização, você poderá realizar uma nova solicitação."
    ),
    "credit_score_insuficiente": (
        "Seu perfil financeiro atual não atende aos critérios mínimos para "
        "concessão de crédito. Recomendamos buscar orientação financeira e "
        "tentar novamente após 6 meses."
    ),
    "renda_abaixo_do_minimo": (
        "Sua renda mensal informada está abaixo do valor mínimo necessário para "
        "concessão de crédito pelo Aurora Bank. Caso sua situação financeira mude, "
        "entre em contato novamente."
    ),
    "idade_menor_que_18": (
        "Infelizmente, a concessão de crédito é permitida apenas para clientes "
        "maiores de 18 anos."
    ),
    "idade_maior_que_90": (
        "Com base em nossos critérios internos, não é possível conceder crédito "
        "neste momento. Entre em contato com uma agência para mais informações."
    ),
}


def gerar_justificativa(
    decisao: str,
    score_composto: float,
    limite_sugerido: float,
    criterio_eliminatorio: str | None,
    row: pd.Series,
    detalhamento: dict,
) -> str:
    """
    Gera justificativa textual em linguagem simples e acessível ao cliente.

    Regras de geração:
        - Nenhum jargão técnico sem tradução (score, inadimplência, percentil).
        - Texto empático, claro e direto.
        - Para recusados: explica o motivo principal sem exposição excessiva.
        - Para aprovados: destaca os pontos positivos e informa o limite.

    Parâmetros:
        decisao (str): 'APROVADO' ou 'RECUSADO'.
        score_composto (float): Score composto final.
        limite_sugerido (float): Limite calculado em R$.
        criterio_eliminatorio (str | None): Código do critério eliminatório, se houver.
        row (pd.Series): Dados completos do cliente.
        detalhamento (dict): Detalhamento dos componentes do score.

    Retorno:
        str: Texto da justificativa pronto para exibição ao cliente.
    """
    # Recusado por critério eliminatório
    if criterio_eliminatorio:
        return JUSTIFICATIVAS_ELIMINATORIO.get(
            criterio_eliminatorio,
            "Sua solicitação não pôde ser aprovada no momento. Entre em contato com "
            "uma agência para mais informações.",
        )

    # Recusado por score baixo (< 30, mas passou nos eliminatórios)
    if decisao == "RECUSADO":
        return (
            "Após analisar seu histórico e perfil financeiro, não foi possível "
            "aprovar o crédito neste momento. Recomendamos fortalecer seu "
            "relacionamento com o banco e buscar orientação financeira. "
            "Você pode tentar novamente em 6 meses."
        )

    # Aprovado — montar texto com destaques positivos
    anos_relacionamento = calcular_anos_relacionamento(str(row["data_abertura_conta"]))
    nome_primeiro = str(row["nome"]).split()[0]

    partes = []

    # Destaques positivos
    fatores_positivos = []
    if detalhamento["comp_credit_score"] >= 20:
        fatores_positivos.append("seu excelente histórico de pagamentos")
    elif detalhamento["comp_credit_score"] >= 10:
        fatores_positivos.append("seu bom histórico de pagamentos")

    if anos_relacionamento >= 5:
        fatores_positivos.append(
            f"seu tempo de relacionamento com o banco "
            f"({int(anos_relacionamento)} anos)"
        )

    if detalhamento["comp_renda"] >= 15:
        fatores_positivos.append("sua renda mensal")

    if int(row["quantidade_produtos"]) >= 5:
        fatores_positivos.append("a variedade de produtos que você utiliza conosco")

    if fatores_positivos:
        lista = ", ".join(fatores_positivos[:-1])
        if len(fatores_positivos) > 1:
            lista += f" e {fatores_positivos[-1]}"
        else:
            lista = fatores_positivos[0]
        partes.append(
            f"Levamos em consideração {lista}, que demonstram sua capacidade "
            "de pagamento e comprometimento financeiro."
        )
    else:
        partes.append(
            "Analisamos seu perfil financeiro e histórico de relacionamento com o banco."
        )

    # Observação sobre inadimplência recente (penalizada mas aprovada)
    if row["inadimplente"] == "Sim":
        tempo = row["tempo_inadimplencia_meses"]
        if pd.notna(tempo) and tempo != "" and int(tempo) <= 6:
            partes.append(
                "Notamos uma ocorrência recente em seu histórico, o que resultou "
                "em um limite ligeiramente menor do que o usual."
            )

    # Limite e decisão
    limite_fmt = f"R$ {limite_sugerido:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    partes.append(
        f"Por isso, aprovamos um limite de crédito de {limite_fmt} para o seu cartão."
    )

    return " ".join(partes)


# ═══════════════════════════════════════════════════════════════════════════════
#  FUNÇÃO PRINCIPAL DE AVALIAÇÃO
# ═══════════════════════════════════════════════════════════════════════════════

def avaliar_cliente(row: pd.Series) -> dict:
    """
    Executa o pipeline completo de avaliação para um único cliente.

    Etapas executadas em sequência:
        A → verifica critérios eliminatórios
        B → calcula score composto e componentes
        C → aplica penalizações (dentro de calcular_score_composto)
        D → determina decisão e limite
        E → gera justificativa textual

    Parâmetros:
        row (pd.Series): Linha do DataFrame com todos os dados do cliente.

    Retorno:
        dict: Resultado completo com score_composto, decisao, limite_sugerido,
              justificativa_cliente, criterio_eliminatorio e detalhamento_score.
    """
    # Etapa A
    criterio = verificar_criterios_eliminatorios(row)
    if criterio:
        justificativa = gerar_justificativa(
            decisao="RECUSADO",
            score_composto=0.0,
            limite_sugerido=0.0,
            criterio_eliminatorio=criterio,
            row=row,
            detalhamento={},
        )
        return {
            "id_cliente": row["id_cliente"],
            "nome": row["nome"],
            "score_composto": 0.0,
            "decisao": "RECUSADO",
            "limite_sugerido": 0.00,
            "justificativa_cliente": justificativa,
            "criterio_eliminatorio": criterio,
            "detalhamento_score": json.dumps({}),
        }

    # Etapas B e C
    score_composto, detalhamento = calcular_score_composto(row)

    # Etapa D
    decisao, limite = calcular_decisao_e_limite(score_composto, float(row["renda_mensal"]))

    # Etapa E
    justificativa = gerar_justificativa(
        decisao=decisao,
        score_composto=score_composto,
        limite_sugerido=limite,
        criterio_eliminatorio=None,
        row=row,
        detalhamento=detalhamento,
    )

    return {
        "id_cliente": row["id_cliente"],
        "nome": row["nome"],
        "score_composto": score_composto,
        "decisao": decisao,
        "limite_sugerido": limite,
        "justificativa_cliente": justificativa,
        "criterio_eliminatorio": "",
        "detalhamento_score": json.dumps(detalhamento, ensure_ascii=False),
    }


def processar_base(df_clientes: pd.DataFrame) -> pd.DataFrame:
    """
    Processa todos os clientes da base e retorna o DataFrame de resultados.

    Parâmetros:
        df_clientes (pd.DataFrame): Base completa de clientes.

    Retorno:
        pd.DataFrame: DataFrame com os resultados do modelo correto para cada cliente.
    """
    resultados = df_clientes.apply(avaliar_cliente, axis=1).tolist()
    return pd.DataFrame(resultados)


def imprimir_resumo(df_clientes: pd.DataFrame, df_resultado: pd.DataFrame) -> None:
    """
    Imprime resumo do modelo correto, incluindo correlação com renda.

    Parâmetros:
        df_clientes (pd.DataFrame): Base de clientes com 'renda_mensal'.
        df_resultado (pd.DataFrame): Resultado do modelo correto.
    """
    aprovados = (df_resultado["decisao"] == "APROVADO").sum()
    recusados = (df_resultado["decisao"] == "RECUSADO").sum()
    total = len(df_resultado)

    aprovados_com_limite = df_resultado[df_resultado["limite_sugerido"] > 0]
    r, p_valor = pearsonr(
        df_clientes.loc[aprovados_com_limite.index, "renda_mensal"].values,
        aprovados_com_limite["limite_sugerido"].values,
    )

    print("\n" + "=" * 60)
    print("     ANÁLISE DO MODELO CORRETO — AURORA BANK")
    print("=" * 60)
    print(f"  Total avaliado   : {total:,}")
    print(f"  Aprovados        : {aprovados:,} ({aprovados / total * 100:.1f}%)")
    print(f"  Recusados        : {recusados:,} ({recusados / total * 100:.1f}%)")
    print()
    print(f"  Limite médio (aprovados): R$ {aprovados_com_limite['limite_sugerido'].mean():>10,.2f}")
    print(f"  Limite máximo           : R$ {df_resultado['limite_sugerido'].max():>10,.2f}")
    print()
    print(f"  Correlação de Pearson (limite vs. renda): r = {r:.4f}  |  p-valor = {p_valor:.6f}")
    if r > 0.6:
        print("  OK: Correlacao positiva e forte -- modelo considera renda adequadamente.")
    else:
        print(f"  ATENCAO: Correlacao de {r:.4f} -- verificar calibracao do modelo.")
    print()

    criterios = df_resultado[df_resultado["criterio_eliminatorio"] != ""]["criterio_eliminatorio"].value_counts()
    if not criterios.empty:
        print("  Critérios eliminatórios mais frequentes:")
        for criterio, qtd in criterios.items():
            print(f"    {criterio:<35}: {qtd:,}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    if not os.path.exists(ENTRADA):
        raise FileNotFoundError(
            f"Base de clientes não encontrada em '{ENTRADA}'. "
            "Execute src/gerar_base.py primeiro."
        )

    df_clientes = pd.read_csv(ENTRADA, encoding="utf-8", sep=",")
    print(f"Base carregada: {len(df_clientes):,} clientes.")

    print("Processando avaliações de crédito...")
    df_resultado = processar_base(df_clientes)

    os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
    df_resultado.to_csv(SAIDA, index=False, encoding="utf-8", sep=",")
    print(f"Arquivo salvo em: {SAIDA}")

    imprimir_resumo(df_clientes, df_resultado)
