"""
agente_cliente.py
=================
Agente Cliente (Customer Agent) — Etapa 3 do pipeline multi-agente Aurora Bank.

Responsabilidade:
    Analisar histórico, comportamento financeiro e capacidade de pagamento do
    cliente, calculando o score composto, seus componentes individuais,
    penalizações aplicadas e sinalizando critérios eliminatórios.

Integração com IBM watsonx Orchestrate (Bob):
    Este módulo é importado pelo orchestrate_pipeline.py e expõe a função
    principal como ferramenta registrável no Orchestrate.

Entrada : todos os dados cadastrais do cliente (dict)
Saída   : dict com score composto, componentes, penalizações e sinalização
          de critérios eliminatórios
"""

import logging
from datetime import date

from modelo_correto import (
    calcular_idade,
    calcular_anos_relacionamento,
    calcular_score_composto,
    verificar_criterios_eliminatorios,
)
import pandas as pd

logger = logging.getLogger(__name__)

# ── Campos obrigatórios para análise do cliente ───────────────────────────────
CAMPOS_OBRIGATORIOS = [
    "nome",
    "data_nascimento",
    "data_abertura_conta",
    "renda_mensal",
    "quantidade_produtos",
    "credit_score",
    "inadimplente",
]


def validar_campos(dados_cliente: dict) -> list[str]:
    """
    Verifica se todos os campos obrigatórios estão presentes nos dados do cliente.

    Parâmetros:
        dados_cliente (dict): Dados do cliente a serem validados.

    Retorno:
        list[str]: Lista de campos ausentes. Vazia se todos estiverem presentes.
    """
    ausentes = [campo for campo in CAMPOS_OBRIGATORIOS if campo not in dados_cliente]
    return ausentes


def executar_agente_cliente(dados_cliente: dict) -> dict:
    """
    Ponto de entrada principal do Agente Cliente.

    Analisa o perfil financeiro e de relacionamento do cliente, calculando:
        - Score composto (0–100) com detalhamento de componentes
        - Critérios eliminatórios (se aplicáveis)
        - Penalizações aplicadas
        - Indicadores de risco e de relacionamento

    Este método é registrado como ferramenta no IBM watsonx Orchestrate.

    Parâmetros:
        dados_cliente (dict): Dicionário com os campos do cliente:
            - nome (str)
            - data_nascimento (str, formato DD/MM/AAAA)
            - data_abertura_conta (str, formato DD/MM/AAAA)
            - renda_mensal (float)
            - quantidade_produtos (int)
            - credit_score (int)
            - inadimplente (str: 'Sim' | 'Não')
            - tempo_inadimplencia_meses (int | None | ''): obrigatório se inadimplente = Sim

    Retorno:
        dict: {
            "status": "ok" | "erro",
            "nome": str,
            "idade": int,
            "anos_relacionamento": float,
            "score_composto": float,
            "detalhamento_score": dict,
            "criterio_eliminatorio": str | None,
            "inadimplente": str,
            "nivel_risco": str,  ("BAIXO", "MEDIO", "ALTO", "CRITICO")
            "mensagem_erro": str  (presente apenas em caso de erro)
        }

    Erros tratados:
        - Campos obrigatórios ausentes
        - Valores inválidos de data, renda ou score
        - inadimplente = Sim sem tempo_inadimplencia_meses
    """
    # ── Validação de campos obrigatórios ─────────────────────────────────────
    ausentes = validar_campos(dados_cliente)
    if ausentes:
        msg = f"Campos obrigatórios ausentes: {', '.join(ausentes)}"
        logger.error("Agente Cliente: %s", msg)
        return {"status": "erro", "mensagem_erro": msg}

    # Validação adicional: inadimplente=Sim sem tempo informado
    if dados_cliente.get("inadimplente") == "Sim":
        tempo = dados_cliente.get("tempo_inadimplencia_meses")
        if tempo is None or tempo == "":
            msg = (
                "Campo 'tempo_inadimplencia_meses' é obrigatório quando "
                "'inadimplente' = 'Sim'."
            )
            logger.error("Agente Cliente: %s", msg)
            return {"status": "erro", "mensagem_erro": msg}

    # ── Conversão para pd.Series (reutiliza lógica de modelo_correto) ────────
    try:
        row = pd.Series({
            "data_nascimento": str(dados_cliente["data_nascimento"]),
            "data_abertura_conta": str(dados_cliente["data_abertura_conta"]),
            "renda_mensal": float(dados_cliente["renda_mensal"]),
            "quantidade_produtos": int(dados_cliente["quantidade_produtos"]),
            "credit_score": int(dados_cliente["credit_score"]),
            "inadimplente": str(dados_cliente["inadimplente"]),
            "tempo_inadimplencia_meses": dados_cliente.get("tempo_inadimplencia_meses", ""),
        })
    except (ValueError, TypeError) as e:
        msg = f"Erro ao converter dados do cliente: {e}"
        logger.error("Agente Cliente: %s", msg)
        return {"status": "erro", "mensagem_erro": msg}

    # ── Cálculos ──────────────────────────────────────────────────────────────
    try:
        idade = calcular_idade(row["data_nascimento"])
        anos_relacionamento = calcular_anos_relacionamento(row["data_abertura_conta"])
    except ValueError as e:
        return {"status": "erro", "mensagem_erro": f"Data inválida: {e}"}

    criterio_eliminatorio = verificar_criterios_eliminatorios(row)

    if criterio_eliminatorio:
        score_composto = 0.0
        detalhamento = {}
    else:
        score_composto, detalhamento = calcular_score_composto(row)

    # ── Classificação do nível de risco ───────────────────────────────────────
    if criterio_eliminatorio:
        nivel_risco = "CRITICO"
    elif score_composto < 30:
        nivel_risco = "ALTO"
    elif score_composto < 50:
        nivel_risco = "MEDIO"
    else:
        nivel_risco = "BAIXO"

    logger.info(
        "Agente Cliente: %s | idade=%d | relacionamento=%.1f anos | "
        "score=%.2f | risco=%s | eliminatorio=%s",
        dados_cliente.get("nome", "?"),
        idade,
        anos_relacionamento,
        score_composto,
        nivel_risco,
        criterio_eliminatorio or "nenhum",
    )

    return {
        "status": "ok",
        "nome": dados_cliente.get("nome", ""),
        "idade": idade,
        "anos_relacionamento": round(anos_relacionamento, 2),
        "score_composto": score_composto,
        "detalhamento_score": detalhamento,
        "criterio_eliminatorio": criterio_eliminatorio,
        "inadimplente": dados_cliente.get("inadimplente", "Não"),
        "nivel_risco": nivel_risco,
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    casos_teste = [
        {
            "nome": "Maria Silva",
            "data_nascimento": "15/03/1985",
            "data_abertura_conta": "10/06/2005",
            "renda_mensal": 8_500.00,
            "quantidade_produtos": 7,
            "credit_score": 720,
            "inadimplente": "Não",
        },
        {
            "nome": "João Santos",
            "data_nascimento": "20/11/1990",
            "data_abertura_conta": "01/01/2015",
            "renda_mensal": 3_200.00,
            "quantidade_produtos": 2,
            "credit_score": 250,   # Eliminatório: score < 300
            "inadimplente": "Não",
        },
        {
            "nome": "Ana Oliveira",
            "data_nascimento": "05/07/1978",
            "data_abertura_conta": "20/03/1998",
            "renda_mensal": 15_000.00,
            "quantidade_produtos": 10,
            "credit_score": 850,
            "inadimplente": "Sim",
            "tempo_inadimplencia_meses": 3,  # Recente: penalização
        },
    ]

    for i, caso in enumerate(casos_teste, 1):
        print(f"\n{'─'*55}")
        print(f"Caso {i}: {caso['nome']}")
        resultado = executar_agente_cliente(caso)
        print(f"  Status              : {resultado.get('status')}")
        print(f"  Idade               : {resultado.get('idade')} anos")
        print(f"  Relacionamento      : {resultado.get('anos_relacionamento')} anos")
        print(f"  Score composto      : {resultado.get('score_composto'):.2f}")
        print(f"  Nível de risco      : {resultado.get('nivel_risco')}")
        print(f"  Critério eliminat.  : {resultado.get('criterio_eliminatorio') or 'nenhum'}")
        if resultado.get("detalhamento_score"):
            d = resultado["detalhamento_score"]
            print(f"  Detalhamento score  :")
            print(f"    Credit score      : {d.get('comp_credit_score', 0):.2f}")
            print(f"    Renda             : {d.get('comp_renda', 0):.2f}")
            print(f"    Relacionamento    : {d.get('comp_relacionamento', 0):.2f}")
            print(f"    Produtos          : {d.get('comp_produtos', 0):.2f}")
            print(f"    Penalização       : -{d.get('penalizacao_inadimplencia', 0):.2f}")
