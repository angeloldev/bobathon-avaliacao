"""
modelo_errado.py
================
Modelo de referência INCORRETO para concessão de limite de crédito.

# ATENÇÃO: Este modelo é intencionalmente incorreto. Limites são aleatórios
#          e não refletem capacidade de pagamento.

Propósito didático: demonstrar que atribuir limites sem critério gera
correlação próxima de zero com a renda, evidenciando a ausência de justiça
e explicabilidade nas decisões.

Entrada : src/dados/clientes.csv
Saída   : src/dados/limites_modelo_errado.csv
"""

import os
import random
import numpy as np
import pandas as pd
from scipy.stats import pearsonr

# ── Configuração de seed para reprodutibilidade ──────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# ── Caminhos ─────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(__file__)
ENTRADA = os.path.join(BASE_DIR, "dados", "clientes.csv")
SAIDA = os.path.join(BASE_DIR, "dados", "limites_modelo_errado.csv")

# ── Constantes do modelo errado ───────────────────────────────────────────────
LIMITE_MIN = 500.00
LIMITE_MAX = 50_000.00


def atribuir_limite_aleatorio(n: int) -> np.ndarray:
    """
    Gera n limites de crédito de forma completamente aleatória (distribuição uniforme).

    # ATENÇÃO: Este modelo é intencionalmente incorreto. Limites são aleatórios
    #          e não refletem capacidade de pagamento.

    Parâmetros:
        n (int): Número de registros a gerar.

    Retorno:
        np.ndarray: Array com n valores float entre LIMITE_MIN e LIMITE_MAX,
                    sem qualquer correlação com dados do cliente.
    """
    return np.random.uniform(low=LIMITE_MIN, high=LIMITE_MAX, size=n).round(2)


def gerar_modelo_errado(df_clientes: pd.DataFrame) -> pd.DataFrame:
    """
    Gera o DataFrame de limites incorretos a partir da base de clientes.

    Parâmetros:
        df_clientes (pd.DataFrame): DataFrame com os clientes (deve conter
                                    'id_cliente' e 'nome').

    Retorno:
        pd.DataFrame: DataFrame com colunas id_cliente, nome e
                      limite_cartao_modelo_errado.

    Lógica:
        Os limites são gerados de forma uniforme aleatória, sem consultar
        nenhum dado financeiro ou cadastral do cliente. Isso simula o
        comportamento opaco do sistema legado do Aurora Bank.
    """
    limites = atribuir_limite_aleatorio(len(df_clientes))

    df_resultado = pd.DataFrame({
        "id_cliente": df_clientes["id_cliente"].values,
        "nome": df_clientes["nome"].values,
        "limite_cartao_modelo_errado": limites,
    })
    return df_resultado


def calcular_e_imprimir_correlacao(df_clientes: pd.DataFrame, df_resultado: pd.DataFrame) -> None:
    """
    Calcula e imprime a correlação de Pearson entre limite aleatório e renda mensal.

    Parâmetros:
        df_clientes (pd.DataFrame): Base de clientes com 'renda_mensal'.
        df_resultado (pd.DataFrame): Resultado do modelo com 'limite_cartao_modelo_errado'.

    Saída no console:
        Correlação de Pearson (esperada próxima de zero) evidenciando
        que o modelo não considera capacidade de pagamento.
    """
    r, p_valor = pearsonr(
        df_clientes["renda_mensal"].values,
        df_resultado["limite_cartao_modelo_errado"].values,
    )

    print("\n" + "=" * 60)
    print("     ANÁLISE DO MODELO ERRADO — AURORA BANK")
    print("=" * 60)
    print(f"  Registros gerados          : {len(df_resultado):,}")
    print(f"  Limite mínimo (R$)         : {df_resultado['limite_cartao_modelo_errado'].min():>10,.2f}")
    print(f"  Limite máximo (R$)         : {df_resultado['limite_cartao_modelo_errado'].max():>10,.2f}")
    print(f"  Limite médio (R$)          : {df_resultado['limite_cartao_modelo_errado'].mean():>10,.2f}")
    print()
    print(f"  Correlação de Pearson (limite vs. renda): r = {r:.4f}  |  p-valor = {p_valor:.4f}")
    print()
    if abs(r) < 0.05:
        avaliacao = "OK Confirmado: correlacao praticamente nula -- limites sao aleatorios."
    else:
        avaliacao = f"ATENCAO: Correlacao inesperada de {r:.4f} -- verificar geracao."
    print(f"  Avaliacao: {avaliacao}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    if not os.path.exists(ENTRADA):
        raise FileNotFoundError(
            f"Base de clientes não encontrada em '{ENTRADA}'. "
            "Execute src/gerar_base.py primeiro."
        )

    df_clientes = pd.read_csv(ENTRADA, encoding="utf-8", sep=",")
    print(f"Base carregada: {len(df_clientes):,} clientes.")

    df_resultado = gerar_modelo_errado(df_clientes)

    os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
    df_resultado.to_csv(SAIDA, index=False, encoding="utf-8", sep=",")
    print(f"Arquivo salvo em: {SAIDA}")

    calcular_e_imprimir_correlacao(df_clientes, df_resultado)
