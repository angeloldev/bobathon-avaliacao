"""
orchestrate_pipeline.py
=======================
Orquestrador do pipeline multi-agente de crédito — Aurora Bank.

Implementa as 7 etapas do pipeline de concessão de crédito utilizando
o IBM watsonx Orchestrate (Bob) como plataforma de orquestração.

Etapas do pipeline:
    1. Recebimento e validação do pedido
    2. Agente Carteira (produtos e teto de limite)
    3. Agente Cliente (score, componentes, critérios eliminatórios)
    4. Orquestração (consolidação e resolução de conflitos entre agentes)
    5. Decisão clara (APROVADO / RECUSADO + limite)
    6. Justificativa ao cliente (linguagem acessível e empática)
    7. Registro auditável (JSON imutável para fins regulatórios)

Integração IBM watsonx Orchestrate (Bob):
    O Orchestrate coordena os agentes Carteira e Cliente como ferramentas
    (tools) registradas. Este módulo expõe `executar_pipeline()` como a
    ferramenta principal, chamada pelo fluxo de automação no Bob.

    Configuração esperada no Orchestrate:
        - Ferramenta "agente_carteira"   → executar_agente_carteira()
        - Ferramenta "agente_cliente"    → executar_agente_cliente()
        - Ferramenta "pipeline_credito"  → executar_pipeline()

Uso como módulo:
    from orchestrate_pipeline import executar_pipeline
    resultado = executar_pipeline(dados_cliente)

Uso como script:
    python orchestrate_pipeline.py
"""

import json
import logging
import sys
import os

# Garantir que src/ está no path para imports relativos
sys.path.insert(0, os.path.dirname(__file__))

from agente_carteira import executar_agente_carteira
from agente_cliente import executar_agente_cliente
from modelo_correto import calcular_decisao_e_limite, gerar_justificativa
from registro_auditavel import registrar_decisao
import pandas as pd

logger = logging.getLogger(__name__)

# ── Campos obrigatórios do pedido de crédito ──────────────────────────────────
CAMPOS_OBRIGATORIOS_PEDIDO = [
    "nome",
    "data_nascimento",
    "data_abertura_conta",
    "renda_mensal",
    "quantidade_produtos",
    "credit_score",
    "inadimplente",
]


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA 1 — RECEBIMENTO E VALIDAÇÃO DO PEDIDO
# ═══════════════════════════════════════════════════════════════════════════════

def etapa1_validar_pedido(dados_cliente: dict) -> dict:
    """
    Etapa 1 — Recebe e valida o pedido de crédito.

    Verifica se todos os campos obrigatórios estão presentes e com tipos
    coerentes. Retorna o pedido estruturado e validado para processamento.

    Parâmetros:
        dados_cliente (dict): Dados brutos do cliente no formato JSON de entrada.
            Campos obrigatórios:
                - nome (str)
                - data_nascimento (str, DD/MM/AAAA)
                - data_abertura_conta (str, DD/MM/AAAA)
                - renda_mensal (float)
                - quantidade_produtos (int)
                - credit_score (int)
                - inadimplente (str: 'Sim' | 'Não')
            Campos opcionais:
                - id_cliente (int)
                - tempo_inadimplencia_meses (int)
                - valor_solicitado (float)

    Retorno:
        dict: {
            "status": "ok" | "erro",
            "pedido_validado": dict,  (presente se status="ok")
            "erros_validacao": list[str]  (presente se status="erro")
        }
    """
    erros = []

    # Verificar campos obrigatórios
    for campo in CAMPOS_OBRIGATORIOS_PEDIDO:
        if campo not in dados_cliente or dados_cliente[campo] is None:
            erros.append(f"Campo obrigatório ausente: '{campo}'")

    if erros:
        logger.error("Etapa 1 — Validação falhou: %s", erros)
        return {"status": "erro", "erros_validacao": erros}

    # Validação de tipos e valores básicos
    try:
        renda = float(dados_cliente["renda_mensal"])
        if renda <= 0:
            erros.append("'renda_mensal' deve ser um valor positivo.")
    except (ValueError, TypeError):
        erros.append(f"'renda_mensal' inválida: {dados_cliente['renda_mensal']}")

    try:
        score = int(dados_cliente["credit_score"])
        if not (1 <= score <= 1000):
            erros.append("'credit_score' deve estar entre 1 e 1000.")
    except (ValueError, TypeError):
        erros.append(f"'credit_score' inválido: {dados_cliente['credit_score']}")

    try:
        qtd = int(dados_cliente["quantidade_produtos"])
        if not (1 <= qtd <= 15):
            erros.append("'quantidade_produtos' deve estar entre 1 e 15.")
    except (ValueError, TypeError):
        erros.append(f"'quantidade_produtos' inválido: {dados_cliente['quantidade_produtos']}")

    if dados_cliente.get("inadimplente") not in ("Sim", "Não"):
        erros.append("'inadimplente' deve ser 'Sim' ou 'Não'.")

    if dados_cliente.get("inadimplente") == "Sim":
        tempo = dados_cliente.get("tempo_inadimplencia_meses")
        if tempo is None or tempo == "":
            erros.append(
                "'tempo_inadimplencia_meses' é obrigatório quando 'inadimplente' = 'Sim'."
            )

    if erros:
        logger.error("Etapa 1 — Validação falhou: %s", erros)
        return {"status": "erro", "erros_validacao": erros}

    logger.info("Etapa 1 — Pedido validado: %s", dados_cliente.get("nome", "?"))
    return {"status": "ok", "pedido_validado": dados_cliente}


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA 4 — ORQUESTRAÇÃO (CONSOLIDAÇÃO E RESOLUÇÃO DE CONFLITOS)
# ═══════════════════════════════════════════════════════════════════════════════

def etapa4_consolidar(
    resultado_carteira: dict,
    resultado_cliente: dict,
    dados_cliente: dict,
) -> dict:
    """
    Etapa 4 — Orquestração: consolida outputs dos Agentes Carteira e Cliente.

    Responsabilidade do IBM watsonx Orchestrate (Bob):
        O Bob coordena a execução sequencial dos Agentes Carteira e Cliente,
        aguarda ambos os outputs e chama esta função para consolidar os
        resultados antes de acionar a etapa de decisão.

    Regras de resolução de conflitos:
        - Se o Agente Carteira retornou erro, o teto de limite é definido como
          o máximo absoluto (R$ 500.000) e prossegue-se com os demais dados.
        - Se o Agente Cliente retornou erro, o pipeline é encerrado com recusa.
        - O teto de limite efetivo é o menor entre: teto do Agente Carteira e
          o limite máximo absoluto do sistema (R$ 500.000).

    Parâmetros:
        resultado_carteira (dict): Output do Agente Carteira (Etapa 2).
        resultado_cliente (dict): Output do Agente Cliente (Etapa 3).
        dados_cliente (dict): Dados originais do cliente.

    Retorno:
        dict: Dados consolidados prontos para a etapa de decisão.
    """
    # Agente Cliente com erro → recusa imediata
    if resultado_cliente.get("status") == "erro":
        return {
            "status": "erro",
            "motivo": f"Agente Cliente: {resultado_cliente.get('mensagem_erro')}",
        }

    # Agente Carteira com erro → usa teto padrão
    if resultado_carteira.get("status") == "erro":
        logger.warning(
            "Etapa 4 — Agente Carteira retornou erro; usando teto padrão R$ 500.000."
        )
        teto_carteira = 500_000.00
        produtos = []
    else:
        teto_carteira = resultado_carteira.get("teto_limite_global", 500_000.00)
        produtos = resultado_carteira.get("produtos_elegiveis", [])

    score_composto = resultado_cliente.get("score_composto", 0.0)
    criterio_eliminatorio = resultado_cliente.get("criterio_eliminatorio")
    detalhamento = resultado_cliente.get("detalhamento_score", {})

    logger.info(
        "Etapa 4 — Consolidado: score=%.2f | teto=R$ %.2f | produtos=%d | criterio=%s",
        score_composto,
        teto_carteira,
        len(produtos),
        criterio_eliminatorio or "nenhum",
    )

    return {
        "status": "ok",
        "score_composto": score_composto,
        "detalhamento_score": detalhamento,
        "criterio_eliminatorio": criterio_eliminatorio,
        "teto_limite_global": teto_carteira,
        "produtos_elegiveis": produtos,
        "total_produtos_elegiveis": len(produtos),
        "nivel_risco": resultado_cliente.get("nivel_risco", "ALTO"),
        "dados_cliente": dados_cliente,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA 5 — DECISÃO CLARA
# ═══════════════════════════════════════════════════════════════════════════════

def etapa5_decidir(consolidado: dict) -> dict:
    """
    Etapa 5 — Emite a decisão binária (APROVADO / RECUSADO) e calcula limite.

    Combina o score composto do Agente Cliente com o teto de limite do
    Agente Carteira para determinar a decisão final e o limite efetivo.

    Parâmetros:
        consolidado (dict): Output consolidado da Etapa 4.

    Retorno:
        dict: {
            "decisao": "APROVADO" | "RECUSADO",
            "limite_sugerido": float,
            "moeda": "BRL"
        }
    """
    criterio = consolidado.get("criterio_eliminatorio")
    score = consolidado.get("score_composto", 0.0)
    renda = float(consolidado["dados_cliente"].get("renda_mensal", 0))
    teto = consolidado.get("teto_limite_global", 500_000.00)

    if criterio:
        decisao, limite = "RECUSADO", 0.00
    else:
        decisao, limite_modelo = calcular_decisao_e_limite(score, renda)
        # Aplicar teto do Agente Carteira
        limite = min(limite_modelo, teto)

    logger.info(
        "Etapa 5 — Decisão: %s | Limite: R$ %.2f | Score: %.2f",
        decisao, limite, score,
    )

    return {"decisao": decisao, "limite_sugerido": limite, "moeda": "BRL"}


# ═══════════════════════════════════════════════════════════════════════════════
#  ETAPA 6 — JUSTIFICATIVA AO CLIENTE
# ═══════════════════════════════════════════════════════════════════════════════

def etapa6_justificar(consolidado: dict, decisao_resultado: dict) -> str:
    """
    Etapa 6 — Gera a justificativa em linguagem acessível e empática ao cliente.

    Regra: nenhum jargão técnico (score, inadimplência, percentil, etc.)
    deve aparecer sem ser traduzido para linguagem simples.

    Parâmetros:
        consolidado (dict): Output consolidado da Etapa 4.
        decisao_resultado (dict): Output da Etapa 5 com decisão e limite.

    Retorno:
        str: Texto da justificativa pronto para exibição ao cliente e
             para envio regulatório.
    """
    dados_cliente = consolidado.get("dados_cliente", {})
    row = pd.Series({
        "nome": dados_cliente.get("nome", ""),
        "data_nascimento": str(dados_cliente.get("data_nascimento", "")),
        "data_abertura_conta": str(dados_cliente.get("data_abertura_conta", "")),
        "renda_mensal": float(dados_cliente.get("renda_mensal", 0)),
        "quantidade_produtos": int(dados_cliente.get("quantidade_produtos", 1)),
        "credit_score": int(dados_cliente.get("credit_score", 0)),
        "inadimplente": str(dados_cliente.get("inadimplente", "Não")),
        "tempo_inadimplencia_meses": dados_cliente.get("tempo_inadimplencia_meses", ""),
    })

    texto = gerar_justificativa(
        decisao=decisao_resultado["decisao"],
        score_composto=consolidado.get("score_composto", 0.0),
        limite_sugerido=decisao_resultado["limite_sugerido"],
        criterio_eliminatorio=consolidado.get("criterio_eliminatorio"),
        row=row,
        detalhamento=consolidado.get("detalhamento_score", {}),
    )

    logger.info("Etapa 6 — Justificativa gerada (%d chars).", len(texto))
    return texto


# ═══════════════════════════════════════════════════════════════════════════════
#  FUNÇÃO PRINCIPAL DO PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def executar_pipeline(dados_cliente: dict) -> dict:
    """
    Executa o pipeline completo de 7 etapas para um pedido de crédito.

    Esta função é o ponto de entrada registrado no IBM watsonx Orchestrate (Bob).
    O Bob chama esta função como ferramenta principal do fluxo de automação
    de crédito, orquestrando internamente os agentes Carteira e Cliente.

    Parâmetros:
        dados_cliente (dict): Dados do cliente. Campos obrigatórios:
            nome, data_nascimento, data_abertura_conta, renda_mensal,
            quantidade_produtos, credit_score, inadimplente.
            Opcionais: id_cliente, tempo_inadimplencia_meses, valor_solicitado.

    Retorno:
        dict: Resultado completo do pipeline:
            {
                "status": "ok" | "erro",
                "id_auditoria": str,
                "decisao": "APROVADO" | "RECUSADO",
                "limite_sugerido": float,
                "moeda": "BRL",
                "justificativa_cliente": str,
                "score_composto": float,
                "nivel_risco": str,
                "caminho_log_auditoria": str,
                "etapas_executadas": list[str]
            }

    Erros retornados:
        Se qualquer etapa crítica falhar, retorna {"status": "erro", "motivo": str}.
        Nenhuma decisão é emitida sem dados completos e validados.
    """
    etapas_executadas = []

    # ── Etapa 1: Validação ───────────────────────────────────────────────────
    logger.info("Pipeline iniciado para: %s", dados_cliente.get("nome", "?"))
    resultado_etapa1 = etapa1_validar_pedido(dados_cliente)
    etapas_executadas.append("1_validacao")

    if resultado_etapa1["status"] == "erro":
        return {
            "status": "erro",
            "motivo": f"Validação falhou: {resultado_etapa1['erros_validacao']}",
            "etapas_executadas": etapas_executadas,
        }

    pedido = resultado_etapa1["pedido_validado"]

    # ── Etapa 2: Agente Carteira ──────────────────────────────────────────────
    resultado_carteira = executar_agente_carteira(pedido)
    etapas_executadas.append("2_agente_carteira")

    # ── Etapa 3: Agente Cliente ───────────────────────────────────────────────
    resultado_cliente = executar_agente_cliente(pedido)
    etapas_executadas.append("3_agente_cliente")

    # ── Etapa 4: Orquestração (consolidação) ─────────────────────────────────
    consolidado = etapa4_consolidar(resultado_carteira, resultado_cliente, pedido)
    etapas_executadas.append("4_orquestracao")

    if consolidado.get("status") == "erro":
        return {
            "status": "erro",
            "motivo": consolidado.get("motivo"),
            "etapas_executadas": etapas_executadas,
        }

    # ── Etapa 5: Decisão ──────────────────────────────────────────────────────
    decisao_resultado = etapa5_decidir(consolidado)
    etapas_executadas.append("5_decisao")

    # ── Etapa 6: Justificativa ────────────────────────────────────────────────
    justificativa = etapa6_justificar(consolidado, decisao_resultado)
    etapas_executadas.append("6_justificativa")

    # ── Montar resultado completo do pipeline ─────────────────────────────────
    resultado_pipeline = {
        **decisao_resultado,
        "score_composto": consolidado["score_composto"],
        "detalhamento_score": consolidado["detalhamento_score"],
        "criterio_eliminatorio": consolidado.get("criterio_eliminatorio"),
        "teto_limite_global": consolidado.get("teto_limite_global"),
        "total_produtos_elegiveis": consolidado.get("total_produtos_elegiveis", 0),
        "justificativa_cliente": justificativa,
    }

    # ── Etapa 7: Registro auditável ───────────────────────────────────────────
    caminho_log = registrar_decisao(
        dados_entrada=pedido,
        resultado_agente_carteira=resultado_carteira,
        resultado_agente_cliente=resultado_cliente,
        resultado_pipeline=resultado_pipeline,
    )
    etapas_executadas.append("7_registro_auditavel")

    id_auditoria = f"AUD-{pedido.get('id_cliente', 'sem_id')}"
    logger.info(
        "Pipeline concluído: %s | %s | R$ %.2f | log=%s",
        pedido.get("nome", "?"),
        decisao_resultado["decisao"],
        decisao_resultado["limite_sugerido"],
        caminho_log,
    )

    return {
        "status": "ok",
        "id_auditoria": id_auditoria,
        "decisao": decisao_resultado["decisao"],
        "limite_sugerido": decisao_resultado["limite_sugerido"],
        "moeda": "BRL",
        "justificativa_cliente": justificativa,
        "score_composto": consolidado["score_composto"],
        "nivel_risco": consolidado.get("nivel_risco", "N/A"),
        "caminho_log_auditoria": caminho_log,
        "etapas_executadas": etapas_executadas,
    }


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    print("\n" + "=" * 65)
    print("   AURORA BANK - PIPELINE DE CREDITO MULTI-AGENTE (7 ETAPAS)")
    print("=" * 65)

    pedidos_teste = [
        {
            "id_cliente": 101,
            "nome": "Beatriz Ferreira",
            "data_nascimento": "22/04/1990",
            "data_abertura_conta": "15/08/2012",
            "renda_mensal": 7_500.00,
            "quantidade_produtos": 5,
            "credit_score": 680,
            "inadimplente": "Não",
        },
        {
            "id_cliente": 102,
            "nome": "Carlos Rodrigues",
            "data_nascimento": "10/10/1975",
            "data_abertura_conta": "01/01/1995",
            "renda_mensal": 25_000.00,
            "quantidade_produtos": 12,
            "credit_score": 890,
            "inadimplente": "Não",
        },
        {
            "id_cliente": 103,
            "nome": "Lucas Lima",
            "data_nascimento": "05/05/1998",
            "data_abertura_conta": "10/10/2018",
            "renda_mensal": 3_200.00,
            "quantidade_produtos": 2,
            "credit_score": 280,   # Eliminatório
            "inadimplente": "Não",
        },
        {
            "id_cliente": 104,
            "nome": "Patrícia Gonçalves",
            "data_nascimento": "18/09/1983",
            "data_abertura_conta": "20/07/2003",
            "renda_mensal": 11_000.00,
            "quantidade_produtos": 8,
            "credit_score": 750,
            "inadimplente": "Sim",
            "tempo_inadimplencia_meses": 4,   # Penalização, mas não eliminatório
        },
    ]

    for pedido in pedidos_teste:
        print(f"\n{'-'*65}")
        print(f"  Cliente: {pedido['nome']}")
        resultado = executar_pipeline(pedido)
        print(f"  Status     : {resultado.get('status')}")
        if resultado.get("status") == "ok":
            print(f"  Decisão    : {resultado.get('decisao')}")
            print(f"  Limite     : R$ {resultado.get('limite_sugerido'):,.2f}")
            print(f"  Score      : {resultado.get('score_composto'):.2f}")
            print(f"  Risco      : {resultado.get('nivel_risco')}")
            print(f"  Etapas     : {' > '.join(resultado.get('etapas_executadas', []))}")
            print(f"  Log        : {resultado.get('caminho_log_auditoria')}")
            print(f"\n  Justificativa ao cliente:")
            print(f"  \"{resultado.get('justificativa_cliente')}\"")
        else:
            print(f"  Motivo erro: {resultado.get('motivo')}")

    print("\n" + "=" * 65)
    print("   Pipeline concluido com sucesso.")
    print("=" * 65 + "\n")
