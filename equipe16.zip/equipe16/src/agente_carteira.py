"""
agente_carteira.py
==================
Agente Carteira (Wallet Agent) — Etapa 2 do pipeline multi-agente Aurora Bank.

Responsabilidade:
    Consultar os produtos do banco disponíveis e os limites máximos vigentes
    por faixa de renda, retornando a lista de produtos elegíveis e o teto de
    limite disponível para o perfil do cliente.

Integração com IBM watsonx Orchestrate (Bob):
    Este módulo é importado pelo orchestrate_pipeline.py e expõe a função
    principal como ferramenta registrável no Orchestrate.

Entrada : renda_mensal (float) do cliente
Saída   : dict com lista de produtos elegíveis e teto de limite disponível
"""

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ── Catálogo de produtos do Aurora Bank ──────────────────────────────────────
# Cada produto define: nome, renda mínima exigida, teto máximo de limite
# e se aceita o score composto mínimo para elegibilidade.

CATALOGO_PRODUTOS = [
    {
        "codigo": "CARTAO_BASICO",
        "nome": "Cartão de Crédito Básico Aurora",
        "renda_minima": 2_000.00,
        "teto_limite": 5_000.00,
        "score_minimo": 30,
        "descricao": "Cartão sem anuidade para clientes com perfil inicial de crédito.",
    },
    {
        "codigo": "CARTAO_CLASSICO",
        "nome": "Cartão de Crédito Clássico Aurora",
        "renda_minima": 3_000.00,
        "teto_limite": 15_000.00,
        "score_minimo": 45,
        "descricao": "Cartão com benefícios de seguro de viagem e programa de pontos.",
    },
    {
        "codigo": "CARTAO_GOLD",
        "nome": "Cartão de Crédito Gold Aurora",
        "renda_minima": 5_000.00,
        "teto_limite": 30_000.00,
        "score_minimo": 60,
        "descricao": "Cartão com sala VIP em aeroportos e cashback em compras.",
    },
    {
        "codigo": "CARTAO_PLATINUM",
        "nome": "Cartão de Crédito Platinum Aurora",
        "renda_minima": 10_000.00,
        "teto_limite": 80_000.00,
        "score_minimo": 72,
        "descricao": "Cartão premium com concierge 24h e milhas aéreas duplas.",
    },
    {
        "codigo": "CARTAO_BLACK",
        "nome": "Cartão de Crédito Black Aurora",
        "renda_minima": 20_000.00,
        "teto_limite": 500_000.00,
        "score_minimo": 85,
        "descricao": "Cartão exclusivo com benefícios ilimitados e gerente dedicado.",
    },
]

# ── Tabela de teto de limite por faixa de renda ───────────────────────────────
# (faixa_min, faixa_max, teto_limite_global)
FAIXAS_TETO = [
    (2_000.00,   4_999.99,   5_000.00),
    (5_000.00,   9_999.99,  15_000.00),
    (10_000.00,  19_999.99,  40_000.00),
    (20_000.00,  49_999.99, 100_000.00),
    (50_000.00, 250_000.00, 500_000.00),
]


def obter_teto_por_renda(renda_mensal: float) -> float:
    """
    Retorna o teto máximo de limite global para a faixa de renda do cliente.

    Parâmetros:
        renda_mensal (float): Renda mensal do cliente em R$.

    Retorno:
        float: Teto máximo de limite disponível para a faixa de renda.
    """
    for faixa_min, faixa_max, teto in FAIXAS_TETO:
        if faixa_min <= renda_mensal <= faixa_max:
            return teto
    if renda_mensal > 250_000.00:
        return 500_000.00
    return 0.0  # abaixo do mínimo permitido


def listar_produtos_elegiveis(renda_mensal: float, score_composto: float = 0.0) -> list[dict]:
    """
    Retorna a lista de produtos bancários para os quais o cliente é elegível.

    Um produto é elegível quando:
        - renda_mensal >= renda_minima do produto
        - score_composto >= score_minimo do produto (se fornecido)

    Parâmetros:
        renda_mensal (float): Renda mensal do cliente em R$.
        score_composto (float): Score composto calculado (0–100). Padrão 0.0
                                 (só filtra por renda).

    Retorno:
        list[dict]: Lista de produtos elegíveis com código, nome, teto e descrição.
    """
    elegiveis = []
    for produto in CATALOGO_PRODUTOS:
        atende_renda = renda_mensal >= produto["renda_minima"]
        atende_score = score_composto >= produto["score_minimo"] if score_composto > 0 else True
        if atende_renda and atende_score:
            elegiveis.append({
                "codigo": produto["codigo"],
                "nome": produto["nome"],
                "teto_limite": produto["teto_limite"],
                "descricao": produto["descricao"],
            })
    return elegiveis


def executar_agente_carteira(dados_cliente: dict) -> dict:
    """
    Ponto de entrada principal do Agente Carteira.

    Consulta produtos disponíveis e teto de limite para o perfil de renda do cliente.
    Este método é registrado como ferramenta no IBM watsonx Orchestrate.

    Parâmetros:
        dados_cliente (dict): Deve conter ao menos 'renda_mensal' (float).
                              Opcionalmente 'score_composto' (float) para filtragem
                              mais precisa dos produtos elegíveis.

    Retorno:
        dict: {
            "status": "ok" | "erro",
            "renda_mensal": float,
            "teto_limite_global": float,
            "produtos_elegiveis": list[dict],
            "total_produtos": int,
            "mensagem": str  (presente apenas em caso de erro)
        }

    Erros tratados:
        - renda_mensal ausente ou inválida
        - renda abaixo do mínimo operacional (< R$ 2.000)
    """
    # Validação da entrada
    if "renda_mensal" not in dados_cliente:
        logger.error("Agente Carteira: campo 'renda_mensal' ausente.")
        return {
            "status": "erro",
            "mensagem": "Campo obrigatório 'renda_mensal' não foi fornecido.",
        }

    try:
        renda = float(dados_cliente["renda_mensal"])
    except (ValueError, TypeError):
        logger.error("Agente Carteira: 'renda_mensal' inválida: %s", dados_cliente["renda_mensal"])
        return {
            "status": "erro",
            "mensagem": f"Valor inválido para 'renda_mensal': {dados_cliente['renda_mensal']}",
        }

    if renda < 2_000.00:
        logger.warning("Agente Carteira: renda abaixo do mínimo (R$ %.2f).", renda)
        return {
            "status": "ok",
            "renda_mensal": renda,
            "teto_limite_global": 0.0,
            "produtos_elegiveis": [],
            "total_produtos": 0,
            "observacao": "Renda abaixo do mínimo operacional. Nenhum produto disponível.",
        }

    score = float(dados_cliente.get("score_composto", 0.0))
    teto = obter_teto_por_renda(renda)
    produtos = listar_produtos_elegiveis(renda, score)

    logger.info(
        "Agente Carteira: renda=R$ %.2f | teto=R$ %.2f | produtos=%d",
        renda, teto, len(produtos),
    )

    return {
        "status": "ok",
        "renda_mensal": renda,
        "teto_limite_global": teto,
        "produtos_elegiveis": produtos,
        "total_produtos": len(produtos),
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    # Exemplos de teste
    casos = [
        {"renda_mensal": 3_500.00, "score_composto": 55.0},
        {"renda_mensal": 12_000.00, "score_composto": 75.0},
        {"renda_mensal": 1_500.00},
        {"renda_mensal": 45_000.00, "score_composto": 88.0},
    ]

    for i, caso in enumerate(casos, 1):
        print(f"\n{'─'*50}")
        print(f"Caso {i}: renda=R$ {caso.get('renda_mensal', '?'):,.2f}")
        resultado = executar_agente_carteira(caso)
        print(f"  Status         : {resultado.get('status')}")
        print(f"  Teto global    : R$ {resultado.get('teto_limite_global', 0):,.2f}")
        print(f"  Produtos       : {resultado.get('total_produtos', 0)}")
        for p in resultado.get("produtos_elegiveis", []):
            print(f"    → {p['nome']} (teto: R$ {p['teto_limite']:,.2f})")
