"""
api_tools.py
============
Servidor HTTP que expõe as ferramentas do Aurora Bank Credit XAI como
endpoints REST, prontos para importação no IBM watsonx Orchestrate via
especificação OpenAPI.

Ferramentas expostas:
    POST /agente-carteira      → executar_agente_carteira()
    POST /agente-cliente       → executar_agente_cliente()
    POST /pipeline-credito     → executar_pipeline()

Uso:
    python src/api_tools.py

O servidor sobe em http://localhost:8080 por padrão.
Para produção, utilize um servidor WSGI como gunicorn ou uwsgi,
ou faça deploy em IBM Cloud Code Engine / Cloud Foundry.
"""

import json
import logging
import os
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

# Garantir que src/ está no path para imports
sys.path.insert(0, os.path.dirname(__file__))

from agente_carteira import executar_agente_carteira
from agente_cliente import executar_agente_cliente
from orchestrate_pipeline import executar_pipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", 8080))


# ── Roteamento ────────────────────────────────────────────────────────────────

ROTAS = {
    "/agente-carteira": executar_agente_carteira,
    "/agente-cliente": executar_agente_cliente,
    "/pipeline-credito": executar_pipeline,
    "/health": None,  # rota especial de health check
}


class AuroraBankHandler(BaseHTTPRequestHandler):
    """Handler HTTP para as ferramentas do Aurora Bank Credit XAI."""

    def log_message(self, format, *args):  # noqa: A002
        """Suprime log padrão do BaseHTTPRequestHandler; usa logger próprio."""
        logger.info("%s - %s", self.address_string(), format % args)

    def _enviar_json(self, status: int, dados: dict) -> None:
        corpo = json.dumps(dados, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(corpo)

    def _ler_body_json(self) -> dict | None:
        tamanho = int(self.headers.get("Content-Length", 0))
        if tamanho == 0:
            return {}
        try:
            return json.loads(self.rfile.read(tamanho).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.error("Erro ao decodificar body JSON: %s", e)
            return None

    def do_GET(self):  # noqa: N802
        """Health check e spec OpenAPI simplificada."""
        if self.path == "/health":
            self._enviar_json(200, {"status": "ok", "servico": "aurora-bank-credit-tools"})
        elif self.path == "/openapi.json":
            self._servir_openapi()
        else:
            self._enviar_json(404, {"erro": f"Rota GET '{self.path}' não encontrada."})

    def do_POST(self):  # noqa: N802
        """Despacha chamadas às ferramentas registradas."""
        if self.path not in ROTAS or ROTAS[self.path] is None:
            self._enviar_json(404, {"erro": f"Rota POST '{self.path}' não encontrada."})
            return

        dados = self._ler_body_json()
        if dados is None:
            self._enviar_json(400, {"erro": "Body da requisição inválido ou não é JSON."})
            return

        funcao = ROTAS[self.path]
        logger.info("Chamando ferramenta: %s | payload: %s", self.path, dados)

        try:
            resultado = funcao(dados)
            self._enviar_json(200, resultado)
        except Exception as e:  # noqa: BLE001
            logger.exception("Erro interno ao executar ferramenta '%s': %s", self.path, e)
            self._enviar_json(500, {"erro": f"Erro interno: {str(e)}"})

    def do_OPTIONS(self):  # noqa: N802
        """Suporte a CORS preflight."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def _servir_openapi(self) -> None:
        """Retorna a especificação OpenAPI 3.0 das ferramentas."""
        spec = gerar_openapi_spec()
        self._enviar_json(200, spec)


def gerar_openapi_spec() -> dict:
    """
    Gera a especificação OpenAPI 3.0 das ferramentas do Aurora Bank.

    Esta especificação é usada para importar as ferramentas no IBM watsonx
    Orchestrate via 'Import Tool > OpenAPI'.

    Retorno:
        dict: Especificação OpenAPI 3.0 completa.
    """
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "Aurora Bank — Ferramentas de Concessão de Crédito",
            "description": (
                "API REST das ferramentas do sistema de concessão de crédito "
                "explicável do Aurora Bank, orquestradas pelo IBM watsonx Orchestrate."
            ),
            "version": "1.0.0",
        },
        "servers": [
            {"url": f"http://localhost:{PORT}", "description": "Servidor local de desenvolvimento"}
        ],
        "paths": {
            "/agente-carteira": {
                "post": {
                    "operationId": "executar_agente_carteira",
                    "summary": "Agente Carteira",
                    "description": (
                        "Consulta os produtos bancários disponíveis e o teto de limite "
                        "vigente para o perfil de renda do cliente."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["renda_mensal"],
                                    "properties": {
                                        "renda_mensal": {
                                            "type": "number",
                                            "description": "Renda mensal do cliente em R$.",
                                            "example": 8500.0,
                                        },
                                        "score_composto": {
                                            "type": "number",
                                            "description": "Score composto calculado (0–100). Opcional.",
                                            "example": 65.0,
                                        },
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Lista de produtos elegíveis e teto de limite.",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "status": {"type": "string"},
                                            "renda_mensal": {"type": "number"},
                                            "teto_limite_global": {"type": "number"},
                                            "produtos_elegiveis": {
                                                "type": "array",
                                                "items": {"type": "object"},
                                            },
                                            "total_produtos": {"type": "integer"},
                                        },
                                    }
                                }
                            },
                        }
                    },
                }
            },
            "/agente-cliente": {
                "post": {
                    "operationId": "executar_agente_cliente",
                    "summary": "Agente Cliente",
                    "description": (
                        "Analisa o perfil financeiro e de relacionamento do cliente, "
                        "calculando o score composto e verificando critérios eliminatórios."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": [
                                        "nome",
                                        "data_nascimento",
                                        "data_abertura_conta",
                                        "renda_mensal",
                                        "quantidade_produtos",
                                        "credit_score",
                                        "inadimplente",
                                    ],
                                    "properties": {
                                        "nome": {"type": "string", "example": "Maria Silva"},
                                        "data_nascimento": {
                                            "type": "string",
                                            "description": "Formato DD/MM/AAAA",
                                            "example": "15/03/1985",
                                        },
                                        "data_abertura_conta": {
                                            "type": "string",
                                            "description": "Formato DD/MM/AAAA",
                                            "example": "10/06/2005",
                                        },
                                        "renda_mensal": {"type": "number", "example": 8500.0},
                                        "quantidade_produtos": {"type": "integer", "example": 7},
                                        "credit_score": {"type": "integer", "example": 720},
                                        "inadimplente": {
                                            "type": "string",
                                            "enum": ["Sim", "Não"],
                                            "example": "Não",
                                        },
                                        "tempo_inadimplencia_meses": {
                                            "type": "integer",
                                            "description": "Obrigatório se inadimplente = Sim.",
                                            "example": 3,
                                        },
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Score composto e análise do perfil do cliente.",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "status": {"type": "string"},
                                            "nome": {"type": "string"},
                                            "idade": {"type": "integer"},
                                            "anos_relacionamento": {"type": "number"},
                                            "score_composto": {"type": "number"},
                                            "detalhamento_score": {"type": "object"},
                                            "criterio_eliminatorio": {"type": "string"},
                                            "nivel_risco": {"type": "string"},
                                        },
                                    }
                                }
                            },
                        }
                    },
                }
            },
            "/pipeline-credito": {
                "post": {
                    "operationId": "executar_pipeline",
                    "summary": "Pipeline de Crédito (7 etapas)",
                    "description": (
                        "Executa o pipeline completo de concessão de crédito em 7 etapas, "
                        "retornando decisão, limite sugerido, justificativa ao cliente e "
                        "caminho do log de auditoria."
                    ),
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": [
                                        "nome",
                                        "data_nascimento",
                                        "data_abertura_conta",
                                        "renda_mensal",
                                        "quantidade_produtos",
                                        "credit_score",
                                        "inadimplente",
                                    ],
                                    "properties": {
                                        "id_cliente": {"type": "integer", "example": 1001},
                                        "nome": {"type": "string", "example": "Fernanda Costa"},
                                        "data_nascimento": {
                                            "type": "string",
                                            "example": "12/08/1987",
                                        },
                                        "data_abertura_conta": {
                                            "type": "string",
                                            "example": "03/03/2010",
                                        },
                                        "renda_mensal": {"type": "number", "example": 9000.0},
                                        "quantidade_produtos": {"type": "integer", "example": 6},
                                        "credit_score": {"type": "integer", "example": 680},
                                        "inadimplente": {
                                            "type": "string",
                                            "enum": ["Sim", "Não"],
                                            "example": "Não",
                                        },
                                        "tempo_inadimplencia_meses": {
                                            "type": "integer",
                                            "example": 0,
                                        },
                                        "valor_solicitado": {
                                            "type": "number",
                                            "description": "Valor solicitado pelo cliente (opcional).",
                                            "example": 15000.0,
                                        },
                                    },
                                }
                            }
                        },
                    },
                    "responses": {
                        "200": {
                            "description": "Resultado completo do pipeline de crédito.",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "status": {"type": "string"},
                                            "id_auditoria": {"type": "string"},
                                            "decisao": {
                                                "type": "string",
                                                "enum": ["APROVADO", "RECUSADO"],
                                            },
                                            "limite_sugerido": {"type": "number"},
                                            "moeda": {"type": "string"},
                                            "justificativa_cliente": {"type": "string"},
                                            "score_composto": {"type": "number"},
                                            "nivel_risco": {"type": "string"},
                                            "caminho_log_auditoria": {"type": "string"},
                                            "etapas_executadas": {
                                                "type": "array",
                                                "items": {"type": "string"},
                                            },
                                        },
                                    }
                                }
                            },
                        }
                    },
                }
            },
            "/health": {
                "get": {
                    "operationId": "health_check",
                    "summary": "Health Check",
                    "description": "Verifica se o servidor está em operação.",
                    "responses": {
                        "200": {
                            "description": "Servidor em operação.",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "status": {"type": "string"},
                                            "servico": {"type": "string"},
                                        },
                                    }
                                }
                            },
                        }
                    },
                }
            },
        },
    }


def salvar_openapi_spec(caminho: str = None) -> str:
    """
    Salva a especificação OpenAPI em disco para importação no Orchestrate.

    Parâmetros:
        caminho (str): Caminho de destino. Padrão: src/openapi_aurora_bank.json

    Retorno:
        str: Caminho do arquivo salvo.
    """
    if caminho is None:
        caminho = os.path.join(os.path.dirname(__file__), "openapi_aurora_bank.json")

    spec = gerar_openapi_spec()
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)

    logger.info("Especificacao OpenAPI salva em: %s", caminho)
    return caminho


if __name__ == "__main__":
    # Salvar spec OpenAPI para importação no Orchestrate
    caminho_spec = salvar_openapi_spec()
    print(f"\nEspecificacao OpenAPI salva em: {caminho_spec}")
    print("Use este arquivo para importar as tools no IBM watsonx Orchestrate.")

    # Subir servidor HTTP
    servidor = HTTPServer((HOST, PORT), AuroraBankHandler)
    print(f"\nServidor iniciado em http://{HOST}:{PORT}")
    print("Endpoints disponíveis:")
    print(f"  GET  http://localhost:{PORT}/health")
    print(f"  GET  http://localhost:{PORT}/openapi.json")
    print(f"  POST http://localhost:{PORT}/agente-carteira")
    print(f"  POST http://localhost:{PORT}/agente-cliente")
    print(f"  POST http://localhost:{PORT}/pipeline-credito")
    print("\nPressione Ctrl+C para encerrar.\n")

    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
        servidor.server_close()
