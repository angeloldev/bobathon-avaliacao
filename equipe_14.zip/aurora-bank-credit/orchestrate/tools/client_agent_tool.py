"""
Ferramenta: Agente Cliente — Aurora Bank Credit Decision System
===============================================================
Ferramenta Python para o IBM watsonx Orchestrate.
Analisa o perfil histórico, comportamento de pagamentos e indicadores
de risco do cliente a partir da base de conhecimento (clientes.csv).

CRÍTICO: este arquivo é autocontido — todas as definições de tipos,
funções auxiliares e constantes estão neste único arquivo, conforme
exigência da plataforma watsonx Orchestrate para portabilidade de ferramentas.
"""

import csv
import hashlib
import os
from typing import Optional
from pydantic import BaseModel, Field
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission

# ---------------------------------------------------------------------------
# Caminho da base de conhecimento (relativo ao diretório do projeto)
# ---------------------------------------------------------------------------
_CAMINHO_CLIENTES = os.path.join(
    os.path.dirname(__file__), "..", "..", "src", "knowledge_base", "clientes.csv"
)

# ---------------------------------------------------------------------------
# Limiares de classificação de pagamento
# ---------------------------------------------------------------------------
_LIMIAR_EXCELENTE = 0.95
_LIMIAR_BOM = 0.80
_LIMIAR_REGULAR = 0.60

# ---------------------------------------------------------------------------
# Schemas Pydantic de entrada e saída
# ---------------------------------------------------------------------------

class EntradaAnaliseCliente(BaseModel):
    """Dados de entrada para análise do perfil do cliente."""
    cpf_hash: str = Field(
        description="Hash SHA-256 do CPF do cliente para consulta na base de conhecimento"
    )
    renda_declarada: float = Field(
        description="Renda mensal bruta declarada pelo cliente em R$"
    )


class SaidaAnaliseCliente(BaseModel):
    """Resultado da análise do perfil do cliente pelo Agente Cliente."""
    score_risco: int = Field(
        description="Score interno de risco do cliente (0 a 1000)"
    )
    classificacao_risco: str = Field(
        description="Classificação do risco: MUITO_BAIXO, BAIXO, MEDIO, ALTO ou MUITO_ALTO"
    )
    capacidade_pagamento_estimada: float = Field(
        description="Capacidade de pagamento estimada em R$ (base para o limite)"
    )
    historico_comportamental_resumido: str = Field(
        description="Resumo do comportamento financeiro do cliente (sem dados sigilosos)"
    )
    flags_alerta: str = Field(
        description="Flags de alerta identificadas, separadas por vírgula"
    )
    segmento_cliente: str = Field(
        description="Segmento do cliente: BASICO, INTERMEDIARIO, PREMIUM ou EXCLUSIVO"
    )
    tempo_relacionamento_meses: int = Field(
        description="Tempo de relacionamento do cliente com o banco em meses"
    )
    qtd_produtos_banco: int = Field(
        description="Quantidade de produtos ativos do cliente no banco"
    )
    id_cliente: str = Field(
        description="Identificador do cliente na base de conhecimento"
    )
    classificacao_historico_pagamento: str = Field(
        description="Classificação do histórico: EXCELENTE, BOM, REGULAR ou RUIM"
    )
    flag_inadimplente: bool = Field(
        description="Indica se o cliente possui inadimplência ativa com o banco"
    )
    flag_negativado: bool = Field(
        description="Indica se o cliente possui restrição cadastral ativa (negativado)"
    )
    cliente_encontrado: bool = Field(
        description="Indica se o cliente foi localizado na base de conhecimento"
    )
    mensagem_erro: Optional[str] = Field(
        default=None,
        description="Mensagem de erro caso o cliente não seja encontrado"
    )


# ---------------------------------------------------------------------------
# Funções auxiliares (autocontidas neste arquivo)
# ---------------------------------------------------------------------------

def _classificar_risco(score: int) -> str:
    """Classifica o risco com base no score interno."""
    if score < 200:
        return "MUITO_ALTO"
    elif score < 400:
        return "ALTO"
    elif score < 600:
        return "MEDIO"
    elif score < 800:
        return "BAIXO"
    return "MUITO_BAIXO"


def _classificar_historico(percentual_str: str) -> str:
    """Classifica o histórico de pagamentos."""
    try:
        valor = float(percentual_str)
        if valor > 1:
            valor = valor / 100
    except (ValueError, TypeError):
        return "INDISPONÍVEL"
    if valor >= _LIMIAR_EXCELENTE:
        return "EXCELENTE"
    elif valor >= _LIMIAR_BOM:
        return "BOM"
    elif valor >= _LIMIAR_REGULAR:
        return "REGULAR"
    return "RUIM"


def _construir_flags(cliente: dict) -> list:
    """Constrói a lista de flags de alerta."""
    flags = []
    if str(cliente.get("flag_inadimplente", "FALSE")).upper() in ("TRUE", "1", "SIM"):
        flags.append("CLIENTE_INADIMPLENTE")
    if str(cliente.get("flag_negativado", "FALSE")).upper() in ("TRUE", "1", "SIM"):
        flags.append("CLIENTE_NEGATIVADO")
    if int(cliente.get("qtd_dividas_ativas", 0)) >= 3:
        flags.append("MULTIPLAS_DIVIDAS_ATIVAS")
    historico = float(cliente.get("historico_pagamento_ultimos_12m", 1))
    if historico > 1:
        historico /= 100
    if historico < _LIMIAR_REGULAR:
        flags.append("HISTORICO_PAGAMENTO_INADEQUADO")
    if int(cliente.get("score_externo_serasa", 999)) < 300:
        flags.append("SCORE_EXTERNO_CRITICO")
    return flags


def _buscar_cliente(cpf_hash: str) -> Optional[dict]:
    """Busca o cliente na base de conhecimento pelo hash do CPF."""
    try:
        with open(_CAMINHO_CLIENTES, newline="", encoding="utf-8") as arq:
            for linha in csv.DictReader(arq):
                if linha.get("cpf_hash", "").strip() == cpf_hash.strip():
                    return linha
    except FileNotFoundError:
        pass
    return None


# ---------------------------------------------------------------------------
# Definição da ferramenta para o Orchestrate
# ---------------------------------------------------------------------------

@tool(permission=ToolPermission.READ_ONLY)
def analisar_perfil_cliente(entrada: EntradaAnaliseCliente) -> SaidaAnaliseCliente:
    """
    Analisa o perfil do cliente para a decisão de crédito de cartão.

    Consulta a base de conhecimento de clientes (clientes.csv) e retorna
    indicadores de risco, capacidade de pagamento e histórico comportamental.
    Nenhuma inferência é feita fora do escopo da base de conhecimento.

    Args:
        entrada (EntradaAnaliseCliente): Hash do CPF e renda declarada do cliente.

    Returns:
        SaidaAnaliseCliente: Análise completa do perfil do cliente.
    """
    cliente = _buscar_cliente(entrada.cpf_hash)

    if cliente is None:
        return SaidaAnaliseCliente(
            score_risco=0,
            classificacao_risco="INDISPONÍVEL",
            capacidade_pagamento_estimada=0.0,
            historico_comportamental_resumido="Cliente não localizado na base de conhecimento.",
            flags_alerta="CLIENTE_NAO_ENCONTRADO",
            segmento_cliente="INDISPONÍVEL",
            tempo_relacionamento_meses=0,
            qtd_produtos_banco=0,
            id_cliente="N/A",
            classificacao_historico_pagamento="INDISPONÍVEL",
            flag_inadimplente=False,
            flag_negativado=False,
            cliente_encontrado=False,
            mensagem_erro=(
                "Cliente não localizado na base de conhecimento. "
                "Não é possível realizar análise de crédito sem dados cadastrais verificados."
            ),
        )

    score = int(cliente.get("score_interno", 0))
    classificacao = _classificar_risco(score)
    hist_pct = cliente.get("historico_pagamento_ultimos_12m", "0")
    class_hist = _classificar_historico(hist_pct)
    flags = _construir_flags(cliente)

    renda_estimada = float(cliente.get("renda_mensal_estimada", entrada.renda_declarada))
    renda_base = min(entrada.renda_declarada, renda_estimada)
    fator = {
        "MUITO_BAIXO": 0.40, "BAIXO": 0.35, "MEDIO": 0.28,
        "ALTO": 0.20, "MUITO_ALTO": 0.10,
    }.get(classificacao, 0.20)
    capacidade = round(renda_base * fator * 12, 2)

    resumo = (
        f"Histórico de pagamentos: '{class_hist}' (últimos 12 meses). "
        f"Perfil de risco: '{classificacao}'. "
        f"Relacionamento com o banco: {cliente.get('tempo_relacionamento_banco_meses', 0)} meses. "
        f"Produtos ativos no banco: {cliente.get('qtd_produtos_banco', 0)}."
    )

    return SaidaAnaliseCliente(
        score_risco=score,
        classificacao_risco=classificacao,
        capacidade_pagamento_estimada=capacidade,
        historico_comportamental_resumido=resumo,
        flags_alerta=", ".join(flags) if flags else "NENHUM",
        segmento_cliente=cliente.get("segmento_cliente", "PADRÃO"),
        tempo_relacionamento_meses=int(cliente.get("tempo_relacionamento_banco_meses", 0)),
        qtd_produtos_banco=int(cliente.get("qtd_produtos_banco", 0)),
        id_cliente=cliente.get("id_cliente", "N/A"),
        classificacao_historico_pagamento=class_hist,
        flag_inadimplente=str(cliente.get("flag_inadimplente", "FALSE")).upper() in ("TRUE", "1", "SIM"),
        flag_negativado=str(cliente.get("flag_negativado", "FALSE")).upper() in ("TRUE", "1", "SIM"),
        cliente_encontrado=True,
    )
