"""
Flow: Decisão de Crédito — Aurora Bank Credit Decision System
=============================================================
Flow principal do IBM watsonx Orchestrate que orquestra a execução
sequencial do Agente Cliente → Agente Carteira → Decisão Final.

Estrutura do flow:
  START
    ↓
  [analisar_perfil_cliente]  — Agente Cliente
    ↓
  [recomendar_produto_cartao] — Agente Carteira
    ↓
  [gerar_decisao_credito]    — Motor de Decisão (nó LLM prompt)
    ↓
  END
"""

from pydantic import BaseModel, Field
from ibm_watsonx_orchestrate.flow_builder.flows import Flow, flow, START, END
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission

# Importações das ferramentas deste projeto (mesmos arquivos)
from .client_agent_tool import analisar_perfil_cliente, EntradaAnaliseCliente
from .wallet_agent_tool import recomendar_produto_cartao, EntradaMatchingProduto


# ---------------------------------------------------------------------------
# Schema de entrada do flow
# ---------------------------------------------------------------------------

class EntradaDecisaoCredito(BaseModel):
    """Dados de entrada para o flow de decisão de crédito de cartão."""
    cpf_hash: str = Field(
        description="Hash SHA-256 do CPF do cliente (LGPD — não armazene o CPF bruto)"
    )
    renda_declarada: float = Field(
        description="Renda mensal bruta declarada pelo cliente em R$"
    )
    tipo_produto_desejado: str = Field(
        description="Tipo de cartão desejado: BASICO, INTERMEDIARIO, PREMIUM ou EXCLUSIVO"
    )
    nome_anonimizado: str = Field(
        default="N/A",
        description="Nome do cliente anonimizado para registro de auditoria"
    )


# ---------------------------------------------------------------------------
# Definição do flow principal de orquestração
# ---------------------------------------------------------------------------

@flow(
    name="decisao_credito_cartao",
    display_name="Decisão de Crédito — Cartão Aurora Bank",
    description=(
        "Flow principal que orquestra a análise completa para decisão de crédito "
        "de cartão de crédito. Executa o Agente Cliente (análise de risco e perfil) "
        "seguido pelo Agente Carteira (matching de produto), consolidando os resultados "
        "em uma decisão explicável e auditável conforme normas do BACEN."
    ),
    input_schema=EntradaDecisaoCredito,
)
def build_decisao_credito_cartao(aflow: Flow) -> Flow:
    """
    Flow de orquestração da decisão de crédito de cartão Aurora Bank.

    Garante que ambos os agentes (Cliente e Carteira) executem antes
    de qualquer decisão ser tomada. Nenhuma decisão com apenas um agente.

    CRITICAL: Flow function signature MUST be:
    def build_<flow_name>(aflow: Flow) -> Flow:
    """
    # Nó 1 — Agente Cliente: análise de risco e perfil
    no_agente_cliente = aflow.tool(analisar_perfil_cliente)

    # Nó 2 — Agente Carteira: matching de produto
    no_agente_carteira = aflow.tool(recomendar_produto_cartao)

    # Nó 3 — Decisão Final via LLM prompt (consolidação e explicação)
    no_decisao_final = aflow.prompt(
        name="consolidar_decisao_credito",
        system_prompt=[
            "Você é o motor de decisão de crédito do Aurora Bank, responsável por "
            "consolidar os outputs do Agente Cliente e do Agente Carteira em uma "
            "decisão final de crédito para cartão de crédito.\n\n"
            "REGRAS OBRIGATÓRIAS:\n"
            "1. A decisão deve ser APENAS 'APROVADO' ou 'REPROVADO'\n"
            "2. REPROVADO obrigatório se: cliente_encontrado=false, flag_negativado=true, "
            "   flag_inadimplente=true, classificacao_risco=MUITO_ALTO, "
            "   historico=RUIM, ou produto_encontrado=false\n"
            "3. A justificativa ao cliente NÃO pode conter: CPF, valores exatos de renda, "
            "   score numérico, taxas de juros, políticas internas ou dados sigilosos\n"
            "4. Quando APROVADO, calcule o limite como: min(capacidade_pagamento_estimada * 0.35, "
            "   limite_maximo_produto, renda_declarada * 12 * 0.30), arredondado para R$50\n"
            "5. Gere um protocolo único no formato: AUR-{DATA}-{UUID12}\n"
            "6. A justificativa deve ser em linguagem simples, acessível e humanizada\n\n"
            "GUARDRAILS:\n"
            "- Se cliente_encontrado=false: REPROVADO por insuficiência de dados cadastrais\n"
            "- Se produto_encontrado=false: REPROVADO pois nenhum produto se adequa ao perfil\n"
            "- Nunca exponha dados da base de conhecimento diretamente ao cliente"
        ],
        user_prompt=[
            "Com base nos seguintes dados de análise, tome a decisão de crédito:\n\n"
            "=== ANÁLISE DO AGENTE CLIENTE ===\n"
            "Score de Risco: {analisar_perfil_cliente.score_risco}\n"
            "Classificação: {analisar_perfil_cliente.classificacao_risco}\n"
            "Capacidade de Pagamento: R$ {analisar_perfil_cliente.capacidade_pagamento_estimada}\n"
            "Histórico de Pagamentos: {analisar_perfil_cliente.classificacao_historico_pagamento}\n"
            "Flags de Alerta: {analisar_perfil_cliente.flags_alerta}\n"
            "Inadimplente: {analisar_perfil_cliente.flag_inadimplente}\n"
            "Negativado: {analisar_perfil_cliente.flag_negativado}\n"
            "Cliente Encontrado: {analisar_perfil_cliente.cliente_encontrado}\n"
            "Resumo Comportamental: {analisar_perfil_cliente.historico_comportamental_resumido}\n\n"
            "=== ANÁLISE DO AGENTE CARTEIRA ===\n"
            "Produto Recomendado: {recomendar_produto_cartao.produto_recomendado}\n"
            "Limite Mínimo: R$ {recomendar_produto_cartao.limite_minimo}\n"
            "Limite Máximo: R$ {recomendar_produto_cartao.limite_maximo}\n"
            "Critérios Atendidos: {recomendar_produto_cartao.criterios_elegibilidade_atendidos}\n"
            "Produto Encontrado: {recomendar_produto_cartao.produto_encontrado}\n"
            "Benefícios: {recomendar_produto_cartao.beneficios}\n\n"
            "=== DADOS DA SOLICITAÇÃO ===\n"
            "Renda Declarada: R$ {renda_declarada}\n"
            "Produto Desejado: {tipo_produto_desejado}\n\n"
            "Retorne a decisão no seguinte formato JSON:\n"
            "{\n"
            "  \"decisao\": \"APROVADO ou REPROVADO\",\n"
            "  \"limite_sugerido\": 0.00,\n"
            "  \"produto_recomendado\": \"nome do produto\",\n"
            "  \"justificativa_cliente\": \"texto em linguagem simples sem dados sigilosos\",\n"
            "  \"motivo_principal\": \"codigo do motivo\",\n"
            "  \"protocolo_decisao\": \"AUR-YYYYMMDD-XXXXXXXXXXXX\"\n"
            "}"
        ],
        llm="groq/openai/gpt-oss-120b",
        input_schema=EntradaDecisaoCredito,
    )

    # Sequência do flow: Agente Cliente → Agente Carteira → Decisão Final
    aflow.sequence(START, no_agente_cliente, no_agente_carteira, no_decisao_final, END)

    return aflow
