"""
Ferramenta: Agente Carteira — Aurora Bank Credit Decision System
================================================================
Ferramenta Python para o IBM watsonx Orchestrate.
Realiza o matching do perfil do cliente com os produtos de cartão de
crédito disponíveis na base de conhecimento (produtos_banco.csv).

CRÍTICO: este arquivo é autocontido — todas as definições de tipos,
funções auxiliares e constantes estão neste único arquivo, conforme
exigência da plataforma watsonx Orchestrate para portabilidade de ferramentas.
"""

import csv
import os
from typing import Optional
from pydantic import BaseModel, Field
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission

# ---------------------------------------------------------------------------
# Caminho da base de conhecimento (relativo ao diretório do projeto)
# ---------------------------------------------------------------------------
_CAMINHO_PRODUTOS = os.path.join(
    os.path.dirname(__file__), "..", "..", "src", "knowledge_base", "produtos_banco.csv"
)


# ---------------------------------------------------------------------------
# Schemas Pydantic de entrada e saída
# ---------------------------------------------------------------------------

class EntradaMatchingProduto(BaseModel):
    """Dados de entrada para o matching de produto de cartão de crédito."""
    renda_declarada: float = Field(
        description="Renda mensal bruta declarada pelo cliente em R$"
    )
    score_interno: int = Field(
        description="Score interno de risco do cliente (0 a 1000), obtido do Agente Cliente"
    )
    tipo_produto_desejado: str = Field(
        description="Tipo de produto desejado: BASICO, INTERMEDIARIO, PREMIUM ou EXCLUSIVO"
    )
    flag_inadimplente: bool = Field(
        default=False,
        description="Indica se o cliente possui inadimplência ativa com o banco"
    )
    flag_negativado: bool = Field(
        default=False,
        description="Indica se o cliente possui restrição cadastral ativa"
    )
    tempo_relacionamento_banco_meses: int = Field(
        default=0,
        description="Tempo de relacionamento do cliente com o banco em meses"
    )


class FaixaLimite(BaseModel):
    """Faixa de limite de crédito do produto recomendado."""
    limite_minimo: float = Field(description="Limite mínimo do produto em R$")
    limite_maximo: float = Field(description="Limite máximo do produto em R$")


class SaidaMatchingProduto(BaseModel):
    """Resultado do matching de produto pelo Agente Carteira."""
    produto_recomendado: str = Field(
        description="Nome do produto de cartão de crédito recomendado"
    )
    id_produto: str = Field(
        description="Identificador único do produto na base de conhecimento"
    )
    limite_minimo: float = Field(
        description="Limite mínimo de crédito do produto em R$"
    )
    limite_maximo: float = Field(
        description="Limite máximo de crédito do produto em R$"
    )
    criterios_elegibilidade_atendidos: str = Field(
        description="Critérios de elegibilidade atendidos pelo cliente, separados por ponto-e-vírgula"
    )
    segmento_alvo: str = Field(
        description="Segmento-alvo do produto recomendado"
    )
    beneficios: str = Field(
        description="Benefícios do produto recomendado"
    )
    score_risco_produto: str = Field(
        description="Classificação de risco associada ao produto"
    )
    produtos_elegiveis_count: int = Field(
        description="Total de produtos elegíveis encontrados na base"
    )
    justificativa_produto: str = Field(
        description="Justificativa da seleção do produto (para auditoria)"
    )
    produto_encontrado: bool = Field(
        description="Indica se algum produto elegível foi encontrado"
    )
    mensagem_erro: Optional[str] = Field(
        default=None,
        description="Mensagem de erro caso nenhum produto seja encontrado"
    )


# ---------------------------------------------------------------------------
# Funções auxiliares (autocontidas neste arquivo)
# ---------------------------------------------------------------------------

def _classificar_risco(score: int) -> str:
    """Classifica o risco com base no score interno."""
    if score < 200:
        return "MUITO_ALTO"
    elif score < 400:
        return "ALTO"
    elif score < 600:
        return "MEDIO"
    elif score < 800:
        return "BAIXO"
    return "MUITO_BAIXO"


def _carregar_produtos() -> list:
    """Carrega todos os produtos ativos da base de conhecimento."""
    produtos = []
    try:
        with open(_CAMINHO_PRODUTOS, newline="", encoding="utf-8") as arq:
            for linha in csv.DictReader(arq):
                if linha.get("flag_ativo", "").strip().upper() in ("TRUE", "1", "SIM"):
                    produtos.append(linha)
    except FileNotFoundError:
        pass
    return produtos


def _produto_elegivel(produto: dict, entrada: EntradaMatchingProduto) -> bool:
    """Verifica se o cliente atende os critérios de elegibilidade do produto."""
    try:
        renda_min = float(produto.get("renda_minima_exigida", 0))
        score_min = int(produto.get("score_minimo_exigido", 0))
    except (ValueError, TypeError):
        return False

    # Bloqueio absoluto: negativado não acessa nenhum produto
    if entrada.flag_negativado:
        return False

    # Bloqueio para segmentos Premium/Exclusivo se inadimplente
    segmento = produto.get("segmento_alvo", "").upper()
    if entrada.flag_inadimplente and segmento in ("PREMIUM", "EXCLUSIVO"):
        return False

    return entrada.renda_declarada >= renda_min and entrada.score_interno >= score_min


def _filtrar_por_tipo(produtos: list, tipo: str) -> list:
    """Filtra produtos pelo tipo desejado; retorna todos se nenhum match."""
    tipo_upper = tipo.upper()
    filtrados = [p for p in produtos if p.get("segmento_alvo", "").upper() == tipo_upper]
    return filtrados if filtrados else produtos


# ---------------------------------------------------------------------------
# Definição da ferramenta para o Orchestrate
# ---------------------------------------------------------------------------

@tool(permission=ToolPermission.READ_ONLY)
def recomendar_produto_cartao(entrada: EntradaMatchingProduto) -> SaidaMatchingProduto:
    """
    Realiza o matching do perfil do cliente com os produtos de cartão de crédito.

    Consulta a base de conhecimento de produtos (produtos_banco.csv) e retorna
    o produto mais adequado ao perfil financeiro e de risco do cliente.
    Nenhuma recomendação é feita fora dos produtos disponíveis na base.

    Args:
        entrada (EntradaMatchingProduto): Perfil do cliente com score, renda e tipo desejado.

    Returns:
        SaidaMatchingProduto: Produto recomendado com faixa de limite e critérios atendidos.
    """
    todos_produtos = _carregar_produtos()
    elegiveis = [p for p in todos_produtos if _produto_elegivel(p, entrada)]

    if not elegiveis:
        return SaidaMatchingProduto(
            produto_recomendado="N/A",
            id_produto="N/A",
            limite_minimo=0.0,
            limite_maximo=0.0,
            criterios_elegibilidade_atendidos="",
            segmento_alvo="N/A",
            beneficios="",
            score_risco_produto="N/A",
            produtos_elegiveis_count=0,
            justificativa_produto="Nenhum produto elegível encontrado para o perfil apresentado.",
            produto_encontrado=False,
            mensagem_erro=(
                "Nenhum produto de cartão de crédito elegível foi identificado "
                "para o perfil apresentado na base de conhecimento disponível."
            ),
        )

    # Ordena: dentro do tipo desejado, preferencia pelo maior score_minimo atendido
    tipo_filtrado = _filtrar_por_tipo(elegiveis, entrada.tipo_produto_desejado)
    tipo_filtrado.sort(key=lambda p: int(p.get("score_minimo_exigido", 0)), reverse=True)
    produto = tipo_filtrado[0]

    classificacao = _classificar_risco(entrada.score_interno)

    criterios = []
    if entrada.renda_declarada >= float(produto.get("renda_minima_exigida", 0)):
        criterios.append("Renda compatível com o perfil do produto")
    if entrada.score_interno >= int(produto.get("score_minimo_exigido", 0)):
        criterios.append("Histórico de crédito adequado")
    if not entrada.flag_negativado:
        criterios.append("Ausência de restrições cadastrais ativas")
    if entrada.tempo_relacionamento_banco_meses > 0:
        criterios.append("Cliente com relacionamento ativo com o banco")

    justificativa = (
        f"O produto '{produto.get('nome_produto')}' foi selecionado como o mais adequado "
        f"ao perfil do cliente, atendendo {len(criterios)} critério(s) de elegibilidade "
        f"dentre {len(elegiveis)} produto(s) elegível(is) encontrado(s) na base."
    )

    return SaidaMatchingProduto(
        produto_recomendado=produto.get("nome_produto", ""),
        id_produto=produto.get("id_produto", ""),
        limite_minimo=float(produto.get("limite_minimo", 0)),
        limite_maximo=float(produto.get("limite_maximo", 0)),
        criterios_elegibilidade_atendidos="; ".join(criterios),
        segmento_alvo=produto.get("segmento_alvo", ""),
        beneficios=produto.get("beneficios", ""),
        score_risco_produto=classificacao,
        produtos_elegiveis_count=len(elegiveis),
        justificativa_produto=justificativa,
        produto_encontrado=True,
    )
