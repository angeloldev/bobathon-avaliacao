#!/usr/bin/env bash
# =============================================================================
# Script de Importação — Aurora Bank Credit Decision System
# IBM watsonx Orchestrate ADK
# =============================================================================
#
# Uso:
#   ./import-all.sh
#
# Pré-requisitos:
#   - IBM watsonx Orchestrate ADK instalado e configurado
#   - Ambiente ativo: orchestrate env activate <nome-do-ambiente>
#   - Variáveis de ambiente configuradas (.env)
#
# Ordem de importação:
#   1. Ferramentas Python (client_agent_tool, wallet_agent_tool)
#   2. Flow Tool (credit_decision_flow)
#   3. Agentes (client_agent, wallet_agent, aurora_credit_orchestrator)
# =============================================================================

set -e  # Interrompe em caso de erro

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

echo ""
echo "============================================================"
echo "  Aurora Bank Credit Decision System"
echo "  Importação para IBM watsonx Orchestrate"
echo "============================================================"
echo ""

# Ativa o ambiente (descomente e ajuste conforme necessário)
# orchestrate env activate local

# ---------------------------------------------------------------------------
# ETAPA 1: Importar ferramentas Python
# ---------------------------------------------------------------------------
echo "[ 1/3 ] Importando ferramentas Python..."
echo ""

for ferramenta in client_agent_tool.py wallet_agent_tool.py; do
    echo "  → Importando: ${ferramenta}"
    orchestrate tools import -k python -f "${SCRIPT_DIR}/tools/${ferramenta}"
    echo "  ✓ ${ferramenta} importado com sucesso"
    echo ""
done

# ---------------------------------------------------------------------------
# ETAPA 2: Importar flow tool de orquestração
# ---------------------------------------------------------------------------
echo "[ 2/3 ] Importando flow de decisão de crédito..."
echo ""

orchestrate tools import -k flow -f "${SCRIPT_DIR}/tools/credit_decision_flow.py"
echo "  ✓ credit_decision_flow importado com sucesso"
echo ""

# ---------------------------------------------------------------------------
# ETAPA 3: Importar agentes (ordem: especializados primeiro, orquestrador por último)
# ---------------------------------------------------------------------------
echo "[ 3/3 ] Importando agentes..."
echo ""

for agente in client_agent.yaml wallet_agent.yaml aurora_credit_orchestrator.yaml; do
    echo "  → Importando agente: ${agente}"
    orchestrate agents import -f "${SCRIPT_DIR}/agents/${agente}"
    echo "  ✓ ${agente} importado com sucesso"
    echo ""
done

# ---------------------------------------------------------------------------
# Conclusão
# ---------------------------------------------------------------------------
echo "============================================================"
echo "  ✓ Importação concluída com sucesso!"
echo ""
echo "  Para iniciar o chat com o orquestrador:"
echo "  orchestrate chat start"
echo ""
echo "  Selecione: aurora_credit_orchestrator"
echo "============================================================"
echo ""
