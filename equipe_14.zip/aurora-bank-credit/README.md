# Aurora Bank Credit Decision System

> **Sistema de Decisão de Crédito Explicável, Auditável e Regulatoriamente Conforme**  
> Substituição do sistema legado de 22 anos — Aurora Bank  
> Produto analisado: **Cartão de Crédito**

---

## Índice

1. [Descrição do Sistema e Problema Resolvido](#1-descrição-do-sistema-e-problema-resolvido)
2. [Arquitetura Agêntica](#2-arquitetura-agêntica)
3. [Execução Agêntica no IBM watsonx Orchestrate](#3-execução-agêntica-no-ibm-watsonx-orchestrate)
4. [Execução Local (Interface Web)](#4-execução-local-interface-web)
5. [Casos de Uso Principais](#5-casos-de-uso-principais)
6. [Estrutura de Pastas](#6-estrutura-de-pastas)
7. [Bases de Conhecimento — Schema dos CSVs](#7-bases-de-conhecimento--schema-dos-csvs)
8. [Políticas de Guardrails](#8-políticas-de-guardrails)
9. [Massa de Dados para Teste](#9-massa-de-dados-para-teste)
10. [Exportação de Auditoria para Reguladores](#10-exportação-de-auditoria-para-reguladores)
11. [Tecnologias Utilizadas](#11-tecnologias-utilizadas)

---

## 1. Descrição do Sistema e Problema Resolvido

### Problema

O sistema legado do Aurora Bank operava há 22 anos com as seguintes falhas críticas:

| Problema | Impacto |
|---|---|
| 4 milhões de decisões/mês sem justificativa | Zero conformidade regulatória (BACEN) |
| Clientes recusados sem saber o motivo | Violação do direito à informação (CDC) |
| Carta de decisão: "não pode ser explicada nem contestada" | Infração à Resolução CMN nº 4.966/2021 |
| Clientes recebendo crédito sem solicitação | Risco reputacional e jurídico |
| Decisões não auditáveis | Impossibilidade de defesa em processos PROCON/Judiciário |

### Solução

O **Aurora Bank Credit Decision System** é um sistema que pode ser operado tanto via **interface web Flask** quanto via **agentes nativos no IBM watsonx Orchestrate**. Ele:

- Processa solicitações de crédito para **cartão de crédito** com dois agentes de IA especializados e colaborativos
- Entrega **decisão explicável** (APROVADO/REPROVADO) com justificativa em linguagem simples
- Gera **trilha de auditoria imutável** com hash SHA-256 por decisão
- Fornece **protocolo único** para contestação pelo cliente junto ao SAC, PROCON e BACEN
- Garante **conformidade LGPD**: CPF nunca armazenado em texto plano, apenas hash SHA-256
- É **rastreável end-to-end**: do input à decisão, cada etapa é registrada

---

## 2. Arquitetura Agêntica

### Diagrama de Arquitetura Geral

```mermaid
graph TB
    Cliente[Cliente / Usuário]
    WebUI[Interface Web Flask]
    Orchestrator[Agente Orquestrador\nauro_credit_orchestrator]
    AgCliente[Agente Cliente\nclient_agent]
    AgCarteira[Agente Carteira\nwallet_agent]
    ToolCliente[Tool Python\nanalisar_perfil_cliente]
    ToolCarteira[Tool Python\nrecomendar_produto_cartao]
    FlowTool[Flow Tool\ndecisao_credito_cartao]
    MotorDecisao[Motor de Decisão\ndecision_engine.py]
    Auditoria[Logger de Auditoria\naudit_logger.py]
    Guardrails[Guardrails\nguardrails.py]
    KBClientes[(clientes.csv\n70 clientes)]
    KBProdutos[(produtos_banco.csv\n12 produtos)]
    SQLite[(auditoria.db\nSQLite)]
    Admin[Painel Administrativo\n/admin]
    Regulador[Órgãos Reguladores\nBACEN / PROCON]

    Cliente -->|Preenche formulário| WebUI
    Cliente -->|Chat| Orchestrator
    WebUI -->|dados_solicitacao| Guardrails
    Guardrails -->|validado| MotorDecisao
    Orchestrator -->|invoca flow| FlowTool
    FlowTool -->|cpf_hash + renda| AgCliente
    FlowTool -->|perfil enriquecido| AgCarteira
    AgCliente -->|chama| ToolCliente
    AgCarteira -->|chama| ToolCarteira
    ToolCliente -->|consulta| KBClientes
    ToolCarteira -->|consulta| KBProdutos
    AgCliente -->|saida estruturada| FlowTool
    AgCarteira -->|saida estruturada| FlowTool
    FlowTool -->|perfil_consolidado| Orchestrator
    MotorDecisao -->|resultado_decisao| Guardrails
    Guardrails -->|sanitiza justificativa| WebUI
    MotorDecisao -->|registrar| Auditoria
    Auditoria -->|persiste| SQLite
    WebUI -->|exibe resultado + protocolo| Cliente
    Orchestrator -->|resposta humanizada + protocolo| Cliente
    Admin -->|consulta| SQLite
    Admin -->|exporta| Regulador

    style AgCliente fill:#4A90E2,stroke:#2E5C8A,color:#fff
    style AgCarteira fill:#4A90E2,stroke:#2E5C8A,color:#fff
    style Orchestrator fill:#7B68EE,stroke:#483D8B,color:#fff
    style FlowTool fill:#9B59B6,stroke:#6C3483,color:#fff
    style MotorDecisao fill:#50C878,stroke:#2E7D4E,color:#fff
    style Guardrails fill:#FF6B6B,stroke:#CC0000,color:#fff
    style Auditoria fill:#F39C12,stroke:#C87F0A,color:#fff
```

### Agentes e suas Responsabilidades

#### Agente Orquestrador (`aurora_credit_orchestrator`)

Agente principal com o qual o cliente interage via chat no watsonx Orchestrate.

| Propriedade | Valor |
|---|---|
| Estilo | `react_core` |
| Ferramenta | `decisao_credito_cartao` (flow) |
| Colaboradores | `client_agent`, `wallet_agent` |
| LLM | `groq/openai/gpt-oss-120b` |

**Responsabilidade**: Receber a solicitação do cliente via chat, invocar o flow `decisao_credito_cartao` com os dados necessários, e apresentar a decisão em linguagem humanizada com protocolo de contestação.

#### Agente Cliente (`client_agent`)

| Propriedade | Valor |
|---|---|
| Estilo | `react_core` |
| Ferramenta | `analisar_perfil_cliente` |
| LLM | `groq/openai/gpt-oss-120b` |

**Responsabilidade**: Analisar o perfil histórico e de risco do cliente consultando `clientes.csv` pelo `cpf_hash`. Retorna score, classificação de risco, flags de alerta e capacidade de pagamento.

| Campo analisado | Fonte | Uso |
|---|---|---|
| Score interno (0-1000) | `clientes.csv` | Classificação de risco |
| Histórico de pagamentos 12m | `clientes.csv` | Avaliação comportamental |
| Flags (inadimplente, negativado) | `clientes.csv` | Bloqueio de guardrail |
| Renda estimada vs. declarada | `clientes.csv` | Capacidade de pagamento |
| Tempo de relacionamento | `clientes.csv` | Critério de elegibilidade |

**Output**: `score_risco`, `classificacao_risco`, `capacidade_pagamento_estimada`, `historico_comportamental_resumido`, `flags_alerta`

#### Agente Carteira (`wallet_agent`)

| Propriedade | Valor |
|---|---|
| Estilo | `react_core` |
| Ferramenta | `recomendar_produto_cartao` |
| LLM | `groq/openai/gpt-oss-120b` |

**Responsabilidade**: Fazer o matching entre o perfil do cliente (output do Agente Cliente) e os produtos disponíveis em `produtos_banco.csv`. Retorna o produto mais adequado, faixa de limite e critérios atendidos.

| Campo analisado | Fonte | Uso |
|---|---|---|
| Renda mínima exigida | `produtos_banco.csv` | Filtro de elegibilidade |
| Score mínimo exigido | `produtos_banco.csv` | Filtro de elegibilidade |
| Segmento do produto | `produtos_banco.csv` | Matching por tipo desejado |
| Faixa de limite | `produtos_banco.csv` | Cálculo do limite final |
| Benefícios | `produtos_banco.csv` | Comunicação ao cliente |

**Output**: `produto_recomendado`, `faixa_limite_compativel`, `criterios_elegibilidade_atendidos`

### Motor de Decisão

Aplicado pelo orquestrador após consolidar os outputs dos dois agentes:

```
1. Cliente negativado?          → REPROVADO (CLIENTE_NEGATIVADO)
2. Cliente inadimplente?        → REPROVADO (CLIENTE_INADIMPLENTE)
3. Score < 300?                 → REPROVADO (SCORE_INSUFICIENTE)
4. Risco MUITO_ALTO?            → REPROVADO (SCORE_INSUFICIENTE)
5. Histórico RUIM?              → REPROVADO (HISTORICO_INADEQUADO)
6. Capacidade < limite_min?     → REPROVADO (CAPACIDADE_INSUFICIENTE)
7. Comprometimento renda > 30%? → REPROVADO (COMPROMETIMENTO_EXCESSIVO)
→ Todos os guardrails passados: APROVADO
```

---

## 3. Execução Agêntica no IBM watsonx Orchestrate

### Pré-requisitos

- IBM watsonx Orchestrate ADK instalado
- Ambiente Orchestrate ativo (`orchestrate env activate <nome>`)
- Python 3.10+ com dependências instaladas

### Instalação das Dependências

```bash
cd aurora-bank-credit
pip install -r requirements.txt
```

### Importação Automática (recomendado)

O script [`import-all.sh`](orchestrate/import-all.sh) importa todos os artefatos na ordem correta:

```bash
cd orchestrate
chmod +x import-all.sh
./import-all.sh
```

A ordem de importação é obrigatória:

```
1. Tools Python  → analisar_perfil_cliente  (client_agent_tool.py)
2. Tools Python  → recomendar_produto_cartao (wallet_agent_tool.py)
3. Flow Tool     → decisao_credito_cartao    (credit_decision_flow.py)
4. Agente        → client_agent              (client_agent.yaml)
5. Agente        → wallet_agent              (wallet_agent.yaml)
6. Agente        → aurora_credit_orchestrator (aurora_credit_orchestrator.yaml)
```

### Importação Manual (passo a passo)

```bash
# 1. Importar ferramenta do Agente Cliente
orchestrate tools import -k python -f orchestrate/tools/client_agent_tool.py

# 2. Importar ferramenta do Agente Carteira
orchestrate tools import -k python -f orchestrate/tools/wallet_agent_tool.py

# 3. Importar flow de orquestração
orchestrate tools import -k flow -f orchestrate/tools/credit_decision_flow.py

# 4. Importar Agente Cliente
orchestrate agents import -f orchestrate/agents/client_agent.yaml

# 5. Importar Agente Carteira
orchestrate agents import -f orchestrate/agents/wallet_agent.yaml

# 6. Importar Orquestrador (por último)
orchestrate agents import -f orchestrate/agents/aurora_credit_orchestrator.yaml
```

### Verificar a Importação

```bash
# Listar agentes importados
orchestrate agents list

# Listar ferramentas importadas
orchestrate tools list
```

Você deve ver os seguintes artefatos:

| Tipo | Nome |
|---|---|
| Tool (Python) | `analisar_perfil_cliente` |
| Tool (Python) | `recomendar_produto_cartao` |
| Tool (Flow) | `decisao_credito_cartao` |
| Agent (native) | `client_agent` |
| Agent (native) | `wallet_agent` |
| Agent (native) | `aurora_credit_orchestrator` |

### Iniciar o Chat Agêntico

```bash
orchestrate chat start
# Selecione: aurora_credit_orchestrator
```

### Exemplos de Prompts para Teste no Chat

O orquestrador já vem com prompts iniciais configurados. Para testar com os clientes da base de dados, use o formato abaixo:

```
# Teste com cliente PREMIUM (CLI056 — Carlos Eduardo Fonseca)
Quero solicitar um cartão de crédito Aurora.
CPF hash: 03ad270a044f65833f07b2f013c071156f841079a475d29aa43aded3a9f16400
Renda mensal: R$ 8.500
Tipo de cartão: PREMIUM
Nome: Carlos Eduardo Fonseca
```

```
# Teste com cliente EXCLUSIVO (CLI067 — Gustavo Monteiro Leite)
Solicite análise de crédito para cartão exclusivo.
Hash: 12fcddf72629558511d13db3eaacf43a6e95dc385ed4d5fb273ae52093ae2528
Renda: R$ 25.000
Produto desejado: EXCLUSIVO
```

```
# Teste de reprovação — cliente negativado (CLI063 — Luiz Fernando Maciel)
Quero um cartão básico.
CPF hash: 035106df541ea4dcdc43e2354867dc0d3d959e14de747d147ce801e385ed35e8
Renda: R$ 1.200
Tipo: BASICO
```

> **Importante:** o Agente Cliente busca o cliente exclusivamente pelo `cpf_hash`. Use sempre o hash correspondente ao CPF cadastrado em `clientes.csv`. Consulte a [Seção 9](#9-massa-de-dados-para-teste) para a tabela completa de CPFs e hashes de teste.

### Fluxo Agêntico Completo

```mermaid
sequenceDiagram
    participant U as Usuário
    participant O as aurora_credit_orchestrator
    participant F as decisao_credito_cartao (Flow)
    participant CA as client_agent
    participant WA as wallet_agent
    participant TC as analisar_perfil_cliente
    participant TW as recomendar_produto_cartao

    U->>O: Solicita cartão (cpf_hash, renda, tipo)
    O->>F: Invoca flow com dados da solicitação
    F->>CA: Delega análise de perfil
    CA->>TC: Chama tool com cpf_hash + renda_declarada
    TC-->>CA: score, risco, flags, capacidade
    CA-->>F: saida_agente_cliente
    F->>WA: Delega matching de produto (com perfil enriquecido)
    WA->>TW: Chama tool com score + renda + tipo desejado
    TW-->>WA: produto, limite, critérios
    WA-->>F: saida_agente_carteira
    F-->>O: perfil_consolidado (decisão + protocolo)
    O-->>U: Resposta humanizada com decisão, limite e protocolo
```

---

## 4. Execução Local (Interface Web)

### Instalação

```bash
# 1. Clone o repositório
git clone <url-do-repositorio>
cd aurora-bank-credit

# 2. Crie e ative o ambiente virtual
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate    # Windows

# 3. Instale as dependências
pip install -r requirements.txt

# 4. Configure as variáveis de ambiente
cp .env.example .env
# Edite .env — defina ORCHESTRATE_MODO_SIMULACAO=true para rodar sem API

# 5. Execute a aplicação
cd src/web
python app.py
```

### Variáveis de Ambiente Principais

| Variável | Padrão | Descrição |
|---|---|---|
| `ORCHESTRATE_MODO_SIMULACAO` | `true` | `true` executa agentes localmente sem API Orchestrate |
| `FLASK_PORT` | `5001` | Porta da aplicação web |
| `FLASK_SECRET_KEY` | `aurora-bank-dev-secret-2025` | Chave de sessão Flask |
| `ADMIN_TOKEN` | `aurora-admin-2025` | Token de acesso ao painel `/admin` |
| `AURORA_AUDIT_DB_PATH` | `evidencias/auditoria.db` | Caminho do banco SQLite de auditoria |

### Acesso

| Recurso | URL |
|---|---|
| Formulário de solicitação | `http://localhost:5001/` |
| Resultado da decisão | `http://localhost:5001/resultado/<protocolo>` |
| Painel administrativo | `http://localhost:5001/admin?token=aurora-admin-2025` |
| Health check | `http://localhost:5001/health` |

### Produção com Gunicorn

```bash
gunicorn -w 4 -b 0.0.0.0:5001 "src.web.app:app"
```

---

## 5. Casos de Uso Principais

### UC-01: Solicitação via Chat Agêntico (watsonx Orchestrate)

```
Pré-condição: Agentes importados e chat iniciado com aurora_credit_orchestrator

1. Usuário envia mensagem com cpf_hash, renda e tipo de cartão desejado

2. Orquestrador invoca o flow decisao_credito_cartao

3. Flow aciona o Agente Cliente (client_agent):
   - Busca cliente por cpf_hash na base
   - Calcula score, risco, capacidade e flags

4. Flow aciona o Agente Carteira (wallet_agent) com perfil enriquecido:
   - Busca produtos elegíveis na base
   - Seleciona o mais compatível com o perfil

5. Flow retorna perfil consolidado ao Orquestrador

6. Orquestrador apresenta ao usuário:
   - APROVADO ✓ ou REPROVADO ✗
   - Limite inicial (se aprovado)
   - Produto recomendado e benefícios
   - Justificativa em linguagem simples
   - Protocolo único para contestação
```

### UC-02: Solicitação via Interface Web

```
Pré-condição: Cliente acessa http://localhost:5001/

1. Cliente preenche formulário com:
   - Nome completo
   - CPF (convertido em hash SHA-256 pelo sistema)
   - Renda mensal bruta
   - Tipo de cartão desejado
   - Aceite dos termos (LGPD)

2. Sistema invoca Guardrail de entrada:
   - Valida campos obrigatórios
   - Gera hash do CPF (LGPD)

3. Orquestrador local executa os dois agentes sequencialmente

4. Motor de Decisão aplica a árvore de regras com rastreabilidade

5. Auditoria registra a decisão com hash SHA-256

6. Cliente recebe resultado com protocolo de contestação
```

### UC-03: Consulta de Trilha de Auditoria (Operador)

```
Pré-condição: Operador acessa /admin com token válido

1. Operador filtra decisões por período, tipo ou status
2. Sistema exibe tabela com decisões e metadados
3. Operador clica em "Ver trilha" para uma decisão específica
4. Sistema exibe:
   - Input anonimizado recebido
   - Output completo do Agente Cliente
   - Output completo do Agente Carteira
   - Justificativa interna (para auditoria)
   - Hash de integridade e status de verificação
```

### UC-04: Exportação para Reguladores (BACEN/PROCON)

```
Pré-condição: Operador autenticado no painel /admin

1. Operador seleciona período e filtros
2. Clica em "Exportar JSON (BACEN)" ou "Exportar CSV (PROCON)"
3. Sistema gera arquivo com:
   - Todos os registros do período
   - Hash de integridade de cada registro
   - Timestamp da exportação
   - Metadados regulatórios (base legal LGPD, prazo de retenção)
```

---

## 6. Estrutura de Pastas

```
aurora-bank-credit/
├── src/                            # Código-fonte do sistema web local
│   ├── agents/
│   │   ├── wallet_agent.py         # Agente Carteira (matching de produto)
│   │   └── client_agent.py         # Agente Cliente (análise de risco)
│   ├── orchestration/
│   │   └── orchestrator.py         # Coordena os dois agentes localmente
│   ├── decision/
│   │   └── decision_engine.py      # Motor de decisão com árvore rastreável
│   ├── audit/
│   │   └── audit_logger.py         # Registro imutável + exportação CSV/JSON
│   ├── guardrails/
│   │   └── guardrails.py           # Validações, sanitização, bloqueios
│   ├── web/
│   │   ├── app.py                  # Aplicação Flask (rotas, formulários, admin)
│   │   ├── templates/
│   │   │   ├── index.html          # Formulário de solicitação
│   │   │   ├── resultado.html      # Exibição da decisão ao cliente
│   │   │   ├── admin.html          # Painel de auditoria
│   │   │   ├── admin_decisao.html  # Trilha de auditoria individual
│   │   │   └── admin_login.html    # Login administrativo
│   │   └── static/
│   │       ├── css/aurora.css      # Design system Aurora Bank
│   │       └── js/aurora.js        # Máscaras, validações, UX
│   ├── knowledge_base/
│   │   ├── clientes.csv            # Base de 70 clientes com perfis variados
│   │   ├── produtos_banco.csv      # 12 produtos de cartão de crédito
│   │   └── historico_decisoes.csv  # 100 decisões históricas
│   └── utils/
│       └── helpers.py              # Hashing CPF, formatação, protocolo, timestamps
│
├── orchestrate/                    # Artefatos nativos IBM watsonx Orchestrate
│   ├── tools/
│   │   ├── client_agent_tool.py    # Tool Python: analisar_perfil_cliente
│   │   ├── wallet_agent_tool.py    # Tool Python: recomendar_produto_cartao
│   │   └── credit_decision_flow.py # Flow Tool: decisao_credito_cartao
│   ├── agents/
│   │   ├── client_agent.yaml       # Spec YAML: Agente Cliente
│   │   ├── wallet_agent.yaml       # Spec YAML: Agente Carteira
│   │   └── aurora_credit_orchestrator.yaml  # Spec YAML: Orquestrador principal
│   └── import-all.sh               # Script de importação completa
│
├── evidencias/                     # Trilhas de auditoria exportáveis
│   ├── auditoria.db                # SQLite com todos os registros (gerado em runtime)
│   ├── exemplo_auditoria.json      # Exemplo do formato de registro regulatório
│   └── AUR-*.json                  # Um arquivo por decisão (gerado em runtime)
│
├── requirements.txt                # Dependências Python
├── .env.example                    # Template de variáveis de ambiente
└── README.md                       # Este arquivo
```

---

## 7. Bases de Conhecimento — Schema dos CSVs

### `clientes.csv` (70 registros)

| Campo | Tipo | Descrição |
|---|---|---|
| `id_cliente` | string | Identificador único (ex.: CLI001) |
| `nome` | string | Nome completo do cliente |
| `cpf_hash` | string | Hash SHA-256 do CPF (LGPD — nunca armazena CPF bruto) |
| `idade` | int | Idade em anos |
| `estado_civil` | string | `SOLTEIRO`, `CASADO`, `DIVORCIADO`, `VIUVO`, `UNIAO_ESTAVEL` |
| `escolaridade` | string | `FUNDAMENTAL`, `MEDIO`, `SUPERIOR`, `POS_GRADUACAO` |
| `renda_mensal_estimada` | float | Renda estimada pelo banco em R$ |
| `tempo_relacionamento_banco_meses` | int | Meses desde a abertura de conta |
| `score_interno` | int | Score de risco interno (0-1000) |
| `score_externo_serasa` | int | Score Serasa/Boa Vista |
| `qtd_produtos_banco` | int | Produtos ativos no banco |
| `qtd_dividas_ativas` | int | Dívidas ativas no sistema |
| `valor_total_dividas` | float | Soma das dívidas em R$ |
| `historico_pagamento_ultimos_12m` | float | % de pagamentos em dia (0.0–1.0) |
| `media_gastos_mensais` | float | Média de gastos mensais em R$ |
| `limite_atual_cartao` | float | Limite atual de cartão em R$ |
| `flag_inadimplente` | bool | `TRUE` se possui inadimplência ativa com o banco |
| `flag_negativado` | bool | `TRUE` se possui restrição cadastral ativa |
| `segmento_cliente` | string | `BASICO`, `INTERMEDIARIO`, `PREMIUM`, `EXCLUSIVO` |
| `ultima_atualizacao_cadastral` | date | Data da última atualização cadastral |

### `produtos_banco.csv` (12 produtos)

| Campo | Tipo | Descrição |
|---|---|---|
| `id_produto` | string | Identificador único (ex.: PROD001) |
| `nome_produto` | string | Nome comercial do cartão |
| `tipo_produto` | string | `CARTAO_CREDITO` |
| `segmento_alvo` | string | `BASICO`, `INTERMEDIARIO`, `PREMIUM`, `EXCLUSIVO` |
| `renda_minima_exigida` | float | Renda mínima para elegibilidade em R$ |
| `score_minimo_exigido` | int | Score mínimo interno para elegibilidade |
| `limite_minimo` | float | Limite mínimo do produto em R$ |
| `limite_maximo` | float | Limite máximo do produto em R$ |
| `taxa_juros_rotativo_mensal` | float | Taxa do rotativo ao mês (%) — sigiloso |
| `anuidade` | float | Valor da anuidade em R$ (0 = isento) |
| `beneficios` | string | Lista de benefícios do produto |
| `criterios_elegibilidade` | string | Critérios detalhados de elegibilidade |
| `flag_ativo` | bool | `TRUE` se o produto está disponível para concessão |

### `historico_decisoes.csv` (100 registros)

| Campo | Tipo | Descrição |
|---|---|---|
| `id_decisao` | string | Protocolo único (ex.: AUR-20250101-HIST000001) |
| `id_cliente` | string | ID do cliente na base |
| `data_decisao` | datetime | Timestamp ISO 8601 da decisão |
| `decisao` | string | `APROVADO` ou `REPROVADO` |
| `limite_sugerido` | float | Limite concedido em R$ (0 se reprovado) |
| `produto_recomendado` | string | Nome do produto recomendado |
| `motivo_principal` | string | Código do motivo da decisão |
| `score_decisao` | float | Pontuação composta da decisão |
| `agente_carteira_output` | string | Resumo do output do Agente Carteira |
| `agente_cliente_output` | string | Resumo do output do Agente Cliente |
| `trilha_auditoria_hash` | string | Hash SHA-256 do registro |
| `operador_sistema` | string | Identificador do sistema decisor |

---

## 8. Políticas de Guardrails

### Guardrails de Entrada

| Guardrail | Regra | Ação em caso de violação |
|---|---|---|
| Campos obrigatórios | `nome`, `cpf_hash`, `renda_declarada`, `tipo_produto_desejado` | Rejeição com mensagem padronizada |
| Injeção de campos sigilosos | CPF, renda exata, score, dados bancários via input | Bloqueio com erro de segurança |
| Completude mínima | Ambos os agentes devem retornar outputs válidos | Decisão vetada |

### Guardrails de Processamento

| Guardrail | Regra | Ação |
|---|---|---|
| Dados ausentes | Nenhuma inferência sobre dados não presentes no CSV | `GuardrailError` lançado |
| Cliente não encontrado | Base de clientes não contém o `cpf_hash` | Decisão bloqueada por insuficiência de dados |
| Produto não encontrado | Nenhum produto elegível na base | Decisão bloqueada |
| Inferência especulativa | Tentativa de deduzir dados ausentes | `bloquear_inferencia_especulativa()` |

### Guardrails de Saída

| Guardrail | Regra | Implementação |
|---|---|---|
| Sanitização de justificativa | Remove CPF, score numérico, taxas, políticas internas | `sanitizar_justificativa_cliente()` |
| Dados sigilosos ao cliente | Score exato, renda estimada, taxa de juros | Omitidos na camada de apresentação |
| Dados internos do banco | Margens, critérios detalhados de política de risco | Nunca expostos na interface |

### Campos Sigilosos (nunca expostos ao cliente)

```python
CAMPOS_SIGILOSOS = {
    "cpf", "cpf_hash", "renda_mensal_estimada", "valor_total_dividas",
    "score_externo_serasa", "score_interno", "taxa_juros_rotativo_mensal",
    "limite_minimo", "limite_maximo", "criterios_elegibilidade_internos",
    "margem_banco", "politica_risco_interna"
}
```

---

## 9. Massa de Dados para Teste

Os registros a seguir foram adicionados ao `clientes.csv` (CLI056–CLI070) com CPFs fictícios e hashes SHA-256 pré-calculados. Use-os tanto no **formulário web** quanto no **chat agêntico**.

### ✅ Alta probabilidade de aprovação

| CLI | Nome | CPF (formulário) | cpf_hash (chat) | Renda | Cartão | Segmento |
|-----|------|-----------------|-----------------|-------|--------|---------|
| 056 | Carlos Eduardo Fonseca | `348.526.891-04` | `03ad270a...f16400` | `8.500,00` | PREMIUM | PREMIUM |
| 057 | Mariana Luisa Carvalho | `521.874.036-72` | `2ebd5d36...d4a0` | `15.000,00` | EXCLUSIVO | EXCLUSIVO |
| 058 | Paulo Henrique Teixeira | `763.012.485-90` | `63b909dc...cd94` | `6.200,00` | INTERMEDIARIO | INTERMEDIARIO |
| 059 | Renata Souza Almeida | `914.237.560-18` | `1f93fac5...e6f9` | `9.800,00` | PREMIUM | PREMIUM |
| 067 | Gustavo Monteiro Leite | `512.937.084-62` | `12fcddf7...2528` | `25.000,00` | EXCLUSIVO | EXCLUSIVO |
| 070 | Fernanda Couto Pires | `935.704.812-49` | `46efecb7...43db` | `11.200,00` | PREMIUM | PREMIUM |

### ⚠️ Perfil limítrofe / análise criteriosa

| CLI | Nome | CPF (formulário) | cpf_hash (chat) | Renda | Cartão | Segmento |
|-----|------|-----------------|-----------------|-------|--------|---------|
| 060 | Joao Vitor Ramos | `237.680.154-63` | `99bf6b16...3757` | `2.800,00` | BASICO | BASICO |
| 061 | Patricia Nunes Azevedo | `489.315.027-51` | `5ad89c51...dd5f` | `4.100,00` | INTERMEDIARIO | INTERMEDIARIO |
| 066 | Ana Beatriz Costa | `389.752.146-08` | `d34b8e54...6a55` | `3.500,00` | BASICO | BASICO |
| 068 | Silvia Barros Figueira | `741.268.053-90` | `b9802c0f...0f9d` | `3.750,50` | BASICO | BASICO |
| 069 | Jose Benedito Carmo | `864.391.720-55` | `c81150bc...18a` | `3.100,00` | BASICO | INTERMEDIARIO |

### ❌ Tendência de negação (risco alto / negativado / inadimplente)

| CLI | Nome | CPF (formulário) | cpf_hash (chat) | Renda | Cartão | Motivo esperado |
|-----|------|-----------------|-----------------|-------|--------|----------------|
| 062 | Andre Luiz Bezerra | `672.094.318-86` | `7b1bce28...14c7` | `1.900,00` | BASICO | SCORE_INSUFICIENTE |
| 063 | Luiz Fernando Maciel | `815.463.270-39` | `035106df...35e8` | `1.200,00` | BASICO | CLIENTE_NEGATIVADO |
| 064 | Beatriz Oliveira Lopes | `103.728.954-07` | `6eb8b589...89d3` | `1.500,00` | BASICO | SCORE_INSUFICIENTE |
| 065 | Marcio Pereira Duarte | `256.841.073-95` | `5fc23089...85a9` | `2.000,00` | BASICO | CLIENTE_INADIMPLENTE |

> **Hashes completos** para uso no chat: consulte a coluna `cpf_hash` do arquivo `src/knowledge_base/clientes.csv` nos registros CLI056–CLI070.

---

## 10. Exportação de Auditoria para Reguladores

### Via Interface Web (Painel Administrativo)

1. Acesse `/admin?token=<ADMIN_TOKEN>`
2. Aplique filtros de período, decisão ou produto
3. Clique em **"Exportar JSON (BACEN)"** ou **"Exportar CSV (PROCON)"**

### Via API

```bash
# Exportar JSON (período)
curl "http://localhost:5001/admin/exportar?token=aurora-admin-2025&formato=json&data_inicio=2025-01-01&data_fim=2025-12-31"

# Exportar CSV — apenas reprovados
curl "http://localhost:5001/admin/exportar?token=aurora-admin-2025&formato=csv&decisao=REPROVADO"
```

### Verificação de Integridade

Cada registro possui um hash SHA-256. A verificação detecta adulterações:

```python
from src.audit.audit_logger import verificar_integridade
resultado = verificar_integridade("AUR-20250115-ABCD1234EFGH")
# {"integro": True, "detalhes": "Hash verificado. Registro íntegro."}
```

### Informações Regulatórias nos Registros

| Campo | Conteúdo |
|---|---|
| Base legal LGPD | Art. 7, inciso V — execução de contrato |
| Base legal BACEN | Resolução CMN nº 4.966/2021 |
| Cadastro positivo | Lei nº 12.414/2011 |
| Prazo de retenção | 5 anos (Resolução BACEN nº 4.557/2017) |
| Destinatários autorizados | BACEN, PROCON, Judiciário, Titular dos dados |

---

## 11. Tecnologias Utilizadas

| Componente | Tecnologia | Versão |
|---|---|---|
| Linguagem | Python | 3.10+ |
| Framework web | Flask | 3.0.3 |
| Orquestração agêntica | IBM watsonx Orchestrate | ADK mais recente |
| Persistência de auditoria | SQLite3 | Nativa Python |
| Base de conhecimento | CSV | — |
| Hashing LGPD | hashlib SHA-256 | Nativa Python |
| Validação de dados | Pydantic | 2.7.4 |
| Frontend | HTML5 + CSS3 + JavaScript | — |
| Servidor WSGI (prod.) | Gunicorn | 22.0.0 |

### Regulação de Referência

- **Resolução CMN nº 4.966/2021** — Risco de crédito
- **Circular BACEN nº 3.978/2020** — KYC e prevenção à lavagem de dinheiro
- **Lei nº 12.414/2011** — Cadastro positivo
- **LGPD — Lei nº 13.709/2018** — Proteção de dados pessoais
- **CDC — Lei nº 8.078/1990** — Direito à informação e contestação
- **Resolução BACEN nº 4.557/2017** — Gestão de riscos e governança

---

*Aurora Bank Credit Decision System v1.0 — Decisões explicáveis, auditáveis e conformes.*

### Equipe
- Samuel Couto
- Sergio Melo
- Manoel Dias
- Henrique Costa
- Paulo Ribeiro
