"""
Motor de Decisão — Aurora Bank Credit Decision System
======================================================
Responsável pela tomada de decisão final de crédito, consolidando os
outputs dos dois agentes e aplicando as regras de negócio do banco.

A decisão é sempre APROVADO ou REPROVADO, jamais ambígua.
A justificativa gerada é sanitizada via guardrails antes de ser entregue
ao cliente — sem dados sigilosos, sem jargão técnico, sem referências
a sistemas internos ou políticas de risco.

Regulação de referência:
- Resolução CMN nº 4.966/2021 (risco de crédito)
- Circular BACEN nº 3.978/2020 (KYC e prevenção a lavagem de dinheiro)
- Lei nº 12.414/2011 (cadastro positivo)
- LGPD — Lei nº 13.709/2018
"""

import logging
from typing import Any

from src.guardrails.guardrails import Guardrails
from src.utils.helpers import (
    formatar_moeda_brl,
    calcular_comprometimento_renda,
    gerar_protocolo_decisao,
    timestamp_agora,
)

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constantes de decisão
# ---------------------------------------------------------------------------
DECISAO_APROVADO = "APROVADO"
DECISAO_REPROVADO = "REPROVADO"

# Comprometimento máximo de renda permitido para aprovação (30%)
LIMITE_COMPROMETIMENTO_RENDA = 0.30

# Score mínimo interno para aprovação
SCORE_MINIMO_APROVACAO = 300

# Fatores de ajuste do limite por classificação de risco
FATOR_LIMITE_POR_RISCO = {
    "MUITO_BAIXO": 1.00,
    "BAIXO":       0.85,
    "MEDIO":       0.70,
    "ALTO":        0.50,
    "MUITO_ALTO":  0.00,  # Bloqueio total para risco muito alto
}

# Mensagens de reprovação por motivo (sem expor dados internos)
MENSAGENS_REPROVACAO = {
    "SCORE_INSUFICIENTE": (
        "Com base na análise do seu histórico financeiro, seu perfil atual não "
        "atende os requisitos mínimos para concessão de crédito neste momento. "
        "Recomendamos regularizar eventuais pendências e tentar novamente em 90 dias."
    ),
    "CLIENTE_NEGATIVADO": (
        "Identificamos restrições cadastrais ativas em seu nome que impedem a "
        "concessão de crédito neste momento. Para regularizar sua situação, "
        "entre em contato com o SAC do banco ou consulte os órgãos de proteção ao crédito."
    ),
    "CLIENTE_INADIMPLENTE": (
        "Há compromissos financeiros em aberto com o banco que precisam ser "
        "regularizados antes de uma nova análise de crédito. "
        "Entre em contato com nossa equipe para negociar suas pendências."
    ),
    "COMPROMETIMENTO_EXCESSIVO": (
        "O limite de crédito solicitado resultaria em um comprometimento de renda "
        "superior ao recomendado para manter a saúde financeira. "
        "Sugerimos solicitar um limite menor ou aguardar melhora na composição de renda."
    ),
    "CAPACIDADE_INSUFICIENTE": (
        "Após análise do seu perfil financeiro, a capacidade de pagamento estimada "
        "não é compatível com a concessão de crédito neste momento. "
        "Considere aumentar sua renda comprovada e tente novamente."
    ),
    "HISTORICO_INADEQUADO": (
        "O histórico de pagamentos dos últimos meses indica um padrão que não permite "
        "a aprovação de crédito neste momento. Manter os pagamentos em dia por pelo "
        "menos 6 meses consecutivos pode melhorar sua elegibilidade."
    ),
}

MENSAGEM_APROVACAO_PADRAO = (
    "Ficamos felizes em informar que sua solicitação de cartão de crédito foi aprovada! "
    "O limite foi definido com base no seu perfil financeiro e histórico de relacionamento "
    "com o banco. Em caso de dúvidas, entre em contato com nossa central de atendimento."
)


def _calcular_limite_final(
    faixa_limite: dict,
    capacidade_pagamento: float,
    renda_declarada: float,
    classificacao_risco: str,
) -> float:
    """
    Calcula o limite de crédito final a ser concedido, respeitando:
    - A faixa de limite do produto recomendado
    - A capacidade de pagamento estimada
    - O fator de ajuste de risco
    - O teto de comprometimento de renda (30%)

    Args:
        faixa_limite: Dict com 'limite_minimo' e 'limite_maximo' do produto.
        capacidade_pagamento: Capacidade de pagamento estimada pelo Agente Cliente.
        renda_declarada: Renda mensal declarada pelo cliente.
        classificacao_risco: Classificação de risco do cliente.

    Returns:
        Limite de crédito calculado (float).
    """
    fator = FATOR_LIMITE_POR_RISCO.get(classificacao_risco, 0.50)
    limite_maximo_produto = float(faixa_limite.get("limite_maximo", 0))
    limite_minimo_produto = float(faixa_limite.get("limite_minimo", 0))

    # Limite baseado na capacidade de pagamento ajustada pelo risco
    limite_por_capacidade = capacidade_pagamento * fator

    # Limite baseado no comprometimento máximo de renda (30% da renda anual)
    limite_por_renda = renda_declarada * 12 * LIMITE_COMPROMETIMENTO_RENDA

    # Limite final: menor entre produto, capacidade e renda
    limite_candidato = min(limite_por_capacidade, limite_por_renda, limite_maximo_produto)
    limite_candidato = max(limite_candidato, limite_minimo_produto)

    # Arredonda para o múltiplo de R$50 mais próximo (padrão de mercado)
    return round(limite_candidato / 50) * 50


def processar_decisao(resultado_orquestrador: dict[str, Any]) -> dict[str, Any]:
    """
    Processa a decisão final de crédito com base nos outputs consolidados
    do orquestrador (Agente Carteira + Agente Cliente).

    Esta função é o núcleo do sistema de decisão explicável e auditável.
    Cada etapa de raciocínio é registrada para fins regulatórios.

    Args:
        resultado_orquestrador: Dict retornado pelo orquestrador, contendo
            saida_agente_carteira, saida_agente_cliente e perfil_consolidado.

    Returns:
        Dicionário com:
            - protocolo_decisao: identificador único rastreável
            - decisao: 'APROVADO' ou 'REPROVADO'
            - limite_sugerido: valor em R$ (apenas quando aprovado)
            - produto_recomendado: nome do produto
            - justificativa_cliente: texto sanitizado para o cliente
            - justificativa_auditoria: texto completo para auditoria
            - motivo_principal: código do motivo da decisão
            - score_decisao: pontuação composta usada na decisão
            - timestamp_decisao: momento da decisão
    """
    protocolo = gerar_protocolo_decisao()
    timestamp = timestamp_agora()

    perfil = resultado_orquestrador["perfil_consolidado"]
    saida_cliente = resultado_orquestrador["saida_agente_cliente"]
    saida_carteira = resultado_orquestrador["saida_agente_carteira"]

    flags = perfil.get("flags_alerta", [])
    classificacao_risco = perfil.get("classificacao_risco", "MUITO_ALTO")
    score_risco = int(perfil.get("score_risco", 0))
    capacidade_pagamento = float(perfil.get("capacidade_pagamento_estimada", 0))
    renda_declarada = float(perfil.get("renda_declarada", 0))
    faixa_limite = perfil.get("faixa_limite", {"limite_minimo": 0, "limite_maximo": 0})

    # ---------------------------------------------------------------------------
    # Árvore de decisão com rastreabilidade total
    # ---------------------------------------------------------------------------
    decisao = DECISAO_APROVADO
    motivo_principal = "APROVADO_PERFIL_ADEQUADO"
    justificativa_interna = []

    # Regra 1 — Negativado é bloqueio absoluto
    if "CLIENTE_NEGATIVADO" in flags:
        decisao = DECISAO_REPROVADO
        motivo_principal = "CLIENTE_NEGATIVADO"
        justificativa_interna.append("Cliente com restrição cadastral ativa (negativado).")

    # Regra 2 — Inadimplente com o banco é bloqueio
    elif "CLIENTE_INADIMPLENTE" in flags:
        decisao = DECISAO_REPROVADO
        motivo_principal = "CLIENTE_INADIMPLENTE"
        justificativa_interna.append("Cliente com inadimplência ativa no banco.")

    # Regra 3 — Score mínimo não atingido
    elif score_risco < SCORE_MINIMO_APROVACAO:
        decisao = DECISAO_REPROVADO
        motivo_principal = "SCORE_INSUFICIENTE"
        justificativa_interna.append(f"Score interno ({score_risco}) abaixo do mínimo exigido ({SCORE_MINIMO_APROVACAO}).")

    # Regra 4 — Risco muito alto bloqueia
    elif classificacao_risco == "MUITO_ALTO":
        decisao = DECISAO_REPROVADO
        motivo_principal = "SCORE_INSUFICIENTE"
        justificativa_interna.append(f"Classificação de risco '{classificacao_risco}' impede a concessão.")

    # Regra 5 — Histórico de pagamento inadequado
    elif "HISTORICO_PAGAMENTO_INADEQUADO" in flags:
        decisao = DECISAO_REPROVADO
        motivo_principal = "HISTORICO_INADEQUADO"
        justificativa_interna.append("Histórico de pagamentos abaixo do patamar mínimo exigido.")

    # Regra 6 — Capacidade de pagamento insuficiente
    elif capacidade_pagamento < float(faixa_limite.get("limite_minimo", 0)):
        decisao = DECISAO_REPROVADO
        motivo_principal = "CAPACIDADE_INSUFICIENTE"
        justificativa_interna.append(
            f"Capacidade de pagamento estimada (R${capacidade_pagamento:.2f}) "
            f"inferior ao limite mínimo do produto."
        )

    # ---------------------------------------------------------------------------
    # Cálculo do limite (apenas para aprovações)
    # ---------------------------------------------------------------------------
    limite_sugerido = 0.0
    if decisao == DECISAO_APROVADO:
        limite_sugerido = _calcular_limite_final(
            faixa_limite=faixa_limite,
            capacidade_pagamento=capacidade_pagamento,
            renda_declarada=renda_declarada,
            classificacao_risco=classificacao_risco,
        )

        # Verificação de comprometimento de renda pós-cálculo
        comprometimento = calcular_comprometimento_renda(renda_declarada, limite_sugerido)
        if comprometimento > LIMITE_COMPROMETIMENTO_RENDA:
            decisao = DECISAO_REPROVADO
            motivo_principal = "COMPROMETIMENTO_EXCESSIVO"
            justificativa_interna.append(
                f"Comprometimento de renda calculado ({comprometimento:.1%}) "
                f"excede o limite máximo de {LIMITE_COMPROMETIMENTO_RENDA:.0%}."
            )
            limite_sugerido = 0.0
        else:
            justificativa_interna.append(
                f"Limite calculado: {formatar_moeda_brl(limite_sugerido)}. "
                f"Comprometimento de renda: {comprometimento:.1%} (dentro do limite). "
                f"Produto: {saida_carteira['produto_recomendado']}."
            )

    # Pontuação composta da decisão (para fins de auditoria)
    score_decisao = round(
        (score_risco * 0.60)
        + (capacidade_pagamento / 100 * 0.20)
        + ((1 if decisao == DECISAO_APROVADO else 0) * 0.20 * 1000),
        2,
    )

    # Justificativa sanitizada para o cliente
    if decisao == DECISAO_APROVADO:
        justificativa_cliente = MENSAGEM_APROVACAO_PADRAO
    else:
        justificativa_cliente = MENSAGENS_REPROVACAO.get(
            motivo_principal,
            "Sua solicitação não pôde ser aprovada neste momento. "
            "Entre em contato com nossa central para mais informações.",
        )

    # Sanitização de guardrail — garante que nenhum dado sigiloso escapou
    justificativa_cliente = Guardrails.sanitizar_justificativa_cliente(justificativa_cliente)

    # Justificativa completa para auditoria (contém dados internos)
    justificativa_auditoria = (
        f"Decisão: {decisao}. "
        f"Protocolo: {protocolo}. "
        f"Score: {score_risco}. "
        f"Risco: {classificacao_risco}. "
        f"Flags: {flags}. "
        f"Motivo: {motivo_principal}. "
        f"Raciocínio: {' | '.join(justificativa_interna)}. "
        f"Produto: {saida_carteira.get('produto_recomendado')}. "
        f"Limite: {formatar_moeda_brl(limite_sugerido) if limite_sugerido else 'N/A'}."
    )

    logger.info(
        "Decisão tomada — Protocolo: %s | Decisão: %s | Motivo: %s",
        protocolo, decisao, motivo_principal,
    )

    return {
        "protocolo_decisao": protocolo,
        "decisao": decisao,
        "limite_sugerido": limite_sugerido,
        "produto_recomendado": saida_carteira.get("produto_recomendado"),
        "id_produto": saida_carteira.get("id_produto"),
        "justificativa_cliente": justificativa_cliente,
        "justificativa_auditoria": justificativa_auditoria,
        "motivo_principal": motivo_principal,
        "score_decisao": score_decisao,
        "timestamp_decisao": timestamp,
        "id_cliente": saida_cliente.get("id_cliente"),
        "segmento_cliente": perfil.get("segmento_cliente"),
        "criterios_atendidos": perfil.get("criterios_atendidos", []),
    }
