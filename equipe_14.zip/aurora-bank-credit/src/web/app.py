"""
Aplicação Web — Aurora Bank Credit Decision System
===================================================
Interface web principal do sistema de decisão de crédito explicável.
Construída com Flask para atender formulários de solicitação de crédito
e o painel administrativo de auditoria regulatória.

Rotas principais:
  GET  /                          — Formulário de solicitação de crédito
  POST /solicitar                 — Processa a solicitação de crédito
  GET  /resultado/<protocolo>     — Exibe o resultado da decisão
  GET  /admin                     — Painel administrativo de auditoria
  GET  /admin/decisao/<protocolo> — Detalhe da trilha de auditoria
  GET  /admin/exportar            — Exportação para reguladores
  GET  /health                    — Health check do sistema
"""

import os
import sys
import logging
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file

# Adiciona o diretório raiz ao path para imports relativos
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.orchestration.orchestrator import orquestrar_decisao_credito
from src.decision.decision_engine import processar_decisao
from src.audit.audit_logger import (
    registrar_decisao,
    consultar_decisao,
    listar_decisoes,
    exportar_para_csv,
    exportar_para_json,
    verificar_integridade,
)
from src.guardrails.guardrails import GuardrailError
from src.utils.helpers import gerar_hash_cpf, formatar_moeda_brl, anonimizar_nome

# ---------------------------------------------------------------------------
# Configuração da aplicação Flask
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "aurora-bank-dev-secret-2025")
app.config["JSON_SORT_KEYS"] = False

# Filtro de template para formatação de moeda
app.jinja_env.filters["moeda_brl"] = formatar_moeda_brl

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)

# Credencial administrativa (em produção, use autenticação robusta)
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "aurora-admin-2025")


# ---------------------------------------------------------------------------
# Rotas Públicas — Interface do Cliente
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    """Página inicial com formulário de solicitação de crédito."""
    return render_template("index.html")


@app.route("/solicitar", methods=["POST"])
def solicitar_credito():
    """
    Processa a solicitação de crédito submetida pelo formulário.

    Fluxo:
    1. Extrai e valida dados do formulário
    2. Gera hash do CPF (LGPD)
    3. Invoca o orquestrador (Agente Carteira + Agente Cliente)
    4. Processa a decisão final
    5. Registra a trilha de auditoria
    6. Redireciona para a página de resultado
    """
    try:
        nome = request.form.get("nome", "").strip()
        cpf_raw = request.form.get("cpf", "").strip()
        renda_str = request.form.get("renda_declarada", "0").strip().replace(".", "").replace(",", ".")
        tipo_produto = request.form.get("tipo_produto_desejado", "").strip()
        estado_civil = request.form.get("estado_civil", "").strip()
        escolaridade = request.form.get("escolaridade", "").strip()
        aceite_termos = request.form.get("aceite_termos")

        # Validações básicas de formulário
        if not all([nome, cpf_raw, renda_str, tipo_produto]):
            flash("Por favor, preencha todos os campos obrigatórios.", "erro")
            return redirect(url_for("index"))

        if not aceite_termos:
            flash("É necessário aceitar os termos para prosseguir com a solicitação.", "erro")
            return redirect(url_for("index"))

        try:
            renda_declarada = float(renda_str)
            if renda_declarada <= 0:
                raise ValueError("Renda inválida")
        except ValueError:
            flash("Valor de renda declarada inválido. Por favor, informe um valor numérico.", "erro")
            return redirect(url_for("index"))

        # Hash do CPF — o CPF bruto NÃO é armazenado
        cpf_hash = gerar_hash_cpf(cpf_raw)

        # Dados da solicitação (sem CPF bruto)
        dados_solicitacao = {
            "nome": nome,
            "cpf_hash": cpf_hash,
            "renda_declarada": renda_declarada,
            "tipo_produto_desejado": tipo_produto,
            "estado_civil": estado_civil,
            "escolaridade": escolaridade,
        }

        # Dados anonimizados para registro de auditoria
        dados_anonimizados = {
            "nome_anonimizado": anonimizar_nome(nome),
            "cpf_hash": cpf_hash,
            "renda_declarada": renda_declarada,
            "tipo_produto_desejado": tipo_produto,
        }

        # Executa o fluxo completo de decisão
        resultado_orquestrador = orquestrar_decisao_credito(dados_solicitacao)
        resultado_decisao = processar_decisao(resultado_orquestrador)

        # Registra na trilha de auditoria
        registrar_decisao(resultado_decisao, resultado_orquestrador, dados_anonimizados)

        logger.info(
            "Solicitação processada. Protocolo: %s | Decisão: %s",
            resultado_decisao["protocolo_decisao"],
            resultado_decisao["decisao"],
        )

        return redirect(url_for("resultado", protocolo=resultado_decisao["protocolo_decisao"]))

    except GuardrailError as exc:
        logger.warning("Guardrail ativado durante solicitação: %s", exc)
        flash(str(exc), "guardrail")
        return redirect(url_for("index"))

    except Exception as exc:
        logger.error("Erro inesperado durante processamento: %s", exc)
        flash(
            "Ocorreu um erro interno ao processar sua solicitação. "
            "Por favor, tente novamente ou entre em contato com nossa central.",
            "erro",
        )
        return redirect(url_for("index"))


@app.route("/resultado/<protocolo>")
def resultado(protocolo: str):
    """
    Exibe o resultado da decisão de crédito ao cliente.
    Mostra apenas informações sanitizadas, sem dados sigilosos.
    """
    registro = consultar_decisao(protocolo)
    if not registro:
        flash("Protocolo de decisão não encontrado.", "erro")
        return redirect(url_for("index"))

    import json
    # Desserializa o output do agente carteira para exibir benefícios
    saida_carteira = {}
    try:
        saida_carteira = json.loads(registro.get("output_agente_carteira", "{}"))
    except Exception:
        pass

    return render_template(
        "resultado.html",
        registro=registro,
        saida_carteira=saida_carteira,
        formatar_moeda=formatar_moeda_brl,
    )


# ---------------------------------------------------------------------------
# Rotas Administrativas — Painel de Auditoria
# ---------------------------------------------------------------------------

@app.route("/admin")
def admin():
    """
    Painel administrativo de auditoria.
    Exige token de acesso via query string ou cookie.
    """
    token = request.args.get("token") or request.cookies.get("admin_token")
    if token != ADMIN_TOKEN:
        return render_template("admin_login.html"), 401

    # Filtros
    data_inicio = request.args.get("data_inicio", "")
    data_fim = request.args.get("data_fim", "")
    decisao_filtro = request.args.get("decisao", "")
    produto_filtro = request.args.get("produto", "")
    pagina = int(request.args.get("pagina", 1))
    por_pagina = 20
    offset = (pagina - 1) * por_pagina

    registros = listar_decisoes(
        data_inicio=data_inicio or None,
        data_fim=data_fim or None,
        decisao_filtro=decisao_filtro or None,
        produto_filtro=produto_filtro or None,
        limite=por_pagina,
        offset=offset,
    )

    total = len(listar_decisoes(
        data_inicio=data_inicio or None,
        data_fim=data_fim or None,
        decisao_filtro=decisao_filtro or None,
        produto_filtro=produto_filtro or None,
        limite=10000,
    ))

    return render_template(
        "admin.html",
        registros=registros,
        pagina=pagina,
        por_pagina=por_pagina,
        total=total,
        token=token,
        filtros={
            "data_inicio": data_inicio,
            "data_fim": data_fim,
            "decisao": decisao_filtro,
            "produto": produto_filtro,
        },
    )


@app.route("/admin/decisao/<protocolo>")
def admin_decisao(protocolo: str):
    """Exibe a trilha de auditoria completa de uma decisão específica."""
    token = request.args.get("token") or request.cookies.get("admin_token")
    if token != ADMIN_TOKEN:
        return render_template("admin_login.html"), 401

    registro = consultar_decisao(protocolo)
    if not registro:
        flash("Protocolo não encontrado.", "erro")
        return redirect(url_for("admin", token=token))

    integridade = verificar_integridade(protocolo)

    import json
    saida_carteira = {}
    saida_cliente = {}
    input_anonimizado = {}
    try:
        saida_carteira = json.loads(registro.get("output_agente_carteira", "{}"))
        saida_cliente = json.loads(registro.get("output_agente_cliente", "{}"))
        input_anonimizado = json.loads(registro.get("input_anonimizado", "{}"))
    except Exception:
        pass

    return render_template(
        "admin_decisao.html",
        registro=registro,
        saida_carteira=saida_carteira,
        saida_cliente=saida_cliente,
        input_anonimizado=input_anonimizado,
        integridade=integridade,
        token=token,
        formatar_moeda=formatar_moeda_brl,
    )


@app.route("/admin/exportar")
def admin_exportar():
    """
    Exporta registros de auditoria para CSV ou JSON para entrega a reguladores.
    """
    token = request.args.get("token") or request.cookies.get("admin_token")
    if token != ADMIN_TOKEN:
        return jsonify({"erro": "Acesso não autorizado"}), 401

    formato = request.args.get("formato", "json").lower()
    data_inicio = request.args.get("data_inicio")
    data_fim = request.args.get("data_fim")
    decisao_filtro = request.args.get("decisao")

    registros = listar_decisoes(
        data_inicio=data_inicio,
        data_fim=data_fim,
        decisao_filtro=decisao_filtro,
        limite=100000,
    )

    if formato == "csv":
        caminho = exportar_para_csv(registros)
        return send_file(caminho, as_attachment=True, download_name="auditoria_aurora_bank.csv")
    else:
        caminho = exportar_para_json(registros)
        return send_file(caminho, as_attachment=True, download_name="auditoria_aurora_bank.json")


# ---------------------------------------------------------------------------
# API de Health Check
# ---------------------------------------------------------------------------

@app.route("/health")
def health():
    """Health check do sistema para monitoramento e orquestração."""
    return jsonify({
        "status": "operacional",
        "sistema": "Aurora Bank Credit Decision System",
        "versao": "1.0.0",
        "timestamp": datetime.utcnow().isoformat() + "Z",
    })


# ---------------------------------------------------------------------------
# Ponto de entrada
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    porta = int(os.getenv("FLASK_PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    logger.info("Aurora Bank Credit Decision System iniciando na porta %d...", porta)
    app.run(host="0.0.0.0", port=porta, debug=debug)
