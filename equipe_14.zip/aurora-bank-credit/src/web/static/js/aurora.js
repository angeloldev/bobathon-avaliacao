/**
 * Aurora Bank — JavaScript da Interface
 * Sistema de Decisão de Crédito
 *
 * Funcionalidades:
 * - Máscara de CPF
 * - Máscara de valor monetário (BRL)
 * - Validação de formulário
 * - Estado de loading no botão de envio
 * - Cópia de protocolo para área de transferência
 */

document.addEventListener("DOMContentLoaded", function () {

  // -------------------------------------------------------------------------
  // Máscara de CPF
  // -------------------------------------------------------------------------
  const campoCPF = document.getElementById("cpf");
  if (campoCPF) {
    campoCPF.addEventListener("input", function () {
      let val = this.value.replace(/\D/g, "").slice(0, 11);
      if (val.length > 9) {
        val = val.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
      } else if (val.length > 6) {
        val = val.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
      } else if (val.length > 3) {
        val = val.replace(/(\d{3})(\d{1,3})/, "$1.$2");
      }
      this.value = val;
    });
  }

  // -------------------------------------------------------------------------
  // Máscara de Valor Monetário (renda_declarada)
  // -------------------------------------------------------------------------
  const campoRenda = document.getElementById("renda_declarada");
  if (campoRenda) {
    campoRenda.addEventListener("blur", function () {
      const raw = this.value.replace(/[^\d,]/g, "").replace(",", ".");
      const num = parseFloat(raw);
      if (!isNaN(num)) {
        this.value = num.toLocaleString("pt-BR", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        });
      }
    });
    campoRenda.addEventListener("focus", function () {
      // Remove formatação ao focar para edição
      this.value = this.value.replace(/\./g, "").replace(",", ".");
    });
  }

  // -------------------------------------------------------------------------
  // Validação e estado de loading no formulário
  // -------------------------------------------------------------------------
  const formSolicitacao = document.getElementById("form-solicitacao");
  if (formSolicitacao) {
    formSolicitacao.addEventListener("submit", function (event) {
      const btnEnviar = document.getElementById("btn-enviar");
      const btnTexto = btnEnviar ? btnEnviar.querySelector(".btn-texto") : null;
      const btnLoading = btnEnviar ? btnEnviar.querySelector(".btn-loading") : null;

      // Validações básicas
      const nome = document.getElementById("nome");
      const cpf = document.getElementById("cpf");
      const renda = document.getElementById("renda_declarada");
      const produto = document.getElementById("tipo_produto_desejado");
      const aceite = document.getElementById("aceite_termos");

      let valido = true;
      const erros = [];

      if (!nome || !nome.value.trim() || nome.value.trim().split(" ").length < 2) {
        erros.push("Informe seu nome completo (nome e sobrenome).");
        valido = false;
      }

      if (!cpf || cpf.value.replace(/\D/g, "").length !== 11) {
        erros.push("CPF inválido. Informe todos os 11 dígitos.");
        valido = false;
      }

      const rendaVal = parseFloat(
        (renda ? renda.value : "0").replace(/\./g, "").replace(",", ".")
      );
      if (isNaN(rendaVal) || rendaVal <= 0) {
        erros.push("Informe um valor válido de renda mensal.");
        valido = false;
      }

      if (!produto || !produto.value) {
        erros.push("Selecione o tipo de cartão desejado.");
        valido = false;
      }

      if (!aceite || !aceite.checked) {
        erros.push("Você precisa aceitar os termos para prosseguir.");
        valido = false;
      }

      if (!valido) {
        event.preventDefault();
        const mensagem = erros.join("\n");
        alert("Por favor, corrija os seguintes erros:\n\n" + mensagem);
        return;
      }

      // Ativa estado de loading
      if (btnEnviar) btnEnviar.disabled = true;
      if (btnTexto) btnTexto.hidden = true;
      if (btnLoading) btnLoading.hidden = false;
    });
  }

  // -------------------------------------------------------------------------
  // Cópia do protocolo para área de transferência
  // -------------------------------------------------------------------------
  window.copiarProtocolo = function (protocolo) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(protocolo).then(function () {
        mostrarToast("Protocolo copiado para a área de transferência!");
      });
    } else {
      // Fallback para navegadores mais antigos
      const temp = document.createElement("textarea");
      temp.value = protocolo;
      document.body.appendChild(temp);
      temp.select();
      document.execCommand("copy");
      document.body.removeChild(temp);
      mostrarToast("Protocolo copiado!");
    }
  };

  // -------------------------------------------------------------------------
  // Toast de confirmação
  // -------------------------------------------------------------------------
  function mostrarToast(mensagem) {
    const toast = document.createElement("div");
    toast.textContent = mensagem;
    toast.style.cssText = [
      "position: fixed",
      "bottom: 2rem",
      "left: 50%",
      "transform: translateX(-50%)",
      "background: #1e293b",
      "color: #fff",
      "padding: 0.75rem 1.5rem",
      "border-radius: 8px",
      "font-size: 0.9rem",
      "z-index: 9999",
      "box-shadow: 0 4px 12px rgba(0,0,0,0.2)",
      "transition: opacity 0.3s",
    ].join(";");
    document.body.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = "0";
      setTimeout(function () { document.body.removeChild(toast); }, 300);
    }, 2500);
  }

  // -------------------------------------------------------------------------
  // Auto-fechamento de alertas após 8 segundos
  // -------------------------------------------------------------------------
  document.querySelectorAll(".alerta").forEach(function (alerta) {
    setTimeout(function () {
      alerta.style.transition = "opacity 0.5s";
      alerta.style.opacity = "0";
      setTimeout(function () { alerta.remove(); }, 500);
    }, 8000);
  });

});
