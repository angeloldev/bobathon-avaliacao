"""
Utilitários — Aurora Bank Credit Decision System
=================================================
Funções auxiliares compartilhadas entre os módulos do sistema.
Inclui hashing, formatação de dados, geração de identificadores únicos
e tratamento de CPF em conformidade com a LGPD.
"""

import hashlib
import re
import uuid
from datetime import datetime, timezone


def gerar_hash_cpf(cpf: str) -> str:
    """
    Gera um hash SHA-256 irreversível do CPF informado.

    O CPF nunca é armazenado em texto plano. Apenas o hash trafega
    pelo sistema, em conformidade com a LGPD (Lei 13.709/2018).

    Args:
        cpf: CPF do cliente (com ou sem formatação).

    Returns:
        Hash SHA-256 hexadecimal do CPF limpo (apenas dígitos).
    """
    cpf_limpo = re.sub(r"[^\d]", "", cpf)
    return hashlib.sha256(cpf_limpo.encode("utf-8")).hexdigest()


def gerar_protocolo_decisao() -> str:
    """
    Gera um protocolo único para rastreamento da decisão de crédito.

    O protocolo é baseado em UUID4, garantindo unicidade global e
    adequando-se ao requisito de rastreabilidade regulatória.

    Returns:
        String no formato 'AUR-YYYYMMDD-XXXXXXXXXXXX'.
    """
    data_hoje = datetime.now(tz=timezone.utc).strftime("%Y%m%d")
    sufixo = uuid.uuid4().hex[:12].upper()
    return f"AUR-{data_hoje}-{sufixo}"


def gerar_hash_registro_auditoria(registro: dict) -> str:
    """
    Gera um hash SHA-256 de um registro de auditoria para garantir
    sua imutabilidade. Qualquer alteração posterior ao registro
    invalidará o hash, detectando adulteração.

    Args:
        registro: Dicionário com os dados do registro de auditoria.

    Returns:
        Hash SHA-256 hexadecimal do conteúdo serializado.
    """
    import json
    conteudo = json.dumps(registro, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(conteudo.encode("utf-8")).hexdigest()


def formatar_moeda_brl(valor: float) -> str:
    """
    Formata um valor numérico como moeda brasileira (R$).

    Args:
        valor: Valor numérico a ser formatado.

    Returns:
        String no formato 'R$ X.XXX,XX'.
    """
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def timestamp_agora() -> str:
    """
    Retorna o timestamp atual em formato ISO 8601 com fuso horário UTC.

    Returns:
        String ISO 8601, ex.: '2025-01-15T10:30:00+00:00'.
    """
    return datetime.now(tz=timezone.utc).isoformat()


def calcular_comprometimento_renda(
    renda_mensal: float,
    limite_sugerido: float,
    percentual_minimo_fatura: float = 0.05,
) -> float:
    """
    Calcula o comprometimento de renda estimado com o limite de crédito sugerido,
    assumindo o pagamento mínimo da fatura (padrão: 5% do limite).

    Args:
        renda_mensal: Renda mensal declarada pelo cliente.
        limite_sugerido: Limite de crédito a ser concedido.
        percentual_minimo_fatura: Percentual mínimo de pagamento (padrão BACEN: 5%).

    Returns:
        Percentual de comprometimento da renda (0.0 a 1.0).
    """
    if renda_mensal <= 0:
        return 1.0
    pagamento_minimo = limite_sugerido * percentual_minimo_fatura
    return round(pagamento_minimo / renda_mensal, 4)


def classificar_risco(score: int) -> str:
    """
    Classifica o risco do cliente com base no score interno, seguindo
    a escala de risco operacional do sistema Aurora Bank.

    Args:
        score: Score interno do cliente (0 a 1000).

    Returns:
        Classificação: 'MUITO_ALTO', 'ALTO', 'MEDIO', 'BAIXO' ou 'MUITO_BAIXO'.
    """
    if score < 200:
        return "MUITO_ALTO"
    elif score < 400:
        return "ALTO"
    elif score < 600:
        return "MEDIO"
    elif score < 800:
        return "BAIXO"
    else:
        return "MUITO_BAIXO"


def anonimizar_nome(nome: str) -> str:
    """
    Anonimiza o nome do cliente para uso em logs de auditoria públicos.
    Preserva a inicial e o sobrenome, omitindo o restante.

    Args:
        nome: Nome completo do cliente.

    Returns:
        Nome anonimizado, ex.: 'J*** S***'.
    """
    partes = nome.strip().split()
    if len(partes) == 1:
        return partes[0][0] + "***"
    return partes[0][0] + "*** " + partes[-1][0] + "***"
