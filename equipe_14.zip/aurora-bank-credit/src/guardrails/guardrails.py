"""
Módulo de Guardrails — Aurora Bank Credit Decision System
==========================================================
Responsável por validar entradas, saídas e inferências do sistema,
garantindo conformidade com políticas internas, LGPD e requisitos do
Banco Central do Brasil (BACEN).

Nenhuma decisão pode ser baseada em dados ausentes ou especulativos.
Nenhuma informação sigilosa pode ser exposta nas justificativas ao cliente.
"""

import re
from typing import Any

# ---------------------------------------------------------------------------
# Campos sigilosos que NUNCA devem aparecer em justificativas ao cliente
# ---------------------------------------------------------------------------
# Campos sigilosos que não devem ser injetados externamente via formulário do cliente.
# NOTA: 'cpf_hash' é gerado internamente após o hash do CPF bruto — é permitido internamente.
# 'cpf' é o CPF bruto que nunca deve trafegar após o hashing.
CAMPOS_SIGILOSOS = {
    "cpf",                           # CPF bruto — nunca deve trafegar (apenas o hash)
    "renda_mensal_estimada",         # Renda estimada interna do banco
    "valor_total_dividas",           # Valor exato das dívidas
    "score_externo_serasa",          # Score Serasa — dado de bureau externo
    "score_interno",                 # Score interno — política interna do banco
    "taxa_juros_rotativo_mensal",    # Taxa de juros — dado interno do banco
    "limite_minimo",                 # Critério de produto — não injetável externamente
    "limite_maximo",                 # Critério de produto — não injetável externamente
    "criterios_elegibilidade_internos",
    "margem_banco",
    "politica_risco_interna",
}

# ---------------------------------------------------------------------------
# Campos obrigatórios para que uma decisão possa ser tomada
# ---------------------------------------------------------------------------
CAMPOS_OBRIGATORIOS_CLIENTE = {
    "nome",
    "cpf_hash",
    "renda_declarada",
    "tipo_produto_desejado",
}

CAMPOS_OBRIGATORIOS_SAIDA_AGENTE_CARTEIRA = {
    "produto_recomendado",
    "faixa_limite_compativel",
    "criterios_elegibilidade_atendidos",
}

CAMPOS_OBRIGATORIOS_SAIDA_AGENTE_CLIENTE = {
    "score_risco",
    "capacidade_pagamento_estimada",
    "historico_comportamental_resumido",
    "flags_alerta",
}

# ---------------------------------------------------------------------------
# Padrões de texto que não devem aparecer em justificativas ao cliente
# ---------------------------------------------------------------------------
PADROES_PROIBIDOS_JUSTIFICATIVA = [
    r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b",   # CPF no formato XXX.XXX.XXX-YY
    r"\bscore\s+\d+\b",                  # Score numérico direto
    r"\b\d{4,}(?:\.\d{2})?\b",           # Valores monetários exatos
    r"\btaxa\s+de\s+juros\s+de\s+\d",   # Taxa de juros específica
    r"\bpolítica\s+interna\b",           # Menção a políticas internas
    r"\bsistema\s+legado\b",             # Menção ao sistema legado
]

# ---------------------------------------------------------------------------
# Mensagens padrão de rejeição por insuficiência de dados
# ---------------------------------------------------------------------------
MENSAGEM_DADOS_INSUFICIENTES = (
    "Não foi possível concluir a análise de crédito por insuficiência de dados "
    "cadastrais. Por favor, atualize seu cadastro junto ao banco e tente novamente."
)

MENSAGEM_INFERENCIA_ESPECULATIVA = (
    "O sistema identificou uma tentativa de inferência fora do escopo das bases "
    "de conhecimento autorizadas. A operação foi bloqueada por guardrail de conformidade."
)


class GuardrailError(Exception):
    """Exceção lançada quando uma violação de guardrail é detectada."""
    pass


class Guardrails:
    """
    Classe principal de guardrails do sistema de decisão de crédito.

    Todas as validações críticas passam por esta classe antes de qualquer
    processamento ou entrega de resultado ao cliente ou ao regulador.
    """

    @staticmethod
    def validar_entrada_solicitacao(dados: dict[str, Any]) -> dict[str, Any]:
        """
        Valida os dados de entrada de uma solicitação de crédito.

        Garante que todos os campos obrigatórios estejam presentes e que
        nenhum campo sigiloso seja injetado diretamente pelo cliente.

        Args:
            dados: Dicionário com os dados da solicitação de crédito.

        Returns:
            Dicionário validado com os dados da solicitação.

        Raises:
            GuardrailError: Se campos obrigatórios estiverem ausentes.
        """
        campos_ausentes = CAMPOS_OBRIGATORIOS_CLIENTE - set(dados.keys())
        if campos_ausentes:
            raise GuardrailError(
                f"Solicitação rejeitada — campos obrigatórios ausentes: "
                f"{', '.join(sorted(campos_ausentes))}. {MENSAGEM_DADOS_INSUFICIENTES}"
            )
        # Garante que campos sigilosos não foram injetados externamente
        for campo in CAMPOS_SIGILOSOS:
            if campo in dados:
                raise GuardrailError(
                    f"Campo sigiloso '{campo}' não é permitido na entrada da solicitação. "
                    "Violação de guardrail de segurança."
                )
        return dados

    @staticmethod
    def validar_saida_agente_carteira(saida: dict[str, Any]) -> dict[str, Any]:
        """
        Valida o output do Agente Carteira antes de ser usado na decisão.

        Args:
            saida: Dicionário com o output do Agente Carteira.

        Returns:
            Output validado.

        Raises:
            GuardrailError: Se campos obrigatórios estiverem ausentes.
        """
        campos_ausentes = CAMPOS_OBRIGATORIOS_SAIDA_AGENTE_CARTEIRA - set(saida.keys())
        if campos_ausentes:
            raise GuardrailError(
                f"Agente Carteira retornou output incompleto — campos ausentes: "
                f"{', '.join(sorted(campos_ausentes))}. Decisão bloqueada por guardrail."
            )
        return saida

    @staticmethod
    def validar_saida_agente_cliente(saida: dict[str, Any]) -> dict[str, Any]:
        """
        Valida o output do Agente Cliente antes de ser usado na decisão.

        Args:
            saida: Dicionário com o output do Agente Cliente.

        Returns:
            Output validado.

        Raises:
            GuardrailError: Se campos obrigatórios estiverem ausentes.
        """
        campos_ausentes = CAMPOS_OBRIGATORIOS_SAIDA_AGENTE_CLIENTE - set(saida.keys())
        if campos_ausentes:
            raise GuardrailError(
                f"Agente Cliente retornou output incompleto — campos ausentes: "
                f"{', '.join(sorted(campos_ausentes))}. Decisão bloqueada por guardrail."
            )
        return saida

    @staticmethod
    def sanitizar_justificativa_cliente(justificativa: str) -> str:
        """
        Remove qualquer informação sigilosa ou padrão proibido da justificativa
        que será entregue ao cliente.

        Args:
            justificativa: Texto da justificativa gerada pelo motor de decisão.

        Returns:
            Texto sanitizado, seguro para entrega ao cliente.
        """
        for padrao in PADROES_PROIBIDOS_JUSTIFICATIVA:
            justificativa = re.sub(padrao, "[INFORMAÇÃO OMITIDA]", justificativa, flags=re.IGNORECASE)
        # Remove menções explícitas a campos do CSV
        for campo in CAMPOS_SIGILOSOS:
            campo_legivel = campo.replace("_", " ")
            justificativa = re.sub(
                rf"\b{re.escape(campo_legivel)}\b",
                "[INFORMAÇÃO OMITIDA]",
                justificativa,
                flags=re.IGNORECASE,
            )
        return justificativa

    @staticmethod
    def bloquear_inferencia_especulativa(
        campo_ausente: str, contexto: str = ""
    ) -> None:
        """
        Lança erro padronizado quando o sistema tenta inferir dados não disponíveis
        nas bases de conhecimento autorizadas.

        Args:
            campo_ausente: Nome do campo sobre o qual haveria inferência.
            contexto: Contexto adicional sobre a tentativa de inferência.

        Raises:
            GuardrailError: Sempre, pois inferências especulativas são proibidas.
        """
        raise GuardrailError(
            f"{MENSAGEM_INFERENCIA_ESPECULATIVA} "
            f"Campo ausente: '{campo_ausente}'. Contexto: {contexto or 'não informado'}."
        )

    @staticmethod
    def validar_completude_para_decisao(
        saida_carteira: dict[str, Any],
        saida_cliente: dict[str, Any],
    ) -> bool:
        """
        Garante que ambos os agentes retornaram seus outputs antes de qualquer
        decisão ser tomada. Decisão com apenas um agente é vetada.

        Args:
            saida_carteira: Output do Agente Carteira.
            saida_cliente: Output do Agente Cliente.

        Returns:
            True se ambos os outputs estão completos.

        Raises:
            GuardrailError: Se qualquer um dos outputs estiver vazio ou ausente.
        """
        if not saida_carteira:
            raise GuardrailError(
                "Decisão vetada pelo guardrail: output do Agente Carteira está ausente. "
                "Ambos os agentes devem ter retornado outputs válidos."
            )
        if not saida_cliente:
            raise GuardrailError(
                "Decisão vetada pelo guardrail: output do Agente Cliente está ausente. "
                "Ambos os agentes devem ter retornado outputs válidos."
            )
        return True
