"""
Orquestrador — Aurora Bank Credit Decision System
==================================================
Coordena a execução sequencial e/ou paralela dos dois agentes especializados
(Agente Carteira e Agente Cliente) via IBM watsonx Orchestrate.

O orquestrador é responsável por:
- Iniciar a execução de ambos os agentes
- Consolidar os outputs em uma estrutura unificada
- Garantir que NENHUMA decisão seja tomada sem os dois outputs válidos
- Alimentar o motor de decisão final com os dados consolidados
- Registrar a trilha de raciocínio para auditoria regulatória
"""
from __future__ import annotations


import logging
import os
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from src.agents.wallet_agent import executar_agente_carteira
from src.agents.client_agent import executar_agente_cliente
from src.guardrails.guardrails import Guardrails, GuardrailError
from src.utils.helpers import timestamp_agora, gerar_hash_cpf

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configurações de integração com IBM watsonx Orchestrate
# Carregadas a partir de variáveis de ambiente
# ---------------------------------------------------------------------------
ORCHESTRATE_API_URL = os.getenv("ORCHESTRATE_API_URL", "")
ORCHESTRATE_API_KEY = os.getenv("ORCHESTRATE_API_KEY", "")
ORCHESTRATE_INSTANCE_ID = os.getenv("ORCHESTRATE_INSTANCE_ID", "")
MODO_SIMULACAO = os.getenv("ORCHESTRATE_MODO_SIMULACAO", "true").lower() == "true"


def _chamar_orchestrate_api(
    nome_agente: str,
    payload: dict,
) -> dict:
    """
    Realiza a chamada à API do IBM watsonx Orchestrate para execução de um agente.

    Em modo de simulação (ORCHESTRATE_MODO_SIMULACAO=true), executa os agentes
    localmente sem necessidade de credenciais da plataforma. Em produção, realiza
    a chamada HTTP à API real do Orchestrate.

    Args:
        nome_agente: Nome do agente a ser invocado no Orchestrate.
        payload: Dados de entrada para o agente.

    Returns:
        Resposta do agente em formato de dicionário.

    Raises:
        RuntimeError: Se a chamada à API falhar em modo produção.
    """
    if MODO_SIMULACAO:
        logger.info("[SIMULAÇÃO] Chamada ao Orchestrate para agente '%s' simulada localmente.", nome_agente)
        return {"modo": "simulacao", "agente": nome_agente, "payload": payload}

    try:
        import requests
        headers = {
            "Authorization": f"Bearer {ORCHESTRATE_API_KEY}",
            "Content-Type": "application/json",
            "X-Instance-ID": ORCHESTRATE_INSTANCE_ID,
        }
        url = f"{ORCHESTRATE_API_URL}/v1/agents/{nome_agente}/invoke"
        resposta = requests.post(url, headers=headers, json=payload, timeout=30)
        resposta.raise_for_status()
        return resposta.json()
    except Exception as exc:
        logger.error("Falha na chamada ao Orchestrate para agente '%s': %s", nome_agente, exc)
        raise RuntimeError(
            f"Falha na comunicação com IBM watsonx Orchestrate para agente '{nome_agente}': {exc}"
        ) from exc


def orquestrar_decisao_credito(
    dados_solicitacao: dict[str, Any],
) -> dict[str, Any]:
    """
    Função principal do orquestrador. Executa ambos os agentes em paralelo
    e consolida os resultados para o motor de decisão.

    Fluxo de execução:
    1. Valida a entrada via guardrails
    2. Prepara os perfis para cada agente
    3. Executa Agente Carteira e Agente Cliente em paralelo (ThreadPoolExecutor)
    4. Valida que ambos os outputs foram recebidos (guardrail crítico)
    5. Consolida os outputs em estrutura unificada
    6. Registra trilha de raciocínio do orquestrador

    Args:
        dados_solicitacao: Dicionário com dados da solicitação de crédito:
            - nome: nome do cliente
            - cpf_hash: hash SHA-256 do CPF
            - renda_declarada: renda mensal declarada
            - tipo_produto_desejado: tipo de produto solicitado

    Returns:
        Dicionário consolidado com:
            - saida_agente_carteira: output completo do Agente Carteira
            - saida_agente_cliente: output completo do Agente Cliente
            - perfil_consolidado: dados unificados para o motor de decisão
            - trilha_raciocinio_orquestrador: log do raciocínio
            - timestamp_orquestracao: momento da orquestração
            - modo_execucao: 'PARALELO' ou 'SEQUENCIAL'

    Raises:
        GuardrailError: Se a entrada for inválida ou qualquer agente falhar.
    """
    timestamp_inicio = timestamp_agora()
    logger.info("Orquestrador iniciado. Solicitação de: %s ****",
                dados_solicitacao.get("cpf_hash", "N/A")[:8])

    # --- Passo 1: Validação de entrada ---
    Guardrails.validar_entrada_solicitacao(dados_solicitacao)

    cpf_hash = dados_solicitacao["cpf_hash"]
    renda_declarada = float(dados_solicitacao.get("renda_declarada", 0))

    # Prepara o perfil do cliente para o Agente Carteira (enriquecido com dados do CSV)
    # O Agente Carteira precisa dos dados já resgatados pelo Agente Cliente
    saida_carteira: dict | None = None
    saida_cliente: dict | None = None
    erros: list[str] = []

    # --- Passo 2: Execução do Agente Cliente (deve rodar antes para enriquecer carteira) ---
    # Por design, o Agente Cliente roda primeiro para enriquecer o perfil
    # antes do matching de produto pelo Agente Carteira
    try:
        logger.info("Executando Agente Cliente...")
        _chamar_orchestrate_api("client_agent", {"cpf_hash": cpf_hash, "renda_declarada": renda_declarada})
        saida_cliente = executar_agente_cliente(
            cpf_hash=cpf_hash,
            renda_declarada=renda_declarada,
        )
        logger.info("Agente Cliente concluído com sucesso.")
    except GuardrailError as exc:
        logger.error("Guardrail ativado no Agente Cliente: %s", exc)
        raise
    except Exception as exc:
        logger.error("Falha no Agente Cliente: %s", exc)
        erros.append(f"Agente Cliente: {exc}")

    # --- Passo 3: Execução do Agente Carteira (com perfil enriquecido) ---
    if saida_cliente:
        try:
            logger.info("Executando Agente Carteira...")
            perfil_enriquecido = {
                **dados_solicitacao,
                "score_interno": saida_cliente.get("score_risco", 0),
                "flag_inadimplente": str(saida_cliente.get("flag_inadimplente", False)).upper(),
                "flag_negativado": str(saida_cliente.get("flag_negativado", False)).upper(),
                "tempo_relacionamento_banco_meses": saida_cliente.get("tempo_relacionamento_meses", 0),
            }
            _chamar_orchestrate_api("wallet_agent", perfil_enriquecido)
            saida_carteira = executar_agente_carteira(perfil_enriquecido)
            logger.info("Agente Carteira concluído com sucesso.")
        except GuardrailError as exc:
            logger.error("Guardrail ativado no Agente Carteira: %s", exc)
            raise
        except Exception as exc:
            logger.error("Falha no Agente Carteira: %s", exc)
            erros.append(f"Agente Carteira: {exc}")

    # --- Passo 4: Verificação de completude (guardrail crítico) ---
    Guardrails.validar_completude_para_decisao(saida_carteira, saida_cliente)

    # --- Passo 5: Consolidação dos outputs ---
    perfil_consolidado = {
        "cpf_hash": cpf_hash,
        "renda_declarada": renda_declarada,
        "score_risco": saida_cliente["score_risco"],
        "classificacao_risco": saida_cliente["classificacao_risco"],
        "capacidade_pagamento_estimada": saida_cliente["capacidade_pagamento_estimada"],
        "historico_pagamento": saida_cliente["classificacao_historico_pagamento"],
        "flags_alerta": saida_cliente["flags_alerta"],
        "segmento_cliente": saida_cliente["segmento_cliente"],
        "produto_recomendado": saida_carteira["produto_recomendado"],
        "id_produto": saida_carteira["id_produto"],
        "faixa_limite": saida_carteira["faixa_limite_compativel"],
        "criterios_atendidos": saida_carteira["criterios_elegibilidade_atendidos"],
    }

    trilha_raciocinio = (
        f"[{timestamp_agora()}] Orquestrador concluído. "
        f"Agente Cliente: risco='{saida_cliente['classificacao_risco']}', "
        f"flags={saida_cliente['flags_alerta']}. "
        f"Agente Carteira: produto='{saida_carteira['produto_recomendado']}', "
        f"elegíveis={saida_carteira['produtos_elegiveis_count']}. "
        f"Ambos os agentes retornaram outputs válidos. "
        f"Decisão encaminhada ao motor de decisão."
    )

    logger.info("Orquestrador concluído. Consolidação realizada com sucesso.")

    return {
        "saida_agente_carteira": saida_carteira,
        "saida_agente_cliente": saida_cliente,
        "perfil_consolidado": perfil_consolidado,
        "trilha_raciocinio_orquestrador": trilha_raciocinio,
        "timestamp_orquestracao": timestamp_inicio,
        "modo_execucao": "SEQUENCIAL",
        "erros": erros,
    }
