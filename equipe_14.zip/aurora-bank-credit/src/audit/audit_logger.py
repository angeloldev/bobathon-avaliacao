"""
Logger de Auditoria — Aurora Bank Credit Decision System
=========================================================
Responsável por registrar, persistir e exportar trilhas de auditoria
imutáveis de cada decisão de crédito.

Cada registro é protegido por hash de integridade SHA-256, garantindo
que qualquer alteração posterior seja detectável. Os registros são
suficientemente detalhados para atender solicitações do Banco Central
do Brasil (BACEN) e do PROCON.

Formatos de exportação suportados: CSV e JSON.
"""
from __future__ import annotations


import csv
import json
import logging
import os
import sqlite3
from datetime import datetime, timezone
from typing import Any

from src.utils.helpers import gerar_hash_registro_auditoria, timestamp_agora

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configurações de persistência
# ---------------------------------------------------------------------------
CAMINHO_SQLITE = os.path.join(
    os.path.dirname(__file__), "..", "..", "evidencias", "auditoria.db"
)
CAMINHO_EVIDENCIAS = os.path.join(
    os.path.dirname(__file__), "..", "..", "evidencias"
)

# Garante que a pasta de evidências existe
os.makedirs(CAMINHO_EVIDENCIAS, exist_ok=True)


def _obter_conexao() -> sqlite3.Connection:
    """
    Obtém conexão com o banco de dados SQLite de auditoria.
    Cria as tabelas necessárias caso não existam.

    Returns:
        Conexão SQLite configurada.
    """
    conn = sqlite3.connect(CAMINHO_SQLITE)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS trilha_auditoria (
            id_decisao          TEXT PRIMARY KEY,
            id_cliente          TEXT,
            cpf_hash            TEXT,
            timestamp_decisao   TEXT NOT NULL,
            decisao             TEXT NOT NULL,
            limite_sugerido     REAL,
            produto_recomendado TEXT,
            motivo_principal    TEXT,
            score_decisao       REAL,
            justificativa_auditoria TEXT,
            input_anonimizado   TEXT,
            output_agente_carteira  TEXT,
            output_agente_cliente   TEXT,
            raciocinio_orquestrador TEXT,
            hash_integridade    TEXT NOT NULL,
            operador_sistema    TEXT DEFAULT 'aurora_bank_v1',
            exportado_regulador INTEGER DEFAULT 0,
            timestamp_exportacao TEXT
        )
    """)
    conn.commit()
    return conn


def registrar_decisao(
    resultado_decisao: dict[str, Any],
    resultado_orquestrador: dict[str, Any],
    dados_solicitacao_anonimizados: dict[str, Any],
) -> str:
    """
    Registra uma decisão de crédito na trilha de auditoria imutável.

    O registro inclui todos os inputs, outputs dos agentes, raciocínio
    do orquestrador, decisão final e hash de integridade.

    Args:
        resultado_decisao: Output do motor de decisão.
        resultado_orquestrador: Output do orquestrador (outputs dos agentes).
        dados_solicitacao_anonimizados: Dados de entrada sem informações sigilosas.

    Returns:
        ID da decisão registrada (protocolo).
    """
    id_decisao = resultado_decisao["protocolo_decisao"]

    # Monta o registro base (sem o hash, para calcular depois)
    registro_base = {
        "id_decisao": id_decisao,
        "id_cliente": resultado_decisao.get("id_cliente"),
        "cpf_hash": dados_solicitacao_anonimizados.get("cpf_hash"),
        "timestamp_decisao": resultado_decisao["timestamp_decisao"],
        "decisao": resultado_decisao["decisao"],
        "limite_sugerido": resultado_decisao.get("limite_sugerido", 0),
        "produto_recomendado": resultado_decisao.get("produto_recomendado"),
        "motivo_principal": resultado_decisao.get("motivo_principal"),
        "score_decisao": resultado_decisao.get("score_decisao"),
        "justificativa_auditoria": resultado_decisao.get("justificativa_auditoria"),
        "input_anonimizado": json.dumps(dados_solicitacao_anonimizados, ensure_ascii=False),
        "output_agente_carteira": json.dumps(
            resultado_orquestrador.get("saida_agente_carteira", {}), ensure_ascii=False
        ),
        "output_agente_cliente": json.dumps(
            resultado_orquestrador.get("saida_agente_cliente", {}), ensure_ascii=False
        ),
        "raciocinio_orquestrador": resultado_orquestrador.get("trilha_raciocinio_orquestrador"),
        "operador_sistema": "aurora_bank_v1",
    }

    # Calcula o hash de integridade APÓS construir o registro completo
    hash_integridade = gerar_hash_registro_auditoria(registro_base)
    registro_base["hash_integridade"] = hash_integridade

    # Persiste no SQLite
    with _obter_conexao() as conn:
        conn.execute("""
            INSERT OR IGNORE INTO trilha_auditoria (
                id_decisao, id_cliente, cpf_hash, timestamp_decisao, decisao,
                limite_sugerido, produto_recomendado, motivo_principal, score_decisao,
                justificativa_auditoria, input_anonimizado, output_agente_carteira,
                output_agente_cliente, raciocinio_orquestrador, hash_integridade,
                operador_sistema
            ) VALUES (
                :id_decisao, :id_cliente, :cpf_hash, :timestamp_decisao, :decisao,
                :limite_sugerido, :produto_recomendado, :motivo_principal, :score_decisao,
                :justificativa_auditoria, :input_anonimizado, :output_agente_carteira,
                :output_agente_cliente, :raciocinio_orquestrador, :hash_integridade,
                :operador_sistema
            )
        """, registro_base)

    # Persiste também em JSON na pasta evidencias (cópia redundante para reguladores)
    caminho_json = os.path.join(CAMINHO_EVIDENCIAS, f"{id_decisao}.json")
    with open(caminho_json, "w", encoding="utf-8") as arq:
        json.dump(registro_base, arq, ensure_ascii=False, indent=2, default=str)

    logger.info("Auditoria registrada. Protocolo: %s | Hash: %s...", id_decisao, hash_integridade[:16])
    return id_decisao


def consultar_decisao(id_decisao: str) -> dict | None:
    """
    Consulta um registro de auditoria pelo protocolo de decisão.

    Args:
        id_decisao: Protocolo da decisão (ex.: 'AUR-20250115-XXXXXXXXXXXX').

    Returns:
        Dicionário com o registro completo, ou None se não encontrado.
    """
    with _obter_conexao() as conn:
        cursor = conn.execute(
            "SELECT * FROM trilha_auditoria WHERE id_decisao = ?", (id_decisao,)
        )
        linha = cursor.fetchone()
        if linha:
            return dict(linha)
    return None


def listar_decisoes(
    id_cliente: str | None = None,
    data_inicio: str | None = None,
    data_fim: str | None = None,
    decisao_filtro: str | None = None,
    produto_filtro: str | None = None,
    limite: int = 100,
    offset: int = 0,
) -> list[dict]:
    """
    Lista registros de auditoria com filtros opcionais.

    Args:
        id_cliente: Hash do CPF do cliente para filtrar.
        data_inicio: Data inicial no formato ISO 8601.
        data_fim: Data final no formato ISO 8601.
        decisao_filtro: 'APROVADO' ou 'REPROVADO'.
        produto_filtro: Nome do produto para filtrar.
        limite: Número máximo de registros retornados.
        offset: Deslocamento para paginação.

    Returns:
        Lista de dicionários com os registros encontrados.
    """
    clausulas = []
    params: list = []

    if id_cliente:
        clausulas.append("cpf_hash = ?")
        params.append(id_cliente)
    if data_inicio:
        clausulas.append("timestamp_decisao >= ?")
        params.append(data_inicio)
    if data_fim:
        clausulas.append("timestamp_decisao <= ?")
        params.append(data_fim)
    if decisao_filtro:
        clausulas.append("decisao = ?")
        params.append(decisao_filtro.upper())
    if produto_filtro:
        clausulas.append("produto_recomendado LIKE ?")
        params.append(f"%{produto_filtro}%")

    where = f"WHERE {' AND '.join(clausulas)}" if clausulas else ""
    query = f"SELECT * FROM trilha_auditoria {where} ORDER BY timestamp_decisao DESC LIMIT ? OFFSET ?"
    params.extend([limite, offset])

    with _obter_conexao() as conn:
        cursor = conn.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]


def exportar_para_csv(
    registros: list[dict],
    caminho_saida: str | None = None,
) -> str:
    """
    Exporta registros de auditoria para CSV, adequado para entrega a
    órgãos reguladores (BACEN, PROCON).

    Args:
        registros: Lista de registros de auditoria.
        caminho_saida: Caminho do arquivo CSV de saída. Se None, gera nome automático.

    Returns:
        Caminho do arquivo CSV gerado.
    """
    if not caminho_saida:
        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
        caminho_saida = os.path.join(CAMINHO_EVIDENCIAS, f"exportacao_regulatoria_{timestamp}.csv")

    if not registros:
        logger.warning("Nenhum registro para exportar.")
        return caminho_saida

    campos = list(registros[0].keys())
    with open(caminho_saida, "w", newline="", encoding="utf-8") as arq:
        escritor = csv.DictWriter(arq, fieldnames=campos)
        escritor.writeheader()
        escritor.writerows(registros)

    logger.info("Exportação CSV gerada: %s (%d registros).", caminho_saida, len(registros))
    return caminho_saida


def exportar_para_json(
    registros: list[dict],
    caminho_saida: str | None = None,
) -> str:
    """
    Exporta registros de auditoria para JSON, adequado para entrega a
    sistemas regulatórios do Banco Central do Brasil.

    Args:
        registros: Lista de registros de auditoria.
        caminho_saida: Caminho do arquivo JSON de saída.

    Returns:
        Caminho do arquivo JSON gerado.
    """
    if not caminho_saida:
        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
        caminho_saida = os.path.join(CAMINHO_EVIDENCIAS, f"exportacao_regulatoria_{timestamp}.json")

    exportacao = {
        "sistema": "Aurora Bank Credit Decision System",
        "versao": "1.0.0",
        "timestamp_exportacao": timestamp_agora(),
        "total_registros": len(registros),
        "registros": registros,
    }

    with open(caminho_saida, "w", encoding="utf-8") as arq:
        json.dump(exportacao, arq, ensure_ascii=False, indent=2, default=str)

    logger.info("Exportação JSON gerada: %s (%d registros).", caminho_saida, len(registros))
    return caminho_saida


# Campos que compõem o registro_base original para fins de verificação de hash
_CAMPOS_HASH = [
    "id_decisao", "id_cliente", "cpf_hash", "timestamp_decisao", "decisao",
    "limite_sugerido", "produto_recomendado", "motivo_principal", "score_decisao",
    "justificativa_auditoria", "input_anonimizado", "output_agente_carteira",
    "output_agente_cliente", "raciocinio_orquestrador", "operador_sistema",
]


def verificar_integridade(id_decisao: str) -> dict:
    """
    Verifica a integridade de um registro de auditoria.

    Estratégia: usa o arquivo JSON individual como fonte primária de verdade
    (gerado no momento da decisão), pois o SQLite pode alterar tipos durante
    a serialização/desserialização. Se o JSON não existir, recorre ao SQLite.

    Args:
        id_decisao: Protocolo da decisão a verificar.

    Returns:
        Dict com 'integro' (bool) e 'detalhes' (str).
    """
    registro_db = consultar_decisao(id_decisao)
    if not registro_db:
        return {"integro": False, "detalhes": "Registro não encontrado."}

    hash_armazenado = registro_db.get("hash_integridade", "")

    # Tenta verificar a partir do JSON individual (fonte mais fiel)
    caminho_json = os.path.join(CAMINHO_EVIDENCIAS, f"{id_decisao}.json")
    if os.path.exists(caminho_json):
        with open(caminho_json, encoding="utf-8") as arq:
            registro_json = json.load(arq)
        registro_para_hash = {k: registro_json.get(k) for k in _CAMPOS_HASH}
        hash_recalculado = gerar_hash_registro_auditoria(registro_para_hash)
    else:
        # Fallback: usa o SQLite (pode haver pequenas diferenças de tipo)
        registro_para_hash = {k: registro_db.get(k) for k in _CAMPOS_HASH}
        hash_recalculado = gerar_hash_registro_auditoria(registro_para_hash)

    if hash_armazenado == hash_recalculado:
        return {"integro": True, "detalhes": "Hash verificado. Registro íntegro."}
    else:
        return {
            "integro": False,
            "detalhes": (
                f"ALERTA: hash divergente! Possível adulteração detectada. "
                f"Hash original: {hash_armazenado[:16]}... "
                f"Hash recalculado: {hash_recalculado[:16]}..."
            ),
        }
