"""
Agente Carteira (wallet_agent) — Aurora Bank Credit Decision System
====================================================================
Agente especializado para uso no IBM watsonx Orchestrate.

Responsabilidade: verificar os produtos do banco, as linhas de crédito
disponíveis e realizar o matching do perfil do cliente com o melhor
produto de cartão de crédito disponível na base de conhecimento.

IMPORTANTE: este agente NUNCA realiza inferências fora do escopo da
base de conhecimento de produtos (produtos_banco.csv). Toda recomendação
deve ser rastreável a um registro existente na base.
"""

import csv
import os
import logging
from typing import Any

from src.guardrails.guardrails import Guardrails, GuardrailError
from src.utils.helpers import classificar_risco

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

# Caminho padrão da base de conhecimento de produtos
CAMINHO_PRODUTOS_CSV = os.path.join(
    os.path.dirname(__file__), "..", "knowledge_base", "produtos_banco.csv"
)


def carregar_produtos(caminho_csv: str = CAMINHO_PRODUTOS_CSV) -> list[dict]:
    """
    Carrega a base de conhecimento de produtos bancários a partir do CSV.

    Args:
        caminho_csv: Caminho para o arquivo produtos_banco.csv.

    Returns:
        Lista de dicionários representando cada produto ativo.

    Raises:
        FileNotFoundError: Se o arquivo CSV não for encontrado.
    """
    produtos = []
    with open(caminho_csv, newline="", encoding="utf-8") as arq:
        leitor = csv.DictReader(arq)
        for linha in leitor:
            if linha.get("flag_ativo", "").strip().upper() in ("TRUE", "1", "SIM"):
                produtos.append(linha)
    logger.info("Base de produtos carregada: %d produtos ativos.", len(produtos))
    return produtos


def _produto_elegivel(produto: dict, perfil_cliente: dict) -> bool:
    """
    Verifica se o cliente é elegível para um determinado produto de cartão.

    A elegibilidade é verificada exclusivamente com base nos campos presentes
    na base de conhecimento. Nenhuma inferência especulativa é realizada.

    Args:
        produto: Dicionário com os dados do produto bancário.
        perfil_cliente: Dicionário com o perfil do cliente (já enriquecido).

    Returns:
        True se o cliente atende aos critérios de elegibilidade do produto.
    """
    try:
        renda_minima = float(produto.get("renda_minima_exigida", 0))
        score_minimo = int(produto.get("score_minimo_exigido", 0))
    except (ValueError, TypeError):
        logger.warning("Produto '%s' possui valores inválidos de elegibilidade.", produto.get("nome_produto"))
        return False

    renda_cliente = float(perfil_cliente.get("renda_declarada", 0))
    score_cliente = int(perfil_cliente.get("score_interno", 0))
    flag_inadimplente = str(perfil_cliente.get("flag_inadimplente", "FALSE")).upper()
    flag_negativado = str(perfil_cliente.get("flag_negativado", "FALSE")).upper()

    # Restrições absolutas: inadimplente ou negativado não são elegíveis a nenhum produto premium
    segmento_alvo = produto.get("segmento_alvo", "").upper()
    if flag_inadimplente in ("TRUE", "1", "SIM") and segmento_alvo in ("PREMIUM", "EXCLUSIVO"):
        return False
    if flag_negativado in ("TRUE", "1", "SIM"):
        return False

    return renda_cliente >= renda_minima and score_cliente >= score_minimo


def executar_agente_carteira(
    perfil_cliente: dict[str, Any],
    caminho_csv: str = CAMINHO_PRODUTOS_CSV,
) -> dict[str, Any]:
    """
    Função principal do Agente Carteira. Executa o matching entre o perfil
    do cliente e os produtos disponíveis na base de conhecimento.

    Conforme política de guardrails, NENHUMA recomendação pode ser feita
    caso não exista produto elegível na base de conhecimento.

    Args:
        perfil_cliente: Dicionário com os dados do perfil do cliente,
                        enriquecido com dados do Agente Cliente.
        caminho_csv: Caminho para a base de conhecimento de produtos.

    Returns:
        Dicionário com:
            - produto_recomendado: nome do produto mais adequado
            - id_produto: identificador do produto
            - faixa_limite_compativel: dict com limite_minimo e limite_maximo
            - criterios_elegibilidade_atendidos: lista de critérios cumpridos
            - segmento_alvo: segmento do produto recomendado
            - beneficios: benefícios do produto
            - score_risco_produto: classificação de risco para o produto
            - produtos_elegiveis_count: total de produtos elegíveis encontrados
            - justificativa_produto: texto explicativo para auditoria

    Raises:
        GuardrailError: Se nenhum produto elegível for encontrado.
    """
    logger.info("Agente Carteira iniciado para cliente (hash): %s",
                perfil_cliente.get("cpf_hash", "N/A")[:8] + "****")

    produtos = carregar_produtos(caminho_csv)
    produtos_elegiveis = []

    for produto in produtos:
        if _produto_elegivel(produto, perfil_cliente):
            produtos_elegiveis.append(produto)

    if not produtos_elegiveis:
        logger.warning("Nenhum produto elegível encontrado para o perfil analisado.")
        raise GuardrailError(
            "Agente Carteira: nenhum produto de cartão de crédito elegível "
            "foi identificado para o perfil apresentado. Decisão não pode ser "
            "tomada com base na base de conhecimento disponível."
        )

    # Ordena por score_minimo (produto mais compatível = maior exigência atendida)
    produtos_elegiveis.sort(
        key=lambda p: int(p.get("score_minimo_exigido", 0)),
        reverse=True,
    )
    produto_recomendado = produtos_elegiveis[0]

    classificacao_risco = classificar_risco(int(perfil_cliente.get("score_interno", 0)))

    # Constrói a lista de critérios atendidos (sem expor valores exatos de threshold)
    criterios_atendidos = []
    if float(perfil_cliente.get("renda_declarada", 0)) >= float(produto_recomendado.get("renda_minima_exigida", 0)):
        criterios_atendidos.append("Renda compatível com o perfil do produto")
    if int(perfil_cliente.get("score_interno", 0)) >= int(produto_recomendado.get("score_minimo_exigido", 0)):
        criterios_atendidos.append("Histórico de crédito adequado")
    if str(perfil_cliente.get("flag_negativado", "FALSE")).upper() not in ("TRUE", "1", "SIM"):
        criterios_atendidos.append("Ausência de restrições cadastrais ativas")
    if int(perfil_cliente.get("tempo_relacionamento_banco_meses", 0)) > 0:
        criterios_atendidos.append("Cliente com relacionamento ativo com o banco")

    saida = {
        "produto_recomendado": produto_recomendado.get("nome_produto"),
        "id_produto": produto_recomendado.get("id_produto"),
        "faixa_limite_compativel": {
            "limite_minimo": float(produto_recomendado.get("limite_minimo", 0)),
            "limite_maximo": float(produto_recomendado.get("limite_maximo", 0)),
        },
        "criterios_elegibilidade_atendidos": criterios_atendidos,
        "segmento_alvo": produto_recomendado.get("segmento_alvo"),
        "beneficios": produto_recomendado.get("beneficios"),
        "score_risco_produto": classificacao_risco,
        "produtos_elegiveis_count": len(produtos_elegiveis),
        "justificativa_produto": (
            f"O produto '{produto_recomendado.get('nome_produto')}' foi selecionado "
            f"por ser o mais adequado ao perfil do cliente dentro da base de "
            f"produtos ativos, atendendo {len(criterios_atendidos)} critério(s) "
            f"de elegibilidade verificados."
        ),
    }

    # Validação de guardrail na saída
    Guardrails.validar_saida_agente_carteira(saida)

    logger.info(
        "Agente Carteira concluído. Produto recomendado: '%s'. Elegíveis: %d.",
        saida["produto_recomendado"],
        saida["produtos_elegiveis_count"],
    )
    return saida
