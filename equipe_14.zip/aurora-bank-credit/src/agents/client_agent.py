"""
Agente Cliente (client_agent) — Aurora Bank Credit Decision System
===================================================================
Agente especializado para uso no IBM watsonx Orchestrate.

Responsabilidade: analisar o perfil histórico do cliente, comportamento
de gastos, capacidade de pagamento e indicadores de risco com base
exclusivamente na base de conhecimento de clientes (clientes.csv).

IMPORTANTE: este agente NUNCA realiza inferências sobre dados ausentes
na base. Quando o cliente não é encontrado, o agente retorna status
de dados insuficientes para que o guardrail bloqueie a decisão.
"""
from __future__ import annotations

import csv
import os
import logging
from typing import Any, Optional

from src.guardrails.guardrails import Guardrails, GuardrailError
from src.utils.helpers import classificar_risco, calcular_comprometimento_renda

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

# Caminho padrão da base de conhecimento de clientes
CAMINHO_CLIENTES_CSV = os.path.join(
    os.path.dirname(__file__), "..", "knowledge_base", "clientes.csv"
)

# Limiares de classificação de comportamento de pagamento
LIMIAR_PAGAMENTO_EXCELENTE = 0.95   # ≥95% de pagamentos em dia
LIMIAR_PAGAMENTO_BOM = 0.80         # ≥80%
LIMIAR_PAGAMENTO_REGULAR = 0.60     # ≥60%
# Abaixo de 60% = comportamento RUIM

# Comprometimento máximo de renda permitido pelo sistema (política interna)
COMPROMETIMENTO_MAXIMO_RENDA = 0.30  # 30%


def carregar_cliente(
    cpf_hash: str,
    caminho_csv: str = CAMINHO_CLIENTES_CSV,
) -> dict | None:
    """
    Busca o cliente na base de conhecimento pelo hash do CPF.

    Args:
        cpf_hash: Hash SHA-256 do CPF do cliente.
        caminho_csv: Caminho para o arquivo clientes.csv.

    Returns:
        Dicionário com os dados do cliente, ou None se não encontrado.
    """
    with open(caminho_csv, newline="", encoding="utf-8") as arq:
        leitor = csv.DictReader(arq)
        for linha in leitor:
            if linha.get("cpf_hash", "").strip() == cpf_hash.strip():
                return linha
    return None


def _classificar_historico_pagamento(percentual_str: str) -> str:
    """
    Classifica o histórico de pagamento do cliente com base no percentual
    de pagamentos realizados em dia nos últimos 12 meses.

    Args:
        percentual_str: Percentual como string (ex.: '0.92' ou '92').

    Returns:
        Classificação: 'EXCELENTE', 'BOM', 'REGULAR' ou 'RUIM'.
    """
    try:
        valor = float(percentual_str)
        # Normaliza: se o valor for > 1, assume que está em percentual (ex.: 92 → 0.92)
        if valor > 1:
            valor = valor / 100
    except (ValueError, TypeError):
        return "INDISPONÍVEL"

    if valor >= LIMIAR_PAGAMENTO_EXCELENTE:
        return "EXCELENTE"
    elif valor >= LIMIAR_PAGAMENTO_BOM:
        return "BOM"
    elif valor >= LIMIAR_PAGAMENTO_REGULAR:
        return "REGULAR"
    else:
        return "RUIM"


def _construir_flags_alerta(cliente: dict) -> list[str]:
    """
    Identifica e lista os flags de alerta no perfil do cliente.

    Args:
        cliente: Dicionário com os dados do cliente da base de conhecimento.

    Returns:
        Lista de strings com os alertas identificados.
    """
    flags = []

    if str(cliente.get("flag_inadimplente", "FALSE")).upper() in ("TRUE", "1", "SIM"):
        flags.append("CLIENTE_INADIMPLENTE")

    if str(cliente.get("flag_negativado", "FALSE")).upper() in ("TRUE", "1", "SIM"):
        flags.append("CLIENTE_NEGATIVADO")

    qtd_dividas = int(cliente.get("qtd_dividas_ativas", 0))
    if qtd_dividas >= 3:
        flags.append("MULTIPLAS_DIVIDAS_ATIVAS")

    historico = float(cliente.get("historico_pagamento_ultimos_12m", 1))
    if historico > 1:
        historico = historico / 100
    if historico < LIMIAR_PAGAMENTO_REGULAR:
        flags.append("HISTORICO_PAGAMENTO_INADEQUADO")

    score_externo = int(cliente.get("score_externo_serasa", 0))
    if score_externo < 300:
        flags.append("SCORE_EXTERNO_CRITICO")

    return flags


def executar_agente_cliente(
    cpf_hash: str,
    renda_declarada: float,
    caminho_csv: str = CAMINHO_CLIENTES_CSV,
) -> dict[str, Any]:
    """
    Função principal do Agente Cliente. Analisa o perfil do cliente
    com base na base de conhecimento e retorna indicadores de risco e
    capacidade de pagamento.

    Conforme política de guardrails, SE o cliente não for encontrado na
    base de conhecimento, a decisão NÃO pode ser tomada.

    Args:
        cpf_hash: Hash SHA-256 do CPF do cliente para busca na base.
        renda_declarada: Renda mensal declarada pelo cliente na solicitação.
        caminho_csv: Caminho para a base de conhecimento de clientes.

    Returns:
        Dicionário com:
            - score_risco: score interno do cliente (0-1000)
            - classificacao_risco: string de classificação de risco
            - capacidade_pagamento_estimada: valor máximo estimado de crédito
            - historico_comportamental_resumido: resumo do comportamento
            - flags_alerta: lista de flags de risco
            - segmento_cliente: segmento do cliente
            - tempo_relacionamento_meses: tempo de relacionamento com o banco
            - qtd_produtos_banco: quantidade de produtos ativos
            - id_cliente: identificador do cliente na base

    Raises:
        GuardrailError: Se o cliente não for encontrado na base de conhecimento.
    """
    logger.info("Agente Cliente iniciado para CPF hash: %s****", cpf_hash[:8])

    cliente = carregar_cliente(cpf_hash, caminho_csv)

    if cliente is None:
        logger.warning("Cliente não encontrado na base de conhecimento. CPF hash: %s****", cpf_hash[:8])
        raise GuardrailError(
            "Agente Cliente: cliente não localizado na base de conhecimento. "
            "Não é possível realizar análise de crédito sem dados cadastrais "
            "verificados. Decisão bloqueada por guardrail de integridade de dados."
        )

    score_interno = int(cliente.get("score_interno", 0))
    classificacao = classificar_risco(score_interno)
    historico_pct = cliente.get("historico_pagamento_ultimos_12m", "0")
    classificacao_historico = _classificar_historico_pagamento(historico_pct)
    flags_alerta = _construir_flags_alerta(cliente)

    # Capacidade de pagamento: menor entre renda declarada e estimada × fator de risco
    renda_estimada = float(cliente.get("renda_mensal_estimada", renda_declarada))
    renda_base = min(renda_declarada, renda_estimada)
    fator_risco = {
        "MUITO_BAIXO": 0.40,
        "BAIXO": 0.35,
        "MEDIO": 0.28,
        "ALTO": 0.20,
        "MUITO_ALTO": 0.10,
    }.get(classificacao, 0.20)
    capacidade_pagamento = round(renda_base * fator_risco * 12, 2)  # Limite anualizado

    # Constrói o resumo comportamental (sem dados sigilosos)
    resumo_comportamental = (
        f"O cliente possui histórico de pagamentos classificado como "
        f"'{classificacao_historico}' com base nos últimos 12 meses. "
        f"Perfil de risco avaliado como '{classificacao}'. "
        f"Relacionamento com o banco de "
        f"{cliente.get('tempo_relacionamento_banco_meses', 0)} meses. "
        f"Total de {cliente.get('qtd_produtos_banco', 0)} produto(s) ativo(s) no banco."
    )

    saida = {
        "score_risco": score_interno,
        "classificacao_risco": classificacao,
        "capacidade_pagamento_estimada": capacidade_pagamento,
        "historico_comportamental_resumido": resumo_comportamental,
        "flags_alerta": flags_alerta,
        "segmento_cliente": cliente.get("segmento_cliente", "PADRÃO"),
        "tempo_relacionamento_meses": int(cliente.get("tempo_relacionamento_banco_meses", 0)),
        "qtd_produtos_banco": int(cliente.get("qtd_produtos_banco", 0)),
        "id_cliente": cliente.get("id_cliente"),
        "classificacao_historico_pagamento": classificacao_historico,
        "flag_inadimplente": str(cliente.get("flag_inadimplente", "FALSE")).upper() in ("TRUE", "1", "SIM"),
        "flag_negativado": str(cliente.get("flag_negativado", "FALSE")).upper() in ("TRUE", "1", "SIM"),
    }

    # Validação de guardrail na saída
    Guardrails.validar_saida_agente_cliente(saida)

    logger.info(
        "Agente Cliente concluído. Risco: '%s'. Flags: %s. Capacidade: R$%.2f.",
        saida["classificacao_risco"],
        saida["flags_alerta"],
        saida["capacidade_pagamento_estimada"],
    )
    return saida
