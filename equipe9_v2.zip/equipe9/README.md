# AuroraCard — Sistema de Análise de Crédito Explicável

> **Aurora Bank · Hackathon BRBobathon**  
> Equipe: AuroraBank Challenge

---

## O Problema

O Aurora Bank opera um sistema legado de 22 anos que processa **4 milhões de decisões de crédito por mês** sem emitir nenhuma justificativa. Clientes recusados não sabem o motivo. Clientes aprovados não entendem os critérios. O regulador não recebe trilha auditável. A carta de decisão simplesmente dizia: *"não pode ser explicada nem contestada"*.

**AuroraCard resolve isso.**

---

## O Que a Solução Faz

1. Recebe um pedido de cartão de crédito com CPF e nome do solicitante
2. Consulta o histórico, score e capacidade de pagamento do cliente (**AgenteCliente**)
3. Verifica produtos disponíveis, limites e elegibilidade (**AgenteCarteira**)
4. Consolida os dados e emite uma decisão: **APROVADO / REPROVADO / ANÁLISE ADICIONAL**
5. Gera uma **justificativa em linguagem simples** que o cliente entende
6. Registra uma **trilha de auditoria** completa com todos os dados usados

---

## Arquitetura de Agentes

```
Solicitação de Cartão
        │
        ▼
┌─────────────────────┐
│   AuroraCard        │  ← Orquestrador (IBM watsonx Orchestrate)
│   (Orquestrador)    │
└─────────┬─────┬─────┘
          │     │
    ┌─────▼──┐ ┌▼──────────────┐
    │Agente  │ │AgenteCarteira │
    │Cliente │ │               │
    └─────┬──┘ └──────┬────────┘
          │           │
          └─────┬─────┘
                ▼
        Decisão Justificada
        + Trilha de Auditoria
```

### Agentes

| Agente | Papel | Arquivo behavior |
|---|---|---|
| **AuroraCard** | Orquestrador — coordena, consolida e decide | [`behavior_auroracard_orchestrator.md`](behavior_auroracard_orchestrator.md) |
| **AgenteCliente** | Analisa histórico, score e capacidade de pagamento | [`behavior_agentecliente.md`](behavior_agentecliente.md) |
| **AgenteCarteira** | Verifica produtos, limites e elegibilidade | [`behavior_agentecarteira.md`](behavior_agentecarteira.md) |

---

## Como Funciona

### Fluxo de uma Decisão

```
1. Usuário envia: { cpf, nome, produto_solicitado }
2. AuroraCard aciona AgenteCliente(cpf, nome)
3. AuroraCard aciona AgenteCarteira(perfil, renda, score, dívidas)
4. AuroraCard aguarda retorno dos dois subagentes
5. AuroraCard consolida e emite decisão com justificativa
6. Registro de auditoria gerado com timestamp
```

### Regra de Limite de Crédito

```
capacidade_pagamento = renda_mensal × 0.30
limite_sugerido = MIN(capacidade_pagamento × 3, limite_máximo_do_produto)

Se dívidas_ativas = Sim:
  limite_sugerido = limite_sugerido × 0.60
```

### Produtos Disponíveis

| Produto | Score Mínimo | Renda Mínima | Limite Máximo |
|---|---|---|---|
| Aurora Básico | 500 | R$ 1.500 | R$ 1.500 |
| Aurora Plus | 600 | R$ 3.000 | R$ 5.000 |
| Aurora Gold | 700 | R$ 8.000 | R$ 15.000 |
| Aurora Platinum | 750 | R$ 15.000 | R$ 40.000 |
| Aurora Black | 800 | R$ 30.000 | R$ 100.000 |

---

## Uso do IBM Bob e Orchestrate

### IBM Bob
- Utilizado para **criar e iterar os behavior files** de cada agente
- Geração da **base de dados mock** (`base_clientes_aurorabank.xlsx`) com dados fictícios para teste
- Desenvolvimento do fluxo de orquestração e das regras de negócio

### IBM watsonx Orchestrate
- **AuroraCard** é configurado como agente orquestrador no Orchestrate
- **AgenteCliente** e **AgenteCarteira** são subagentes conectados via tool calls sequenciais
- O Orchestrate gerencia o fluxo: chama os dois subagentes, aguarda retorno de ambos e passa o contexto consolidado ao orquestrador para decisão final
- Cada agente possui seu `behavior.md` que define instruções, regras e formato de saída

---

## Estrutura do Repositório

```
auroraBank/
├── README.md                                  ← este arquivo
├── behavior_auroracard_orchestrator.md        ← behavior do orquestrador
├── behavior_agentecliente.md                  ← behavior do AgenteCliente
├── behavior_agentecarteira.md                 ← behavior do AgenteCarteira
├── mock/
│   └── base_clientes_aurorabank.xlsx          ← base de clientes (CPF como PK)
├── evidencias/                                ← prints e exportações do Orchestrate
└── src/                                       ← código auxiliar (se houver)
```

---

## Base de Clientes Mock

Arquivo: [`mock/base_clientes_aurorabank.xlsx`](mock/base_clientes_aurorabank.xlsx)

**Chave primária:** coluna `cpf` (formato `XXX.XXX.XXX-XX` — dados fictícios para teste)

| Coluna | Descrição |
|---|---|
| `cpf` | **PK** — CPF fictício do cliente |
| `nome` | Nome completo |
| `idade` | Idade em anos |
| `renda_mensal` | Renda mensal em R$ |
| `patrimonio` | Patrimônio total em R$ |
| `score_interno` | Score de crédito interno (0–1000) |
| `historico_pagamento` | `excelente` / `bom` / `regular` / `ruim` |
| `dividas_ativas` | `Sim` ou `Não` |
| `perfil_comportamental` | Conservador / Moderado / Arrojado / Sofisticado |
| `horizonte` | Curto / Médio / Longo / Variável |
| `observacoes` | Notas comportamentais do cliente |

**15 clientes fictícios** disponíveis para teste, cobrindo todos os perfis e cenários (aprovado, reprovado, análise adicional, com e sem dívidas).

---

## Princípios de Design

- **Funciona > ambicioso** — escopo pequeno e completo
- **Incerteza declarada** — agente que inventa perde pontos; dado ausente é declarado como ausente
- **Auditabilidade total** — cada decisão registra os dados usados, agentes consultados e regra aplicada
- **Linguagem do cliente** — justificativa em português simples, sem jargão técnico
- **CPF nunca exposto** — sempre mascarado como `***.***.XXX-**`

---

## Equipe

Aurora Bank Challenge — BRBobathon
