# Aurora Bank — Sistema de Decisão de Crédito Transparente

**Grupo 2237**
Andre Bezerra dos Santos · Caroline de Albuquerque Duarte · Gilson Fidelis de Santana · Luciano Holanda Porto

---

## O Problema

O Aurora Bank opera um sistema legado de concessão de crédito há 22 anos. O sistema decide sozinho — aprova, recusa, define limites — sem registrar o raciocínio. Resultado: 4 milhões de decisões por mês, 0 justificativas entregues ao regulador, e cartas que dizem ao cliente "a decisão não pode ser explicada nem contestada".

## A Solução

Um conjunto de agentes com responsabilidades claras que transformam um pedido de crédito em uma decisão transparente, explicável e auditável.

Cada passo do raciocínio é registrado. O cliente recebe uma explicação em linguagem simples. O regulador recebe uma trilha auditável completa.

---

## Arquitetura

```
Pedido de Crédito (POST /credito)
        │
        ▼
  AgenteCliente    → avalia perfil, histórico e capacidade de pagamento → score
        │
        ▼
  AgenteCarteira   → identifica produto elegível e limite máximo
        │
        ▼
  AgenteDecisor    → aplica regras transparentes → aprovado ou recusado
        │
        ▼
  AgenteAuditoria  → registra todas as etapas → trilha auditável
        │
        ▼
  Resposta Final   → { decisao, limite, explicacao_cliente, auditoria }
```

### Os Quatro Agentes

| Agente | Responsabilidade | Saída |
|---|---|---|
| **AgenteCliente** | Avalia perfil financeiro, histórico, comportamento e calcula score | `{ score, risco, justificativa }` |
| **AgenteCarteira** | Identifica produto de crédito adequado e limite máximo elegível | `{ produto_indicado, limite_maximo, justificativa }` |
| **AgenteDecisor** | Aplica regras transparentes e emite decisão com motivo | `{ decisao, limite_aprovado, motivo }` |
| **AgenteAuditoria** | Registra todas as entradas, análises e decisão em trilha auditável | `{ audit_id, timestamp, etapas }` |

### Regras do AgenteDecisor (legíveis por humanos)

```
score >= 80   →  APROVADO  (limite máximo da carteira)
score 60–79   →  APROVADO  (limite reduzido: 70% do máximo)
score < 60    →  RECUSADO
```

---

## Como Funciona

### Endpoint principal

```
POST /credito
```

Payload de entrada:

```json
{
  "cliente_id": "C001",
  "valor_solicitado": 20000
}
```

Resposta:

```json
{
  "decisao": "APROVADO",
  "limite_aprovado": 20000,
  "explicacao_cliente": "Seu crédito foi aprovado porque sua renda mensal é compatível com o valor solicitado, você possui histórico positivo de pagamentos e mantém relacionamento com o banco há mais de 10 anos.",
  "auditoria": {
    "audit_id": "AUD-20240115-C001",
    "timestamp": "2024-01-15T10:30:00",
    "etapas": [
      { "agente": "cliente", "resultado": { "score": 85, "risco": "BAIXO", "justificativa": "..." } },
      { "agente": "carteira", "resultado": { "produto_indicado": "Crédito Fidelidade", "limite_maximo": 30000 } },
      { "agente": "decisor", "resultado": { "decisao": "APROVADO", "limite_aprovado": 20000 } }
    ]
  }
}
```

### Outros endpoints

```
GET  /clientes           → lista todos os clientes fictícios de demonstração
GET  /clientes/{id}      → detalhe de um cliente
GET  /auditoria/{id}     → recupera trilha de auditoria por audit_id
GET  /health             → status da API
```

---

## Como Executar

### Pré-requisitos

- Python 3.9+
- pip

### Instalação

```bash
cd grupo-2237/src
pip install -r requirements.txt
```

### Execução

```bash
uvicorn main:app --reload --port 8000
```

### Documentação interativa

Acesse: [http://localhost:8000/docs](http://localhost:8000/docs)

### Teste rápido

```bash
curl -X POST http://localhost:8000/credito \
  -H "Content-Type: application/json" \
  -d '{"cliente_id": "C001", "valor_solicitado": 20000}'
```

---

## Casos de Demonstração

| Cliente | Cenário | Score Esperado | Decisão Esperada |
|---|---|---|---|
| C001 — João Oliveira | Excelente perfil | 85 | APROVADO |
| C003 — Carlos Mendes | Perfil médio | 72 | APROVADO (limite reduzido) |
| C002 — Ana Costa | Alto comprometimento | 45 | RECUSADO |

Ver todos os 10 clientes em `src/data/clientes.json`.

---

## Uso do IBM Bob

O IBM Bob foi utilizado como:

1. **Par de programação** — geração e revisão do código Python dos agentes
2. **Consultor de arquitetura** — definição do fluxo de orquestração e separação de responsabilidades
3. **Gerador dos YAMLs** — configuração dos agentes no watsonx Orchestrate
4. **Co-autor do README** — estrutura e linguagem da documentação
5. **Revisor de lógica** — validação das regras de decisão e dos prompts dos agentes

> Evidência: este projeto foi inteiramente planejado e implementado em sessão de pair programming com o IBM Bob no hackathon IBMbathon 2025.

---

## Uso do IBM watsonx Orchestrate

Os quatro agentes foram configurados no IBM watsonx Orchestrate Agent Builder:

- **AgenteCliente** — agente colaborador com instrução de análise de perfil
- **AgenteCarteira** — agente colaborador com catálogo de produtos embutido
- **AgenteDecisor** — agente colaborador com regras de decisão explícitas
- **AgenteAuditoria** — agente supervisor que coordena os três anteriores e gera a trilha

Os YAMLs de configuração estão em `src/orchestrate/`.
As evidências de uso (prints da plataforma) estão em `evidencias/`.

---

## Estrutura de Arquivos

```
grupo-2237/
├── README.md                          ← este arquivo
├── evidencias/
│   └── README.md                      ← instruções de quais prints capturar
└── src/
    ├── main.py                        ← API FastAPI principal
    ├── requirements.txt               ← dependências
    ├── agents/
    │   ├── __init__.py
    │   ├── cliente.py                 ← AgenteCliente
    │   ├── carteira.py                ← AgenteCarteira
    │   ├── decisor.py                 ← AgenteDecisor
    │   └── auditoria.py              ← AgenteAuditoria
    ├── models/
    │   ├── __init__.py
    │   └── schemas.py                 ← modelos Pydantic
    ├── data/
    │   └── clientes.json              ← 10 clientes fictícios
    └── orchestrate/
        ├── agente_cliente.yaml
        ├── agente_carteira.yaml
        ├── agente_decisor.yaml
        └── agente_auditoria.yaml
```

---

## Critérios do Desafio — Checklist

- [x] Recebe pedido de crédito com dados do cliente
- [x] Analisa perfil: histórico, comportamento, capacidade de pagamento
- [x] Decide: aprovado ou recusado, com limite sugerido
- [x] Explica a decisão em linguagem que o cliente entende
- [x] Registra trilha auditável de todo o caminho
- [x] Usa IBM Bob (evidenciado neste README)
- [x] Usa IBM watsonx Orchestrate (YAMLs + prints em evidencias/)
- [x] Solução pequena, funcional, demonstrável em minutos
- [x] Agente não inventa — declara incerteza quando dados são insuficientes
