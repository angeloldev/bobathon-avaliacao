# evidencias/

Esta pasta contém as evidências de uso do IBM watsonx Orchestrate, conforme exigido pela Regra 2 do desafio.

---

## Prints obrigatórios a capturar

Capture os seguintes screenshots diretamente no IBM watsonx Orchestrate e salve nesta pasta.

### 1. Lista de agentes criados
**Arquivo:** `01-lista-agentes.png`

Acesse a tela principal do Agent Builder no Orchestrate e capture a lista mostrando os quatro agentes:
- AgenteCliente-Aurora
- AgenteCarteira-Aurora
- AgenteDecisor-Aurora
- AgenteAuditoria-Aurora (supervisor)

---

### 2. Configuração do AgenteCliente
**Arquivo:** `02-agente-cliente-config.png`

Abra o AgenteCliente-Aurora e capture a tela mostrando:
- Nome do agente
- Campo "Instructions" (system prompt) preenchido
- Modelo selecionado

---

### 3. Configuração do AgenteCarteira
**Arquivo:** `03-agente-carteira-config.png`

Abra o AgenteCarteira-Aurora e capture a tela mostrando:
- Nome do agente
- Campo "Instructions" (system prompt) preenchido com o catálogo de produtos

---

### 4. Configuração do AgenteDecisor
**Arquivo:** `04-agente-decisor-config.png`

Abra o AgenteDecisor-Aurora e capture a tela mostrando:
- Nome do agente
- Campo "Instructions" com as regras de decisão visíveis

---

### 5. Configuração do AgenteAuditoria (supervisor)
**Arquivo:** `05-agente-auditoria-config.png`

Abra o AgenteAuditoria-Aurora e capture a tela mostrando:
- Nome do agente
- Agentes colaboradores configurados (lista dos outros três agentes)
- Campo "Instructions"

---

### 6. Conversa de demonstração — Aprovação
**Arquivo:** `06-demo-aprovado.png`

No chat do agente supervisor, envie um pedido de crédito para o cliente C001 (João Oliveira) e capture a resposta completa mostrando:
- Decisão: APROVADO
- Limite sugerido
- Explicação em linguagem simples
- Rastro auditável

---

### 7. Conversa de demonstração — Recusa
**Arquivo:** `07-demo-recusado.png`

No chat do agente supervisor, envie um pedido para o cliente C002 (Ana Costa) e capture a resposta completa mostrando:
- Decisão: RECUSADO
- Motivo em linguagem simples

---

### 8. (Opcional) Exportação dos agentes
**Arquivo:** `08-export-agentes.png` ou `agentes-export.zip`

Se o Orchestrate oferecer opção de exportar a configuração dos agentes, capture essa tela ou salve o arquivo exportado aqui.

---

## Evidências da API (se o backend for executado)

### 9. Swagger da API
**Arquivo:** `09-swagger-ui.png`

Capture a tela do Swagger UI em `http://localhost:8000/docs` mostrando os endpoints disponíveis.

### 10. Resposta de aprovação
**Arquivo:** `10-resposta-aprovacao.png`

Capture o resultado de um `POST /credito` com cliente C001 no Swagger ou terminal.

### 11. Resposta de recusa
**Arquivo:** `11-resposta-recusa.png`

Capture o resultado de um `POST /credito` com cliente C002.

---

## Observações

- Prints podem ser `.png`, `.jpg` ou `.pdf`.
- Um vídeo curto da demonstração (mp4, até 2 min) também é aceito como evidência — salve como `demo.mp4`.
- O que não estiver nesta pasta não existe para a avaliação.
