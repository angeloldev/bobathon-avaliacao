"""
Aurora Bank — API de Decisão de Crédito Transparente
Grupo 2237 — IBMbathon 2025

Endpoints:
  POST /credito        → analisa pedido de crédito e retorna decisão + auditoria
  GET  /clientes       → lista clientes fictícios de demonstração
  GET  /clientes/{id}  → detalhe de um cliente
  GET  /auditoria/{id} → recupera trilha de auditoria por audit_id
  GET  /health         → status da API
"""

import json
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import PedidoCredito, RespostaFinal, ResultadoAuditoria, EtapaAuditoria
from agents.cliente import analisar_cliente
from agents.carteira import avaliar_carteira
from agents.decisor import decidir
from agents.auditoria import registrar

# ── inicialização ──────────────────────────────────────────────────────────────

app = FastAPI(
    title="Aurora Bank — Decisão de Crédito Transparente",
    description=(
        "Sistema de concessão de crédito com explicabilidade e trilha auditável. "
        "Substitui 22 anos de caixa-preta por decisões legíveis e contestáveis. "
        "Grupo 2237 — IBMbathon 2025."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── dados fictícios ────────────────────────────────────────────────────────────

_DATA_PATH = Path(__file__).parent / "data" / "clientes.json"
_clientes_raw = json.loads(_DATA_PATH.read_text(encoding="utf-8"))
CLIENTES: Dict[str, dict] = {c["id"]: c for c in _clientes_raw}

# trilhas de auditoria em memória (demonstração)
AUDITORIAS: Dict[str, dict] = {}


# ── endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health", tags=["Utilitários"])
def health():
    """Verifica se a API está no ar."""
    return {"status": "ok", "servico": "Aurora Bank Credit Decision API v1.0.0"}


@app.get("/clientes", tags=["Clientes"])
def listar_clientes():
    """Lista todos os clientes fictícios disponíveis para demonstração."""
    return list(CLIENTES.values())


@app.get("/clientes/{cliente_id}", tags=["Clientes"])
def obter_cliente(cliente_id: str):
    """Retorna os dados de um cliente específico."""
    cliente = CLIENTES.get(cliente_id)
    if not cliente:
        raise HTTPException(
            status_code=404,
            detail=f"Cliente '{cliente_id}' não encontrado. "
                   f"IDs disponíveis: {list(CLIENTES.keys())}",
        )
    return cliente


@app.post("/credito", response_model=RespostaFinal, tags=["Crédito"])
def analisar_credito(pedido: PedidoCredito):
    """
    Analisa um pedido de crédito passando pelos quatro agentes:

    1. **AgenteCliente** — avalia perfil, histórico e capacidade de pagamento
    2. **AgenteCarteira** — identifica produto elegível e limite máximo
    3. **AgenteDecisor** — aplica regras transparentes e emite decisão
    4. **AgenteAuditoria** — registra trilha auditável completa

    Retorna: decisão, limite aprovado, explicação em linguagem simples e auditoria.
    """
    # Localiza cliente
    cliente = CLIENTES.get(pedido.cliente_id)
    if not cliente:
        raise HTTPException(
            status_code=404,
            detail=f"Cliente '{pedido.cliente_id}' não encontrado. "
                   f"IDs disponíveis: {list(CLIENTES.keys())}",
        )

    # 1. AgenteCliente
    resultado_cliente = analisar_cliente(cliente)

    # 2. AgenteCarteira
    resultado_carteira = avaliar_carteira(cliente, resultado_cliente["risco"])

    # 3. AgenteDecisor
    resultado_decisor = decidir(
        resultado_cliente,
        resultado_carteira,
        pedido.valor_solicitado,
    )

    # 4. AgenteAuditoria
    trilha = registrar(
        pedido.cliente_id,
        pedido.valor_solicitado,
        resultado_cliente,
        resultado_carteira,
        resultado_decisor,
    )

    AUDITORIAS[trilha["audit_id"]] = trilha

    return RespostaFinal(
        decisao=resultado_decisor["decisao"],
        limite_aprovado=resultado_decisor["limite_aprovado"],
        explicacao_cliente=resultado_decisor["explicacao_cliente"],
        auditoria=ResultadoAuditoria(
            audit_id=trilha["audit_id"],
            cliente_id=trilha["cliente_id"],
            timestamp=trilha["timestamp"],
            valor_solicitado=trilha["valor_solicitado"],
            etapas=[
                EtapaAuditoria(**e) for e in trilha["etapas"]
            ],
        ),
    )


@app.get("/auditoria/{audit_id}", tags=["Auditoria"])
def recuperar_auditoria(audit_id: str):
    """
    Recupera a trilha auditável de uma decisão pelo seu ID.

    O audit_id é retornado no campo `auditoria.audit_id` da resposta do POST /credito.
    """
    registro = AUDITORIAS.get(audit_id)
    if not registro:
        raise HTTPException(
            status_code=404,
            detail=f"Auditoria '{audit_id}' não encontrada. "
                   "Realize uma análise de crédito primeiro via POST /credito.",
        )
    return registro
