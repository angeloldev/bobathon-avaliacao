# Código-fonte — Aurora Bank Credit Decision

Este arquivo contém todos os arquivos de código-fonte da solução.
Use o modo Agent do IBM Bob para criar os arquivos `.py` e `.yaml` a partir deste documento.

---

## src/models/schemas.py

```python
from pydantic import BaseModel
from typing import List, Optional, Any
from datetime import datetime


class PedidoCredito(BaseModel):
    cliente_id: str
    valor_solicitado: float


class ResultadoCliente(BaseModel):
    score: int
    risco: str  # BAIXO, MEDIO, ALTO
    justificativa: str
    fatores_positivos: List[str]
    fatores_negativos: List[str]


class ResultadoCarteira(BaseModel):
    produto_indicado: str
    limite_maximo: float
    justificativa: str


class ResultadoDecisor(BaseModel):
    decisao: str  # APROVADO, RECUSADO
    limite_aprovado: float
    motivo: str
    explicacao_cliente: str


class EtapaAuditoria(BaseModel):
    agente: str
    resultado: Any


class ResultadoAuditoria(BaseModel):
    audit_id: str
    cliente_id: str
    timestamp: str
    valor_solicitado: float
    etapas: List[EtapaAuditoria]


class RespostaFinal(BaseModel):
    decisao: str
    limite_aprovado: float
    explicacao_cliente: str
    auditoria: ResultadoAuditoria
```

---

## src/data/clientes.json

```json
[
  {
    "id": "C001",
    "nome": "João Oliveira",
    "idade": 42,
    "renda_mensal": 6500.00,
    "tempo_relacionamento_anos": 12,
    "historico_pagamentos": "EXCELENTE",
    "comprometimento_renda_pct": 18,
    "score_comportamental": 85,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C002",
    "nome": "Ana Costa",
    "idade": 29,
    "renda_mensal": 2200.00,
    "tempo_relacionamento_anos": 1,
    "historico_pagamentos": "RUIM",
    "comprometimento_renda_pct": 68,
    "score_comportamental": 42,
    "dividas_ativas": true,
    "restricoes_cpf": true
  },
  {
    "id": "C003",
    "nome": "Carlos Mendes",
    "idade": 35,
    "renda_mensal": 4800.00,
    "tempo_relacionamento_anos": 6,
    "historico_pagamentos": "BOM",
    "comprometimento_renda_pct": 35,
    "score_comportamental": 72,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C004",
    "nome": "Fernanda Lima",
    "idade": 51,
    "renda_mensal": 12000.00,
    "tempo_relacionamento_anos": 18,
    "historico_pagamentos": "EXCELENTE",
    "comprometimento_renda_pct": 12,
    "score_comportamental": 92,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C005",
    "nome": "Roberto Alves",
    "idade": 23,
    "renda_mensal": 1800.00,
    "tempo_relacionamento_anos": 0,
    "historico_pagamentos": "SEM_HISTORICO",
    "comprometimento_renda_pct": 55,
    "score_comportamental": 38,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C006",
    "nome": "Patrícia Souza",
    "idade": 44,
    "renda_mensal": 7200.00,
    "tempo_relacionamento_anos": 9,
    "historico_pagamentos": "BOM",
    "comprometimento_renda_pct": 28,
    "score_comportamental": 78,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C007",
    "nome": "Marcos Pereira",
    "idade": 38,
    "renda_mensal": 3500.00,
    "tempo_relacionamento_anos": 4,
    "historico_pagamentos": "REGULAR",
    "comprometimento_renda_pct": 48,
    "score_comportamental": 55,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C008",
    "nome": "Juliana Castro",
    "idade": 33,
    "renda_mensal": 5100.00,
    "tempo_relacionamento_anos": 7,
    "historico_pagamentos": "EXCELENTE",
    "comprometimento_renda_pct": 22,
    "score_comportamental": 81,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C009",
    "nome": "Eduardo Santos",
    "idade": 47,
    "renda_mensal": 9500.00,
    "tempo_relacionamento_anos": 15,
    "historico_pagamentos": "BOM",
    "comprometimento_renda_pct": 30,
    "score_comportamental": 76,
    "dividas_ativas": false,
    "restricoes_cpf": false
  },
  {
    "id": "C010",
    "nome": "Camila Rodrigues",
    "idade": 27,
    "renda_mensal": 2800.00,
    "tempo_relacionamento_anos": 2,
    "historico_pagamentos": "REGULAR",
    "comprometimento_renda_pct": 42,
    "score_comportamental": 58,
    "dividas_ativas": false,
    "restricoes_cpf": false
  }
]
```

---

## src/agents/cliente.py

```python
"""
AgenteCliente — Avalia o perfil financeiro do cliente e calcula score explicável.

Regras de score (totalmente transparentes):
  - Histórico EXCELENTE:     +30 pontos
  - Histórico BOM:           +20 pontos
  - Histórico REGULAR:       +5 pontos
  - Histórico RUIM:          -20 pontos
  - Histórico SEM_HISTORICO: +0 pontos (base: 50)

  - Comprometimento <= 20%:  +20 pontos
  - Comprometimento 21-35%:  +10 pontos
  - Comprometimento 36-50%:  +0 pontos
  - Comprometimento > 50%:   -20 pontos

  - Relacionamento >= 10 anos: +15 pontos
  - Relacionamento 5-9 anos:   +10 pontos
  - Relacionamento 2-4 anos:   +5 pontos
  - Relacionamento < 2 anos:   +0 pontos

  - Restrições no CPF:  -25 pontos
  - Dívidas ativas:     -10 pontos

Score base: 50
Score máximo possível: 115 → normalizado para 0-100
"""

from typing import Dict, Any


HISTORICO_PONTOS = {
    "EXCELENTE": 30,
    "BOM": 20,
    "REGULAR": 5,
    "RUIM": -20,
    "SEM_HISTORICO": 0,
}


def calcular_score(cliente: Dict[str, Any]) -> tuple[int, list, list]:
    """Calcula score explicável. Retorna (score, fatores_positivos, fatores_negativos)."""
    pontos = 50
    positivos = []
    negativos = []

    # Histórico de pagamentos
    historico = cliente.get("historico_pagamentos", "SEM_HISTORICO")
    pts_historico = HISTORICO_PONTOS.get(historico, 0)
    pontos += pts_historico
    if pts_historico > 0:
        positivos.append(f"Histórico de pagamentos {historico.lower()}")
    elif pts_historico < 0:
        negativos.append(f"Histórico de pagamentos {historico.lower()}")

    # Comprometimento de renda
    comp = cliente.get("comprometimento_renda_pct", 50)
    if comp <= 20:
        pontos += 20
        positivos.append(f"Apenas {comp}% da renda comprometida — excelente margem")
    elif comp <= 35:
        pontos += 10
        positivos.append(f"{comp}% da renda comprometida — dentro do limite saudável")
    elif comp > 50:
        pontos -= 20
        negativos.append(f"{comp}% da renda já comprometida — acima do limite seguro")

    # Tempo de relacionamento
    tempo = cliente.get("tempo_relacionamento_anos", 0)
    if tempo >= 10:
        pontos += 15
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    elif tempo >= 5:
        pontos += 10
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    elif tempo >= 2:
        pontos += 5
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    else:
        negativos.append("Relacionamento recente com o banco (menos de 2 anos)")

    # Restrições e dívidas
    if cliente.get("restricoes_cpf", False):
        pontos -= 25
        negativos.append("Restrição ativa no CPF")

    if cliente.get("dividas_ativas", False):
        pontos -= 10
        negativos.append("Dívida ativa pendente")

    # Usar score_comportamental como referência (média ponderada)
    score_base = cliente.get("score_comportamental", pontos)
    score_final = round((pontos + score_base) / 2)
    score_final = max(0, min(100, score_final))

    return score_final, positivos, negativos


def classificar_risco(score: int) -> str:
    if score >= 80:
        return "BAIXO"
    elif score >= 60:
        return "MEDIO"
    return "ALTO"


def gerar_justificativa(score: int, risco: str, positivos: list, negativos: list) -> str:
    partes = []
    if positivos:
        partes.append("Pontos favoráveis: " + "; ".join(positivos) + ".")
    if negativos:
        partes.append("Pontos de atenção: " + "; ".join(negativos) + ".")
    partes.append(f"Score calculado: {score}/100 — Risco {risco}.")
    return " ".join(partes)


def analisar_cliente(cliente: Dict[str, Any]) -> Dict[str, Any]:
    """Ponto de entrada do AgenteCliente."""
    score, positivos, negativos = calcular_score(cliente)
    risco = classificar_risco(score)
    justificativa = gerar_justificativa(score, risco, positivos, negativos)

    return {
        "score": score,
        "risco": risco,
        "justificativa": justificativa,
        "fatores_positivos": positivos,
        "fatores_negativos": negativos,
    }
```

---

## src/agents/carteira.py

```python
"""
AgenteCarteira — Avalia produtos disponíveis e determina o limite máximo elegível.

Catálogo de produtos do Aurora Bank:

  Crédito Emergencial
    - Público: todos os clientes com conta ativa
    - Limite: R$ 500 – R$ 3.000
    - Requisito: nenhum (conta ativa)

  Crédito Pessoal Aurora
    - Público: clientes com 1+ ano de conta
    - Limite: R$ 1.000 – R$ 15.000
    - Requisito: renda >= R$ 2.000 e sem restrição no CPF

  Crédito Fidelidade
    - Público: clientes com 5+ anos
    - Limite: R$ 5.000 – R$ 50.000
    - Requisito: renda >= R$ 3.500 e histórico BOM ou EXCELENTE

  Crédito Premium
    - Público: clientes com 10+ anos e risco BAIXO
    - Limite: R$ 20.000 – R$ 100.000
    - Requisito: renda >= R$ 8.000 e sem restrições
"""

from typing import Dict, Any


PRODUTOS = [
    {
        "nome": "Crédito Premium",
        "limite_minimo": 20000,
        "limite_maximo": 100000,
        "tempo_minimo_anos": 10,
        "renda_minima": 8000,
        "historico_aceito": ["EXCELENTE", "BOM"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Fidelidade",
        "limite_minimo": 5000,
        "limite_maximo": 50000,
        "tempo_minimo_anos": 5,
        "renda_minima": 3500,
        "historico_aceito": ["EXCELENTE", "BOM"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Pessoal Aurora",
        "limite_minimo": 1000,
        "limite_maximo": 15000,
        "tempo_minimo_anos": 1,
        "renda_minima": 2000,
        "historico_aceito": ["EXCELENTE", "BOM", "REGULAR"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Emergencial",
        "limite_minimo": 500,
        "limite_maximo": 3000,
        "tempo_minimo_anos": 0,
        "renda_minima": 0,
        "historico_aceito": ["EXCELENTE", "BOM", "REGULAR", "RUIM", "SEM_HISTORICO"],
        "aceita_restricao": True,
    },
]


def calcular_limite(cliente: Dict[str, Any], produto: Dict[str, Any]) -> float:
    """Calcula limite baseado na renda (máximo de 3x a renda mensal, respeitando teto do produto)."""
    limite_por_renda = cliente["renda_mensal"] * 3
    return min(limite_por_renda, produto["limite_maximo"])


def avaliar_carteira(cliente: Dict[str, Any], risco: str) -> Dict[str, Any]:
    """Ponto de entrada do AgenteCarteira."""
    historico = cliente.get("historico_pagamentos", "SEM_HISTORICO")
    tempo = cliente.get("tempo_relacionamento_anos", 0)
    renda = cliente.get("renda_mensal", 0)
    tem_restricao = cliente.get("restricoes_cpf", False)

    for produto in PRODUTOS:
        elegivel = (
            tempo >= produto["tempo_minimo_anos"]
            and renda >= produto["renda_minima"]
            and historico in produto["historico_aceito"]
            and (not tem_restricao or produto["aceita_restricao"])
        )
        if elegivel:
            limite = calcular_limite(cliente, produto)
            return {
                "produto_indicado": produto["nome"],
                "limite_maximo": round(limite, 2),
                "justificativa": (
                    f"Produto '{produto['nome']}' selecionado com base em: "
                    f"{tempo} anos de relacionamento, renda de R$ {renda:,.2f}, "
                    f"histórico {historico.lower()}. "
                    f"Limite calculado em 3x a renda mensal, respeitando o teto do produto."
                ),
            }

    # Nenhum produto elegível
    return {
        "produto_indicado": "NENHUM",
        "limite_maximo": 0.0,
        "justificativa": (
            "Nenhum produto disponível atende ao perfil atual do cliente. "
            "Motivos possíveis: restrição ativa no CPF, histórico de pagamentos insuficiente "
            "ou renda abaixo do mínimo exigido para qualquer linha de crédito."
        ),
    }
```

---

## src/agents/decisor.py

```python
"""
AgenteDecisor — Aplica regras transparentes e produz a decisão final.

Regras (explícitas e auditáveis):
  score >= 80  →  APROVADO  (limite máximo da carteira)
  score 60-79  →  APROVADO  (limite reduzido: 70% do máximo)
  score < 60   →  RECUSADO

  Exceção: se nenhum produto for elegível → RECUSADO independente do score.
  Exceção: se valor solicitado > limite máximo → ajusta para o limite disponível.
"""

from typing import Dict, Any


def gerar_explicacao_cliente(
    decisao: str,
    fatores_positivos: list,
    fatores_negativos: list,
    limite_aprovado: float,
    valor_solicitado: float,
    produto: str,
) -> str:
    """Gera explicação em linguagem simples, sem jargão técnico."""
    if decisao == "APROVADO":
        motivos = " e ".join(fatores_positivos[:3]) if fatores_positivos else "seu perfil financeiro"
        texto = f"Seu crédito foi aprovado porque {motivos}."
        if limite_aprovado < valor_solicitado:
            texto += (
                f" O valor aprovado (R$ {limite_aprovado:,.2f}) é menor do que o solicitado "
                f"(R$ {valor_solicitado:,.2f}) para manter suas finanças em equilíbrio."
            )
        texto += f" Produto: {produto}."
        return texto

    # RECUSADO
    if fatores_negativos:
        motivo_principal = fatores_negativos[0]
        texto = f"Seu pedido não foi aprovado porque {motivo_principal.lower()}."
        if len(fatores_negativos) > 1:
            outros = "; ".join(fatores_negativos[1:3])
            texto += f" Outros fatores considerados: {outros}."
    else:
        texto = (
            "Seu pedido não foi aprovado porque seu perfil atual não atende "
            "aos critérios necessários para concessão de crédito."
        )
    texto += " Se quiser, entre em contato com uma agência para entender como melhorar seu perfil."
    return texto


def decidir(
    resultado_cliente: Dict[str, Any],
    resultado_carteira: Dict[str, Any],
    valor_solicitado: float,
) -> Dict[str, Any]:
    """Ponto de entrada do AgenteDecisor."""
    score = resultado_cliente["score"]
    produto = resultado_carteira["produto_indicado"]
    limite_maximo = resultado_carteira["limite_maximo"]
    fatores_positivos = resultado_cliente.get("fatores_positivos", [])
    fatores_negativos = resultado_cliente.get("fatores_negativos", [])

    # Regra 0: sem produto elegível → recusado
    if produto == "NENHUM" or limite_maximo == 0:
        explicacao = gerar_explicacao_cliente(
            "RECUSADO", fatores_positivos, fatores_negativos, 0, valor_solicitado, produto
        )
        return {
            "decisao": "RECUSADO",
            "limite_aprovado": 0.0,
            "motivo": "Nenhum produto de crédito disponível para o perfil atual.",
            "explicacao_cliente": explicacao,
        }

    # Regra 1: score >= 80 → aprovado, limite máximo disponível
    if score >= 80:
        limite = min(limite_maximo, valor_solicitado)
        explicacao = gerar_explicacao_cliente(
            "APROVADO", fatores_positivos, fatores_negativos, limite, valor_solicitado, produto
        )
        return {
            "decisao": "APROVADO",
            "limite_aprovado": round(limite, 2),
            "motivo": f"Score {score}/100 (BAIXO risco). Aprovado com limite de R$ {limite:,.2f}.",
            "explicacao_cliente": explicacao,
        }

    # Regra 2: score 60-79 → aprovado com limite reduzido (70%)
    if 60 <= score < 80:
        limite = min(round(limite_maximo * 0.70, 2), valor_solicitado)
        explicacao = gerar_explicacao_cliente(
            "APROVADO", fatores_positivos, fatores_negativos, limite, valor_solicitado, produto
        )
        return {
            "decisao": "APROVADO",
            "limite_aprovado": round(limite, 2),
            "motivo": f"Score {score}/100 (MÉDIO risco). Aprovado com limite reduzido (70% do máximo).",
            "explicacao_cliente": explicacao,
        }

    # Regra 3: score < 60 → recusado
    explicacao = gerar_explicacao_cliente(
        "RECUSADO", fatores_positivos, fatores_negativos, 0, valor_solicitado, produto
    )
    return {
        "decisao": "RECUSADO",
        "limite_aprovado": 0.0,
        "motivo": f"Score {score}/100 (ALTO risco). Perfil não atende aos critérios mínimos.",
        "explicacao_cliente": explicacao,
    }
```

---

## src/agents/auditoria.py

```python
"""
AgenteAuditoria — Registra todas as etapas e gera a trilha auditável.

Produz um JSON completo com:
  - Identificador único da auditoria (AUD-YYYYMMDD-HHMMSS-clienteID)
  - Timestamp da decisão
  - Dados do pedido original
  - Resultado de cada agente (etapas)
  - Decisão final
"""

from datetime import datetime
from typing import Dict, Any


def gerar_audit_id(cliente_id: str) -> str:
    agora = datetime.now()
    return f"AUD-{agora.strftime('%Y%m%d-%H%M%S')}-{cliente_id}"


def registrar(
    cliente_id: str,
    valor_solicitado: float,
    resultado_cliente: Dict[str, Any],
    resultado_carteira: Dict[str, Any],
    resultado_decisor: Dict[str, Any],
) -> Dict[str, Any]:
    """Ponto de entrada do AgenteAuditoria. Retorna trilha auditável completa."""
    agora = datetime.now()

    return {
        "audit_id": gerar_audit_id(cliente_id),
        "cliente_id": cliente_id,
        "timestamp": agora.isoformat(),
        "valor_solicitado": valor_solicitado,
        "etapas": [
            {
                "agente": "AgenteCliente",
                "descricao": "Avaliação de perfil financeiro e cálculo de score",
                "resultado": resultado_cliente,
            },
            {
                "agente": "AgenteCarteira",
                "descricao": "Seleção de produto elegível e cálculo de limite máximo",
                "resultado": resultado_carteira,
            },
            {
                "agente": "AgenteDecisor",
                "descricao": "Aplicação das regras de decisão e emissão do resultado",
                "resultado": resultado_decisor,
            },
        ],
        "decisao_final": resultado_decisor["decisao"],
        "limite_final": resultado_decisor["limite_aprovado"],
    }
```

---

## src/main.py

```python
"""
Aurora Bank — API de Decisão de Crédito Transparente
Grupo 2237 — IBMbathon 2025

Endpoints:
  POST /credito          → analisa pedido de crédito
  GET  /clientes         → lista clientes fictícios de demonstração
  GET  /clientes/{id}    → detalhe de cliente
  GET  /auditoria/{id}   → recupera registro de auditoria
  GET  /health           → status da API
"""

import json
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import PedidoCredito, RespostaFinal, ResultadoAuditoria
from agents.cliente import analisar_cliente
from agents.carteira import avaliar_carteira
from agents.decisor import decidir
from agents.auditoria import registrar

# ── inicialização ──────────────────────────────────────────────────────────────

app = FastAPI(
    title="Aurora Bank — Decisão de Crédito Transparente",
    description=(
        "Sistema de concessão de crédito com explicabilidade e trilha auditável. "
        "Substitui 22 anos de caixa-preta por decisões legíveis e contestáveis."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── carrega dados fictícios ────────────────────────────────────────────────────

DATA_PATH = Path(__file__).parent / "data" / "clientes.json"
_clientes_raw = json.loads(DATA_PATH.read_text(encoding="utf-8"))
CLIENTES: Dict[str, dict] = {c["id"]: c for c in _clientes_raw}

# registros de auditoria em memória (demonstração)
AUDITORIAS: Dict[str, dict] = {}


# ── endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "servico": "Aurora Bank Credit Decision API"}


@app.get("/clientes")
def listar_clientes():
    """Lista todos os clientes fictícios disponíveis para demonstração."""
    return list(CLIENTES.values())


@app.get("/clientes/{cliente_id}")
def obter_cliente(cliente_id: str):
    """Retorna os dados de um cliente específico."""
    cliente = CLIENTES.get(cliente_id)
    if not cliente:
        raise HTTPException(status_code=404, detail=f"Cliente '{cliente_id}' não encontrado.")
    return cliente


@app.post("/credito", response_model=RespostaFinal)
def analisar_credito(pedido: PedidoCredito):
    """
    Analisa um pedido de crédito e retorna decisão transparente com:
    - Decisão (APROVADO / RECUSADO)
    - Limite aprovado
    - Explicação em linguagem simples para o cliente
    - Trilha auditável completa
    """
    # 1. Localiza cliente
    cliente = CLIENTES.get(pedido.cliente_id)
    if not cliente:
        raise HTTPException(
            status_code=404,
            detail=f"Cliente '{pedido.cliente_id}' não encontrado. "
                   f"Clientes disponíveis: {list(CLIENTES.keys())}",
        )

    # 2. AgenteCliente — avalia perfil e calcula score
    resultado_cliente = analisar_cliente(cliente)

    # 3. AgenteCarteira — identifica produto e limite
    resultado_carteira = avaliar_carteira(cliente, resultado_cliente["risco"])

    # 4. AgenteDecisor — aplica regras e emite decisão
    resultado_decisor = decidir(
        resultado_cliente,
        resultado_carteira,
        pedido.valor_solicitado,
    )

    # 5. AgenteAuditoria — registra trilha completa
    trilha = registrar(
        pedido.cliente_id,
        pedido.valor_solicitado,
        resultado_cliente,
        resultado_carteira,
        resultado_decisor,
    )

    # Persiste em memória para consulta posterior
    AUDITORIAS[trilha["audit_id"]] = trilha

    return RespostaFinal(
        decisao=resultado_decisor["decisao"],
        limite_aprovado=resultado_decisor["limite_aprovado"],
        explicacao_cliente=resultado_decisor["explicacao_cliente"],
        auditoria=ResultadoAuditoria(**{
            "audit_id": trilha["audit_id"],
            "cliente_id": trilha["cliente_id"],
            "timestamp": trilha["timestamp"],
            "valor_solicitado": trilha["valor_solicitado"],
            "etapas": trilha["etapas"],
        }),
    )


@app.get("/auditoria/{audit_id}")
def recuperar_auditoria(audit_id: str):
    """Recupera a trilha auditável de uma decisão pelo seu ID."""
    registro = AUDITORIAS.get(audit_id)
    if not registro:
        raise HTTPException(
            status_code=404,
            detail=f"Auditoria '{audit_id}' não encontrada. "
                   "Realize uma análise de crédito primeiro.",
        )
    return registro
```

---

## src/agents/__init__.py

```python
# agents package
```

---

## src/models/__init__.py

```python
# models package
```
