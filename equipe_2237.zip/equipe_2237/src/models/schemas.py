from pydantic import BaseModel
from typing import List, Any


class PedidoCredito(BaseModel):
    cliente_id: str
    valor_solicitado: float


class ResultadoCliente(BaseModel):
    score: int
    risco: str  # BAIXO, MEDIO, ALTO
    justificativa: str
    fatores_positivos: List[str]
    fatores_negativos: List[str]


class ResultadoCarteira(BaseModel):
    produto_indicado: str
    limite_maximo: float
    justificativa: str


class ResultadoDecisor(BaseModel):
    decisao: str  # APROVADO, RECUSADO
    limite_aprovado: float
    motivo: str
    explicacao_cliente: str


class EtapaAuditoria(BaseModel):
    agente: str
    descricao: str
    resultado: Any


class ResultadoAuditoria(BaseModel):
    audit_id: str
    cliente_id: str
    timestamp: str
    valor_solicitado: float
    etapas: List[EtapaAuditoria]


class RespostaFinal(BaseModel):
    decisao: str
    limite_aprovado: float
    explicacao_cliente: str
    auditoria: ResultadoAuditoria
