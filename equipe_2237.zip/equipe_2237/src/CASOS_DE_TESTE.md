# Casos de Teste — Aurora Bank Credit Decision

Este arquivo descreve todos os casos de teste para validar a solução.

---

## Casos de Teste Funcionais

### CASO 01 — Aprovação completa (score alto)
**Cliente:** C001 — João Oliveira
**Perfil:** 12 anos de relacionamento, renda R$ 6.500, histórico EXCELENTE, 18% comprometido
**Valor solicitado:** R$ 20.000

**Score real:** 100 (BAIXO risco) — histórico excelente + 12 anos + 18% comprometido = média alta
**Produto esperado:** Crédito Fidelidade
**Decisão esperada:** APROVADO
**Limite esperado:** R$ 19.500,00 (3x renda = R$ 19.500 < R$ 20.000 solicitado)

**Explicação esperada (linguagem simples):**
"Seu crédito foi aprovado porque você possui histórico de pagamentos excelente, mantém relacionamento com o banco há mais de 10 anos e apenas 18% da sua renda está comprometida."

---

### CASO 02 — Recusa por alto risco
**Cliente:** C002 — Ana Costa
**Perfil:** 1 ano de relacionamento, renda R$ 2.200, histórico RUIM, 68% comprometido, restrição no CPF, dívida ativa
**Valor solicitado:** R$ 30.000

**Score real:** 8 (ALTO risco) — histórico RUIM + restrição CPF + dívida ativa + 68% comprometido
**Produto identificado:** Crédito Emergencial (único que aceita restrição no CPF)
**Decisão pelo AgenteDecisor:** RECUSADO (score 8 < 60, independente do produto disponível)
**Decisão esperada:** RECUSADO

**Explicação esperada:**
"Seu pedido não foi aprovado porque atualmente mais de 60% da sua renda já está comprometida com outras obrigações financeiras, e há uma restrição ativa no seu CPF."

---

### CASO 03 — Aprovação com limite reduzido (score médio)
**Cliente:** C003 — Carlos Mendes
**Perfil:** 6 anos de relacionamento, renda R$ 4.800, histórico BOM, 35% comprometido
**Valor solicitado:** R$ 40.000

**Score real:** 81 (BAIXO risco) — BOM histórico + 6 anos + 35% comprometido + score bureau 72 → média 81
**Produto esperado:** Crédito Fidelidade (limite máximo: R$ 14.400 = 3x R$ 4.800)
**Decisão esperada:** APROVADO (score ≥ 80, limite completo)
**Limite esperado:** R$ 14.400,00 (valor solicitado R$ 40.000 > limite disponível, usa o limite)

**Nota:** Score 81 porque a média entre cálculo interno (90 pts) e bureau (72) = 81. Regra 1 aplica.

---

### CASO 04 — Cliente Premium (melhor perfil)
**Cliente:** C004 — Fernanda Lima
**Perfil:** 18 anos de relacionamento, renda R$ 12.000, histórico EXCELENTE, 12% comprometido
**Valor solicitado:** R$ 50.000

**Score esperado:** ~92 (BAIXO risco)
**Produto esperado:** Crédito Premium
**Decisão esperada:** APROVADO
**Limite esperado:** R$ 36.000 (3x renda = R$ 36.000 < R$ 50.000 solicitado)

---

### CASO 05 — Conta nova, sem histórico
**Cliente:** C005 — Roberto Alves
**Perfil:** 0 anos de relacionamento, renda R$ 1.800, sem histórico, 55% comprometido
**Valor solicitado:** R$ 5.000

**Score esperado:** ~38 (ALTO risco)
**Produto esperado:** Crédito Emergencial (único sem requisito de histórico)
**Decisão esperada:** RECUSADO (score < 60, mesmo com produto disponível)

---

### CASO 06 — Perfil médio-alto
**Cliente:** C006 — Patrícia Souza
**Perfil:** 9 anos de relacionamento, renda R$ 7.200, histórico BOM, 28% comprometido
**Valor solicitado:** R$ 25.000

**Score esperado:** ~78 (MÉDIO risco)
**Produto esperado:** Crédito Fidelidade (limite: R$ 21.600)
**Decisão esperada:** APROVADO com limite reduzido
**Limite esperado:** R$ 15.120 (70% de R$ 21.600)

---

### CASO 07 — Recusa por comprometimento
**Cliente:** C007 — Marcos Pereira
**Perfil:** 4 anos de relacionamento, renda R$ 3.500, histórico REGULAR, 48% comprometido
**Valor solicitado:** R$ 15.000

**Score esperado:** ~55 (ALTO risco)
**Decisão esperada:** RECUSADO

---

### CASO 08 — Aprovação para cliente fiel
**Cliente:** C008 — Juliana Castro
**Perfil:** 7 anos de relacionamento, renda R$ 5.100, histórico EXCELENTE, 22% comprometido
**Valor solicitado:** R$ 10.000

**Score esperado:** ~81 (BAIXO risco)
**Produto esperado:** Crédito Fidelidade (limite: R$ 15.300)
**Decisão esperada:** APROVADO
**Limite esperado:** R$ 10.000 (valor solicitado menor que o disponível)

---

### CASO 09 — Cliente sênior com boa renda
**Cliente:** C009 — Eduardo Santos
**Perfil:** 15 anos de relacionamento, renda R$ 9.500, histórico BOM, 30% comprometido
**Valor solicitado:** R$ 60.000

**Score esperado:** ~76 (MÉDIO risco)
**Produto esperado:** Crédito Premium (limite: R$ 28.500)
**Decisão esperada:** APROVADO com limite reduzido
**Limite esperado:** R$ 19.950 (70% de R$ 28.500)

---

### CASO 10 — Perfil limítrofe
**Cliente:** C010 — Camila Rodrigues
**Perfil:** 2 anos de relacionamento, renda R$ 2.800, histórico REGULAR, 42% comprometido
**Valor solicitado:** R$ 8.000

**Score esperado:** ~58 (ALTO risco — limítrofe)
**Produto esperado:** Crédito Pessoal Aurora (limite: R$ 8.400)
**Decisão esperada:** RECUSADO (score 58 < 60)

---

## Comandos de Teste com curl

```bash
# Iniciar a API
cd grupo-2237/src && uvicorn main:app --reload --port 8000

# CASO 01 — Aprovação
curl -s -X POST http://localhost:8000/credito \
  -H "Content-Type: application/json" \
  -d '{"cliente_id": "C001", "valor_solicitado": 20000}' | python -m json.tool

# CASO 02 — Recusa
curl -s -X POST http://localhost:8000/credito \
  -H "Content-Type: application/json" \
  -d '{"cliente_id": "C002", "valor_solicitado": 30000}' | python -m json.tool

# CASO 03 — Aprovação com limite reduzido
curl -s -X POST http://localhost:8000/credito \
  -H "Content-Type: application/json" \
  -d '{"cliente_id": "C003", "valor_solicitado": 40000}' | python -m json.tool

# CASO 04 — Premium
curl -s -X POST http://localhost:8000/credito \
  -H "Content-Type: application/json" \
  -d '{"cliente_id": "C004", "valor_solicitado": 50000}' | python -m json.tool

# Listar todos os clientes
curl -s http://localhost:8000/clientes | python -m json.tool

# Verificar health
curl -s http://localhost:8000/health
```

---

## Teste no watsonx Orchestrate (chat)

Copie e cole no chat do **AgenteAuditoria-Aurora** para testar:

### Teste 1 — Aprovação
```
Analise o seguinte pedido de crédito:

Cliente:
- ID: C001
- Nome: João Oliveira
- Idade: 42 anos
- Renda mensal: R$ 6.500
- Tempo de relacionamento: 12 anos
- Histórico de pagamentos: EXCELENTE
- Comprometimento da renda: 18%
- Score comportamental: 85
- Dívidas ativas: não
- Restrição no CPF: não

Valor solicitado: R$ 20.000

Analise o perfil, verifique os produtos disponíveis, tome a decisão e gere a trilha auditável completa.
```

### Teste 2 — Recusa
```
Analise o seguinte pedido de crédito:

Cliente:
- ID: C002
- Nome: Ana Costa
- Idade: 29 anos
- Renda mensal: R$ 2.200
- Tempo de relacionamento: 1 ano
- Histórico de pagamentos: RUIM
- Comprometimento da renda: 68%
- Score comportamental: 42
- Dívidas ativas: sim
- Restrição no CPF: sim

Valor solicitado: R$ 30.000

Analise o perfil, verifique os produtos disponíveis, tome a decisão e gere a trilha auditável completa.
```

---

## Resultados Esperados por Caso

| Caso | Cliente | Score | Produto | Decisão | Limite |
|---|---|---|---|---|---|
| 01 | João Oliveira | ~85 | Crédito Fidelidade | APROVADO | R$ 19.500 |
| 02 | Ana Costa | ~35 | NENHUM | RECUSADO | R$ 0 |
| 03 | Carlos Mendes | 81 | Crédito Fidelidade | APROVADO | R$ 14.400 |
| 04 | Fernanda Lima | ~92 | Crédito Premium | APROVADO | R$ 36.000 |
| 05 | Roberto Alves | 34 | Crédito Emergencial | RECUSADO | R$ 0 |
| 06 | Patrícia Souza | 84 | Crédito Fidelidade | APROVADO | R$ 20.000 |
| 07 | Marcos Pereira | 58 | Crédito Pessoal Aurora | RECUSADO | R$ 0 |
| 08 | Juliana Castro | 90 | Crédito Fidelidade | APROVADO | R$ 15.300 |
| 09 | Eduardo Santos | 86 | Crédito Premium | APROVADO | R$ 20.000 |
| 10 | Camila Rodrigues | 59 | Crédito Pessoal Aurora | RECUSADO | R$ 0 |
