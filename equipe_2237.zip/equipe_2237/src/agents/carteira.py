"""
AgenteCarteira — Identifica o produto de crédito elegível e calcula limite máximo.

Catálogo de produtos do Aurora Bank (ordem de prioridade decrescente):

  1. Crédito Premium
     Público:    clientes com 10+ anos e risco BAIXO
     Limite:     R$ 20.000 – R$ 100.000
     Requisitos: renda >= R$ 8.000, histórico EXCELENTE ou BOM, sem restrição no CPF

  2. Crédito Fidelidade
     Público:    clientes com 5+ anos
     Limite:     R$ 5.000 – R$ 50.000
     Requisitos: renda >= R$ 3.500, histórico EXCELENTE ou BOM, sem restrição no CPF

  3. Crédito Pessoal Aurora
     Público:    clientes com 1+ ano de conta
     Limite:     R$ 1.000 – R$ 15.000
     Requisitos: renda >= R$ 2.000, histórico EXCELENTE/BOM/REGULAR, sem restrição no CPF

  4. Crédito Emergencial
     Público:    todos os clientes com conta ativa
     Limite:     R$ 500 – R$ 3.000
     Requisitos: nenhum (aceita restrições no CPF)
"""

from typing import Dict, Any, List


PRODUTOS: List[Dict[str, Any]] = [
    {
        "nome": "Crédito Premium",
        "limite_minimo": 20_000,
        "limite_maximo": 100_000,
        "tempo_minimo_anos": 10,
        "renda_minima": 8_000,
        "historico_aceito": ["EXCELENTE", "BOM"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Fidelidade",
        "limite_minimo": 5_000,
        "limite_maximo": 50_000,
        "tempo_minimo_anos": 5,
        "renda_minima": 3_500,
        "historico_aceito": ["EXCELENTE", "BOM"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Pessoal Aurora",
        "limite_minimo": 1_000,
        "limite_maximo": 15_000,
        "tempo_minimo_anos": 1,
        "renda_minima": 2_000,
        "historico_aceito": ["EXCELENTE", "BOM", "REGULAR"],
        "aceita_restricao": False,
    },
    {
        "nome": "Crédito Emergencial",
        "limite_minimo": 500,
        "limite_maximo": 3_000,
        "tempo_minimo_anos": 0,
        "renda_minima": 0,
        "historico_aceito": ["EXCELENTE", "BOM", "REGULAR", "RUIM", "SEM_HISTORICO"],
        "aceita_restricao": True,
    },
]


def calcular_limite(renda: float, limite_maximo_produto: float) -> float:
    """Limite = mínimo entre 3x a renda mensal e o teto do produto."""
    return min(renda * 3, limite_maximo_produto)


def avaliar_carteira(cliente: Dict[str, Any], risco: str) -> Dict[str, Any]:
    """Ponto de entrada do AgenteCarteira."""
    historico = cliente.get("historico_pagamentos", "SEM_HISTORICO")
    tempo = cliente.get("tempo_relacionamento_anos", 0)
    renda = cliente.get("renda_mensal", 0.0)
    tem_restricao = cliente.get("restricoes_cpf", False)

    for produto in PRODUTOS:
        elegivel = (
            tempo >= produto["tempo_minimo_anos"]
            and renda >= produto["renda_minima"]
            and historico in produto["historico_aceito"]
            and (not tem_restricao or produto["aceita_restricao"])
        )
        if elegivel:
            limite = round(calcular_limite(renda, produto["limite_maximo"]), 2)
            return {
                "produto_indicado": produto["nome"],
                "limite_maximo": limite,
                "justificativa": (
                    f"Produto '{produto['nome']}' selecionado. "
                    f"Critérios atendidos: {tempo} ano(s) de relacionamento, "
                    f"renda de R$ {renda:,.2f}, histórico {historico.lower()}. "
                    f"Limite calculado em 3× a renda mensal "
                    f"(R$ {renda * 3:,.2f}), respeitando o teto do produto."
                ),
            }

    return {
        "produto_indicado": "NENHUM",
        "limite_maximo": 0.0,
        "justificativa": (
            "Nenhum produto disponível atende ao perfil atual. "
            "Possíveis motivos: restrição ativa no CPF, histórico de pagamentos "
            "insuficiente ou renda abaixo do mínimo exigido."
        ),
    }
