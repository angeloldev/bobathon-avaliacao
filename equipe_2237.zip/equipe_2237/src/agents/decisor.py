"""
AgenteDecisor — Aplica regras transparentes e produz a decisão final com justificativa.

Regras (explícitas e auditáveis):
  Regra 0: sem produto elegível           → RECUSADO (independe do score)
  Regra 1: score >= 80                    → APROVADO  (limite máximo disponível)
  Regra 2: 60 <= score < 80              → APROVADO  (limite reduzido: 70% do máximo)
  Regra 3: score < 60                    → RECUSADO

  Se valor solicitado < limite disponível → aprova pelo valor solicitado.
"""

from typing import Dict, Any, List


def gerar_explicacao_cliente(
    decisao: str,
    fatores_positivos: List[str],
    fatores_negativos: List[str],
    limite_aprovado: float,
    valor_solicitado: float,
    produto: str,
) -> str:
    """Gera explicação em linguagem simples e sem jargão técnico."""
    if decisao == "APROVADO":
        if fatores_positivos:
            motivos = " e ".join(fatores_positivos[:3])
            texto = f"Seu crédito foi aprovado porque {motivos}."
        else:
            texto = "Seu crédito foi aprovado com base no seu perfil financeiro."
        if limite_aprovado < valor_solicitado:
            texto += (
                f" O valor aprovado (R$ {limite_aprovado:,.2f}) é menor do que o solicitado"
                f" (R$ {valor_solicitado:,.2f}) para manter suas finanças em equilíbrio."
            )
        texto += f" Produto contratado: {produto}."
        return texto

    # RECUSADO
    if fatores_negativos:
        motivo_principal = fatores_negativos[0].lower()
        texto = f"Seu pedido não foi aprovado porque {motivo_principal}."
        if len(fatores_negativos) > 1:
            outros = "; ".join(f[0].lower() + f[1:] for f in fatores_negativos[1:3])
            texto += f" Outros fatores considerados: {outros}."
    else:
        texto = (
            "Seu pedido não foi aprovado porque seu perfil atual não atende"
            " aos critérios necessários para concessão de crédito."
        )
    texto += (
        " Se quiser, entre em contato com uma agência para entender"
        " como melhorar seu perfil para uma próxima solicitação."
    )
    return texto


def decidir(
    resultado_cliente: Dict[str, Any],
    resultado_carteira: Dict[str, Any],
    valor_solicitado: float,
) -> Dict[str, Any]:
    """Ponto de entrada do AgenteDecisor."""
    score = resultado_cliente["score"]
    produto = resultado_carteira["produto_indicado"]
    limite_maximo = resultado_carteira["limite_maximo"]
    positivos = resultado_cliente.get("fatores_positivos", [])
    negativos = resultado_cliente.get("fatores_negativos", [])

    # Regra 0: sem produto elegível
    if produto == "NENHUM" or limite_maximo == 0:
        explicacao = gerar_explicacao_cliente(
            "RECUSADO", positivos, negativos, 0, valor_solicitado, produto
        )
        return {
            "decisao": "RECUSADO",
            "limite_aprovado": 0.0,
            "motivo": "Nenhum produto de crédito elegível para o perfil atual.",
            "explicacao_cliente": explicacao,
        }

    # Regra 1: score >= 80
    if score >= 80:
        limite = round(min(limite_maximo, valor_solicitado), 2)
        explicacao = gerar_explicacao_cliente(
            "APROVADO", positivos, negativos, limite, valor_solicitado, produto
        )
        return {
            "decisao": "APROVADO",
            "limite_aprovado": limite,
            "motivo": f"Score {score}/100 (risco BAIXO). Aprovado pelo limite de R$ {limite:,.2f}.",
            "explicacao_cliente": explicacao,
        }

    # Regra 2: score 60–79
    if 60 <= score < 80:
        limite = round(min(limite_maximo * 0.70, valor_solicitado), 2)
        explicacao = gerar_explicacao_cliente(
            "APROVADO", positivos, negativos, limite, valor_solicitado, produto
        )
        return {
            "decisao": "APROVADO",
            "limite_aprovado": limite,
            "motivo": (
                f"Score {score}/100 (risco MÉDIO). "
                f"Aprovado com limite reduzido (70% do máximo): R$ {limite:,.2f}."
            ),
            "explicacao_cliente": explicacao,
        }

    # Regra 3: score < 60
    explicacao = gerar_explicacao_cliente(
        "RECUSADO", positivos, negativos, 0, valor_solicitado, produto
    )
    return {
        "decisao": "RECUSADO",
        "limite_aprovado": 0.0,
        "motivo": f"Score {score}/100 (risco ALTO). Perfil não atende aos critérios mínimos.",
        "explicacao_cliente": explicacao,
    }
