"""
AgenteAuditoria — Registra todas as etapas e gera a trilha auditável completa.

Produz um JSON com:
  - audit_id único: AUD-YYYYMMDD-HHMMSS-{cliente_id}
  - timestamp ISO 8601
  - dados do pedido original
  - resultado de cada agente (etapas)
  - decisão final
"""

from datetime import datetime
from typing import Dict, Any


def gerar_audit_id(cliente_id: str) -> str:
    agora = datetime.now()
    return f"AUD-{agora.strftime('%Y%m%d-%H%M%S')}-{cliente_id}"


def registrar(
    cliente_id: str,
    valor_solicitado: float,
    resultado_cliente: Dict[str, Any],
    resultado_carteira: Dict[str, Any],
    resultado_decisor: Dict[str, Any],
) -> Dict[str, Any]:
    """Ponto de entrada do AgenteAuditoria. Retorna trilha auditável completa."""
    agora = datetime.now()

    return {
        "audit_id": gerar_audit_id(cliente_id),
        "cliente_id": cliente_id,
        "timestamp": agora.isoformat(),
        "valor_solicitado": valor_solicitado,
        "etapas": [
            {
                "agente": "AgenteCliente",
                "descricao": "Avaliação de perfil financeiro e cálculo de score",
                "resultado": resultado_cliente,
            },
            {
                "agente": "AgenteCarteira",
                "descricao": "Seleção de produto elegível e cálculo de limite máximo",
                "resultado": resultado_carteira,
            },
            {
                "agente": "AgenteDecisor",
                "descricao": "Aplicação das regras de decisão e emissão do resultado",
                "resultado": resultado_decisor,
            },
        ],
        "decisao_final": resultado_decisor["decisao"],
        "limite_final": resultado_decisor["limite_aprovado"],
    }
