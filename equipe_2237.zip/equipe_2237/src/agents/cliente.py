"""
AgenteCliente — Avalia o perfil financeiro do cliente e calcula score explicável.

Regras de score (transparentes e auditáveis):
  Base: 50 pontos

  Histórico de pagamentos:
    EXCELENTE:     +30 | BOM: +20 | REGULAR: +5 | RUIM: -20 | SEM_HISTORICO: 0

  Comprometimento de renda:
    <= 20%: +20 | 21-35%: +10 | 36-50%: 0 | > 50%: -20

  Tempo de relacionamento:
    >= 10 anos: +15 | 5-9 anos: +10 | 2-4 anos: +5 | < 2 anos: 0

  Situação cadastral:
    Restrição no CPF: -25 | Dívida ativa: -10

Score final = média entre cálculo acima e score_comportamental do cliente (0–100).
"""

from typing import Dict, Any, Tuple, List


HISTORICO_PONTOS: Dict[str, int] = {
    "EXCELENTE": 30,
    "BOM": 20,
    "REGULAR": 5,
    "RUIM": -20,
    "SEM_HISTORICO": 0,
}


def calcular_score(cliente: Dict[str, Any]) -> Tuple[int, List[str], List[str]]:
    """Calcula score explicável. Retorna (score, fatores_positivos, fatores_negativos)."""
    pontos = 50
    positivos: List[str] = []
    negativos: List[str] = []

    # Histórico de pagamentos
    historico = cliente.get("historico_pagamentos", "SEM_HISTORICO")
    pts = HISTORICO_PONTOS.get(historico, 0)
    pontos += pts
    if pts > 0:
        positivos.append(f"Histórico de pagamentos {historico.lower()}")
    elif pts < 0:
        negativos.append(f"Histórico de pagamentos {historico.lower()}")

    # Comprometimento de renda
    comp = cliente.get("comprometimento_renda_pct", 50)
    if comp <= 20:
        pontos += 20
        positivos.append(f"Apenas {comp}% da renda comprometida — excelente margem disponível")
    elif comp <= 35:
        pontos += 10
        positivos.append(f"{comp}% da renda comprometida — dentro do limite saudável")
    elif comp > 50:
        pontos -= 20
        negativos.append(f"{comp}% da renda já comprometida — acima do limite seguro de 50%")

    # Tempo de relacionamento
    tempo = cliente.get("tempo_relacionamento_anos", 0)
    if tempo >= 10:
        pontos += 15
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    elif tempo >= 5:
        pontos += 10
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    elif tempo >= 2:
        pontos += 5
        positivos.append(f"{tempo} anos de relacionamento com o banco")
    else:
        negativos.append("Relacionamento recente com o banco (menos de 2 anos)")

    # Situação cadastral
    if cliente.get("restricoes_cpf", False):
        pontos -= 25
        negativos.append("Restrição ativa no CPF")

    if cliente.get("dividas_ativas", False):
        pontos -= 10
        negativos.append("Dívida ativa pendente")

    # Média com score_comportamental externo
    score_ext = cliente.get("score_comportamental", pontos)
    score_final = round((pontos + score_ext) / 2)
    score_final = max(0, min(100, score_final))

    return score_final, positivos, negativos


def classificar_risco(score: int) -> str:
    if score >= 80:
        return "BAIXO"
    if score >= 60:
        return "MEDIO"
    return "ALTO"


def gerar_justificativa(
    score: int, risco: str, positivos: List[str], negativos: List[str]
) -> str:
    partes = []
    if positivos:
        partes.append("Pontos favoráveis: " + "; ".join(positivos) + ".")
    if negativos:
        partes.append("Pontos de atenção: " + "; ".join(negativos) + ".")
    partes.append(f"Score calculado: {score}/100 — Risco {risco}.")
    return " ".join(partes)


def analisar_cliente(cliente: Dict[str, Any]) -> Dict[str, Any]:
    """Ponto de entrada do AgenteCliente."""
    score, positivos, negativos = calcular_score(cliente)
    risco = classificar_risco(score)
    justificativa = gerar_justificativa(score, risco, positivos, negativos)

    return {
        "score": score,
        "risco": risco,
        "justificativa": justificativa,
        "fatores_positivos": positivos,
        "fatores_negativos": negativos,
    }
