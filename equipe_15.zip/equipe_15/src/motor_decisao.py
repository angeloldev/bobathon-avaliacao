"""
Motor de Decisão — módulo consolidador do sistema multi-agentes de crédito.

Recebe os outputs do Agente Carteira e do Agente Cliente, calcula o score
consolidado ponderado, determina a decisão final, seleciona a linha de
crédito mais adequada, calcula o limite aprovado em BRL e gera a justificativa
em linguagem clara e acessível.

Este módulo não consulta bases de dados nem executa lógica de agente —
apenas consolida e decide com base nas entradas recebidas.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from gerador_pedido import PedidoCredito
from agente_carteira import ContextoCarteira
from agente_cliente import ContextoCliente

logger = logging.getLogger(__name__)

VERSAO_MOTOR = "2.0.0-multiagente"

# Faixas de score consolidado → decisão e multiplicador de limite
FAIXAS_DECISAO = [
    (80.0, "APROVADO",              3.0),
    (60.0, "APROVADO",              2.0),
    (40.0, "APROVADO COM RESTRIÇÃO", 1.0),
    (0.0,  "NEGADO",                0.0),
]


# ---------------------------------------------------------------------------
# Estrutura de saída
# ---------------------------------------------------------------------------

@dataclass
class DecisaoFinal:
    """
    Decisão consolidada do motor de crédito.

    Produzida a partir dos outputs do Agente Carteira e do Agente Cliente.
    """

    decisao: str                             # APROVADO | APROVADO COM RESTRIÇÃO | NEGADO
    limite_aprovado: Optional[float]         # None quando NEGADO
    linha_credito_selecionada: str           # Nome da linha aprovada
    score_consolidado: float                 # 0 a 100
    score_agente_carteira: float
    score_agente_cliente: float
    justificativa: str                       # Texto em linguagem acessível
    timestamp: str
    versao_motor: str


# ---------------------------------------------------------------------------
# Motor
# ---------------------------------------------------------------------------

class MotorDecisao:
    """
    Motor de Decisão — consolida os dois agentes e decide o crédito.

    Score consolidado = 40% score carteira + 60% score cliente.
    """

    NOME_MODULO = "Motor de Decisão"
    PESO_CARTEIRA = 0.40
    PESO_CLIENTE = 0.60

    def decidir(
        self,
        pedido: PedidoCredito,
        ctx_carteira: ContextoCarteira,
        ctx_cliente: ContextoCliente,
    ) -> DecisaoFinal:
        """
        Consolida os contextos dos agentes e produz a decisão final.

        Parâmetros
        ----------
        pedido        : PedidoCredito
        ctx_carteira  : ContextoCarteira  Saída do Agente Carteira.
        ctx_cliente   : ContextoCliente   Saída do Agente Cliente.

        Retorna
        -------
        DecisaoFinal
        """
        timestamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        logger.info(f"[{self.NOME_MODULO}] Consolidando decisão para cliente {pedido.id_cliente}.")

        # ------------------------------------------------------------------
        # Bloqueio imediato (vindo do Agente Cliente)
        # ------------------------------------------------------------------
        if ctx_cliente.bloqueio:
            justificativa = self._justificativa_negado(
                pedido=pedido,
                ctx_cliente=ctx_cliente,
                ctx_carteira=ctx_carteira,
                motivo=ctx_cliente.motivo_bloqueio,
            )
            logger.info(f"[{self.NOME_MODULO}] Decisão: NEGADO (bloqueio de cliente).")
            return DecisaoFinal(
                decisao="NEGADO",
                limite_aprovado=None,
                linha_credito_selecionada="",
                score_consolidado=0.0,
                score_agente_carteira=ctx_carteira.score_interno_carteira,
                score_agente_cliente=ctx_cliente.score_risco_cliente,
                justificativa=justificativa,
                timestamp=timestamp,
                versao_motor=VERSAO_MOTOR,
            )

        # Bloqueio pela carteira (nenhuma linha disponível)
        if not ctx_carteira.elegivel:
            justificativa = self._justificativa_negado(
                pedido=pedido,
                ctx_cliente=ctx_cliente,
                ctx_carteira=ctx_carteira,
                motivo="Nenhuma linha de crédito disponível para este perfil no momento.",
            )
            logger.info(f"[{self.NOME_MODULO}] Decisão: NEGADO (sem linhas disponíveis).")
            return DecisaoFinal(
                decisao="NEGADO",
                limite_aprovado=None,
                linha_credito_selecionada="",
                score_consolidado=0.0,
                score_agente_carteira=ctx_carteira.score_interno_carteira,
                score_agente_cliente=ctx_cliente.score_risco_cliente,
                justificativa=justificativa,
                timestamp=timestamp,
                versao_motor=VERSAO_MOTOR,
            )

        # ------------------------------------------------------------------
        # Score consolidado ponderado
        # ------------------------------------------------------------------
        score_consolidado = round(
            ctx_carteira.score_interno_carteira * self.PESO_CARTEIRA
            + ctx_cliente.score_risco_cliente * self.PESO_CLIENTE,
            2,
        )

        # ------------------------------------------------------------------
        # Decisão e multiplicador de limite
        # ------------------------------------------------------------------
        decisao = "NEGADO"
        multiplicador = 0.0
        for limiar, dec, mult in FAIXAS_DECISAO:
            if score_consolidado >= limiar:
                decisao = dec
                multiplicador = mult
                break

        # ------------------------------------------------------------------
        # Seleção da linha e cálculo do limite
        # ------------------------------------------------------------------
        linha_selecionada = ""
        limite_aprovado: Optional[float] = None

        if decisao != "NEGADO" and ctx_carteira.linhas_disponiveis:
            # Seleciona a melhor linha que caiba no multiplicador calculado
            linha_obj = self._selecionar_linha(ctx_carteira, multiplicador, pedido)
            linha_selecionada = linha_obj.nome
            limite_aprovado = round(pedido.renda_mensal_comprovada * multiplicador, 2)
            # Limite não pode exceder o teto da linha selecionada
            limite_aprovado = min(limite_aprovado, linha_obj.limite_maximo)

        # ------------------------------------------------------------------
        # Justificativa
        # ------------------------------------------------------------------
        if decisao == "NEGADO":
            justificativa = self._justificativa_negado(
                pedido=pedido,
                ctx_cliente=ctx_cliente,
                ctx_carteira=ctx_carteira,
                motivo="Pontuação geral insuficiente para concessão de crédito.",
            )
        else:
            justificativa = self._justificativa_aprovado(
                pedido=pedido,
                ctx_cliente=ctx_cliente,
                ctx_carteira=ctx_carteira,
                decisao=decisao,
                limite=limite_aprovado,
                linha=linha_selecionada,
                score=score_consolidado,
            )

        logger.info(
            f"[{self.NOME_MODULO}] Decisão: {decisao} | "
            f"Score consolidado: {score_consolidado:.1f} | "
            f"Limite: R$ {limite_aprovado:,.2f}" if limite_aprovado else
            f"[{self.NOME_MODULO}] Decisão: {decisao} | Score: {score_consolidado:.1f}"
        )

        return DecisaoFinal(
            decisao=decisao,
            limite_aprovado=limite_aprovado,
            linha_credito_selecionada=linha_selecionada,
            score_consolidado=score_consolidado,
            score_agente_carteira=ctx_carteira.score_interno_carteira,
            score_agente_cliente=ctx_cliente.score_risco_cliente,
            justificativa=justificativa,
            timestamp=timestamp,
            versao_motor=VERSAO_MOTOR,
        )

    # ------------------------------------------------------------------
    # Métodos auxiliares
    # ------------------------------------------------------------------

    @staticmethod
    def _selecionar_linha(
        ctx_carteira: ContextoCarteira,
        multiplicador: float,
        pedido: PedidoCredito,
    ):
        """
        Seleciona a linha de crédito mais adequada ao score do cliente.

        Prioriza a linha com maior limite que não exceda o multiplicador
        calculado pelo motor. Se nenhuma se encaixar, retorna a melhor disponível.
        """
        limite_alvo = pedido.renda_mensal_comprovada * multiplicador
        candidatas = sorted(
            ctx_carteira.linhas_disponiveis,
            key=lambda l: l.limite_maximo,
            reverse=True,
        )
        # Prefere a linha cujo limite máximo seja >= limite_alvo
        for linha in candidatas:
            if linha.limite_maximo >= limite_alvo:
                return linha
        # Fallback: linha de maior limite disponível
        return candidatas[0]

    @staticmethod
    def _formatar_brl(valor: float) -> str:
        """Formata valor como moeda BRL."""
        return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    def _justificativa_aprovado(
        self,
        pedido: PedidoCredito,
        ctx_cliente: ContextoCliente,
        ctx_carteira: ContextoCarteira,
        decisao: str,
        limite: Optional[float],
        linha: str,
        score: float,
    ) -> str:
        """Gera justificativa em linguagem simples para decisão aprovada."""
        pontos_fortes = ctx_cliente.fatores_positivos[:3]
        pontos_atencao = ctx_cliente.fatores_negativos[:2]

        limite_fmt = self._formatar_brl(limite) if limite else "a definir"
        restricao = (
            " com restrição de uso inicial" if decisao == "APROVADO COM RESTRIÇÃO" else ""
        )

        texto = (
            f"Olá, {pedido.nome.split()[0]}! Temos uma boa notícia para você.\n\n"
            f"Após analisar o seu perfil, aprovamos o seu pedido de crédito{restricao}. "
            f"Você receberá um limite de {limite_fmt} na modalidade {linha}.\n\n"
        )

        if pontos_fortes:
            texto += "O que pesou positivamente na sua análise:\n"
            for fator in pontos_fortes:
                texto += f"  • {fator}\n"
            texto += "\n"

        if pontos_atencao:
            texto += "Pontos que merecem atenção:\n"
            for fator in pontos_atencao:
                texto += f"  • {fator}\n"
            texto += "\n"

        if decisao == "APROVADO COM RESTRIÇÃO":
            texto += (
                "Por enquanto, seu limite foi calibrado de forma conservadora. "
                "À medida que você utilizar o crédito com responsabilidade, "
                "poderemos revisar esse valor para cima.\n\n"
            )

        texto += (
            f"Seu índice geral de avaliação foi de {score:.0f} pontos (em 100 possíveis). "
            "Qualquer dúvida, nossa equipe está à disposição."
        )
        return texto

    def _justificativa_negado(
        self,
        pedido: PedidoCredito,
        ctx_cliente: ContextoCliente,
        ctx_carteira: ContextoCarteira,
        motivo: str,
    ) -> str:
        """Gera justificativa em linguagem simples para decisão negada."""
        fatores = ctx_cliente.fatores_negativos[:3]

        texto = (
            f"Olá, {pedido.nome.split()[0]}. Agradecemos o seu interesse.\n\n"
            "Após analisar cuidadosamente o seu perfil, não foi possível aprovar "
            "o seu pedido de crédito neste momento.\n\n"
        )

        if motivo:
            texto += f"Motivo principal: {motivo}\n\n"

        if fatores:
            texto += "Outros fatores que influenciaram a decisão:\n"
            for fator in fatores:
                texto += f"  • {fator}\n"
            texto += "\n"

        texto += (
            "Sabemos que essa resposta pode ser frustrante. "
            "Recomendamos quitar eventuais dívidas em aberto, "
            "manter sua renda comprovada atualizada e retornar em 90 dias. "
            "Nossa equipe está disponível para orientá-lo."
        )
        return texto
