"""
Ponto de entrada do sistema multi-agentes de análise de crédito.

Uso:
  python main_agentes.py          — processa um cliente aleatório dos CSVs
  python main_agentes.py 42       — processa o cliente com id_cliente = 42

Fluxo executado:
  1. Monta o PedidoCredito (CSV ou sintético)
  2. Agente Carteira avalia linhas e limites disponíveis
  3. Agente Cliente analisa risco e capacidade de pagamento
  4. Motor de Decisão consolida e decide
  5. Exibe resultado completo no terminal
  6. Salva rastro auditável em auditoria_agentes/
"""

import logging
import random
import sys
from pathlib import Path

import pandas as pd

from orquestrador import Orquestrador, RegistroAuditoria

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            str(Path(__file__).parent / "sistema_multiagentes.log"),
            encoding="utf-8",
        ),
    ],
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Utilitários de formatação
# ---------------------------------------------------------------------------

def _brl(valor: float) -> str:
    """Formata valor como moeda BRL."""
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _sep(char: str = "═", n: int = 70) -> str:
    return char * n


def _imprimir_resultado(registro: RegistroAuditoria) -> None:
    """Imprime o resultado completo e formatado no terminal."""
    dec = registro.decisao_final
    pedido = registro.pedido_entrada
    etapas = registro.etapas

    print(f"\n{_sep()}")
    print("  SISTEMA MULTI-AGENTES DE ANÁLISE DE CRÉDITO")
    print("  Simulação IBM Watson Orchestrate X")
    print(_sep())
    print(f"  Execução ID  : {registro.id_execucao}")
    print(f"  Data/Hora    : {registro.timestamp_inicio}")
    print(f"  Cliente      : {pedido['nome']}  (ID {pedido['id_cliente']})")
    print(f"  CPF          : {pedido['cpf']}")
    print(f"  Cidade/UF    : {pedido['cidade']} / {pedido['estado']}")
    print(f"  Duração total: {registro.duracao_total_ms:.1f} ms")
    print(_sep("─"))

    # --- Etapa 1: Agente Carteira ---
    etapa_carteira = next(e for e in etapas if e.nome_etapa == "Avaliação de Carteira")
    saida_c = etapa_carteira.saida
    print(f"\n  📦  AGENTE CARTEIRA  [{etapa_carteira.duracao_ms:.1f} ms]")
    print(f"  {'─' * 50}")
    print(f"  Score interno carteira : {saida_c['score_interno_carteira']:.1f} / 100")
    print(f"  Linhas disponíveis     : {len(saida_c['linhas_disponiveis'])}")
    if saida_c["linhas_disponiveis"]:
        for linha in saida_c["linhas_disponiveis"]:
            print(f"    • {linha['nome']:<25} limite máx.: {_brl(linha['limite_maximo'])}")
    else:
        print("    (nenhuma linha elegível)")
    print(f"  Observações:")
    for obs in saida_c["observacoes"][:4]:
        print(f"    ↳ {obs}")

    # --- Etapa 2: Agente Cliente ---
    etapa_cliente = next(e for e in etapas if e.nome_etapa == "Análise de Cliente")
    saida_cl = etapa_cliente.saida
    print(f"\n  👤  AGENTE CLIENTE  [{etapa_cliente.duracao_ms:.1f} ms]")
    print(f"  {'─' * 50}")
    print(f"  Score risco cliente    : {saida_cl['score_risco_cliente']:.1f} / 100")
    print(f"  Nível de risco         : {saida_cl['nivel_risco']}")
    cap = saida_cl["capacidade_pagamento_mensal"]
    print(f"  Capacidade pag./mês    : {_brl(cap)}")
    if saida_cl["fatores_positivos"]:
        print("  Fatores positivos:")
        for f in saida_cl["fatores_positivos"]:
            print(f"    ✔ {f}")
    if saida_cl["fatores_negativos"]:
        print("  Fatores negativos:")
        for f in saida_cl["fatores_negativos"]:
            print(f"    ✘ {f}")
    if saida_cl["bloqueio"]:
        print(f"  ⛔ BLOQUEIO: {saida_cl['motivo_bloqueio']}")

    # --- Decisão Final ---
    print(f"\n{_sep('═')}")
    print(f"  🏦  DECISÃO FINAL — MOTOR DE DECISÃO  [{etapas[-1].duracao_ms:.1f} ms]")
    print(_sep("═"))
    print(f"  Decisão                : {dec['decisao']}")
    print(f"  Score consolidado      : {dec['score_consolidado']:.2f} / 100")
    print(f"    ↳ Peso carteira (40%): {dec['score_agente_carteira']:.1f}")
    print(f"    ↳ Peso cliente  (60%): {dec['score_agente_cliente']:.1f}")
    if dec["limite_aprovado"]:
        print(f"  Limite aprovado        : {_brl(dec['limite_aprovado'])}")
        print(f"  Linha de crédito       : {dec['linha_credito_selecionada']}")
    else:
        print("  Limite aprovado        : Não aplicável")
    print(_sep("─"))
    print("\n  JUSTIFICATIVA:\n")
    for linha in dec["justificativa"].splitlines():
        print(f"  {linha}")
    print(f"\n{_sep('─')}")
    print(f"  Rastro auditável salvo em: {registro.caminho_arquivo}")
    print(_sep())
    print()


# ---------------------------------------------------------------------------
# Seleção do id_cliente
# ---------------------------------------------------------------------------

def _obter_id_cliente() -> int:
    """
    Lê id_cliente de sys.argv ou sorteia um aleatório dos CSVs.

    Retorna
    -------
    int
    """
    if len(sys.argv) >= 2:
        try:
            return int(sys.argv[1])
        except ValueError:
            print(f"[ERRO] Argumento inválido: '{sys.argv[1]}'. Informe um número inteiro.")
            sys.exit(1)

    csv_clientes = Path(__file__).parent / "clientes.csv"
    if csv_clientes.exists():
        df = pd.read_csv(csv_clientes, encoding="utf-8-sig")
        id_c = int(random.choice(df["id_cliente"].tolist()))
        logger.info(f"Nenhum id_cliente informado — usando cliente aleatório: {id_c}.")
        return id_c

    id_c = random.randint(1, 200)
    logger.info(f"CSVs não encontrados — gerando cliente sintético com id {id_c}.")
    return id_c


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Função principal — orquestra o fluxo e exibe o resultado."""
    print(f"\n{_sep()}")
    print("  SISTEMA MULTI-AGENTES — IBM Watson Orchestrate X (simulação)")
    print(_sep())

    id_cliente = _obter_id_cliente()
    print(f"  Processando cliente ID: {id_cliente}\n")

    orq = Orquestrador()
    try:
        registro = orq.processar(id_cliente)
    except ValueError as exc:
        print(f"\n[ERRO] {exc}")
        print("Verifique se o id_cliente existe na base ou se os CSVs estão disponíveis.")
        sys.exit(1)

    _imprimir_resultado(registro)


if __name__ == "__main__":
    main()
