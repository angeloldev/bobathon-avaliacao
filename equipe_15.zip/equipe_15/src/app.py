"""
app.py — Servidor Flask do sistema de visualização multi-agentes.

Serve a página web e transmite eventos SSE em tempo real conforme cada
etapa do fluxo de análise de crédito é executada.

Execução:
    python app.py

Acesso:
    http://localhost:5000

Rotas:
    GET  /                       Página principal (static/index.html)
    GET  /analisar?id=<int>      Stream SSE com eventos de cada etapa
    GET  /historico              Últimas decisões da sessão (JSON)
    GET  /clientes_disponiveis   Lista de IDs válidos nos CSVs (JSON)
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
import uuid
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Generator

from flask import Flask, Response, jsonify, request, send_from_directory

# Módulos do sistema multi-agentes (sem modificação)
from gerador_pedido import montar_pedido
from agente_carteira import AgenteCarteira
from agente_cliente import AgenteCliente
from motor_decisao import MotorDecisao
from orquestrador import Orquestrador, DIRETORIO_AUDITORIA

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Pasta raiz do pacote src/ — permite executar de qualquer cwd
_DIR = Path(__file__).parent

app = Flask(__name__, static_folder=str(_DIR / "static"), static_url_path="/static")

# Histórico de decisões da sessão (máx. 50 entradas)
_historico: list[dict] = []
_historico_lock = threading.Lock()

DIRETORIO_AUDITORIA.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# OrquestradorSSE — subclasse que intercala emissão de eventos SSE
# ---------------------------------------------------------------------------

class OrquestradorSSE(Orquestrador):
    """
    Subclasse de Orquestrador que emite eventos SSE em cada etapa do fluxo.

    Não altera nenhuma lógica de negócio dos agentes — apenas envolve
    as chamadas existentes com emissão de mensagens para o cliente SSE.
    """

    def __init__(self, fila: queue.Queue) -> None:
        super().__init__()
        self._q = fila

    def _emitir(self, evento: str, dados: dict) -> None:
        """Coloca um evento SSE na fila de transmissão."""
        self._q.put({"evento": evento, "dados": dados})

    def processar(self, id_cliente: int):  # type: ignore[override]
        """
        Executa o fluxo multi-agentes emitindo um evento SSE por etapa.

        Lógica idêntica ao Orquestrador original, com _emitir() inserido
        antes e depois de cada chamada de agente.
        """
        import time as _time
        import uuid as _uuid
        from dataclasses import asdict as _asdict

        id_execucao = str(_uuid.uuid4())[:8].upper()
        ts_inicio = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        t0_total = _time.perf_counter()

        # --- Etapa 0: montagem do pedido ---
        self._emitir("inicio_fluxo", {
            "id_execucao": id_execucao,
            "id_cliente": id_cliente,
            "timestamp": ts_inicio,
        })

        try:
            pedido = montar_pedido(id_cliente)
        except ValueError as exc:
            self._emitir("erro", {"mensagem": str(exc)})
            raise

        pedido_dict = self._pedido_para_dict(pedido)
        self._emitir("pedido_montado", {
            "id_execucao": id_execucao,
            "pedido": pedido_dict,
        })

        # --- Etapa 1: Agente Carteira ---
        self._emitir("carteira_inicio", {"mensagem": "Agente Carteira iniciando avaliação..."})
        t0 = _time.perf_counter()

        ctx_carteira = self._agente_carteira.avaliar(pedido)

        dur = round((_time.perf_counter() - t0) * 1000, 2)
        self._emitir("carteira_fim", {
            "duracao_ms": dur,
            "dados": self._contexto_carteira_para_dict(ctx_carteira),
        })

        # --- Etapa 2: Agente Cliente ---
        self._emitir("cliente_inicio", {
            "mensagem": f"Agente Cliente iniciando análise ({len(ctx_carteira.linhas_disponiveis)} linhas da carteira)..."
        })
        t0 = _time.perf_counter()

        ctx_cliente = self._agente_cliente.analisar(pedido, ctx_carteira)

        dur = round((_time.perf_counter() - t0) * 1000, 2)
        self._emitir("cliente_fim", {
            "duracao_ms": dur,
            "dados": _asdict(ctx_cliente),
        })

        # --- Etapa 3: Motor de Decisão ---
        self._emitir("decisao_inicio", {"mensagem": "Motor de Decisão consolidando resultado..."})
        t0 = _time.perf_counter()

        decisao = self._motor_decisao.decidir(pedido, ctx_carteira, ctx_cliente)

        dur = round((_time.perf_counter() - t0) * 1000, 2)
        decisao_dict = _asdict(decisao)
        self._emitir("decisao_fim", {
            "duracao_ms": dur,
            "dados": decisao_dict,
        })

        # --- Registro auditável ---
        duracao_total = round((_time.perf_counter() - t0_total) * 1000, 2)

        # Reutiliza o método de salvar da classe pai
        from orquestrador import EtapaExecucao, RegistroAuditoria
        etapas = [
            EtapaExecucao(
                nome_etapa="Avaliação de Carteira",
                agente="AgenteCarteira",
                inicio=ts_inicio,
                fim=datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                duracao_ms=0,
                status="SUCESSO" if ctx_carteira.elegivel else "BLOQUEADO",
                saida=self._contexto_carteira_para_dict(ctx_carteira),
            ),
            EtapaExecucao(
                nome_etapa="Análise de Cliente",
                agente="AgenteCliente",
                inicio=ts_inicio,
                fim=datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                duracao_ms=0,
                status="BLOQUEADO" if ctx_cliente.bloqueio else "SUCESSO",
                saida=_asdict(ctx_cliente),
            ),
            EtapaExecucao(
                nome_etapa="Motor de Decisão",
                agente="MotorDecisao",
                inicio=ts_inicio,
                fim=datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                duracao_ms=dur,
                status="SUCESSO",
                saida=decisao_dict,
            ),
        ]
        registro = RegistroAuditoria(
            id_execucao=id_execucao,
            timestamp_inicio=ts_inicio,
            timestamp_fim=datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            duracao_total_ms=duracao_total,
            versao_orquestrador="1.0.0-web",
            id_cliente=id_cliente,
            pedido_entrada=pedido_dict,
            etapas=etapas,
            decisao_final=decisao_dict,
        )
        caminho = self._salvar_auditoria(registro, id_execucao, id_cliente)
        registro.caminho_arquivo = str(caminho)

        self._emitir("auditoria", {
            "caminho": str(caminho),
            "duracao_total_ms": duracao_total,
            "id_execucao": id_execucao,
        })
        self._emitir("fim", {"id_execucao": id_execucao})

        # Salva no histórico da sessão
        _registrar_historico(
            id_execucao=id_execucao,
            id_cliente=id_cliente,
            nome=pedido.nome,
            decisao=decisao.decisao,
            limite=decisao.limite_aprovado,
            timestamp=ts_inicio,
        )

        return registro


# ---------------------------------------------------------------------------
# Histórico
# ---------------------------------------------------------------------------

def _registrar_historico(
    id_execucao: str,
    id_cliente: int,
    nome: str,
    decisao: str,
    limite,
    timestamp: str,
) -> None:
    with _historico_lock:
        _historico.insert(0, {
            "id_execucao": id_execucao,
            "id_cliente": id_cliente,
            "nome": nome,
            "decisao": decisao,
            "limite": limite,
            "timestamp": timestamp,
        })
        if len(_historico) > 50:
            _historico.pop()


# ---------------------------------------------------------------------------
# Geração de stream SSE
# ---------------------------------------------------------------------------

def _gerar_sse(fila: queue.Queue, timeout: float = 120.0) -> Generator[str, None, None]:
    """Lê eventos da fila e os formata como Server-Sent Events."""
    prazo = time.time() + timeout
    while time.time() < prazo:
        try:
            item = fila.get(timeout=0.5)
            payload = json.dumps(item, ensure_ascii=False, default=str)
            yield f"data: {payload}\n\n"
            if item.get("evento") in ("fim", "erro"):
                return
        except queue.Empty:
            yield ": keep-alive\n\n"


# ---------------------------------------------------------------------------
# Rotas Flask
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    """Serve a página principal."""
    return send_from_directory("static", "index.html")


@app.route("/analisar")
def analisar():
    """
    Rota SSE — executa o fluxo multi-agentes e transmite eventos em tempo real.

    Query param: id (int) — id_cliente a analisar.
    """
    try:
        id_cliente = int(request.args.get("id", 0))
        if id_cliente <= 0:
            raise ValueError("id_cliente deve ser um inteiro positivo.")
    except (ValueError, TypeError) as exc:
        return jsonify({"erro": str(exc)}), 400

    fila: queue.Queue = queue.Queue()

    def executar():
        try:
            orq = OrquestradorSSE(fila)
            orq.processar(id_cliente)
        except Exception as exc:
            fila.put({"evento": "erro", "dados": {"mensagem": str(exc)}})

    thread = threading.Thread(target=executar, daemon=True)
    thread.start()

    return Response(
        _gerar_sse(fila),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Access-Control-Allow-Origin": "*",
        },
    )


@app.route("/historico")
def historico():
    """Retorna o histórico de decisões da sessão atual."""
    with _historico_lock:
        return jsonify(list(_historico))


@app.route("/clientes_disponiveis")
def clientes_disponiveis():
    """Retorna a lista de IDs disponíveis no CSV, ou faixa padrão."""
    csv = _DIR / "clientes.csv"
    if csv.exists():
        import pandas as pd
        df = pd.read_csv(csv, encoding="utf-8-sig")
        ids = sorted(df["id_cliente"].tolist())
        return jsonify({"ids": ids, "total": len(ids)})
    return jsonify({"ids": list(range(1, 201)), "total": 200})


# ---------------------------------------------------------------------------
# Ponto de entrada
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  Sistema Multi-Agentes — Visualizador Web")
    print("  Acesse: http://localhost:5000")
    print("=" * 60 + "\n")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
