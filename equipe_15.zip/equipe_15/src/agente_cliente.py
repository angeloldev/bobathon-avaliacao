"""
Agente Cliente — módulo independente do sistema multi-agentes de crédito.

Responsável por analisar o perfil do cliente: histórico de crédito,
comportamento financeiro e capacidade de pagamento. Recebe o PedidoCredito
e o ContextoCarteira (contexto passado pelo orquestrador após a etapa anterior)
e devolve um ContextoCliente com análise de risco completa.

Este agente não toma a decisão de crédito — apenas produz o diagnóstico
do perfil, que será consolidado pelo motor de decisão.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from gerador_pedido import PedidoCredito
from agente_carteira import ContextoCarteira

logger = logging.getLogger(__name__)

# Níveis de risco
RISCO_BAIXO = "BAIXO"
RISCO_MEDIO = "MÉDIO"
RISCO_ALTO = "ALTO"
RISCO_BLOQUEADO = "BLOQUEADO"


# ---------------------------------------------------------------------------
# Estrutura de saída
# ---------------------------------------------------------------------------

@dataclass
class ContextoCliente:
    """
    Saída do Agente Cliente.

    Contém a análise de risco do perfil, capacidade de pagamento,
    fatores positivos e negativos identificados e flag de bloqueio.
    """

    score_risco_cliente: float          # 0 a 100 — quanto maior, menor o risco
    nivel_risco: str                    # BAIXO / MÉDIO / ALTO / BLOQUEADO
    capacidade_pagamento_mensal: float  # renda comprovada livre de comprometimento
    fatores_positivos: list[str] = field(default_factory=list)
    fatores_negativos: list[str] = field(default_factory=list)
    bloqueio: bool = False
    motivo_bloqueio: str = ""


# ---------------------------------------------------------------------------
# Agente
# ---------------------------------------------------------------------------

class AgenteCliente:
    """
    Agente Cliente — analisa o perfil, histórico e capacidade de pagamento.

    Recebe PedidoCredito + ContextoCarteira e devolve ContextoCliente
    com score de risco, nível de risco e fatores positivos/negativos.
    """

    NOME_AGENTE = "Agente Cliente"

    # Pesos para composição do score de risco
    PESO_SCORE_BUREAU = 30.0
    PESO_COMPROMETIMENTO = 20.0
    PESO_INADIMPLENCIA = 20.0
    PESO_ESTABILIDADE = 15.0
    PESO_TIPO_RENDA = 15.0

    def analisar(
        self,
        pedido: PedidoCredito,
        contexto_carteira: ContextoCarteira,
    ) -> ContextoCliente:
        """
        Realiza a análise de risco do cliente.

        Parâmetros
        ----------
        pedido            : PedidoCredito
        contexto_carteira : ContextoCarteira  Contexto gerado pelo Agente Carteira.

        Retorna
        -------
        ContextoCliente
        """
        logger.info(
            f"[{self.NOME_AGENTE}] Iniciando análise do cliente {pedido.id_cliente} "
            f"(contexto carteira: {len(contexto_carteira.linhas_disponiveis)} linhas disponíveis)."
        )

        fatores_positivos: list[str] = []
        fatores_negativos: list[str] = []
        score = 0.0

        # ------------------------------------------------------------------
        # Verificações bloqueantes
        # ------------------------------------------------------------------
        if pedido.negativado:
            logger.warning(f"[{self.NOME_AGENTE}] Cliente {pedido.id_cliente} está negativado — BLOQUEADO.")
            return ContextoCliente(
                score_risco_cliente=0.0,
                nivel_risco=RISCO_BLOQUEADO,
                capacidade_pagamento_mensal=0.0,
                fatores_positivos=[],
                fatores_negativos=["Há pendências financeiras registradas em órgãos de proteção ao crédito."],
                bloqueio=True,
                motivo_bloqueio="O cliente possui restrições ativas em serviços de proteção ao crédito.",
            )

        if pedido.percentual_comprometimento_renda > 70:
            logger.warning(
                f"[{self.NOME_AGENTE}] Comprometimento de {pedido.percentual_comprometimento_renda:.1f}% — BLOQUEADO."
            )
            return ContextoCliente(
                score_risco_cliente=0.0,
                nivel_risco=RISCO_BLOQUEADO,
                capacidade_pagamento_mensal=0.0,
                fatores_positivos=[],
                fatores_negativos=[
                    f"Mais de {pedido.percentual_comprometimento_renda:.0f}% da renda já está "
                    "comprometida com outras dívidas."
                ],
                bloqueio=True,
                motivo_bloqueio=(
                    f"O comprometimento de renda de {pedido.percentual_comprometimento_renda:.1f}% "
                    "ultrapassa o limite máximo de 70%."
                ),
            )

        # ------------------------------------------------------------------
        # Critério 1 — Score bureau (peso 30)
        # ------------------------------------------------------------------
        sb = pedido.score_bureau
        pts_bureau = (sb / 1000) * self.PESO_SCORE_BUREAU
        score += pts_bureau

        if sb >= 750:
            fatores_positivos.append(
                f"Seu histórico de crédito é excelente (pontuação {sb}/1000)."
            )
        elif sb >= 500:
            fatores_positivos.append(
                f"Seu histórico de crédito é bom (pontuação {sb}/1000)."
            )
        elif sb >= 300:
            fatores_negativos.append(
                f"Seu histórico de crédito está abaixo do ideal (pontuação {sb}/1000)."
            )
        else:
            fatores_negativos.append(
                f"Seu histórico de crédito está muito baixo (pontuação {sb}/1000)."
            )

        # ------------------------------------------------------------------
        # Critério 2 — Comprometimento de renda (peso 20)
        # ------------------------------------------------------------------
        comp = pedido.percentual_comprometimento_renda
        if comp <= 30:
            pts_comp = self.PESO_COMPROMETIMENTO
            fatores_positivos.append(
                f"Apenas {comp:.0f}% da sua renda está comprometida — situação confortável."
            )
        elif comp <= 50:
            pts_comp = self.PESO_COMPROMETIMENTO * 0.6
            fatores_positivos.append(
                f"{comp:.0f}% da renda comprometida — dentro do aceitável."
            )
        else:
            pts_comp = self.PESO_COMPROMETIMENTO * 0.2
            fatores_negativos.append(
                f"{comp:.0f}% da renda já está comprometida com outras dívidas."
            )
        score += pts_comp

        # ------------------------------------------------------------------
        # Critério 3 — Inadimplência histórica (peso 20)
        # ------------------------------------------------------------------
        qtd_inad = sum(1 for p in pedido.produtos if p.inadimplencia_historica)
        if qtd_inad == 0:
            score += self.PESO_INADIMPLENCIA
            fatores_positivos.append("Não há registro de atraso em produtos anteriores.")
        elif qtd_inad == 1:
            pts_inad = self.PESO_INADIMPLENCIA * 0.4
            score += pts_inad
            fatores_negativos.append("Há um registro de atraso em produto anterior.")
        else:
            fatores_negativos.append(
                f"Há {qtd_inad} registros de atraso em produtos anteriores."
            )

        # ------------------------------------------------------------------
        # Critério 4 — Estabilidade de emprego (peso 15)
        # ------------------------------------------------------------------
        est = pedido.estabilidade_emprego_anos
        if est >= 5:
            score += self.PESO_ESTABILIDADE
            fatores_positivos.append(
                f"Tempo de atividade profissional de {est:.1f} anos demonstra estabilidade."
            )
        elif est >= 2:
            score += self.PESO_ESTABILIDADE * 0.6
            fatores_positivos.append(
                f"Você tem {est:.1f} anos na atividade atual — situação estável."
            )
        else:
            score += self.PESO_ESTABILIDADE * 0.1
            fatores_negativos.append(
                f"Tempo de atividade atual de {est:.1f} anos é relativamente curto."
            )

        # ------------------------------------------------------------------
        # Critério 5 — Tipo de renda (peso 15)
        # ------------------------------------------------------------------
        if pedido.tipo_renda in ("CLT", "Servidor Público"):
            score += self.PESO_TIPO_RENDA
            fatores_positivos.append(
                f"Tipo de renda '{pedido.tipo_renda}' oferece alta previsibilidade de pagamento."
            )
        elif pedido.tipo_renda == "Aposentado":
            score += self.PESO_TIPO_RENDA * 0.9
            fatores_positivos.append("Renda de aposentadoria é estável e previsível.")
        elif pedido.tipo_renda == "Empresário":
            score += self.PESO_TIPO_RENDA * 0.5
            fatores_negativos.append(
                "Renda empresarial pode ter variações — analisamos a renda comprovada."
            )
        else:  # Autônomo
            score += self.PESO_TIPO_RENDA * 0.4
            fatores_negativos.append(
                "Renda autônoma pode variar mês a mês — analisamos a renda comprovada."
            )

        # ------------------------------------------------------------------
        # Bônus: tempo de relacionamento e consistência de renda
        # ------------------------------------------------------------------
        if pedido.tempo_relacionamento_meses >= 24:
            score = min(score + 5.0, 100.0)
            fatores_positivos.append(
                f"Você tem {pedido.tempo_relacionamento_meses} meses de relacionamento conosco."
            )

        if pedido.renda_mensal_declarada > 0:
            divergencia = abs(
                pedido.renda_mensal_declarada - pedido.renda_mensal_comprovada
            ) / pedido.renda_mensal_declarada
            if divergencia > 0.30:
                score = max(score - 8.0, 0.0)
                fatores_negativos.append(
                    "A renda declarada difere significativamente da renda comprovada."
                )

        score = round(min(max(score, 0.0), 100.0), 2)

        # ------------------------------------------------------------------
        # Nível de risco
        # ------------------------------------------------------------------
        if score >= 75:
            nivel = RISCO_BAIXO
        elif score >= 50:
            nivel = RISCO_MEDIO
        else:
            nivel = RISCO_ALTO

        # ------------------------------------------------------------------
        # Capacidade de pagamento mensal
        # ------------------------------------------------------------------
        capacidade = round(
            pedido.renda_mensal_comprovada * (1 - pedido.percentual_comprometimento_renda / 100),
            2,
        )

        logger.info(
            f"[{self.NOME_AGENTE}] Análise concluída — score risco: {score:.1f}, "
            f"nível: {nivel}, capacidade mensal: R$ {capacidade:,.2f}."
        )

        return ContextoCliente(
            score_risco_cliente=score,
            nivel_risco=nivel,
            capacidade_pagamento_mensal=capacidade,
            fatores_positivos=fatores_positivos,
            fatores_negativos=fatores_negativos,
            bloqueio=False,
            motivo_bloqueio="",
        )
