"""
Orquestrador — camada de coordenação do sistema multi-agentes de crédito.

Simula o comportamento do IBM Watson Orchestrate X: sequencia a execução dos
agentes (Carteira → Cliente → Motor de Decisão), gerencia a passagem de contexto
entre eles, registra cada etapa e gera o rastro auditável completo em JSON.

Este módulo não contém lógica de negócio — apenas coordena, registra e persiste.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional

from gerador_pedido import montar_pedido, PedidoCredito
from agente_carteira import AgenteCarteira, ContextoCarteira
from agente_cliente import AgenteCliente, ContextoCliente
from motor_decisao import MotorDecisao, DecisaoFinal

logger = logging.getLogger(__name__)

# Diretório de auditoria relativo ao próprio arquivo — funciona de qualquer cwd
_DIR = Path(__file__).parent
DIRETORIO_AUDITORIA = _DIR / "auditoria_agentes"
VERSAO_ORQUESTRADOR = "1.0.0"


# ---------------------------------------------------------------------------
# Estrutura do registro auditável
# ---------------------------------------------------------------------------

@dataclass
class EtapaExecucao:
    """Registro de uma etapa individual da orquestração."""

    nome_etapa: str
    agente: str
    inicio: str
    fim: str
    duracao_ms: float
    status: str          # "SUCESSO" | "ERRO" | "BLOQUEADO"
    saida: dict = field(default_factory=dict)
    erro: Optional[str] = None


@dataclass
class RegistroAuditoria:
    """
    Rastro auditável completo de uma execução do fluxo multi-agentes.

    Contém todos os inputs, outputs de cada agente, decisão final,
    justificativa e metadados de execução.
    """

    id_execucao: str
    timestamp_inicio: str
    timestamp_fim: str
    duracao_total_ms: float
    versao_orquestrador: str
    id_cliente: int
    pedido_entrada: dict
    etapas: list[EtapaExecucao] = field(default_factory=list)
    decisao_final: dict = field(default_factory=dict)
    caminho_arquivo: str = ""


# ---------------------------------------------------------------------------
# Orquestrador
# ---------------------------------------------------------------------------

class Orquestrador:
    """
    Orquestrador principal — simula o IBM Watson Orchestrate X.

    Sequencia: montagem do pedido → Agente Carteira → Agente Cliente
               → Motor de Decisão → registro auditável.
    """

    PREFIXO_LOG = "[ORCHESTRATE]"

    def __init__(self) -> None:
        self._agente_carteira = AgenteCarteira()
        self._agente_cliente = AgenteCliente()
        self._motor_decisao = MotorDecisao()
        DIRETORIO_AUDITORIA.mkdir(exist_ok=True)

    def processar(self, id_cliente: int) -> RegistroAuditoria:
        """
        Executa o fluxo completo de análise de crédito para um cliente.

        Parâmetros
        ----------
        id_cliente : int

        Retorna
        -------
        RegistroAuditoria  Registro completo com todos os outputs e a decisão final.
        """
        id_execucao = str(uuid.uuid4())[:8].upper()
        ts_inicio = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        t0_total = time.perf_counter()

        logger.info(
            f"{self.PREFIXO_LOG} ══════════════════════════════════════════"
        )
        logger.info(
            f"{self.PREFIXO_LOG} Execução {id_execucao} | Cliente {id_cliente} | {ts_inicio}"
        )
        logger.info(
            f"{self.PREFIXO_LOG} Versão orquestrador: {VERSAO_ORQUESTRADOR}"
        )
        logger.info(
            f"{self.PREFIXO_LOG} ══════════════════════════════════════════"
        )

        etapas: list[EtapaExecucao] = []

        # ------------------------------------------------------------------
        # Etapa 0 — Montagem do pedido
        # ------------------------------------------------------------------
        logger.info(f"{self.PREFIXO_LOG} [Etapa 0/3] Montando pedido de crédito...")
        t0 = time.perf_counter()
        inicio_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        try:
            pedido = montar_pedido(id_cliente)
        except ValueError as exc:
            raise ValueError(f"Falha ao montar pedido para cliente {id_cliente}: {exc}") from exc

        dur_etapa = round((time.perf_counter() - t0) * 1000, 2)
        logger.info(
            f"{self.PREFIXO_LOG} [Etapa 0/3] Pedido montado em {dur_etapa} ms — "
            f"cliente: {pedido.nome}."
        )

        pedido_dict = self._pedido_para_dict(pedido)

        # ------------------------------------------------------------------
        # Etapa 1 — Agente Carteira
        # ------------------------------------------------------------------
        logger.info(f"{self.PREFIXO_LOG} [Etapa 1/3] Acionando Agente Carteira...")
        t0 = time.perf_counter()
        inicio_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        ctx_carteira: ContextoCarteira = self._agente_carteira.avaliar(pedido)

        dur_etapa = round((time.perf_counter() - t0) * 1000, 2)
        fim_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        status_etapa = "SUCESSO" if ctx_carteira.elegivel else "BLOQUEADO"
        logger.info(
            f"{self.PREFIXO_LOG} [Etapa 1/3] Agente Carteira concluído em {dur_etapa} ms — "
            f"status: {status_etapa}, linhas: {len(ctx_carteira.linhas_disponiveis)}."
        )

        etapas.append(EtapaExecucao(
            nome_etapa="Avaliação de Carteira",
            agente="AgenteCarteira",
            inicio=inicio_etapa,
            fim=fim_etapa,
            duracao_ms=dur_etapa,
            status=status_etapa,
            saida=self._contexto_carteira_para_dict(ctx_carteira),
        ))

        # ------------------------------------------------------------------
        # Etapa 2 — Agente Cliente
        # ------------------------------------------------------------------
        logger.info(
            f"{self.PREFIXO_LOG} [Etapa 2/3] Acionando Agente Cliente "
            f"(contexto carteira: {len(ctx_carteira.linhas_disponiveis)} linhas)..."
        )
        t0 = time.perf_counter()
        inicio_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        ctx_cliente: ContextoCliente = self._agente_cliente.analisar(pedido, ctx_carteira)

        dur_etapa = round((time.perf_counter() - t0) * 1000, 2)
        fim_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        status_etapa = "BLOQUEADO" if ctx_cliente.bloqueio else "SUCESSO"
        logger.info(
            f"{self.PREFIXO_LOG} [Etapa 2/3] Agente Cliente concluído em {dur_etapa} ms — "
            f"status: {status_etapa}, score risco: {ctx_cliente.score_risco_cliente:.1f}."
        )

        etapas.append(EtapaExecucao(
            nome_etapa="Análise de Cliente",
            agente="AgenteCliente",
            inicio=inicio_etapa,
            fim=fim_etapa,
            duracao_ms=dur_etapa,
            status=status_etapa,
            saida=asdict(ctx_cliente),
        ))

        # ------------------------------------------------------------------
        # Etapa 3 — Motor de Decisão
        # ------------------------------------------------------------------
        logger.info(f"{self.PREFIXO_LOG} [Etapa 3/3] Acionando Motor de Decisão...")
        t0 = time.perf_counter()
        inicio_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        decisao: DecisaoFinal = self._motor_decisao.decidir(pedido, ctx_carteira, ctx_cliente)

        dur_etapa = round((time.perf_counter() - t0) * 1000, 2)
        fim_etapa = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        logger.info(
            f"{self.PREFIXO_LOG} [Etapa 3/3] Decisão em {dur_etapa} ms — "
            f"{decisao.decisao} | Score: {decisao.score_consolidado:.1f} | "
            + (f"Limite: R$ {decisao.limite_aprovado:,.2f}" if decisao.limite_aprovado else "Limite: N/A")
        )

        etapas.append(EtapaExecucao(
            nome_etapa="Motor de Decisão",
            agente="MotorDecisao",
            inicio=inicio_etapa,
            fim=fim_etapa,
            duracao_ms=dur_etapa,
            status="SUCESSO",
            saida=asdict(decisao),
        ))

        # ------------------------------------------------------------------
        # Registro auditável
        # ------------------------------------------------------------------
        ts_fim = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        duracao_total = round((time.perf_counter() - t0_total) * 1000, 2)

        registro = RegistroAuditoria(
            id_execucao=id_execucao,
            timestamp_inicio=ts_inicio,
            timestamp_fim=ts_fim,
            duracao_total_ms=duracao_total,
            versao_orquestrador=VERSAO_ORQUESTRADOR,
            id_cliente=id_cliente,
            pedido_entrada=pedido_dict,
            etapas=etapas,
            decisao_final=asdict(decisao),
        )

        caminho = self._salvar_auditoria(registro, id_execucao, id_cliente)
        registro.caminho_arquivo = str(caminho)

        logger.info(
            f"{self.PREFIXO_LOG} Execução {id_execucao} finalizada em {duracao_total} ms. "
            f"Auditoria: {caminho}"
        )
        logger.info(
            f"{self.PREFIXO_LOG} ══════════════════════════════════════════"
        )

        return registro

    # ------------------------------------------------------------------
    # Persistência
    # ------------------------------------------------------------------

    @staticmethod
    def _salvar_auditoria(registro: RegistroAuditoria, id_exec: str, id_cliente: int) -> Path:
        """Salva o registro auditável em JSON no diretório de auditoria."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_arquivo = f"{ts}_{id_exec}_cliente{id_cliente}.json"
        caminho = DIRETORIO_AUDITORIA / nome_arquivo

        with open(caminho, "w", encoding="utf-8") as f:
            json.dump(asdict(registro), f, ensure_ascii=False, indent=2, default=str)

        return caminho

    # ------------------------------------------------------------------
    # Serialização
    # ------------------------------------------------------------------

    @staticmethod
    def _pedido_para_dict(pedido: PedidoCredito) -> dict:
        """Serializa PedidoCredito para dict (os produtos são lista de dicts)."""
        d = {
            "id_cliente": pedido.id_cliente,
            "nome": pedido.nome,
            "cpf": pedido.cpf,
            "data_nascimento": pedido.data_nascimento,
            "estado_civil": pedido.estado_civil,
            "escolaridade": pedido.escolaridade,
            "cidade": pedido.cidade,
            "estado": pedido.estado,
            "score_bureau": pedido.score_bureau,
            "negativado": pedido.negativado,
            "tempo_relacionamento_meses": pedido.tempo_relacionamento_meses,
            "tipo_renda": pedido.tipo_renda,
            "renda_mensal_declarada": pedido.renda_mensal_declarada,
            "renda_mensal_comprovada": pedido.renda_mensal_comprovada,
            "percentual_comprometimento_renda": pedido.percentual_comprometimento_renda,
            "estabilidade_emprego_anos": pedido.estabilidade_emprego_anos,
            "produtos": [
                {
                    "tipo_produto": p.tipo_produto,
                    "status": p.status,
                    "inadimplencia_historica": p.inadimplencia_historica,
                    "valor_contrato": p.valor_contrato,
                }
                for p in pedido.produtos
            ],
        }
        return d

    @staticmethod
    def _contexto_carteira_para_dict(ctx: ContextoCarteira) -> dict:
        """Serializa ContextoCarteira para dict."""
        return {
            "linhas_disponiveis": [
                {
                    "nome": l.nome,
                    "limite_maximo": l.limite_maximo,
                    "multiplicador_renda": l.multiplicador_renda,
                    "descricao": l.descricao,
                    "tipo": l.tipo,
                }
                for l in ctx.linhas_disponiveis
            ],
            "limite_maximo_banco": ctx.limite_maximo_banco,
            "score_interno_carteira": ctx.score_interno_carteira,
            "melhor_linha": ctx.melhor_linha,
            "observacoes": ctx.observacoes,
            "elegivel": ctx.elegivel,
        }
