"""
Gerador de pedido de crédito — módulo de entrada do sistema multi-agentes.

Monta o objeto PedidoCredito lendo as bases CSV existentes (clientes.csv,
renda.csv, produtos.csv). Caso os arquivos não existam, gera dados sintéticos
mínimos para o id_cliente informado usando a biblioteca Faker.

Não possui dependência dos demais módulos do sistema multi-agentes.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd
from faker import Faker

fake = Faker("pt_BR")

# Caminhos relativos ao próprio arquivo — funciona de qualquer cwd
_DIR = Path(__file__).parent
CAMINHO_CLIENTES = _DIR / "clientes.csv"
CAMINHO_RENDA    = _DIR / "renda.csv"
CAMINHO_PRODUTOS = _DIR / "produtos.csv"

TIPOS_RENDA = ["CLT", "Autônomo", "Empresário", "Aposentado", "Servidor Público"]


# ---------------------------------------------------------------------------
# Estrutura de dados
# ---------------------------------------------------------------------------

@dataclass
class ProdutoPedido:
    """Representa um produto bancário vinculado ao pedido."""

    tipo_produto: str
    status: str                    # "Ativo" ou "Encerrado"
    inadimplencia_historica: bool
    valor_contrato: Optional[float] = None


@dataclass
class PedidoCredito:
    """
    Objeto central de entrada do fluxo multi-agentes.

    Concentra todos os dados do cliente necessários para que os agentes
    Carteira e Cliente executem suas análises de forma independente.
    """

    id_cliente: int
    nome: str
    cpf: str
    data_nascimento: str
    estado_civil: str
    escolaridade: str
    cidade: str
    estado: str
    score_bureau: int
    negativado: bool
    tempo_relacionamento_meses: int
    tipo_renda: str
    renda_mensal_declarada: float
    renda_mensal_comprovada: float
    percentual_comprometimento_renda: float
    estabilidade_emprego_anos: float
    produtos: list[ProdutoPedido] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Funções auxiliares de geração sintética
# ---------------------------------------------------------------------------

def _cpf_fake() -> str:
    """Gera CPF fictício no formato XXX.XXX.XXX-XX."""
    n = [random.randint(0, 9) for _ in range(11)]
    return f"{n[0]}{n[1]}{n[2]}.{n[3]}{n[4]}{n[5]}.{n[6]}{n[7]}{n[8]}-{n[9]}{n[10]}"


def _data_nascimento_fake() -> str:
    """Gera data de nascimento resultando em idade entre 18 e 75 anos."""
    hoje = date.today()
    delta = random.randint(18 * 365, 75 * 365)
    return (hoje - timedelta(days=delta)).strftime("%d/%m/%Y")


def _gerar_pedido_sintetico(id_cliente: int) -> PedidoCredito:
    """
    Cria um PedidoCredito sintético completo quando os CSVs não estão disponíveis.

    Parâmetros
    ----------
    id_cliente : int

    Retorna
    -------
    PedidoCredito
    """
    tipo_renda = random.choice(TIPOS_RENDA)
    score = random.randint(300, 900)
    declarada = round(random.uniform(2000, 20000), 2)
    comprovada = round(declarada * random.uniform(0.70, 1.0), 2)
    comprometimento = round(random.uniform(10, 65), 1)
    estabilidade = round(random.uniform(0.5, 20), 1)

    produtos = []
    for _ in range(random.randint(1, 4)):
        produtos.append(ProdutoPedido(
            tipo_produto=random.choice([
                "Conta Corrente", "Poupança", "Seguro de Vida",
                "Investimento CDB", "Empréstimo Pessoal",
            ]),
            status=random.choice(["Ativo", "Ativo", "Encerrado"]),
            inadimplencia_historica=random.random() < 0.10,
        ))

    return PedidoCredito(
        id_cliente=id_cliente,
        nome=fake.name(),
        cpf=_cpf_fake(),
        data_nascimento=_data_nascimento_fake(),
        estado_civil=random.choice(["Solteiro", "Casado", "Divorciado"]),
        escolaridade=random.choice(["Médio", "Superior Completo", "Pós-graduação"]),
        cidade=fake.city(),
        estado=random.choice(["SP", "RJ", "MG", "RS", "PR", "BA"]),
        score_bureau=score,
        negativado=False,
        tempo_relacionamento_meses=random.randint(6, 60),
        tipo_renda=tipo_renda,
        renda_mensal_declarada=declarada,
        renda_mensal_comprovada=comprovada,
        percentual_comprometimento_renda=comprometimento,
        estabilidade_emprego_anos=estabilidade,
        produtos=produtos,
    )


# ---------------------------------------------------------------------------
# Função pública principal
# ---------------------------------------------------------------------------

def montar_pedido(id_cliente: int) -> PedidoCredito:
    """
    Monta o PedidoCredito para o id_cliente informado.

    Tenta ler os arquivos CSV existentes. Se não encontrá-los, gera dados
    sintéticos. Se o id_cliente não existir nos CSVs, lança ValueError.

    Parâmetros
    ----------
    id_cliente : int

    Retorna
    -------
    PedidoCredito

    Lança
    -----
    ValueError
        Se os CSVs existem mas o id_cliente não está presente neles.
    """
    csvs_existem = all(p.exists() for p in [CAMINHO_CLIENTES, CAMINHO_RENDA, CAMINHO_PRODUTOS])

    if not csvs_existem:
        return _gerar_pedido_sintetico(id_cliente)

    # --- Leitura dos CSVs ---
    df_c = pd.read_csv(CAMINHO_CLIENTES, encoding="utf-8-sig")
    df_r = pd.read_csv(CAMINHO_RENDA, encoding="utf-8-sig")
    df_p = pd.read_csv(CAMINHO_PRODUTOS, encoding="utf-8-sig")

    linha_c = df_c[df_c["id_cliente"] == id_cliente]
    if linha_c.empty:
        raise ValueError(f"id_cliente {id_cliente} não encontrado em clientes.csv.")

    linha_r = df_r[df_r["id_cliente"] == id_cliente]
    if linha_r.empty:
        raise ValueError(f"id_cliente {id_cliente} não encontrado em renda.csv.")

    c = linha_c.iloc[0]
    r = linha_r.iloc[0]

    # Normaliza booleano de negativado (pode vir como string do CSV)
    negativado = str(c["negativado"]).strip().lower() in ("true", "1", "yes", "sim")

    # Produtos
    prods_df = df_p[df_p["id_cliente"] == id_cliente]
    produtos: list[ProdutoPedido] = []
    for _, row in prods_df.iterrows():
        inad = str(row["inadimplencia_historica"]).strip().lower() in ("true", "1", "yes", "sim")
        produtos.append(ProdutoPedido(
            tipo_produto=str(row["tipo_produto"]),
            status=str(row["status"]),
            inadimplencia_historica=inad,
            valor_contrato=float(row["valor_contrato"]) if pd.notna(row.get("valor_contrato")) else None,
        ))

    return PedidoCredito(
        id_cliente=int(c["id_cliente"]),
        nome=str(c["nome"]),
        cpf=str(c["cpf"]),
        data_nascimento=str(c["data_nascimento"]),
        estado_civil=str(c["estado_civil"]),
        escolaridade=str(c["escolaridade"]),
        cidade=str(c["cidade"]),
        estado=str(c["estado"]),
        score_bureau=int(c["score_bureau"]),
        negativado=negativado,
        tempo_relacionamento_meses=int(c["tempo_relacionamento_meses"]),
        tipo_renda=str(r["tipo_renda"]),
        renda_mensal_declarada=float(r["renda_mensal_declarada"]),
        renda_mensal_comprovada=float(r["renda_mensal_comprovada"]),
        percentual_comprometimento_renda=float(r["percentual_comprometimento_renda"]),
        estabilidade_emprego_anos=float(r["estabilidade_emprego_anos"]),
        produtos=produtos,
    )
