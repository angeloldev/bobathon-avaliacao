"""
Módulo de relatórios agregados do sistema de análise de crédito.

Gera estatísticas consolidadas sobre as decisões tomadas, incluindo:
  - Distribuição de decisões
  - Limite médio por faixa de renda comprovada
  - Principais fatores de negação
  - Histograma de scores internos
"""

from __future__ import annotations

from collections import Counter

import numpy as np
import pandas as pd

from motor_regras import LaudoDecisao


def distribuicao_decisoes(laudos: list) -> dict:
    """
    Calcula a distribuição de decisões (APROVADO / APROVADO COM RESTRIÇÃO / NEGADO).

    Parâmetros
    ----------
    laudos : list[LaudoDecisao]

    Retorna
    -------
    dict[str, int]  Contagem por decisão.
    """
    contagem: Counter = Counter(l.decisao for l in laudos)
    return dict(contagem)


def limite_medio_por_faixa_renda(laudos: list) -> pd.DataFrame:
    """
    Calcula o limite médio concedido segmentado por faixa de renda comprovada.

    Faixas (R$): Até 2.000 | 2.001–5.000 | 5.001–10.000 | Acima de 10.000

    Parâmetros
    ----------
    laudos : list[LaudoDecisao]

    Retorna
    -------
    pd.DataFrame  Com colunas: faixa_renda, qtd_aprovados, limite_medio.
    """
    faixas_labels = [
        "Até R$ 2.000",
        "R$ 2.001–5.000",
        "R$ 5.001–10.000",
        "Acima de R$ 10.000",
    ]
    bins = [0, 2000, 5000, 10000, float("inf")]

    rows = []
    for laudo in laudos:
        if laudo.limite_sugerido is not None:
            renda = laudo.parametros_entrada.get("renda_mensal_comprovada", 0)
            rows.append({"renda": renda, "limite": laudo.limite_sugerido})

    if not rows:
        return pd.DataFrame(columns=["faixa_renda", "qtd_aprovados", "limite_medio"])

    df = pd.DataFrame(rows)
    df["faixa_renda"] = pd.cut(df["renda"], bins=bins, labels=faixas_labels, right=True)
    resultado = (
        df.groupby("faixa_renda", observed=True)["limite"]
        .agg(qtd_aprovados="count", limite_medio="mean")
        .reset_index()
    )
    resultado["limite_medio"] = resultado["limite_medio"].round(2)
    return resultado


def principais_fatores_negacao(laudos: list) -> list:
    """
    Identifica e ordena os principais critérios que levaram a negações.

    Parâmetros
    ----------
    laudos : list[LaudoDecisao]

    Retorna
    -------
    list[tuple[str, int]]  Lista de (criterio, contagem) em ordem decrescente.
    """
    contagem: Counter = Counter()
    for laudo in laudos:
        if laudo.decisao == "NEGADO":
            for criterio in laudo.criterios:
                if criterio.get("bloqueante") or (criterio.get("pontuacao", 0) < 0):
                    contagem[criterio["criterio"]] += 1
    return contagem.most_common()


def histograma_scores(laudos: list, bins: int = 10) -> pd.DataFrame:
    """
    Gera um histograma de scores internos calculados pelo motor.

    Parâmetros
    ----------
    laudos : list[LaudoDecisao]
    bins   : int  Número de faixas (padrão 10).

    Retorna
    -------
    pd.DataFrame  Com colunas: faixa_score, quantidade.
    """
    scores = [l.score_interno for l in laudos]
    contagens, bordas = np.histogram(scores, bins=bins, range=(0, 100))
    faixas = [
        f"{bordas[i]:.0f}–{bordas[i + 1]:.0f}"
        for i in range(len(contagens))
    ]
    return pd.DataFrame({"faixa_score": faixas, "quantidade": contagens})


def _formatar_brl(valor: float) -> str:
    """Formata valor como moeda BRL (R$ 1.234,56)."""
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def imprimir_relatorio_console(laudos: list) -> None:
    """
    Imprime no console o relatório agregado completo em português.

    Parâmetros
    ----------
    laudos : list[LaudoDecisao]
    """
    sep = "=" * 70
    print(f"\n{sep}")
    print("  RELATÓRIO CONSOLIDADO — ANÁLISE DE CRÉDITO CARTÃO")
    print(sep)
    print(f"  Total de clientes analisados: {len(laudos)}")

    # --- Distribuição ---
    dist = distribuicao_decisoes(laudos)
    print(f"\n  DISTRIBUIÇÃO DE DECISÕES")
    print(f"  {'-' * 50}")
    for decisao in ["APROVADO", "APROVADO COM RESTRIÇÃO", "NEGADO"]:
        qtd = dist.get(decisao, 0)
        pct = qtd / len(laudos) * 100 if laudos else 0
        print(f"  {decisao:<30} {qtd:>5}  ({pct:.1f}%)")

    # --- Limites por faixa de renda ---
    df_limites = limite_medio_por_faixa_renda(laudos)
    print(f"\n  LIMITE MÉDIO CONCEDIDO POR FAIXA DE RENDA COMPROVADA")
    print(f"  {'-' * 50}")
    if df_limites.empty:
        print("  Nenhum cliente aprovado.")
    else:
        for _, row in df_limites.iterrows():
            if row["qtd_aprovados"] > 0:
                print(
                    f"  {str(row['faixa_renda']):<22}  "
                    f"Aprovados: {int(row['qtd_aprovados']):>4}  "
                    f"Limite médio: {_formatar_brl(row['limite_medio'])}"
                )

    # --- Fatores de negação ---
    fatores = principais_fatores_negacao(laudos)
    print(f"\n  PRINCIPAIS FATORES DE NEGAÇÃO")
    print(f"  {'-' * 50}")
    if not fatores:
        print("  Nenhum cliente negado.")
    else:
        for fator, qtd in fatores:
            print(f"  {fator:<48} {qtd:>4} ocorrência(s)")

    # --- Histograma de scores ---
    df_hist = histograma_scores(laudos)
    print(f"\n  HISTOGRAMA DE SCORES INTERNOS (0–100)")
    print(f"  {'-' * 50}")
    max_qtd = int(df_hist["quantidade"].max()) if not df_hist.empty else 1
    for _, row in df_hist.iterrows():
        qtd = int(row["quantidade"])
        barra = "█" * int(qtd / max(max_qtd, 1) * 30)
        print(f"  {row['faixa_score']:>8}  {barra:<30}  {qtd}")

    print(f"\n{sep}\n")
