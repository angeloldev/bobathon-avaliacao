"""
Camada de integração do sistema de análise de crédito.

Orquestra a leitura das três bases de dados, consolida o perfil de cada
cliente e aciona o motor de regras, registrando cada decisão na trilha
de auditoria (auditoria_decisoes.json).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import pandas as pd

from motor_regras import LaudoDecisao, MotorRegras, PerfilCliente

logger = logging.getLogger(__name__)


class AnalisadorCredito:
    """
    Orquestrador principal da análise de crédito.

    Lê as bases de dados, consolida o perfil de cada cliente e aplica
    o motor de regras, produzindo laudos e trilha de auditoria.
    """

    def __init__(
        self,
        caminho_clientes: str = "clientes.csv",
        caminho_renda: str = "renda.csv",
        caminho_produtos: str = "produtos.csv",
        caminho_auditoria: str = "auditoria_decisoes.json",
    ) -> None:
        """
        Inicializa o analisador com os caminhos dos arquivos de dados.

        Parâmetros
        ----------
        caminho_clientes  : str  Caminho para clientes.csv
        caminho_renda     : str  Caminho para renda.csv
        caminho_produtos  : str  Caminho para produtos.csv
        caminho_auditoria : str  Caminho de saída para o arquivo de auditoria
        """
        self.caminho_clientes = Path(caminho_clientes)
        self.caminho_renda = Path(caminho_renda)
        self.caminho_produtos = Path(caminho_produtos)
        self.caminho_auditoria = Path(caminho_auditoria)
        self.motor = MotorRegras()

        self._df_clientes: Optional[pd.DataFrame] = None
        self._df_renda: Optional[pd.DataFrame] = None
        self._df_produtos: Optional[pd.DataFrame] = None

    # ------------------------------------------------------------------
    # Carga dos dados
    # ------------------------------------------------------------------

    def carregar_bases(self) -> None:
        """
        Carrega as três bases de dados em memória, validando campos obrigatórios.

        Lança
        -----
        FileNotFoundError  Se algum arquivo não for encontrado.
        ValueError         Se campos obrigatórios estiverem ausentes.
        """
        logger.info("Carregando base de clientes...")
        self._df_clientes = pd.read_csv(self.caminho_clientes, encoding="utf-8-sig")
        self._validar_colunas(
            self._df_clientes,
            ["id_cliente", "nome", "score_bureau", "negativado",
             "tempo_relacionamento_meses"],
            "clientes",
        )

        logger.info("Carregando base de renda...")
        self._df_renda = pd.read_csv(self.caminho_renda, encoding="utf-8-sig")
        self._validar_colunas(
            self._df_renda,
            ["id_cliente", "tipo_renda", "renda_mensal_declarada",
             "renda_mensal_comprovada", "percentual_comprometimento_renda",
             "estabilidade_emprego_anos"],
            "renda",
        )

        logger.info("Carregando base de produtos...")
        self._df_produtos = pd.read_csv(self.caminho_produtos, encoding="utf-8-sig")
        self._validar_colunas(
            self._df_produtos,
            ["id_cliente", "id_produto", "tipo_produto", "status",
             "inadimplencia_historica"],
            "produtos",
        )

        # Normalizar booleanos lidos como string pelo CSV
        self._df_clientes["negativado"] = (
            self._df_clientes["negativado"]
            .astype(str)
            .str.lower()
            .map({"true": True, "false": False, "1": True, "0": False})
            .fillna(False)
            .astype(bool)
        )
        self._df_produtos["inadimplencia_historica"] = (
            self._df_produtos["inadimplencia_historica"]
            .astype(str)
            .str.lower()
            .map({"true": True, "false": False, "1": True, "0": False})
            .fillna(False)
            .astype(bool)
        )
        logger.info("Bases carregadas com sucesso.")

    # ------------------------------------------------------------------
    # Análise individual
    # ------------------------------------------------------------------

    def analisar_cliente(self, id_cliente: int) -> LaudoDecisao:
        """
        Consolida o perfil e analisa um cliente específico.

        Parâmetros
        ----------
        id_cliente : int

        Retorna
        -------
        LaudoDecisao

        Lança
        -----
        ValueError  Se o cliente não for encontrado nas bases.
        """
        if self._df_clientes is None:
            self.carregar_bases()

        # --- Cliente ---
        linha_cli = self._df_clientes[
            self._df_clientes["id_cliente"] == id_cliente
        ]
        if linha_cli.empty:
            raise ValueError(f"Cliente {id_cliente} não encontrado na base de clientes.")
        cli = linha_cli.iloc[0]

        # --- Renda ---
        linha_renda = self._df_renda[self._df_renda["id_cliente"] == id_cliente]
        if linha_renda.empty:
            raise ValueError(f"Cliente {id_cliente} não encontrado na base de renda.")
        renda = linha_renda.iloc[0]

        # --- Produtos ---
        prods = self._df_produtos[self._df_produtos["id_cliente"] == id_cliente]
        qtd_ativos = int(prods[prods["status"] == "Ativo"].shape[0]) if not prods.empty else 0
        qtd_inadimplencias = int(
            prods[prods["inadimplencia_historica"] == True].shape[0]
        ) if not prods.empty else 0

        perfil = PerfilCliente(
            id_cliente=int(cli["id_cliente"]),
            nome=str(cli["nome"]),
            score_bureau=int(cli["score_bureau"]),
            negativado=bool(cli["negativado"]),
            tempo_relacionamento_meses=int(cli["tempo_relacionamento_meses"]),
            tipo_renda=str(renda["tipo_renda"]),
            renda_mensal_declarada=float(renda["renda_mensal_declarada"]),
            renda_mensal_comprovada=float(renda["renda_mensal_comprovada"]),
            percentual_comprometimento_renda=float(
                renda["percentual_comprometimento_renda"]
            ),
            estabilidade_emprego_anos=float(renda["estabilidade_emprego_anos"]),
            qtd_produtos_ativos=qtd_ativos,
            qtd_inadimplencias_historicas=qtd_inadimplencias,
        )

        return self.motor.analisar(perfil)

    # ------------------------------------------------------------------
    # Análise em lote
    # ------------------------------------------------------------------

    def analisar_todos(self) -> list:
        """
        Executa a análise para todos os clientes das bases carregadas.

        Retorna
        -------
        list[LaudoDecisao]
            Lista com todos os laudos gerados.
        """
        if self._df_clientes is None:
            self.carregar_bases()

        laudos = []
        ids = self._df_clientes["id_cliente"].tolist()
        logger.info(f"Analisando {len(ids)} clientes...")

        for id_c in ids:
            try:
                laudo = self.analisar_cliente(id_c)
                laudos.append(laudo)
            except ValueError as exc:
                logger.warning(f"Pulando cliente {id_c}: {exc}")

        logger.info(f"Análise concluída. {len(laudos)} laudos gerados.")
        self._salvar_auditoria(laudos)
        return laudos

    # ------------------------------------------------------------------
    # Auditoria
    # ------------------------------------------------------------------

    def _salvar_auditoria(self, laudos: list) -> None:
        """
        Persiste todos os laudos no arquivo de auditoria em formato JSON.

        Parâmetros
        ----------
        laudos : list[LaudoDecisao]
        """
        from dataclasses import asdict

        registros = [asdict(laudo) for laudo in laudos]
        with open(self.caminho_auditoria, "w", encoding="utf-8") as f:
            json.dump(registros, f, ensure_ascii=False, indent=2, default=str)
        logger.info(f"Auditoria salva em '{self.caminho_auditoria}'.")

    # ------------------------------------------------------------------
    # Utilitários internos
    # ------------------------------------------------------------------

    @staticmethod
    def _validar_colunas(
        df: pd.DataFrame, colunas: list, nome_base: str
    ) -> None:
        """
        Valida que as colunas obrigatórias existem no DataFrame.

        Lança
        -----
        ValueError  Se alguma coluna estiver ausente.
        """
        ausentes = [c for c in colunas if c not in df.columns]
        if ausentes:
            raise ValueError(
                f"Colunas ausentes na base '{nome_base}': {ausentes}"
            )
