"""
Ponto de entrada do sistema de análise de perfil de clientes
para concessão de limite de cartão de crédito.

Execução: python main.py

Fluxo:
  1. Gera as três bases sintéticas (clientes, renda, produtos)
  2. Carrega as bases e executa a análise para todos os clientes
  3. Salva o arquivo de auditoria (auditoria_decisoes.json)
  4. Imprime o relatório consolidado no console
  5. Exibe exemplos de laudo para um cliente aprovado e um negado
"""

import logging
import sys
from pathlib import Path

from gerador_dados import gerar_clientes, gerar_renda, gerar_produtos, salvar_bases
from analisador_credito import AnalisadorCredito
from relatorio import imprimir_relatorio_console

# ---------------------------------------------------------------------------
# Configuração de logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            str(Path(__file__).parent / "sistema_credito.log"),
            encoding="utf-8",
        ),
    ],
)
logger = logging.getLogger(__name__)

NUM_CLIENTES = 200


def gerar_e_salvar_dados() -> None:
    """Gera e persiste as três bases de dados sintéticas."""
    logger.info("Gerando bases sintéticas...")
    df_clientes = gerar_clientes(NUM_CLIENTES)
    ids = df_clientes["id_cliente"].tolist()
    df_renda = gerar_renda(ids)
    df_produtos = gerar_produtos(ids)
    salvar_bases(df_clientes, df_renda, df_produtos, caminho=str(Path(__file__).parent))
    logger.info(
        f"Bases geradas: {len(df_clientes)} clientes, "
        f"{len(df_renda)} registros de renda, "
        f"{len(df_produtos)} produtos."
    )


def exibir_exemplos_laudo(analisador: AnalisadorCredito) -> None:
    """
    Exibe um exemplo de laudo para um cliente aprovado/com restrição e um negado.

    Percorre os primeiros 50 clientes em busca dos dois perfis.
    """
    laudo_aprovado = None
    laudo_negado = None

    for id_c in range(1, min(NUM_CLIENTES + 1, 51)):
        try:
            laudo = analisador.analisar_cliente(id_c)
            if laudo_aprovado is None and laudo.decisao in ("APROVADO", "APROVADO COM RESTRIÇÃO"):
                laudo_aprovado = laudo
            if laudo_negado is None and laudo.decisao == "NEGADO":
                laudo_negado = laudo
            if laudo_aprovado and laudo_negado:
                break
        except ValueError:
            continue

    print("\n" + "=" * 70)
    print("  EXEMPLOS DE LAUDOS GERADOS PELO SISTEMA")
    print("=" * 70)

    if laudo_aprovado:
        print(f"\nEXEMPLO 1 — CLIENTE {laudo_aprovado.decisao}\n")
        print(laudo_aprovado.laudo_texto)
    else:
        print("\nNenhum cliente aprovado encontrado nos primeiros registros.")

    if laudo_negado:
        print(f"\nEXEMPLO 2 — CLIENTE {laudo_negado.decisao}\n")
        print(laudo_negado.laudo_texto)
    else:
        print("\nNenhum cliente negado encontrado nos primeiros registros.")


def main() -> None:
    """Função principal — orquestra todo o fluxo do sistema."""
    print("\n" + "=" * 70)
    print("  SISTEMA DE ANÁLISE DE CRÉDITO — CARTÃO DE CRÉDITO")
    print("  Versão 1.0.0")
    print("=" * 70 + "\n")

    # Etapa 1 — Geração das bases
    gerar_e_salvar_dados()

    # Etapa 2 — Análise em lote
    _dir = Path(__file__).parent
    analisador = AnalisadorCredito(
        caminho_clientes=str(_dir / "clientes.csv"),
        caminho_renda=str(_dir / "renda.csv"),
        caminho_produtos=str(_dir / "produtos.csv"),
        caminho_auditoria=str(_dir / "auditoria_decisoes.json"),
    )
    laudos = analisador.analisar_todos()

    # Etapa 3 — Relatório consolidado
    imprimir_relatorio_console(laudos)

    # Etapa 4 — Exemplos de laudo
    exibir_exemplos_laudo(analisador)

    logger.info("Execução concluída com sucesso.")
    print("\nArquivos gerados:")
    print("  clientes.csv            — base de clientes")
    print("  renda.csv               — base de renda")
    print("  produtos.csv            — base de produtos")
    print("  auditoria_decisoes.json — trilha completa de auditoria")
    print("  sistema_credito.log     — log de execução\n")


if __name__ == "__main__":
    main()
