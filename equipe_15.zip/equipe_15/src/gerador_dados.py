"""
Módulo de geração de dados sintéticos para o sistema de análise de crédito.

Responsável pela criação das três bases de dados fictícias:
  - Base 1: Clientes (clientes.csv)
  - Base 2: Renda (renda.csv)
  - Base 3: Produtos Contratados (produtos.csv)

Utiliza a biblioteca Faker para geração de dados realistas em pt_BR.
"""

import random
from datetime import date, timedelta

import numpy as np
import pandas as pd
from faker import Faker

fake = Faker("pt_BR")
random.seed(42)
np.random.seed(42)
Faker.seed(42)

# ---------------------------------------------------------------------------
# Constantes de domínio
# ---------------------------------------------------------------------------
ESTADOS_CIVIS = ["Solteiro", "Casado", "Divorciado", "Viúvo"]
ESCOLARIDADES = [
    "Fundamental",
    "Médio",
    "Superior Incompleto",
    "Superior Completo",
    "Pós-graduação",
]
TIPOS_RENDA = ["CLT", "Autônomo", "Empresário", "Aposentado", "Servidor Público"]
TIPOS_PRODUTO = [
    "Conta Corrente",
    "Poupança",
    "Empréstimo Pessoal",
    "Crédito Consignado",
    "Seguro de Vida",
    "Investimento CDB",
    "Investimento Fundo",
]
ESTADOS_BR = [
    ("São Paulo", "SP"), ("Rio de Janeiro", "RJ"), ("Minas Gerais", "MG"),
    ("Bahia", "BA"), ("Paraná", "PR"), ("Rio Grande do Sul", "RS"),
    ("Pernambuco", "PE"), ("Ceará", "CE"), ("Goiás", "GO"), ("Pará", "PA"),
    ("Santa Catarina", "SC"), ("Maranhão", "MA"), ("Mato Grosso", "MT"),
    ("Amazonas", "AM"), ("Espírito Santo", "ES"), ("Paraíba", "PB"),
    ("Rio Grande do Norte", "RN"), ("Mato Grosso do Sul", "MS"),
    ("Piauí", "PI"), ("Alagoas", "AL"),
]


def _gerar_cpf_ficticio() -> str:
    """Gera um CPF no formato XXX.XXX.XXX-XX com dígitos aleatórios."""
    nums = [random.randint(0, 9) for _ in range(11)]
    return (
        f"{nums[0]}{nums[1]}{nums[2]}."
        f"{nums[3]}{nums[4]}{nums[5]}."
        f"{nums[6]}{nums[7]}{nums[8]}-"
        f"{nums[9]}{nums[10]}"
    )


def _data_nascimento_aleatoria() -> str:
    """Retorna uma data de nascimento resultando em idade entre 18 e 80 anos."""
    hoje = date.today()
    dias_min = 18 * 365
    dias_max = 80 * 365
    delta = random.randint(dias_min, dias_max)
    nascimento = hoje - timedelta(days=delta)
    return nascimento.strftime("%d/%m/%Y")


def gerar_clientes(n: int = 200) -> pd.DataFrame:
    """
    Gera a base de clientes com n registros sintéticos.

    Parâmetros
    ----------
    n : int
        Número de clientes a gerar (padrão 200).

    Retorna
    -------
    pd.DataFrame
        DataFrame com os campos de cliente.
    """
    registros = []
    for i in range(1, n + 1):
        estado, uf = random.choice(ESTADOS_BR)
        negativado = random.random() < 0.15
        if negativado:
            score = random.randint(0, 400)
        else:
            score = random.randint(200, 1000)

        registros.append(
            {
                "id_cliente": i,
                "nome": fake.name(),
                "cpf": _gerar_cpf_ficticio(),
                "data_nascimento": _data_nascimento_aleatoria(),
                "estado_civil": random.choice(ESTADOS_CIVIS),
                "escolaridade": random.choice(ESCOLARIDADES),
                "cidade": fake.city(),
                "estado": uf,
                "score_bureau": score,
                "negativado": negativado,
                "tempo_relacionamento_meses": random.randint(1, 120),
            }
        )
    return pd.DataFrame(registros)


def gerar_renda(ids_clientes: list) -> pd.DataFrame:
    """
    Gera a base de renda para os clientes informados.

    Parâmetros
    ----------
    ids_clientes : list
        Lista de IDs de clientes.

    Retorna
    -------
    pd.DataFrame
        DataFrame com os campos de renda.
    """
    registros = []
    for id_c in ids_clientes:
        tipo = random.choice(TIPOS_RENDA)
        faixas = {
            "CLT": (1500, 15000),
            "Autônomo": (1200, 20000),
            "Empresário": (3000, 50000),
            "Aposentado": (1320, 8000),
            "Servidor Público": (2500, 20000),
        }
        rmin, rmax = faixas[tipo]
        declarada = round(random.uniform(rmin, rmax), 2)
        fator_comprovacao = random.uniform(0.60, 1.0)
        comprovada = round(declarada * fator_comprovacao, 2)
        comprometimento = round(random.uniform(0, 90), 1)
        estabilidade = round(random.uniform(0, 30), 1)

        registros.append(
            {
                "id_cliente": id_c,
                "tipo_renda": tipo,
                "renda_mensal_declarada": declarada,
                "renda_mensal_comprovada": comprovada,
                "percentual_comprometimento_renda": comprometimento,
                "estabilidade_emprego_anos": estabilidade,
            }
        )
    return pd.DataFrame(registros)


def gerar_produtos(ids_clientes: list) -> pd.DataFrame:
    """
    Gera a base de produtos contratados. Cada cliente pode ter de 1 a 5 produtos.

    Parâmetros
    ----------
    ids_clientes : list
        Lista de IDs de clientes.

    Retorna
    -------
    pd.DataFrame
        DataFrame com os campos de produto.
    """
    registros = []
    id_produto = 1
    hoje = date.today()
    for id_c in ids_clientes:
        qtd_produtos = random.randint(1, 5)
        for _ in range(qtd_produtos):
            dias_atras = random.randint(30, 3650)
            data_contrat = (hoje - timedelta(days=dias_atras)).strftime("%d/%m/%Y")
            status = random.choice(["Ativo", "Ativo", "Ativo", "Encerrado"])
            inadimplente = random.random() < 0.12

            tipo_prod = random.choice(TIPOS_PRODUTO)
            if tipo_prod in ("Empréstimo Pessoal", "Crédito Consignado"):
                valor = round(random.uniform(1000, 50000), 2)
            elif tipo_prod in ("Investimento CDB", "Investimento Fundo"):
                valor = round(random.uniform(500, 200000), 2)
            elif tipo_prod == "Seguro de Vida":
                valor = round(random.uniform(50, 500), 2)
            else:
                valor = None

            registros.append(
                {
                    "id_cliente": id_c,
                    "id_produto": id_produto,
                    "tipo_produto": tipo_prod,
                    "data_contratacao": data_contrat,
                    "status": status,
                    "inadimplencia_historica": inadimplente,
                    "valor_contrato": valor,
                }
            )
            id_produto += 1
    return pd.DataFrame(registros)


def salvar_bases(
    df_clientes: pd.DataFrame,
    df_renda: pd.DataFrame,
    df_produtos: pd.DataFrame,
    caminho: str = ".",
) -> None:
    """
    Salva os três DataFrames em arquivos CSV no caminho especificado.

    Parâmetros
    ----------
    df_clientes : pd.DataFrame
    df_renda    : pd.DataFrame
    df_produtos : pd.DataFrame
    caminho     : str  Diretório de destino.
    """
    df_clientes.to_csv(f"{caminho}/clientes.csv", index=False, encoding="utf-8-sig")
    df_renda.to_csv(f"{caminho}/renda.csv", index=False, encoding="utf-8-sig")
    df_produtos.to_csv(f"{caminho}/produtos.csv", index=False, encoding="utf-8-sig")
    print(f"[gerador] Bases salvas em '{caminho}/'.")
