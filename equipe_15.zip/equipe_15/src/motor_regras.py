"""
Motor de regras de concessão de limite de cartão de crédito.

Aplica regras de negócio ponderadas sobre o perfil consolidado do cliente
e produz decisão, limite sugerido, score interno e laudo explicativo.

Versão do motor: 1.0.0
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

VERSAO_MOTOR = "1.0.0"


# ---------------------------------------------------------------------------
# Estruturas de dados
# ---------------------------------------------------------------------------

@dataclass
class PerfilCliente:
    """Representa o perfil consolidado de um cliente para análise."""

    id_cliente: int
    nome: str
    score_bureau: int
    negativado: bool
    tempo_relacionamento_meses: int
    tipo_renda: str
    renda_mensal_declarada: float
    renda_mensal_comprovada: float
    percentual_comprometimento_renda: float
    estabilidade_emprego_anos: float
    qtd_produtos_ativos: int
    qtd_inadimplencias_historicas: int


@dataclass
class ResultadoCriterio:
    """Armazena o resultado parcial de cada critério avaliado."""

    criterio: str
    condicao_encontrada: str
    pontuacao: float
    descricao: str
    bloqueante: bool = False


@dataclass
class LaudoDecisao:
    """Resultado completo da análise de crédito para um cliente."""

    id_cliente: int
    nome: str
    timestamp: str
    versao_motor: str
    decisao: str                        # APROVADO | APROVADO COM RESTRIÇÃO | NEGADO
    score_interno: float
    limite_sugerido: Optional[float]
    criterios: list = field(default_factory=list)
    laudo_texto: str = ""
    parametros_entrada: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Motor principal
# ---------------------------------------------------------------------------

class MotorRegras:
    """
    Motor de regras para concessão de limite de cartão de crédito.

    Aplica critérios ponderados e produz decisão auditável.
    """

    PESO_SCORE_BUREAU_BONUS = 15.0
    PESO_TEMPO_RELACIONAMENTO = 10.0
    PESO_ESTABILIDADE_EMPREGO = 10.0
    PESO_TIPO_RENDA = 10.0
    PESO_PRODUTOS_ATIVOS = 10.0
    PONTUACAO_BASE = 45.0

    def analisar(self, perfil: PerfilCliente) -> LaudoDecisao:
        """
        Executa a análise completa de crédito para o perfil informado.

        Parâmetros
        ----------
        perfil : PerfilCliente
            Perfil consolidado do cliente.

        Retorna
        -------
        LaudoDecisao
            Objeto com decisão, score, limite e laudo.
        """
        timestamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        criterios: list[ResultadoCriterio] = []
        score = self.PONTUACAO_BASE
        bloqueado = False
        motivo_bloqueio = ""

        # ------------------------------------------------------------------
        # Regra 1 — Negativação em bureau (BLOQUEANTE)
        # ------------------------------------------------------------------
        if perfil.negativado:
            criterios.append(ResultadoCriterio(
                criterio="Negativação em bureau",
                condicao_encontrada="Negativado = Sim",
                pontuacao=0,
                descricao=(
                    "Cliente possui restrições ativas em bureau de crédito. "
                    "Regra bloqueante: concessão negada automaticamente."
                ),
                bloqueante=True,
            ))
            bloqueado = True
            motivo_bloqueio = "Negativação em bureau de crédito."
        else:
            criterios.append(ResultadoCriterio(
                criterio="Negativação em bureau",
                condicao_encontrada="Negativado = Não",
                pontuacao=0,
                descricao="Cliente não possui restrições em bureau. Nenhum impacto.",
            ))

        # ------------------------------------------------------------------
        # Regra 2 — Comprometimento de renda (BLOQUEANTE se > 70%)
        # ------------------------------------------------------------------
        comp = perfil.percentual_comprometimento_renda
        if comp > 70:
            criterios.append(ResultadoCriterio(
                criterio="Comprometimento de renda",
                condicao_encontrada=f"Comprometimento = {comp:.1f}%",
                pontuacao=0,
                descricao=(
                    f"Comprometimento de renda de {comp:.1f}% supera o limite de 70%. "
                    "Regra bloqueante: concessão negada automaticamente."
                ),
                bloqueante=True,
            ))
            if not bloqueado:
                bloqueado = True
                motivo_bloqueio = f"Comprometimento de renda ({comp:.1f}%) acima de 70%."
        elif 50 < comp <= 70:
            penalidade = -10.0
            score += penalidade
            criterios.append(ResultadoCriterio(
                criterio="Comprometimento de renda",
                condicao_encontrada=f"Comprometimento = {comp:.1f}%",
                pontuacao=penalidade,
                descricao=(
                    f"Comprometimento de renda entre 50% e 70% ({comp:.1f}%). "
                    f"Penalidade moderada de {penalidade:.0f} pontos aplicada."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Comprometimento de renda",
                condicao_encontrada=f"Comprometimento = {comp:.1f}%",
                pontuacao=0,
                descricao=(
                    f"Comprometimento de renda dentro do limite aceitável ({comp:.1f}%). "
                    "Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Regra 3 — Score bureau
        # ------------------------------------------------------------------
        sb = perfil.score_bureau
        if sb < 300:
            penalidade = -20.0
            score += penalidade
            criterios.append(ResultadoCriterio(
                criterio="Score bureau",
                condicao_encontrada=f"Score = {sb}",
                pontuacao=penalidade,
                descricao=f"Score bureau muito baixo ({sb} < 300). Penalidade severa de {penalidade:.0f} pontos.",
            ))
        elif sb < 500:
            penalidade = -10.0
            score += penalidade
            criterios.append(ResultadoCriterio(
                criterio="Score bureau",
                condicao_encontrada=f"Score = {sb}",
                pontuacao=penalidade,
                descricao=f"Score bureau baixo ({sb} entre 300 e 499). Penalidade moderada de {penalidade:.0f} pontos.",
            ))
        elif sb >= 700:
            bonus = self.PESO_SCORE_BUREAU_BONUS
            score += bonus
            criterios.append(ResultadoCriterio(
                criterio="Score bureau",
                condicao_encontrada=f"Score = {sb}",
                pontuacao=bonus,
                descricao=f"Score bureau alto ({sb} >= 700). Bônus de {bonus:.0f} pontos.",
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Score bureau",
                condicao_encontrada=f"Score = {sb}",
                pontuacao=0,
                descricao=f"Score bureau regular ({sb} entre 500 e 699). Nenhum impacto.",
            ))

        # ------------------------------------------------------------------
        # Regra 4 — Divergência renda declarada vs comprovada
        # ------------------------------------------------------------------
        if perfil.renda_mensal_declarada > 0:
            divergencia = abs(
                perfil.renda_mensal_declarada - perfil.renda_mensal_comprovada
            ) / perfil.renda_mensal_declarada
        else:
            divergencia = 0.0

        if divergencia > 0.30:
            penalidade = -8.0
            score += penalidade
            criterios.append(ResultadoCriterio(
                criterio="Consistência de renda",
                condicao_encontrada=f"Divergência = {divergencia * 100:.1f}%",
                pontuacao=penalidade,
                descricao=(
                    f"Divergência entre renda declarada "
                    f"(R$ {perfil.renda_mensal_declarada:,.2f}) e comprovada "
                    f"(R$ {perfil.renda_mensal_comprovada:,.2f}) é de "
                    f"{divergencia * 100:.1f}%, acima de 30%. "
                    f"Penalidade de {penalidade:.0f} pontos por inconsistência."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Consistência de renda",
                condicao_encontrada=f"Divergência = {divergencia * 100:.1f}%",
                pontuacao=0,
                descricao=(
                    f"Divergência de renda dentro do aceitável ({divergencia * 100:.1f}%). "
                    "Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Regra 5 — Inadimplência histórica em produtos
        # ------------------------------------------------------------------
        qtd_inad = perfil.qtd_inadimplencias_historicas
        if qtd_inad > 0:
            penalidade = max(-5.0 * qtd_inad, -20.0)
            score += penalidade
            criterios.append(ResultadoCriterio(
                criterio="Inadimplência histórica em produtos",
                condicao_encontrada=f"Produtos com inadimplência = {qtd_inad}",
                pontuacao=penalidade,
                descricao=(
                    f"Cliente possui {qtd_inad} produto(s) com histórico de inadimplência. "
                    f"Penalidade de {penalidade:.0f} pontos."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Inadimplência histórica em produtos",
                condicao_encontrada="Nenhuma inadimplência histórica",
                pontuacao=0,
                descricao="Nenhum produto com histórico de inadimplência. Nenhum impacto.",
            ))

        # ------------------------------------------------------------------
        # Regra 6 — Quantidade de produtos ativos (bônus)
        # ------------------------------------------------------------------
        if perfil.qtd_produtos_ativos >= 3:
            bonus = self.PESO_PRODUTOS_ATIVOS
            score += bonus
            criterios.append(ResultadoCriterio(
                criterio="Relacionamento — produtos ativos",
                condicao_encontrada=f"Produtos ativos = {perfil.qtd_produtos_ativos}",
                pontuacao=bonus,
                descricao=(
                    f"Cliente possui {perfil.qtd_produtos_ativos} produtos ativos (>= 3). "
                    f"Bônus de relacionamento de {bonus:.0f} pontos."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Relacionamento — produtos ativos",
                condicao_encontrada=f"Produtos ativos = {perfil.qtd_produtos_ativos}",
                pontuacao=0,
                descricao=(
                    f"Cliente possui {perfil.qtd_produtos_ativos} produto(s) ativo(s) "
                    "(mínimo 3 para bônus). Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Regra 7 — Tempo de relacionamento (bônus)
        # ------------------------------------------------------------------
        if perfil.tempo_relacionamento_meses >= 24:
            bonus = self.PESO_TEMPO_RELACIONAMENTO
            score += bonus
            criterios.append(ResultadoCriterio(
                criterio="Fidelidade — tempo de relacionamento",
                condicao_encontrada=f"Relacionamento = {perfil.tempo_relacionamento_meses} meses",
                pontuacao=bonus,
                descricao=(
                    f"Tempo de relacionamento de {perfil.tempo_relacionamento_meses} meses "
                    f"(>= 24 meses). Bônus de fidelidade de {bonus:.0f} pontos."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Fidelidade — tempo de relacionamento",
                condicao_encontrada=f"Relacionamento = {perfil.tempo_relacionamento_meses} meses",
                pontuacao=0,
                descricao=(
                    f"Tempo de relacionamento de {perfil.tempo_relacionamento_meses} meses "
                    "(mínimo 24 meses para bônus). Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Regra 8 — Estabilidade de emprego (bônus)
        # ------------------------------------------------------------------
        if perfil.estabilidade_emprego_anos >= 2:
            bonus = self.PESO_ESTABILIDADE_EMPREGO
            score += bonus
            criterios.append(ResultadoCriterio(
                criterio="Estabilidade de emprego",
                condicao_encontrada=f"Estabilidade = {perfil.estabilidade_emprego_anos:.1f} anos",
                pontuacao=bonus,
                descricao=(
                    f"Tempo no emprego/atividade de {perfil.estabilidade_emprego_anos:.1f} anos "
                    f"(>= 2 anos). Bônus de estabilidade de {bonus:.0f} pontos."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Estabilidade de emprego",
                condicao_encontrada=f"Estabilidade = {perfil.estabilidade_emprego_anos:.1f} anos",
                pontuacao=0,
                descricao=(
                    f"Tempo no emprego/atividade de {perfil.estabilidade_emprego_anos:.1f} anos "
                    "(mínimo 2 anos para bônus). Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Regra 9 — Tipo de renda (bônus)
        # ------------------------------------------------------------------
        if perfil.tipo_renda in ("CLT", "Servidor Público"):
            bonus = self.PESO_TIPO_RENDA
            score += bonus
            criterios.append(ResultadoCriterio(
                criterio="Estabilidade de renda — tipo",
                condicao_encontrada=f"Tipo de renda = {perfil.tipo_renda}",
                pontuacao=bonus,
                descricao=(
                    f"Tipo de renda '{perfil.tipo_renda}' confere estabilidade alta. "
                    f"Bônus de {bonus:.0f} pontos."
                ),
            ))
        else:
            criterios.append(ResultadoCriterio(
                criterio="Estabilidade de renda — tipo",
                condicao_encontrada=f"Tipo de renda = {perfil.tipo_renda}",
                pontuacao=0,
                descricao=(
                    f"Tipo de renda '{perfil.tipo_renda}' não confere bônus adicional. "
                    "Nenhum impacto."
                ),
            ))

        # ------------------------------------------------------------------
        # Clampar score entre 0 e 100
        # ------------------------------------------------------------------
        score = max(0.0, min(100.0, score))

        # ------------------------------------------------------------------
        # Decisão e limite
        # ------------------------------------------------------------------
        if bloqueado or score < 40:
            decisao = "NEGADO"
            limite = None
        elif score >= 80:
            decisao = "APROVADO"
            limite = round(perfil.renda_mensal_comprovada * 3, 2)
        elif score >= 60:
            decisao = "APROVADO"
            limite = round(perfil.renda_mensal_comprovada * 2, 2)
        else:  # 40 <= score < 60
            decisao = "APROVADO COM RESTRIÇÃO"
            limite = round(perfil.renda_mensal_comprovada * 1, 2)

        # ------------------------------------------------------------------
        # Construção do laudo textual
        # ------------------------------------------------------------------
        laudo = self._gerar_laudo_texto(
            perfil=perfil,
            criterios=criterios,
            score=score,
            decisao=decisao,
            limite=limite,
            bloqueado=bloqueado,
            motivo_bloqueio=motivo_bloqueio,
        )

        return LaudoDecisao(
            id_cliente=perfil.id_cliente,
            nome=perfil.nome,
            timestamp=timestamp,
            versao_motor=VERSAO_MOTOR,
            decisao=decisao,
            score_interno=round(score, 2),
            limite_sugerido=limite,
            criterios=[asdict(c) for c in criterios],
            laudo_texto=laudo,
            parametros_entrada=asdict(perfil),
        )

    # ------------------------------------------------------------------
    # Métodos auxiliares
    # ------------------------------------------------------------------

    @staticmethod
    def _formatar_brl(valor: float) -> str:
        """Formata um valor float como moeda BRL (R$ 1.234,56)."""
        return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    def _gerar_laudo_texto(
        self,
        perfil: PerfilCliente,
        criterios: list,
        score: float,
        decisao: str,
        limite: Optional[float],
        bloqueado: bool,
        motivo_bloqueio: str,
    ) -> str:
        """Gera o laudo explicativo em linguagem natural."""
        linhas = [
            "=" * 70,
            "  LAUDO DE ANÁLISE DE CRÉDITO — CARTÃO DE CRÉDITO",
            "=" * 70,
            f"  Cliente     : {perfil.nome}",
            f"  ID          : {perfil.id_cliente}",
            f"  Data/Hora   : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            f"  Versão Motor: {VERSAO_MOTOR}",
            "-" * 70,
            "  CRITÉRIOS AVALIADOS:",
            "-" * 70,
        ]

        for c in criterios:
            pts = c.pontuacao
            if c.bloqueante:
                sinal = "BLOQUEANTE"
            elif pts > 0:
                sinal = f"+{pts:.0f} pts"
            elif pts < 0:
                sinal = f"{pts:.0f} pts"
            else:
                sinal = "   0 pts"
            linhas.append(f"  [{sinal:>12}]  {c.criterio}")
            linhas.append(f"                Condição  : {c.condicao_encontrada}")
            linhas.append(f"                Avaliação : {c.descricao}")
            linhas.append("")

        linhas += [
            "-" * 70,
            f"  SCORE INTERNO CALCULADO : {score:.2f} / 100",
            "-" * 70,
            f"  DECISÃO FINAL           : {decisao}",
        ]

        if limite is not None:
            linhas.append(f"  LIMITE SUGERIDO         : {self._formatar_brl(limite)}")
        else:
            linhas.append("  LIMITE SUGERIDO         : Não aplicável")

        if bloqueado:
            linhas.append(f"  MOTIVO DO BLOQUEIO      : {motivo_bloqueio}")

        linhas.append("=" * 70)
        return "\n".join(linhas)
