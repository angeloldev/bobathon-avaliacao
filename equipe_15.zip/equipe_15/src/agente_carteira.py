"""
Agente Carteira — módulo independente do sistema multi-agentes de crédito.

Responsável por consultar e avaliar os produtos do banco: quais linhas de
crédito estão disponíveis para o perfil recebido e quais limites máximos
cada linha admite.

Este agente não conhece o perfil de risco do cliente — apenas avalia a
oferta do banco em função dos dados objetivos do pedido.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from gerador_pedido import PedidoCredito

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Catálogo de linhas de crédito do banco
# ---------------------------------------------------------------------------

CATALOGO_LINHAS = {
    "Cartão Básico": {
        "tipo": "cartao",
        "score_minimo": 0,
        "multiplicador_renda": 0.5,
        "descricao": "Linha de crédito básica, disponível para todos os perfis aprovados.",
    },
    "Cartão Gold": {
        "tipo": "cartao",
        "score_minimo": 500,
        "multiplicador_renda": 1.5,
        "descricao": "Linha intermediária para clientes com bom histórico de crédito.",
    },
    "Cartão Platinum": {
        "tipo": "cartao",
        "score_minimo": 750,
        "multiplicador_renda": 3.0,
        "descricao": "Linha premium para clientes com excelente perfil financeiro.",
    },
    "Crédito Consignado": {
        "tipo": "outro",
        "score_minimo": 300,
        "multiplicador_renda": 2.0,
        "descricao": "Linha com desconto em folha, exclusiva para CLT, Servidor Público e Aposentado.",
        "tipo_renda_obrigatorio": ["CLT", "Servidor Público", "Aposentado"],
    },
    "Crédito Pessoal Flex": {
        "tipo": "outro",
        "score_minimo": 400,
        "multiplicador_renda": 1.0,
        "descricao": "Linha flexível para autônomos e empresários com renda comprovada.",
        "tipo_renda_obrigatorio": ["Autônomo", "Empresário"],
    },
}


# ---------------------------------------------------------------------------
# Estrutura de saída
# ---------------------------------------------------------------------------

@dataclass
class LinhaCredito:
    """Representa uma linha de crédito disponível para o cliente."""

    nome: str
    limite_maximo: float
    multiplicador_renda: float
    descricao: str
    tipo: str = "cartao"   # "cartao" | "outro"


@dataclass
class ContextoCarteira:
    """
    Saída do Agente Carteira.

    Contém as linhas disponíveis, o teto de limite absoluto do banco para
    este perfil, o score interno de elegibilidade e observações textuais.
    """

    linhas_disponiveis: list[LinhaCredito] = field(default_factory=list)
    limite_maximo_banco: float = 0.0
    score_interno_carteira: float = 0.0        # 0 a 100
    melhor_linha: str = ""
    observacoes: list[str] = field(default_factory=list)
    elegivel: bool = True                      # False se nenhuma linha disponível


# ---------------------------------------------------------------------------
# Agente
# ---------------------------------------------------------------------------

class AgenteCarteira:
    """
    Agente Carteira — avalia as linhas de crédito disponíveis para o perfil.

    Recebe um PedidoCredito e devolve um ContextoCarteira com as linhas
    elegíveis, limites calculados e score interno de carteira.
    """

    NOME_AGENTE = "Agente Carteira"

    def avaliar(self, pedido: PedidoCredito) -> ContextoCarteira:
        """
        Avalia a elegibilidade às linhas de crédito e calcula limites.

        Parâmetros
        ----------
        pedido : PedidoCredito

        Retorna
        -------
        ContextoCarteira
        """
        logger.info(f"[{self.NOME_AGENTE}] Iniciando avaliação para cliente {pedido.id_cliente}.")

        # --- Bloqueio imediato por negativação ---
        if pedido.negativado:
            logger.warning(
                f"[{self.NOME_AGENTE}] Cliente {pedido.id_cliente} negativado — "
                "nenhuma linha de crédito disponível."
            )
            return ContextoCarteira(
                linhas_disponiveis=[],
                limite_maximo_banco=0.0,
                score_interno_carteira=0.0,
                melhor_linha="",
                observacoes=[
                    "Cliente com restrição ativa em bureau de crédito. "
                    "Nenhuma linha de crédito está disponível enquanto a negativação permanecer."
                ],
                elegivel=False,
            )

        linhas_disponiveis: list[LinhaCredito] = []
        observacoes: list[str] = []

        # --- Verificar elegibilidade por linha ---
        for nome_linha, cfg in CATALOGO_LINHAS.items():
            elegivel = True
            motivos_exclusao = []

            # Score mínimo
            if pedido.score_bureau < cfg["score_minimo"]:
                elegivel = False
                motivos_exclusao.append(
                    f"score bureau ({pedido.score_bureau}) abaixo do mínimo exigido ({cfg['score_minimo']})"
                )

            # Tipo de renda obrigatório (quando aplicável)
            tipos_obrig = cfg.get("tipo_renda_obrigatorio")
            if tipos_obrig and pedido.tipo_renda not in tipos_obrig:
                elegivel = False
                motivos_exclusao.append(
                    f"tipo de renda '{pedido.tipo_renda}' não habilitado para esta linha"
                )

            if elegivel:
                limite = round(pedido.renda_mensal_comprovada * cfg["multiplicador_renda"], 2)
                linhas_disponiveis.append(LinhaCredito(
                    nome=nome_linha,
                    limite_maximo=limite,
                    multiplicador_renda=cfg["multiplicador_renda"],
                    descricao=cfg["descricao"],
                    tipo=cfg.get("tipo", "cartao"),
                ))
                observacoes.append(
                    f"Linha '{nome_linha}' disponível — limite máximo: R$ {limite:,.2f}."
                )
            else:
                razao = "; ".join(motivos_exclusao)
                observacoes.append(f"Linha '{nome_linha}' indisponível: {razao}.")

        # --- Score interno da carteira ---
        score_carteira = self._calcular_score_carteira(pedido, linhas_disponiveis)

        # --- Melhor linha (maior limite) ---
        melhor_linha = ""
        limite_maximo_banco = 0.0
        if linhas_disponiveis:
            melhor = max(linhas_disponiveis, key=lambda l: l.limite_maximo)
            melhor_linha = melhor.nome
            limite_maximo_banco = melhor.limite_maximo

        elegivel = len(linhas_disponiveis) > 0
        if not elegivel:
            observacoes.append(
                "Nenhuma linha de crédito disponível para este perfil no momento."
            )

        logger.info(
            f"[{self.NOME_AGENTE}] Avaliação concluída — "
            f"{len(linhas_disponiveis)} linha(s) disponível(is), "
            f"score carteira: {score_carteira:.1f}."
        )

        return ContextoCarteira(
            linhas_disponiveis=linhas_disponiveis,
            limite_maximo_banco=limite_maximo_banco,
            score_interno_carteira=score_carteira,
            melhor_linha=melhor_linha,
            observacoes=observacoes,
            elegivel=elegivel,
        )

    # ------------------------------------------------------------------
    # Cálculo do score interno de carteira
    # ------------------------------------------------------------------

    @staticmethod
    def _calcular_score_carteira(
        pedido: PedidoCredito,
        linhas_disponiveis: list[LinhaCredito],
    ) -> float:
        """
        Calcula um score de 0 a 100 baseado na oferta disponível ao cliente.

        Critérios:
          - Quantidade de linhas disponíveis (até 30 pts)
          - Score bureau normalizado (até 40 pts)
          - Multiplicador da melhor linha disponível (até 30 pts)
        """
        # Pontos pela quantidade de linhas
        pts_linhas = min(len(linhas_disponiveis) * 6.0, 30.0)

        # Score bureau normalizado (0–1000 → 0–40 pts)
        pts_bureau = (pedido.score_bureau / 1000) * 40.0

        # Multiplicador da melhor linha
        if linhas_disponiveis:
            melhor_mult = max(l.multiplicador_renda for l in linhas_disponiveis)
            pts_mult = min(melhor_mult / 3.0 * 30.0, 30.0)
        else:
            pts_mult = 0.0

        return round(min(pts_linhas + pts_bureau + pts_mult, 100.0), 2)
