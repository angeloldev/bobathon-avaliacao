# 🏦 Sistema Multi-Agentes de Análise de Crédito

![Python](https://img.shields.io/badge/Python-3.14%2B-blue?logo=python&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-3.1.3-lightgrey?logo=flask&logoColor=white)
![IBM Watson Orchestrate](https://img.shields.io/badge/IBM%20Watson-Orchestrate%20X-0062FF?logo=ibm&logoColor=white)
![Motor v2.0.0](https://img.shields.io/badge/Motor-2.0.0--multiagente-purple)
![Linhas de código](https://img.shields.io/badge/linhas%20de%20código-3.216-informational)
![Licença MIT](https://img.shields.io/badge/licen%C3%A7a-MIT-green)

> Plataforma de análise de risco de crédito baseada em múltiplos agentes de IA,
> com orquestração inspirada no **IBM Watson Orchestrate X**, visualização em
> tempo real via **Server-Sent Events** e trilha de auditoria completa por execução.

---

## 📋 Visão Geral

Este projeto implementa um **sistema completo de análise de perfil de clientes para
concessão de limite de cartão de crédito**, resolvendo dois problemas centrais do
setor financeiro:

1. **Decisões opacas** — toda decisão é acompanhada de justificativa em linguagem
   natural e rastro auditável em JSON com o percurso completo da análise.
2. **Monolitos de regras** — a lógica é dividida entre agentes independentes com
   responsabilidades bem definidas, tornando o sistema extensível e testável de
   forma isolada.

### Público-alvo

- Equipes de crédito e risco que precisam de rastreabilidade nas decisões
- Desenvolvedores que constroem plataformas de crédito com arquitetura orientada a agentes
- Demonstrações do padrão de orquestração do IBM Watson Orchestrate X em fluxos financeiros

---

## ✨ Funcionalidades

| # | Funcionalidade | Módulo |
|---|---|---|
| 1 | Geração de 200 clientes sintéticos (CPF, renda, produtos, score) | `gerador_dados.py` |
| 2 | Montagem de pedido de crédito a partir de CSV ou dados sintéticos via Faker | `gerador_pedido.py` |
| 3 | **Agente Carteira** — avalia 5 linhas de crédito com elegibilidade por score e tipo de renda | `agente_carteira.py` |
| 4 | **Agente Cliente** — analisa risco com 5 critérios ponderados (score 0–100) | `agente_cliente.py` |
| 5 | **Orquestrador Watson Orchestrate X** — sequencia agentes, passa contexto e gera auditoria | `orquestrador.py` |
| 6 | **Motor de Decisão** — score consolidado ponderado (40 % carteira + 60 % cliente) | `motor_decisao.py` |
| 7 | Justificativa da decisão em linguagem natural acessível, sem jargão técnico | `motor_decisao.py` |
| 8 | Rastro auditável JSON por execução gravado em `auditoria_agentes/` | `orquestrador.py` |
| 9 | **Interface web em tempo real** com diagrama de fluxo animado via SSE | `app.py` + `static/index.html` |
| 10 | Bloqueio imediato de clientes negativados na entrada do Agente Carteira | `agente_carteira.py` |
| 11 | Sistema legado de análise em lote (200 clientes) com 9 regras ponderadas | `main.py` + `motor_regras.py` |
| 12 | Relatório agregado: distribuição, limites por faixa de renda, histograma de scores | `relatorio.py` |
| 13 | Histórico de decisões da sessão web (últimas 50 entradas) | `app.py` |
| 14 | Hook automático que atualiza `context.md` após cada interação do IBM Bob | `.bob/hooks/` |

---

## 🏗️ Arquitetura

### Sistema Multi-Agentes

```
┌──────────────────────────────────────────────────────────────┐
│                         ENTRADA                              │
│              id_cliente (CLI ou interface web)               │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                   gerador_pedido.py                          │
│   PedidoCredito ← CSV (clientes/renda/produtos) ou Faker     │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│         orquestrador.py  (Watson Orchestrate X)              │
│                                                              │
│  ┌─────────────────────┐   ContextoCarteira                  │
│  │   AgenteCarteira    │ ─────────────────────┐              │
│  │  · 5 linhas crédito │                      │              │
│  │  · score 0–100      │                      ▼              │
│  │  · bloqueia negados │    ┌──────────────────────────────┐ │
│  └─────────────────────┘    │       AgenteCliente          │ │
│                             │  · 5 critérios ponderados    │ │
│                             │  · score risco 0–100         │ │
│                             │  · bloqueio negativado/comp. │ │
│                             └──────────────┬───────────────┘ │
│                                            │ContextoCliente   │
│                                            ▼                  │
│                         ┌─────────────────────────────────┐  │
│                         │         MotorDecisao            │  │
│                         │  40% carteira + 60% cliente     │  │
│                         │  APROVADO / COM RESTRIÇÃO /     │  │
│                         │  NEGADO + limite BRL + texto    │  │
│                         └─────────────────────────────────┘  │
│                                                              │
│  RegistroAuditoria → auditoria_agentes/YYYYMMDD_EXECID.json │
└──────────────────────────────────────────────────────────────┘
```

### Camada Web em Tempo Real (SSE)

```
Browser                  app.py (Flask)             Agentes
   │                          │                        │
   │  GET /                   │                        │
   │ ────────────────────────►│                        │
   │  ◄─ static/index.html ───│                        │
   │                          │                        │
   │  GET /analisar?id=42     │                        │
   │ ────────────────────────►│                        │
   │                          │── OrquestradorSSE ────►│
   │  data: inicio_fluxo      │◄─ pedido_montado ──────│
   │ ◄────────────────────────│                        │
   │  data: carteira_fim      │◄─ carteira_fim ────────│
   │ ◄────────────────────────│                        │
   │  data: cliente_fim       │◄─ cliente_fim ─────────│
   │ ◄────────────────────────│                        │
   │  data: decisao_fim       │◄─ decisao_fim ─────────│
   │ ◄────────────────────────│                        │
   │  data: fim               │                        │
   │ ◄────────────────────────│                        │
```

### Diagrama Mermaid

```mermaid
flowchart TD
    A[id_cliente] --> B[gerador_pedido.py\nPedidoCredito]
    B --> C[orquestrador.py\nWatson Orchestrate X]
    C -->|Etapa 1| D[agente_carteira.py\nAgenteCarteira]
    D -->|ContextoCarteira| C
    C -->|Etapa 2| E[agente_cliente.py\nAgenteCliente]
    E -->|ContextoCliente| C
    C -->|Etapa 3| F[motor_decisao.py\nMotorDecisao]
    F -->|DecisaoFinal| C
    C --> G[auditoria_agentes/*.json]
    C --> H[SSE → browser]
```

---

## 🛠️ Stack Tecnológica

| Camada | Tecnologia | Versão verificada | Uso |
|---|---|---|---|
| Linguagem | Python | **3.14.7** | Todo o back-end |
| Framework web | Flask | **3.1.3** | Servidor HTTP + SSE |
| Dados sintéticos | Faker | **40.38.0** | Clientes fictícios em pt_BR |
| Manipulação de dados | pandas | **3.0.5** | Leitura dos CSVs, agrupamentos |
| Cálculos numéricos | NumPy | **2.5.3** | Histogramas, estatísticas |
| HTTP | requests | **2.34.2** | Dependência transitiva |
| Imagens | Pillow | **12.3.0** | Captura de evidências |
| Front-end | HTML5 + CSS3 + JS Vanilla | — | SPA com diagrama SVG animado |
| Comunicação em tempo real | Server-Sent Events (SSE) | — | Streaming do back-end para o browser |
| Persistência | JSON + CSV | — | Trilhas de auditoria e bases de dados |
| Logging | Python `logging` | stdlib | Logs em arquivo e console |
| Orquestração simulada | IBM Watson Orchestrate X | — | Padrão de design da orquestração |

---

## ✅ Pré-requisitos

- **Python 3.10 ou superior** (testado em 3.14.7)
- **pip** (gerenciador de pacotes Python)
- Sem banco de dados externo — tudo persiste em arquivos locais (CSV e JSON)
- Sem Docker obrigatório — aplicação roda nativamente

```bash
# Verificar versão instalada
python --version
# Python 3.14.7
```

---

## 🚀 Instalação e Configuração

### 1. Clone o repositório

```bash
git clone <url-do-repositorio>
cd bobathon
```

### 2. (Opcional) Crie um ambiente virtual

```bash
python -m venv .venv
source .venv/bin/activate       # Linux / macOS
.venv\Scripts\activate          # Windows
```

### 3. Instale as dependências

```bash
pip install flask pandas numpy faker
```

> Não existe `requirements.txt` ou `pyproject.toml`. As quatro dependências diretas
> estão listadas acima com suas versões verificadas na seção Stack Tecnológica.

### 4. Gere as bases de dados sintéticas

```bash
python main.py
```

Isso cria `clientes.csv`, `renda.csv` e `produtos.csv` com 200 registros sintéticos
e executa a análise em lote do sistema legado, imprimindo o relatório no terminal.

---

## ▶️ Como Executar

### Interface Web (modo principal)

```bash
python app.py
```

Acesse **http://localhost:5000** — o servidor Flask sobe na porta 5000.

Para rodar em segundo plano:

```bash
nohup python app.py >> app_web.log 2>&1 &
echo "Servidor PID: $!"
```

### CLI — analisar um cliente específico

```bash
# Cliente ID 3 — APROVADO, R$ 34.967,79 (Cartão Gold)
python main_agentes.py 3

# Cliente ID 1 — NEGADO (negativado, score 140)
python main_agentes.py 1

# Cliente ID 5 — APROVADO COM RESTRIÇÃO, R$ 5.734,30
python main_agentes.py 5

# Cliente aleatório dos CSVs
python main_agentes.py
```

### Sistema legado — análise em lote

```bash
python main.py
```

Processa todos os 200 clientes e imprime relatório com distribuição de decisões,
limites médios por faixa de renda e histograma de scores no terminal.

---

## 🌐 Endpoints da API

| Método | Rota | Descrição | Parâmetros |
|---|---|---|---|
| `GET` | `/` | Serve a página web (`static/index.html`) | — |
| `GET` | `/analisar` | Stream SSE com eventos em tempo real | `?id=<int>` obrigatório |
| `GET` | `/historico` | Últimas 50 decisões da sessão (JSON) | — |
| `GET` | `/clientes_disponiveis` | Lista de IDs disponíveis nos CSVs | — |

### Eventos SSE emitidos por `/analisar?id=<int>`

A rota emite 10 eventos em sequência, um por etapa do fluxo:

| Evento | Quando | Payload principal |
|---|---|---|
| `inicio_fluxo` | Pedido iniciado | `id_execucao`, `id_cliente`, `timestamp` |
| `pedido_montado` | PedidoCredito montado | objeto `pedido` completo |
| `carteira_inicio` | Agente Carteira acionado | mensagem de status |
| `carteira_fim` | Agente Carteira concluído | `ContextoCarteira` + `duracao_ms` |
| `cliente_inicio` | Agente Cliente acionado | mensagem de status |
| `cliente_fim` | Agente Cliente concluído | `ContextoCliente` + `duracao_ms` |
| `decisao_inicio` | Motor de Decisão acionado | mensagem de status |
| `decisao_fim` | Decisão produzida | `DecisaoFinal` + `duracao_ms` |
| `auditoria` | JSON de auditoria salvo | `caminho`, `duracao_total_ms` |
| `fim` | Fluxo encerrado | `id_execucao` |

#### Exemplo de stream SSE para cliente 3

```
data: {"evento": "inicio_fluxo",    "dados": {"id_execucao": "5270EB02", "id_cliente": 3, "timestamp": "10/09/2026 15:23:17"}}

data: {"evento": "pedido_montado",  "dados": {"id_execucao": "5270EB02", "pedido": {"nome": "Ana Beatriz Alves", "score_bureau": 567, ...}}}

data: {"evento": "carteira_inicio", "dados": {"mensagem": "Agente Carteira iniciando avaliação..."}}

data: {"evento": "carteira_fim",    "dados": {"duracao_ms": 0.15, "dados": {"score_interno_carteira": 55.68, "linhas_disponiveis": [...], "elegivel": true}}}

data: {"evento": "cliente_inicio",  "dados": {"mensagem": "Agente Cliente iniciando análise (3 linhas da carteira)..."}}

data: {"evento": "cliente_fim",     "dados": {"duracao_ms": 0.10, "dados": {"score_risco_cliente": 76.51, "nivel_risco": "BAIXO", "bloqueio": false}}}

data: {"evento": "decisao_inicio",  "dados": {"mensagem": "Motor de Decisão consolidando resultado..."}}

data: {"evento": "decisao_fim",     "dados": {"duracao_ms": 0.11, "dados": {"decisao": "APROVADO", "limite_aprovado": 34967.79, "linha_credito_selecionada": "Cartão Gold", "score_consolidado": 68.18}}}

data: {"evento": "auditoria",       "dados": {"caminho": "auditoria_agentes/20260910_152317_5270EB02_cliente3.json", "duracao_total_ms": 12.79}}

data: {"evento": "fim",             "dados": {"id_execucao": "5270EB02"}}
```

#### Exemplo de resposta `/historico`

```json
[
  {
    "id_execucao": "5270EB02",
    "id_cliente": 3,
    "nome": "Ana Beatriz Alves",
    "decisao": "APROVADO",
    "limite": 34967.79,
    "timestamp": "10/09/2026 15:23:17"
  },
  {
    "id_execucao": "EEBE3785",
    "id_cliente": 1,
    "nome": "Brenda Alves",
    "decisao": "NEGADO",
    "limite": null,
    "timestamp": "10/09/2026 15:22:55"
  }
]
```

#### Exemplo de resposta `/clientes_disponiveis`

```json
{ "ids": [1, 2, 3, 4, 5, "...", 200], "total": 200 }
```

---

## 🤖 Lógica dos Agentes

### Agente Carteira (`agente_carteira.py`) — v1.0.0

Avalia **5 linhas de crédito** com base em dois critérios: score bureau mínimo e
tipo de renda obrigatório. Clientes negativados são bloqueados imediatamente, antes
mesmo do loop de elegibilidade.

| Linha | Tipo | Score mín. | Multiplicador | Tipo de renda exigido |
|---|---|---|---|---|
| Cartão Básico | cartao | 0 | 0,5× renda | Qualquer |
| Cartão Gold | cartao | 500 | 1,5× renda | Qualquer |
| Cartão Platinum | cartao | 750 | 3,0× renda | Qualquer |
| Crédito Consignado | outro | 300 | 2,0× renda | CLT / Servidor Público / Aposentado |
| Crédito Pessoal Flex | outro | 400 | 1,0× renda | Autônomo / Empresário |

> **Score interno de carteira (0–100):**
> `pts_linhas (30) + pts_bureau normalizado (40) + pts_multiplicador (30)`

### Agente Cliente (`agente_cliente.py`) — v1.0.0

Analisa o perfil de risco com **5 critérios ponderados** (total máximo: 100 pts).

| Critério | Peso máx. | Bloqueante |
|---|---|---|
| Score bureau | 30 pts | Não |
| Comprometimento de renda | 20 pts | **Sim** se > 70 % |
| Inadimplência histórica em produtos | 20 pts | Não |
| Estabilidade de emprego | 15 pts | Não |
| Tipo de renda | 15 pts | Não |

Bônus: **+5 pts** se relacionamento ≥ 24 meses.
Penalidade: **−8 pts** se divergência declarado/comprovado > 30 %.
Bloqueio adicional: **negativado = True** retorna score 0 e nível BLOQUEADO.

| Score | Nível de risco |
|---|---|
| ≥ 75 | BAIXO |
| ≥ 50 | MÉDIO |
| < 50 | ALTO |
| Qualquer bloqueio | BLOQUEADO |

### Motor de Decisão (`motor_decisao.py`) — v2.0.0-multiagente

```
Score consolidado = 40% × score_carteira + 60% × score_cliente
```

| Score consolidado | Decisão | Limite aprovado |
|---|---|---|
| ≥ 80 | **APROVADO** | 3× renda comprovada |
| 60–79 | **APROVADO** | 2× renda comprovada |
| 40–59 | **APROVADO COM RESTRIÇÃO** | 1× renda comprovada |
| < 40 | **NEGADO** | — |

---

## 📊 Resultados Reais (base de 200 clientes)

```
DISTRIBUIÇÃO DE DECISÕES
──────────────────────────────────────────────
APROVADO                          80   (40,0%)
APROVADO COM RESTRIÇÃO            43   (21,5%)
NEGADO                            77   (38,5%)

PRINCIPAIS FATORES DE NEGAÇÃO
──────────────────────────────────────────────
Comprometimento de renda               54 ocorrências
Score bureau                           50 ocorrências
Negativação em bureau                  33 ocorrências
```

---

## 🧪 Testes

### Validação rápida dos três agentes individualmente

```bash
python -c "
from gerador_pedido import montar_pedido
from agente_carteira import AgenteCarteira
from agente_cliente import AgenteCliente
from motor_decisao import MotorDecisao

pedido   = montar_pedido(3)
ctx_cart = AgenteCarteira().avaliar(pedido)
ctx_cli  = AgenteCliente().analisar(pedido, ctx_cart)
dec      = MotorDecisao().decidir(pedido, ctx_cart, ctx_cli)

assert dec.decisao == 'APROVADO'
assert dec.score_consolidado == 68.18
assert dec.limite_aprovado == 34967.79
print('✅ Cliente 3 — APROVADO, R\$ 34.967,79')
"
```

### Verificar bloqueio de cliente negativado

```bash
python -c "
from gerador_pedido import montar_pedido
from agente_carteira import AgenteCarteira

pedido = montar_pedido(1)          # negativado=True, score=140
ctx    = AgenteCarteira().avaliar(pedido)

assert ctx.elegivel == False
assert len(ctx.linhas_disponiveis) == 0
print('✅ Cliente negativado — zero linhas de crédito disponíveis')
"
```

### Testar endpoints do servidor

```bash
# Servidor no ar
curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/
# Esperado: 200

# Stream SSE completo para cliente 3
curl -s --max-time 5 "http://localhost:5000/analisar?id=3"

# Histórico da sessão
curl -s http://localhost:5000/historico | python -m json.tool

# IDs disponíveis
curl -s http://localhost:5000/clientes_disponiveis | python -m json.tool
```

### Casos de teste verificados

| ID | Perfil | Decisão esperada | Resultado confirmado |
|---|---|---|---|
| 1 | Negativado, score 140 | NEGADO | ✅ |
| 3 | Score 567, renda R$ 23.311,86 | APROVADO — R$ 34.967,79 | ✅ |
| 5 | Score 450, renda moderada | APROVADO COM RESTRIÇÃO — R$ 5.734,30 | ✅ |

### Evidências capturadas

A pasta `evidencias/` contém 6 screenshots da interface web em sequência:

```
evidencias/
├── screenshot-2026-09-10_15-43-52.png  ← Tela inicial aguardando
├── screenshot-2026-09-10_15-44-05.png  ← Fluxo iniciado (nó Orquestrador ativo)
├── screenshot-2026-09-10_15-44-13.png  ← Agente Carteira concluído
├── screenshot-2026-09-10_15-44-33.png  ← Agente Cliente concluído
├── screenshot-2026-09-10_15-44-43.png  ← Decisão final — APROVADO
└── screenshot-2026-09-10_15-44-57.png  ← Histórico da sessão
```

---

## 📁 Estrutura do Projeto

```
bobathon/
│
├── README.md                       ← Este arquivo
│
├── ── Sistema Multi-Agentes (principal) ──────────────────────────
│   ├── gerador_pedido.py           PedidoCredito: lê CSVs ou gera via Faker
│   ├── agente_carteira.py          Avalia 5 linhas de crédito (AgenteCarteira)
│   ├── agente_cliente.py           Analisa risco e capacidade (AgenteCliente)
│   ├── motor_decisao.py            Consolida e decide (MotorDecisao v2.0.0)
│   ├── orquestrador.py             Sequencia agentes e registra auditoria
│   └── main_agentes.py             CLI: python main_agentes.py [id_cliente]
│
├── ── Interface Web ───────────────────────────────────────────────
│   ├── app.py                      Flask: rotas HTTP + stream SSE
│   └── static/
│       └── index.html              SPA: diagrama SVG animado, painéis, histórico
│
├── ── Sistema Legado (batch) ──────────────────────────────────────
│   ├── gerador_dados.py            Gera clientes.csv, renda.csv, produtos.csv
│   ├── analisador_credito.py       Lê CSVs, consolida perfil, aciona motor
│   ├── motor_regras.py             9 regras ponderadas, score 0–100 (v1.0.0)
│   ├── relatorio.py                Distribuição, histograma, fatores de negação
│   └── main.py                     CLI: python main.py (200 clientes em lote)
│
├── ── Dados e Saídas ──────────────────────────────────────────────
│   ├── clientes.csv                200 clientes sintéticos (Faker pt_BR)
│   ├── renda.csv                   Tipo e valores de renda por cliente
│   ├── produtos.csv                1–5 produtos bancários por cliente
│   ├── auditoria_decisoes.json     Trilha batch do sistema legado
│   └── auditoria_agentes/          Uma entrada JSON por execução multi-agentes
│       └── YYYYMMDD_HHMMSS_EXECID_clienteN.json
│
├── ── Logs ────────────────────────────────────────────────────────
│   ├── sistema_credito.log         Sistema legado
│   ├── sistema_multiagentes.log    CLI multi-agentes
│   └── app_web.log                 Servidor Flask
│
├── ── Evidências e Documentação ───────────────────────────────────
│   └── evidencias/                 Screenshots da interface e exportações JSON
│
└── ── Configuração IBM Bob ────────────────────────────────────────
    ├── .bob/settings.json          Hook Stop: atualiza context.md automaticamente
    ├── .bob/hooks/
    │   └── atualizar-context.mjs   Script Node.js do hook de sessão
    ├── context.md                  Histórico de interações (auto-atualizado)
    └── plano-multi-agentes.md      Plano de implementação (todas as tarefas concluídas)
```

---

## 🔔 Como o IBM Bob e o IBM Watson Orchestrate X foram usados

### IBM Bob (assistente de codificação)

Todo o código desta aplicação foi produzido em sessão de pair programming com o **IBM Bob**,
diretamente no editor. O Bob foi usado para:

| Modo | O que foi feito |
|---|---|
| **Plan** | Planejamento da arquitetura multi-agentes; definição dos agentes, contratos de dados e ordem de execução |
| **Agent** | Geração de todos os 12 módulos Python e da SPA; aplicação de correções cirúrgicas com `apply_diff` |
| **Ask** | Análise do comportamento do Cartão Básico para clientes negativados; diagnóstico da separação de responsabilidades |

O hook [`Stop`](.bob/settings.json) executa [`.bob/hooks/atualizar-context.mjs`](.bob/hooks/atualizar-context.mjs)
após cada resposta, gravando timestamp, ID de sessão e prévia da resposta em [`context.md`](context.md).

### IBM Watson Orchestrate X (padrão de orquestração)

O módulo [`orquestrador.py`](orquestrador.py) implementa o padrão do **IBM Watson Orchestrate X**:

- **Sequenciamento declarativo** — ordem explícita: Carteira → Cliente → Decisão
- **Passagem de contexto** — output de um agente injetado como input do próximo
- **Separação de responsabilidades** — cada agente é independente, sem estado compartilhado
- **Rastreabilidade** — cada etapa registra timestamp, duração em ms e status
- **Trilha auditável** — JSON completo por execução com todos os inputs/outputs

Os logs marcados com `[ORCHESTRATE]` simulam o prefixo de rastreamento do produto:

```
10/09/2026 15:23:17 [ORCHESTRATE] Execução 5270EB02 | Cliente 3 | Versão: 1.0.0
10/09/2026 15:23:17 [ORCHESTRATE] [Etapa 1/3] Acionando Agente Carteira...
10/09/2026 15:23:17 [Agente Carteira] Avaliação concluída — 3 linha(s), score: 55.7
10/09/2026 15:23:17 [ORCHESTRATE] [Etapa 2/3] Acionando Agente Cliente...
10/09/2026 15:23:17 [Agente Cliente] Análise concluída — score risco: 76.5, nível: BAIXO
10/09/2026 15:23:17 [ORCHESTRATE] [Etapa 3/3] Acionando Motor de Decisão...
10/09/2026 15:23:17 [Motor de Decisão] Decisão: APROVADO | Score: 68.2 | Limite: R$ 34.967,79
10/09/2026 15:23:17 [ORCHESTRATE] Execução 5270EB02 finalizada em 12,79 ms.
```

---

## ⚙️ Variáveis de Ambiente

Esta aplicação **não requer variáveis de ambiente**. Toda configuração é feita
por constantes nos módulos Python.

| Parâmetro | Onde configurar | Valor padrão | Obrigatório |
|---|---|---|---|
| Porta HTTP | `app.py` linha 246 | `5000` | Não |
| Host HTTP | `app.py` linha 246 | `0.0.0.0` | Não |
| Nº de clientes gerados | `main.py` linha 37 | `200` | Não |
| Diretório de auditoria | `orquestrador.py` linha 30 | `auditoria_agentes/` | Não |
| Versão do motor de decisão | `motor_decisao.py` linha 27 | `2.0.0-multiagente` | Não |
| Versão do orquestrador | `orquestrador.py` linha 31 | `1.0.0` | Não |

---

## 🤝 Contribuição

### Convenção de commits

```
tipo(escopo): descrição curta em português

feat(agente): adiciona critério de análise de endividamento total
fix(carteira): corrige elegibilidade para score bureau zero
docs(readme): atualiza exemplos com resultados verificados
test(motor): valida score consolidado para perfil intermediário
refactor(orq): extrai serialização para método helper
```

**Tipos:** `feat` · `fix` · `docs` · `test` · `refactor` · `chore`

### Fluxo de branches

```
main                    ← produção, sempre estável e testada
  └── feat/<nome>       ← nova funcionalidade ou agente
  └── fix/<nome>        ← correção de comportamento incorreto
  └── docs/<nome>       ← documentação e evidências
```

### Para contribuir

```bash
# 1. Fork e clone
git clone <url-do-seu-fork>
cd bobathon

# 2. Instale as dependências
pip install flask pandas numpy faker

# 3. Crie uma branch
git checkout -b feat/minha-feature

# 4. Implemente e valide localmente
python main_agentes.py 3    # deve retornar APROVADO
python main_agentes.py 1    # deve retornar NEGADO

# 5. Commit e push
git add .
git commit -m "feat(agente): descrição clara da mudança"
git push origin feat/minha-feature

# 6. Abra um Pull Request descrevendo a mudança e o comportamento esperado
```

### Adicionando um novo agente

1. Crie `agente_<nome>.py` com dataclass de contexto de saída e classe `Agente<Nome>`
2. Registre a nova etapa em [`orquestrador.py`](orquestrador.py) dentro de `processar()`
3. Adicione emissão dos eventos SSE correspondentes em [`app.py`](app.py) em `OrquestradorSSE.processar()`
4. Atualize o diagrama SVG em [`static/index.html`](static/index.html)
5. Documente os critérios e pesos do novo agente neste README

---

## 📜 Licença

Este projeto está licenciado sob a **MIT License**.

```
MIT License — Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS",
WITHOUT WARRANTY OF ANY KIND.
```

---

<div align="center">
  <sub>Desenvolvido com <strong>IBM Bob</strong> · Arquitetura inspirada no <strong>IBM Watson Orchestrate X</strong></sub>
</div>
